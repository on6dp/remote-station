'use strict';
/*
 * Remote Station — serveur VPS
 * Relie la page "Station" (au club, FTX-1 en Web Serial) aux opérateurs (navigateur).
 * Aucune dépendance externe : modules Node natifs uniquement.
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const ws = require('./lib/ws-lite');
const auth = require('./lib/auth');
const ULAW = require('./public/js/ulaw.js');
// Pilotes de radio disponibles (le modèle est annoncé par la page Station)
const DRIVERS = {
  ftx1: require('./public/js/ftx1.js'),
  ftdx10: require('./public/js/ftdx10.js'),
  ftdx101: require('./public/js/ftdx101.js'),
  ftdx5000: require('./public/js/ftdx5000.js'),
  ic7300: require('./public/js/ic7300.js'),
  ic7760: require('./public/js/ic7760.js')
};
const DEFAULT_RIG = DRIVERS.ftx1;
const rig = () => (station && station.rig) || DEFAULT_RIG;
// Vitesse CW la plus haute du manipulateur du TRX (Yaesu : 60, IC-7300 : 48 mots/min)
const cwWpmMax = () => (rig().CW && rig().CW.wpmMax) || 50;

// ---------------------------------------------------------------- configuration
const ROOT = __dirname;
const CFG_PATH = process.env.RS_CONFIG || path.join(ROOT, 'config.json');
const DEFAULTS = {
  listen: '127.0.0.1',
  port: 9000,
  clubName: 'Remote Station',
  stationCall: 'OP0P',
  stationToken: '',
  allowTx: false,
  maxTxSeconds: 120,
  // Phonie à distance : voix de l'opérateur (micro du navigateur) envoyée à l'entrée USB du TRX. false : PTT seul (micro du club).
  remoteVoice: true,
  // FTX-1 : passage MAIN / SUB par CAT (VS seul, selon le manuel CAT). false pour le bloquer (face avant seulement).
  ftx1SubCat: true,
  // Tuner (boîte d'accord) remis en service tout seul à la connexion du TRX et à chaque changement de bande HF / 6 m,
  // pour ne pas l'oublier ; un clic sur TUNER le coupe jusqu'au prochain changement de bande. false : jamais tout seul.
  tunerAuto: true,
  // FTX-1 : passage MAIN ↔ SUB par le dashboard en réception simple (DUAL RX coupé). Refusé par défaut : le 24/10 puis
  // le 25/10 (deux VFO en HF), un clic sur le VFO B en réception simple a mis le TRX en émission (VS1 seul).
  // true : autorisé (essais au club, en surveillant le TRX).
  ftx1SubSingle: false,
  // DX cluster pour la carte de bande (spots à droite de la cascade). clusterHost vide = pas de cluster.
  // clusterCall : indicatif de connexion (avec un SSID, ex. ON5VL-7) ; vide = digiCall suivi de -7.
  // clusterCmds : commandes envoyées après la connexion (set/skimmer = spots du Reverse Beacon Network sur CC-Cluster).
  // Page Station : seuls ces indicatifs (connectés à la page Station avec leur indicatif et leur mot de passe
  // d'administrateur) peuvent modifier le jeton, la vitesse et les bits de stop ; pour les autres, ces champs sont verrouillés
  stationEditors: ['ON6DP', 'ON4LUC'],
  // Sites de DX cluster autorisés à envoyer un spot au dashboard (clic sur un spot → le TRX s'y cale)
  qsyOrigins: ['https://dx.op0p.be', 'http://dx.op0p.be', 'https://cluster.op0p.be', 'http://cluster.op0p.be'],
  clusterHost: 'op0p.be',
  clusterPort: 8000,
  clusterCall: '',
  // clusterSpot : false = aucun spot envoyé au cluster (instance de test, deploy/install-test.sh)
  clusterSpot: true,
  clusterCmds: ['set/skimmer'],
  digiAlcMax: 10, // émission numérique : ALC maximal (% de la zone ALC du TRX) au-delà duquel la page Station baisse le niveau BF ; 0 = pas de limite
  ftxWatchdogMinutes: 6, // émission auto FT8 / FT4 / FT2 : arrêt si le même message part depuis ce temps (WSJT-X : 6 min)
  pttHeartbeatMs: 1500,
  controlIdleMinutes: 15,
  // Équité : quand un autre membre a demandé la main (« Demander la main », valable controlAskMinutes) et que l'opérateur
  // l'a depuis controlMaxMinutes, il est prévenu ; la main passe au demandeur controlWarnSeconds plus tard (jamais pendant
  // une émission : à la fin de celle-ci). 0 = pas de limite.
  controlMaxMinutes: 45,
  controlWarnSeconds: 120,
  controlAskMinutes: 15,
  // Protection du PA : émission coupée si le ROS dépasse maxSwr pendant swrHoldMs (0 = pas de protection).
  // Le PTT reste ensuite refusé sur cette fréquence (±25 kHz) jusqu'à un accord (TUNE).
  // Chien de garde de la page Station : retour en réception si le TRX émet sans modulation pendant txSilenceSeconds,
  // ou sans interruption pendant txHardMaxSeconds (PTT ou micro bloqué au club…)
  txSilenceSeconds: 120,
  txHardMaxSeconds: 300,
  // Émission SSTV : durée maximale d'une image (s). Plafonnée à txHardMaxSeconds − 5 (chien de garde de la page Station).
  // 300 permet tous les modes jusqu'à PD 290 si txHardMaxSeconds le permet ; plus bas pour ménager le PA (100 % du temps en émission).
  maxSstvSeconds: 300,
  maxSwr: 2.5,
  swrHoldMs: 700,
  // Déconnexion automatique d'un membre resté inactif (0 = jamais). Jamais pendant une émission.
  sessionIdleMinutes: 15,
  // Indicatifs jamais déconnectés pour inactivité (seulement par « Déconnexion ») ; la main reste libérée après controlIdleMinutes
  idleExempt: ['ON6DP', 'ON4LUC', 'ON5VL'],
  // Statistiques d'utilisation (page /stats, administrateurs) : fuseau horaire des jours et heures
  stationTz: 'Europe/Brussels',
  // Modes numériques : indicatif émis (FT8, FT4, RTTY, CW) et locator de la station (messages CQ)
  digiCall: 'ON5VL',
  // Indicatifs du club proposés dans « TX call » (émissions numériques, CW, SSTV, carnet), en plus de digiCall et stationCall
  clubCalls: ['ON5VL', 'OR0L'],
  stationGrid: '',
  stationQth: 'LIEGE',
  // QO-100 : fréquence de la FI (MHz) qui correspond à 2400,000 MHz pour chaque convertisseur 2,4 GHz
  // (432,5 = OL 1967,5 MHz, ex. DXpatrol ; mettre 432 pour un OL 1968 MHz ; 0 = pas de convertisseur sur cette bande)
  qo100If: { '2m': 144.5, '70cm': 432.5, '23cm': 1296.5 },
  // Un membre reste connecté quand il actualise la page ou revient plus tard (sur le même navigateur),
  // jusqu'à rememberDays jours après sa dernière visite (0 = mot de passe à chaque fois). « Déconnexion » l'oublie.
  rememberDays: 7,
  usersFile: 'users.json',
  logDir: 'logs',
  txRanges: [],
  // Seuls ces préfixes peuvent se connecter
  allowedPrefixes: ['ON', 'OO', 'OP', 'OQ', 'OR', 'OS', 'OT'],
  allowedCalls: [], // exceptions : indicatifs étrangers admis nommément (node adduser.js F4ABC --exception)
  // Puissance maximale par début d'indicatif (première règle qui correspond), sinon defaultMaxWatts
  powerRules: [{ prefix: 'ON2', maxWatts: 100 }, { prefix: 'ON3', maxWatts: 25 }],
  // Bandes permises en émission par début d'indicatif (licence de base ON3) ; les autres préfixes : toutes les bandes de txRanges
  licenceBands: { ON3: ['80m', '40m', '30m', '20m', '15m', '10m', '2m', '70cm'] },
  defaultMaxWatts: 1500,
  // Indicatifs qui ne peuvent jamais émettre (écouteurs ONL), quel que soit leur compte
  rxOnlyPrefixes: ['ONL']
};
let cfg;
try {
  cfg = Object.assign({}, DEFAULTS, JSON.parse(fs.readFileSync(CFG_PATH, 'utf8')));
} catch (e) {
  console.error('Impossible de lire ' + CFG_PATH + ' : ' + e.message);
  console.error('Lancez d’abord : node init-config.js');
  process.exit(1);
}
if (!cfg.stationToken || cfg.stationToken.length < 24) {
  console.error('stationToken absent ou trop court (24 caractères minimum) dans ' + CFG_PATH);
  process.exit(1);
}
const USERS_FILE = path.resolve(ROOT, cfg.usersFile);
const LOG_DIR = path.resolve(ROOT, cfg.logDir);
fs.mkdirSync(LOG_DIR, { recursive: true });
// Réglages d'émission numérique changés par un administrateur depuis la page FT (limite d'ALC) : gardés ici, pas dans config.json
const TXSET_FILE = path.join(LOG_DIR, 'station-tx.json');
try { const t = JSON.parse(fs.readFileSync(TXSET_FILE, 'utf8')); if (Number.isFinite(t.alcMax)) cfg.digiAlcMax = t.alcMax; } catch (e) { /* réglage de config.json */ }
const ALC_CHOICES = [0, 5, 10, 15, 20, 25, 30, 40, 50, 70, 100];

// ---------------------------------------------------------------- journal des accès
// Événements visibles par les membres connectés (sans adresse IP)
const PUBLIC_EVENTS = ['login', 'logout', 'control_take', 'control_release', 'tx_start', 'tx_stop', 'tune', 'power_limit', 'rig_switch', 'swr_cut', 'tune_fail', 'tx_watchdog',
  'station_online', 'station_offline', 'trx_online', 'trx_offline'];
const recentEvents = [];
// ---------------------------------------------------------------- WSPR : qui a entendu une balise ? (base publique wspr.live = spots de WSPRnet)
// Requête HTTP en lecture seule (https://db1.wspr.live/?query=…), 20 par minute au plus pour tout le monde : cache de 90 s et
// 10 requêtes par minute au plus depuis ce serveur. Indicatif limité à [A-Z0-9/], durée et bande choisies dans une liste.
const WSH = { cache: new Map(), times: [] };
const WSH_BANDS = { '160m': [1.8e6, 2.0e6], '80m': [3.5e6, 4.0e6], '60m': [5.25e6, 5.45e6], '40m': [7.0e6, 7.3e6], '30m': [10.1e6, 10.15e6], '20m': [14.0e6, 14.35e6],
  '17m': [18.068e6, 18.168e6], '15m': [21.0e6, 21.45e6], '12m': [24.89e6, 24.99e6], '10m': [28.0e6, 29.7e6], '6m': [50e6, 54e6], '2m': [144e6, 148e6], '70cm': [430e6, 440e6] };
async function wsprHeard(conn, m) {
  const call = String(m.call || '').toUpperCase().trim();
  const hours = [1, 6, 24, 168].indexOf(Number(m.hours)) >= 0 ? Number(m.hours) : 24;
  const band = WSH_BANDS[m.band] ? m.band : '';
  const dir = m.dir === 'rx' ? 'rx' : 'tx'; // tx : qui a entendu cet indicatif ; rx : ce que cet indicatif a entendu (s'il envoie à WSPRnet)
  const reply = (o) => send(conn, Object.assign({ t: 'wspr_heard', call, hours, band, dir }, o));
  if (!/^[A-Z0-9/]{3,15}$/.test(call)) return reply({ error: 'Indicatif invalide' });
  const key = dir + '|' + call + '|' + hours + '|' + band;
  const c = WSH.cache.get(key);
  if (c && Date.now() - c.at < 90000) return reply({ rows: c.rows, at: c.at });
  WSH.times = WSH.times.filter((t) => Date.now() - t < 60000);
  if (WSH.times.length >= 10) return reply({ error: 'Trop de demandes vers wspr.live : réessayez dans une minute', rows: c ? c.rows : null, at: c ? c.at : 0 });
  WSH.times.push(Date.now());
  const who = dir === 'tx' ? 'tx_sign' : 'rx_sign';
  const fr = band ? ' AND frequency BETWEEN ' + WSH_BANDS[band][0] + ' AND ' + WSH_BANDS[band][1] : '';
  const q = 'SELECT time, frequency, rx_sign, rx_loc, tx_sign, tx_loc, distance, snr, power, drift FROM wspr.rx WHERE time > now() - INTERVAL ' + hours + ' HOUR AND ' +
    who + " = '" + call + "'" + fr + ' ORDER BY time DESC LIMIT 2000 FORMAT JSONCompact';
  try {
    const r = await fetch((process.env.RS_WSPRLIVE || 'https://db1.wspr.live/') + '?query=' + encodeURIComponent(q), { signal: AbortSignal.timeout(20000) });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const j = await r.json();
    const rows = (Array.isArray(j.data) ? j.data : []).map((x) => [String(x[0]), Number(x[1]), String(x[2]), String(x[3]), String(x[4]), String(x[5]), Number(x[6]), Number(x[7]), Number(x[8]), Number(x[9])]);
    WSH.cache.set(key, { at: Date.now(), rows });
    if (WSH.cache.size > 50) WSH.cache.delete(WSH.cache.keys().next().value);
    return reply({ rows, at: Date.now() });
  } catch (e) {
    return reply({ error: 'wspr.live injoignable (' + String(e.message || e).slice(0, 80) + ')', rows: c ? c.rows : null, at: c ? c.at : 0 });
  }
}
function journal(ev, data) {
  const d = new Date();
  const line = JSON.stringify(Object.assign({ ts: d.toISOString(), ev }, data)) + '\n';
  if (PUBLIC_EVENTS.indexOf(ev) >= 0) {
    const e = Object.assign({ ts: d.toISOString(), ev }, data);
    delete e.ip;
    recentEvents.unshift(e);
    if (recentEvents.length > 40) recentEvents.pop();
    if (typeof ops !== 'undefined') {
      const msg = JSON.stringify({ t: 'event', e });
      for (const c of ops) if (c.open) c.send(msg);
    }
  }
  const f = path.join(LOG_DIR, 'access-' + d.toISOString().slice(0, 7) + '.log');
  fs.appendFile(f, line, () => {});
  console.log('[' + ev + ']', JSON.stringify(data));
}

// ---------------------------------------------------------------- HTTP statique
const PUB = path.join(ROOT, 'public');
const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.webp': 'image/webp',
  '.jpg': 'image/jpeg',
  '.ico': 'image/x-icon',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json',
  '.zip': 'application/zip'
};
function qsyOrigins() {
  return (Array.isArray(cfg.qsyOrigins) ? cfg.qsyOrigins : DEFAULTS.qsyOrigins).map(String).filter((o) => /^https?:\/\/[a-z0-9.-]+(:\d+)?$/i.test(o));
}
const ROUTES = { '/': '/index.html', '/ftdx101': '/face.html', '/station': '/station.html', '/digi': '/digi.html', '/ftdx101/digi.html': '/digi.html', '/ftdx101/log.html': '/log.html', '/ftdx101/digi': '/digi.html', '/ftdx101/': '/face.html', '/ftdx10': '/face.html', '/ftdx10/': '/face.html', '/ftdx10/digi.html': '/digi.html', '/ftdx10/digi': '/digi.html', '/ftdx10/log.html': '/log.html', '/ic7300': '/face.html', '/ic7300/': '/face.html', '/ic7300/digi.html': '/digi.html', '/ic7300/digi': '/digi.html', '/ic7300/log.html': '/log.html', '/ftx1': '/face.html', '/ftx1/': '/face.html', '/ftx1/digi.html': '/digi.html', '/ftx1/digi': '/digi.html', '/ftx1/log.html': '/log.html', '/ftdx5000': '/face.html', '/ftdx5000/': '/face.html', '/ftdx5000/digi.html': '/digi.html', '/ftdx5000/digi': '/digi.html', '/ftdx5000/log.html': '/log.html', '/aide': '/aide.html', '/help': '/help.html', '/stats': '/stats.html', '/prop': '/prop.html', '/detache': '/detache.html', '/cw': '/cw.html', '/ssb': '/ssb.html', '/ic7760': '/face.html', '/ic7760/': '/face.html', '/ic7760/digi.html': '/digi.html', '/ic7760/digi': '/digi.html', '/ic7760/log.html': '/log.html' };

function sendJson(res, code, obj) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(obj));
}

// HTTPS direct (serveur Windows sans nginx) : "tls": { "cert": "cert.pem", "key": "key.pem" } dans config.json
function makeServer(handler) {
  const t = cfg.tls;
  if (t && t.cert && t.key) {
    try {
      return require('https').createServer({ cert: fs.readFileSync(path.resolve(ROOT, t.cert)), key: fs.readFileSync(path.resolve(ROOT, t.key)) }, handler);
    } catch (e) {
      console.error('Certificat TLS illisible (' + e.message + ') : serveur en HTTP');
    }
  }
  return http.createServer(handler);
}
const server = makeServer((req, res) => {
  let p;
  try {
    p = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  } catch (e) {
    res.writeHead(400);
    return res.end();
  }
  if (req.method === 'POST' && p === '/station/login') return stationLoginPost(req, res);
  if (req.method === 'POST' && p === '/station/logout') return stationLogout(req, res);
  if (req.method === 'POST' && p === '/station/token') return stationTokenPost(req, res);
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.writeHead(405);
    return res.end();
  }
  if (p === '/station/token') {
    // Jeton de la station donné à la page Station d'un navigateur déjà connecté comme administrateur (cookie de la page
    // Station) : plus besoin de le recopier sur chaque PC, et un nouveau jeton (config.json) est repris tout seul.
    const a = stationAdmin(req);
    const site = String(req.headers['sec-fetch-site'] || 'same-origin');
    if (!a || (site !== 'same-origin' && site !== 'none')) return sendJson(res, 401, {});
    return sendJson(res, 200, { token: String(cfg.stationToken || '') });
  }
  if (p === '/station/whoami') {
    const a = stationAdmin(req);
    // edit : peut modifier le jeton, la vitesse et les bits de stop de la page Station (stationEditors)
    const eds = (Array.isArray(cfg.stationEditors) ? cfg.stationEditors : DEFAULTS.stationEditors).map((c) => String(c).toUpperCase());
    return sendJson(res, a ? 200 : 401, a ? Object.assign({ edit: eds.indexOf(String(a.call).toUpperCase()) >= 0 }, a) : {});
  }
  if (p === '/api/info') {
    return sendJson(res, 200, {
      clubName: cfg.clubName,
      stationCall: cfg.stationCall,
      allowTx: cfg.allowTx,
      maxTxSeconds: cfg.maxTxSeconds,
      txRanges: cfg.txRanges,
      qsyOrigins: qsyOrigins(),
      version: VERSION
    });
  }
  // Agent LoTW : programme et script d'installation Linux (publics : aucun secret dedans)
  if (p === '/agent/agent-lotw.js' || p === '/agent/install-agent-lotw.sh') {
    return fs.readFile(path.join(ROOT, 'agent', path.basename(p)), (err, data) => {
      if (err) { res.writeHead(404); return res.end(); }
      res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff', 'Content-Disposition': 'inline; filename="' + path.basename(p) + '"' });
      res.end(req.method === 'HEAD' ? undefined : data);
    });
  }
  p = ROUTES[p] || p;
  const fp = path.normalize(path.join(PUB, p));
  if (!fp.startsWith(PUB + path.sep) || /[:\0]/.test(path.relative(PUB, fp))) {
    res.writeHead(404);
    return res.end();
  }
  const key = pubKey(fp);
  if (key === 'station-login.html') { res.writeHead(404); return res.end(); }
  if (ST_GATED.indexOf(key) >= 0 && !stationAdmin(req)) {
    if (key === 'station.html') return sendStationLogin(res, '');
    res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' });
    return res.end('Réservé aux administrateurs');
  }
  fs.readFile(fp, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('Introuvable');
    }
    const hd = {
      'Content-Type': TYPES[path.extname(fp)] || 'application/octet-stream',
      'Cache-Control': 'no-cache',
      'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'no-referrer'
    };
    // Relais des spots (qsy.html) : intégrable seulement dans les sites de DX cluster autorisés
    if (key === 'qsy.html') hd['Content-Security-Policy'] = "frame-ancestors 'self' " + qsyOrigins().join(' ');
    res.writeHead(200, hd);
    res.end(req.method === 'HEAD' ? undefined : data);
  });
});

// ---------------------------------------------------------------- état
let station = null; // { conn, ip, since }
let lastHwSplit = null; // dernier état du SPLIT de la face avant (FTX-1)
let txMismatchAt = 0; // SPLIT virtuel : depuis quand le TRX émet sur un autre VFO que celui choisi
let txSel = 0; // SPLIT virtuel (FTX-1) : SPLIT enclenché (1) ou non ; envoyé au TRX seulement en émission
// Règle des TRX : sans SPLIT on émet sur le VFO où l'on écoute ; avec SPLIT, sur l'autre.
// Le VFO de réception est celui d'avant le PTT (le TRX peut changer de côté actif pendant l'émission).
const rxSide = () => (ptt.active && (ptt.rx === 0 || ptt.rx === 1) ? ptt.rx : radio.vfoSel === 1 ? 1 : 0);
const txSide = () => (txSel ? 1 - rxSide() : rxSide());
// Dernière fréquence demandée par VFO (voir la lecture du TRX : pas de retour à l'ancienne fréquence)
const freqCmd = { A: null, B: null };
const FREQ_CMD_HOLD = 2500;
let radio = { connected: false, freq: null, mode: null, modeCode: null, freqB: null, modeB: null, modeCodeB: null, tx: 0, smeter: 0 };
const ops = new Set(); // connexions opérateurs authentifiées
let controller = null; // connexion qui a la main
let ctlView = null;
let ctlFace = null; // affichage de la face avant de celui qui a la main (« Suivre l'opérateur »)
// TXW (écoute de la fréquence d'émission, comme la touche TXW des TRX) : tant que le bouton est maintenu, les VFO sont
// échangés (A ⇄ B) ; au relâchement, sans nouvelles du bouton (2,5 s), au bout de 15 s ou si la main change : échange inverse
let txw = null; // { conn, since, beat }
function txwSwap(by) {
  const R = rig();
  if (!R.CONTROL || !R.CONTROL.swap || !station) return false;
  let v;
  try { v = R.validate('swap', undefined, radio); } catch (e) { return false; }
  toStation({ t: 'cmd', op: 'ctl', id: 'swap', value: v, by, subOk: !!cfg.ftx1SubCat, subSingle: !!cfg.ftx1SubSingle });
  return true;
}
function txwOff(reason) {
  if (!txw) return;
  const t = txw;
  txw = null;
  txwSwap('TXW');
  if (reason && t.conn) t.conn.txwRelease = true; // coupure forcée : relâcher le bouton avant de recommencer
  if (reason && t.conn && t.conn.open !== false) send(t.conn, { t: 'notice', level: 'warn', msg: 'TXW relâché : ' + reason });
  broadcast();
}    // onglet affiché par celui qui a la main { conn, tab, mode } (« Suivre l'opérateur »)
let swrLock = null;     // { freq, swr } : ROS trop élevé constaté à cette fréquence ; { tune: true, band } : accord impossible sur cette bande
let tuneWatch = null;
// Mémoire vocale du TRX en cours d'émission (VOICE TX) : { conn, at, saw }
let vtx = null;
function vtxCheck() {
  const w = vtx;
  if (!w) return;
  if (radio.tx) w.saw = true;
  const lost = controller !== w.conn || !station || !radio.connected;
  if (lost || Date.now() - w.at > 120000) {
    vtx = null;
    if (rig().CONTROL && rig().CONTROL.voiceStop) toStation({ t: 'cmd', op: 'ctl', id: 'voiceStop', value: null, by: 'serveur' });
    if (w.conn && !lost) send(w.conn, { t: 'notice', level: 'warn', msg: 'VOICE TX arrêté (2 minutes au plus).' });
    return;
  }
  if ((w.saw && !radio.tx) || (!w.saw && Date.now() - w.at > 8000)) vtx = null; // fin de la lecture (ou jamais partie)
}
setInterval(() => { if (vtx) vtxCheck(); }, 1000); // aussi quand la page Station ne répond plus
let tunerAuto = { band: '', until: 0 }; // bande HF / 6 m sur laquelle le tuner a été remis en service tout seul   // accord en cours de suivi { freq, at, saw, endAt, call }
let swrHighSince = 0;
// Audio BF du TRX : la station n'envoie le son que si au moins un membre écoute
let audio = { active: false, want: false, frames: 0, silent: false };
// Responsables de la station (stationEditors, ex. ON6DP, ON4LUC) : réglages verrouillés de la page Station, relance de la carte son
function isEditor(call) {
  const eds = (Array.isArray(cfg.stationEditors) ? cfg.stationEditors : DEFAULTS.stationEditors).map((c) => String(c).toUpperCase());
  return eds.indexOf(String(call || '').toUpperCase()) >= 0;
}
function listeners(heard) {
  let n = 0;
  for (const c of ops) if (c.listen && !(heard && c.listenMute)) n++; // heard : sans les cascades seules (page Face avant, son coupé)
  return n;
}
function audioWanted() { return listeners() > 0 || digiModes().size > 0; }
// Scope du TRX (IC-7300) : demandé par les pages Face avant ouvertes (abonnement renouvelé toutes les 20 s) ;
// la page Station ne fait sortir la courbe du CI-V que s'il y a quelqu'un pour la voir
let scopeWant = false;
function scopeWanted() {
  if (!station || station.caps.indexOf('rfscope') < 0 || !rig().SCOPE) return false;
  const now = Date.now();
  for (const c of ops) if (c.scopeSub && now - c.scopeSub < 45000) return true;
  return false;
}
function updateScopeWant(force) {
  const want = scopeWanted();
  if (want !== scopeWant || force) { scopeWant = want; if (station) toStation({ t: 'scope_want', on: want }); }
}
setInterval(() => updateScopeWant(), 5000);
function updateAudioWant() {
  // La station envoie la BF s'il y a un membre à l'écoute ou une fenêtre de décodage ouverte
  const want = audioWanted();
  if (want !== audio.want) {
    audio.want = want;
    toStation({ t: 'audio_want', on: want });
  }
}
// Trame audio de la station → décodeur et chaque membre à l'écoute (un client trop lent saute des trames
// au lieu d'accumuler du retard). 0x01 : µ-law 8 kHz (ancienne page Station), 0x02 : PCM 16 bits 12 kHz.
// TRX à deux récepteurs en stéréo (FTDX101) : trame gauche (0x02, MAIN) puis trame droite (0x04, SUB).
// La voie droite sert au décodeur RTTY B et, en double réception, l'écoute reçoit le mélange des deux (comme au casque).
const stereo = { l: null, at: 0 };
function sendListen(pcm, l, r) {
  if (!listeners()) return;
  let out = null, st2 = null;
  for (const c of ops) {
    if (!c.listen || c.backlog >= 32768) continue;
    // Mémoire vocale avec Auto Monitor : l'opérateur entend sa mémoire seule (pas mélangée au retour du TRX : son haché)
    if (vmPlay && vmPlay.mon && vmPlay.conn === c && ptt.active) continue;
    // Écoute en stéréo (page Face avant, double réception) : MAIN à gauche, SUB à droite, dans une seule trame 0x07
    if (c.listenStereo && l && r) {
      if (!st2) {
        const a = ULAW.encodeFrame(l, 12000), b = ULAW.encodeFrame(r, 12000);
        st2 = Buffer.alloc(a.length + b.length - 1);
        st2[0] = 0x07;
        st2.set(a.subarray(1), 1);
        st2.set(b.subarray(1), a.length);
      }
      c.send(st2);
      continue;
    }
    if (!out) out = Buffer.from(ULAW.encodeFrame(pcm, 12000)); // µ-law 12 kHz pour l'écoute (96 kbit/s)
    c.send(out);
  }
}
// Fluidité (onglet Synchro) : le serveur a-t-il été bloqué (calcul trop long), l'audio de la station arrive-t-il par
// à-coups ? Plus grand blocage et plus grand trou entre deux trames audio sur les 2 dernières minutes, avec leur heure.
const flow = { lag: [], gap: [], lastAudio: 0, tick: 0 };
function flowNote(list, ms) {
  const now = Date.now();
  list.push({ ms, at: now });
  while (list.length && now - list[0].at > 120000) list.shift();
  if (list.length > 200) list.splice(0, list.length - 200);
}
setInterval(() => {
  const now = Date.now();
  const lag = flow.tick ? now - flow.tick - 250 : 0; // 1er passage : le démarrage (lecture du carnet) ne compte pas
  flow.tick = now;
  if (lag > 400) { flowNote(flow.lag, lag); if (lag > 2000) console.error('Serveur bloqué ' + (lag / 1000).toFixed(1) + ' s'); }
}, 250).unref();
function flowState() {
  const now = Date.now();
  const top = (l) => { let b = null; for (const x of l) if (now - x.at <= 120000 && (!b || x.ms > b.ms)) b = x; return b ? { ms: b.ms, ago: now - b.at } : null; };
  return { lag: top(flow.lag), gap: top(flow.gap), wk: workedCache.ms != null ? workedCache.ms : null, qsos: book.qsos.length };
}
function relayAudio(buf) {
  if (!buf || buf.length < 2 || buf.length > 4000) return;
  audio.frames++;
  if (buf[0] === 0x02) {
    const now = Date.now();
    if (flow.lastAudio && now - flow.lastAudio > 400 && now - flow.lastAudio < 60000) flowNote(flow.gap, now - flow.lastAudio);
    flow.lastAudio = now;
  }
  const dualAudio = !!(station && station.rig && station.rig.DUAL_AUDIO);
  if (buf[0] === 0x02 || buf[0] === 0x04) {
    const right = buf[0] === 0x04;
    if (right && !dualAudio) return;
    const pcm = ULAW.decodeFrame(buf);
    if (!pcm) return;
    const forListen = listeners() ? Float32Array.from(pcm) : null;
    if (digi.worker && digiModes().size) digi.worker.postMessage({ t: 'audio', samples: pcm, at: Date.now(), ch: right ? 1 : 0 }, [pcm.buffer]);
    if (!forListen) { stereo.l = null; return; }
    if (!dualAudio) return sendListen(forListen);
    if (!right) {
      if (stereo.l) sendListen(stereo.l); // voie droite absente (entrée son mono) : la gauche seule
      stereo.l = forListen;
      return;
    }
    const l = stereo.l;
    stereo.l = null;
    if (!l) return;
    if (radio.dualRx === 1 && l.length === forListen.length) {
      const left = Float32Array.from(l);
      for (let i = 0; i < l.length; i++) l[i] = (l[i] + forListen[i]) * 0.5;
      return sendListen(l, left, forListen);
    }
    // Réception simple sur le VFO B (FTDX101 : MAIN muet, FR10 ; ou SUB sélectionné) : on entend le SUB (voie droite)
    if (radio.subMute != null && (radio.mainMute === 1 || (radio.vfoSel === 1 && radio.subMute === 0))) return sendListen(forListen);
    return sendListen(l);
  }
  if (buf[0] !== 0x01) return;
  for (const c of ops) if (c.listen && c.backlog < 32768) c.send(buf);
}

// ---------------------------------------------------------------- modes numériques (FT8 / FT4)
// Le décodage tourne dans un Worker (lib/digi-worker.js) dès qu'un membre ouvre la fenêtre FT8/FT4.
const digi = { worker: null, hist: { FT8: [], FT4: [], FT2: [], WSPR: [], JT65: [] }, histB: { FT8: [], FT4: [], FT2: [], WSPR: [], JT65: [] }, latency: null, ms: 0, last: 0, dial: 0, jtty: new Map(), jttyB: new Map() };
// Modes décodés aussi sur le récepteur SUB (FTDX101 en double réception, page des modes numériques de la face avant)
const FT_DUAL_MODES = ['FT8', 'FT4', 'FT2', 'JT65', 'WSPR', 'JTTY', 'CW'];
/** Double décodage FT (FTDX101 : récepteur SUB sur la voie droite) possible : TRX à deux voies son, double réception */
function ftDualOk() { return !!(station && station.rig && station.rig.DUAL_AUDIO && radio.dualRx === 1); }
/** Émission auto possible sur le VFO-B (FTDX101 : TX MAIN / TX SUB). Pas sur le FTX-1 : il émet toujours de son VFO principal */
function ftTxBOk() { return ftDualOk() && !!station.rig.DUAL_TX; }
/** Ce membre veut aussi les décodages du récepteur SUB (page des modes numériques de la face avant FTDX101) */
const ftDualConn = (c) => !!(c.ftDual && FT_DUAL_MODES.indexOf(c.digi) >= 0);
const DIGI_MODES = ['FT8', 'FT4', 'FT2', 'RTTY', 'WSPR', 'JT65', 'JTTY', 'CW', 'SSTV'];
// Images SSTV reçues (mémoire + dossier sstv/)
const { SstvStore } = require('./lib/sstv-store.js');
const sstvStore = new SstvStore(path.join(ROOT, 'sstv'), (m) => console.error(m));
function sstvSendImage(conn, it) {
  send(conn, { t: 'sstv_img', img: sstvStore.meta(it) });
  for (let y = 0; y < it.lines; y++) conn.send(sstvStore.frame(it, y));
}
// Réglages CW d'un membre : tonalité (Hz), largeur du filtre, silencieux → clé du décodeur
function cwCfg(r) {
  if (!r || typeof r !== 'object') return null;
  const f = Math.round(Number(r.f));
  const bw = [50, 100, 200, 400].indexOf(Number(r.bw)) >= 0 ? Number(r.bw) : 100;
  const squelch = Math.max(0, Math.min(20, Math.round(Number(r.squelch))));
  if (!(f >= 200 && f <= 2800) || !Number.isFinite(squelch)) return null;
  return { f, bw, squelch, key: [f, bw, squelch].join('/') };
}
// Réglages RTTY d'un membre (chacun peut suivre un signal différent) → clé du démodulateur
function rttyCfg(r) {
  if (!r || typeof r !== 'object') return null;
  const f = Math.round(Number(r.f));
  const shift = [170, 200, 425, 850].indexOf(Number(r.shift)) >= 0 ? Number(r.shift) : 170;
  const baud = [45.45, 50, 75, 100].indexOf(Number(r.baud)) >= 0 ? Number(r.baud) : 45.45;
  const squelch = Math.max(4, Math.min(25, Math.round(Number(r.squelch) || 9)));
  if (!(f >= 200 && f <= 3900)) return null;
  const c = { f, shift, baud, rev: !!r.rev, squelch };
  c.key = [f, shift, baud, c.rev ? 1 : 0, squelch].join('/');
  return c;
}
// Décodeur RTTY B d'un membre : sur la voie droite (récepteur SUB) avec un TRX à deux récepteurs en double réception
function rttyB(c) {
  const r = c.rtty2;
  if (!r) return null;
  if (!c.rtDual || !(station && station.rig && station.rig.DUAL_AUDIO && radio.dualRx === 1)) return r;
  return Object.assign({}, r, { ch: 1, key: r.key + '/R' });
}
// Décodeur CW B d'un membre : récepteur SUB (voie droite), seulement en double réception
function cwB(c) {
  const r = c.cw2;
  if (!r || !c.ftDual || !ftDualOk()) return null;
  return Object.assign({}, r, { ch: 1, key: r.key + '/R' });
}
function digiModes() {
  const s = new Set();
  for (const c of ops) if (c.digi) s.add(c.digi);
  if (seq && seq.on) s.add(seq.mode); // émission auto : il faut décoder les réponses, même panneau replié
  return s;
}
function startDigi() {
  if (digi.worker) return;
  try {
    const { Worker } = require('worker_threads');
    digi.worker = new Worker(path.join(ROOT, 'lib', 'digi-worker.js'));
  } catch (e) {
    console.error('Décodeur FT8/FT4 indisponible : ' + e.message);
    return;
  }
  digi.worker.on('message', onDigi);
  digi.apKey = '';
  digi.apKeyB = '';
  digi.ftB = false;
  digi.worker.on('error', (e) => console.error('Décodeur FT8/FT4 : ' + e.message));
  digi.worker.on('exit', () => { digi.worker = null; });
}
function updateDigi() {
  const modes = digiModes();
  if (modes.size) startDigi();
  if (digi.worker) {
    digi.worker.postMessage({ t: 'modes', modes: Array.from(modes) });
    // Décodage FT du récepteur SUB : quelqu'un l'a demandé (ou l'émission auto est sur le VFO-B) et le TRX le permet
    let wantB = false;
    for (const c of ops) if (ftDualConn(c)) wantB = true;
    if (seq && seq.on && seq.side === 'B') wantB = true;
    wantB = wantB && ftDualOk();
    if (wantB !== digi.ftB) { digi.ftB = wantB; digi.worker.postMessage({ t: 'ftb', on: wantB }); }
    digi.worker.postMessage({ t: 'dial', hz: radio.freq || 0, hzB: radio.freqB || 0 });
    const cfgs = {};
    for (const c of ops) if (c.digi === 'RTTY') for (const r of [c.rtty, rttyB(c), c.rtty3, c.rtty4]) if (r) cfgs[r.key] = r;
    digi.worker.postMessage({ t: 'rtty', cfgs: Object.values(cfgs) });
    const cwc = {};
    for (const c of ops) if (c.digi === 'CW') for (const r of [c.cw, cwB(c)]) if (r) cwc[r.key] = r;
    digi.worker.postMessage({ t: 'cw', cfgs: Object.values(cwc) });
  }
  updateAudioWant();
}
function onDigi(m) {
  if (m.t === 'wf') {
    // Ligne de cascade : [0x13, largeur de case (mHz, 2 octets), heure de capture (dixièmes de s du jour UTC, 4 octets),
    // octets dB*2+240 par case depuis 0 Hz]
    // 0x14 : même format, voie droite (récepteur SUB d'un TRX à deux récepteurs) pour la cascade du décodeur RTTY B
    const fr = Buffer.allocUnsafe(m.row.length + 7);
    fr[0] = m.ch === 1 ? 0x14 : 0x13;
    fr.writeUInt16BE(Math.round((m.df || 6.25) * 1000), 1);
    fr.writeUInt32BE(Math.floor(((m.at || Date.now()) % 86400000) / 100), 3);
    Buffer.from(m.row.buffer, m.row.byteOffset, m.row.length).copy(fr, 7);
    for (const c of ops) if (c.digi && c.backlog < 65536 && (m.ch !== 1 || c.digi === 'RTTY' || ftDualConn(c))) c.send(fr);
    return;
  }
  if (m.t === 'log') return console.error(m.msg);
  if ((m.t === 'jtty' || m.t === 'rtty_text') && rxMuted(m.t === 'jtty' ? 3000 : 1500)) return;
  if (m.t === 'jtty') {
    // Messages JTTY : dernière version de chaque message (le texte grandit trame après trame) ; ch 1 = récepteur SUB
    const B = m.ch === 1;
    const map = B ? digi.jttyB : digi.jtty;
    map.set(m.u.key, m.u);
    if (map.size > 150) map.delete(map.keys().next().value);
    const msg = JSON.stringify(B ? { t: 'jtty', u: m.u, side: 'B' } : { t: 'jtty', u: m.u });
    for (const c of ops) if (c.digi === 'JTTY' && (!B || ftDualConn(c))) c.send(msg);
    return;
  }
  if (m.t === 'rtty_text' || m.t === 'rtty_lvl') {
    // Deux décodeurs par membre (A : VFO-A, B : VFO-B) : ch = 0 ou 1
    const out = (ch) => JSON.stringify(m.t === 'rtty_text' ? { t: 'rtty', ch, text: m.text } : { t: 'rtty_lvl', ch, m: m.m, s: m.s, c: m.c });
    for (const c of ops) {
      if (c.digi !== 'RTTY') continue;
      if (c.rtty && c.rtty.key === m.key) c.send(out(0));
      const b = rttyB(c);
      if (b && b.key === m.key) c.send(out(1));
      if (c.rtty3 && c.rtty3.key === m.key) c.send(out(2)); // A3, A4 (réception simple)
      if (c.rtty4 && c.rtty4.key === m.key) c.send(out(3));
    }
    return;
  }
  if (m.t === 'sstv') {
    const e = m.e;
    const watchers = Array.from(ops).filter((c) => c.digi === 'SSTV');
    if (e.t === 'start') {
      const it = sstvStore.start(e);
      journal('sstv_rx', { mode: e.mode, shift: e.shift });
      for (const c of watchers) send(c, { t: 'sstv_start', img: sstvStore.meta(it), shift: e.shift });
    } else if (e.t === 'line') {
      const it = sstvStore.line(e);
      if (it) { const fr = sstvStore.frame(it, e.y); for (const c of watchers) c.send(fr); }
    } else if (e.t === 'end') {
      const it = sstvStore.end(e);
      if (it) for (const c of watchers) send(c, { t: 'sstv_end', img: sstvStore.meta(it), refreshed: !!e.rgb, slant: e.slant, why: e.why });
    }
    return;
  }
  if (m.t === 'cw_text' || m.t === 'cw_lvl') {
    // Deux décodeurs par membre en double réception (A : MAIN, B : SUB) : ch = 0 ou 1
    const out = (ch) => JSON.stringify(m.t === 'cw_text' ? { t: 'cw', ch, text: m.text } : { t: 'cw_lvl', ch, s: m.s, wpm: m.wpm, on: m.on });
    for (const c of ops) {
      if (c.digi !== 'CW') continue;
      if (c.cw && c.cw.key === m.key) c.send(out(0));
      const b = cwB(c);
      if (b && b.key === m.key) c.send(out(1));
    }
    return;
  }
  if (m.t === 'decodes') {
    // Notre propre émission décodée (la BF du TRX renvoie le signal émis) : retirée, comme WSJT-X qui n'écoute pas en émission
    if (Array.isArray(m.list) && ftTxSlots.some((x) => x.mode === m.mode && Math.abs(x.slot - m.slot) < 1500)) {
      const mine = myCalls();
      const sent = ftTxSlots.filter((x) => x.mode === m.mode && Math.abs(x.slot - m.slot) < 1500).map((x) => norm(x.text));
      m.list = m.list.filter((d) => {
        const w = norm(d && d.msg).split(' ').map((x) => x.replace(/^<|>$/g, ''));
        return sent.indexOf(norm(d && d.msg)) < 0 && mine.indexOf(w[1]) < 0 && !(w[0] === 'CQ' && (mine.indexOf(w[1]) >= 0 || mine.indexOf(w[2]) >= 0));
      });
    }
    // Pays DXCC, distance et azimut de la station qui émet chaque message (comme JTDX)
    if (Array.isArray(m.list) && m.mode !== 'WSPR' && m.mode !== 'JT65') for (const d of m.list) dxInfo(d);
    // PSK Reporter : stations FT8 / FT4 / FT2 entendues (indicatif, locator, fréquence, SNR), comme WSJT-X
    if (PSKR && Array.isArray(m.list) && FTX_SLOT[m.mode]) {
      const dial = Number(m.ch === 1 ? radio.freqB : radio.freq) || 0;
      if (dial > 1e6) for (const d of m.list) {
        const w = String(d && d.msg || '').toUpperCase().split(/\s+/).map((x) => x.replace(/^<|>$/g, ''));
        const call = w[0] === 'CQ' ? (DX_CALL_RE.test(w[1] || '') ? w[1] : w[2]) : w[1];
        if (!call || !DX_CALL_RE.test(call)) continue;
        const last = w[w.length - 1];
        PSKR.add({ call, grid: /^[A-R]{2}\d{2}$/.test(last) && last !== 'RR73' ? last : '', hz: dial + (Number(d.f) || 0), snr: d.db, mode: m.mode, t: m.slot || Date.now() });
      }
    }
    const item = { slot: m.slot, list: m.list };
    const sideB = m.ch === 1;
    // Passe normale reçue pour cette période (FT8 / FT4) : une émission de la séquence qui l'attendait peut partir
    if (FTX_SLOT[m.mode] && (m.phase === 'normal' || (!m.phase && !m.early))) {
      const key = (sideB ? 'B' : 'A') + m.mode;
      digi.normal = digi.normal || {};
      digi.normal[key] = Math.max(digi.normal[key] || 0, m.slot);
      // Arrivée de la passe normale après la fin de la période (ms) : l'attente avant d'émettre se règle dessus
      digi.normalLate = digi.normalLate || {};
      const l = digi.normalLate[key] || (digi.normalLate[key] = []);
      l.push(Date.now() - m.slot - FTX_SLOT[m.mode]);
      if (l.length > 6) l.shift();
      setTimeout(ftxHoldCheck, 0);
    }
    const h = (sideB ? digi.histB : digi.hist)[m.mode];
    if (!h) return;
    h.push(item);
    while (h.length > (m.mode === 'FT2' ? 120 : 40)) h.shift();
    if (sideB) {
      // Récepteur SUB : à ceux qui l'ont demandé ; l'émission auto sur le VFO-B suit ses décodages
      const msgB = JSON.stringify({ t: 'ftx', mode: m.mode, slot: m.slot, list: m.list, latency: m.latency, side: 'B' });
      for (const c of ops) if (c.digi === m.mode && ftDualConn(c)) c.send(msgB);
      if (FTX_SLOT[m.mode]) seqOnDecodes(m.mode, m.slot, m.list, 'B');
      return;
    }
    digi.latency = m.latency;
    digi.ms = m.ms;
    if (m.engine) digi.engine = m.engine;
    // Heure d'arrivée de chaque passe FT8 / FT4 (après le début de la période) : affichée dans l'onglet Synchro
    if (m.phase && FTX_SLOT[m.mode]) { digi.timing = digi.timing || {}; digi.timing[m.phase] = { at: Date.now() - m.slot, ms: m.ms, mode: m.mode, t: Date.now() }; }
    digi.last = Date.now();
    const msg = JSON.stringify({ t: 'ftx', mode: m.mode, slot: m.slot, list: m.list, latency: m.latency });
    for (const c of ops) if (c.digi === m.mode) c.send(msg);
    seqOnDecodes(m.mode, m.slot, m.list, 'A');
  }
}

// ---------------------------------------------------------------- carnet de trafic et carnets en ligne (version « extended »)
const LB = require('./lib/logbook.js');
const REFDATA = require('./lib/refdata.js');
const { Sync, SERVICES: LOG_SERVICES, udpPacket } = require('./lib/logsync.js');
const VERSION = (() => { try { return require('./package.json').version; } catch (e) { return '0'; } })();
// Dernier installateur Windows publié (releases/<v>/RemoteStation-Setup-<v>.exe) : à changer quand il est reconstruit
const WIN_INSTALLER = '0.42.42';
// Facteurs de propagation (hamqsl.com, N0NBH) : relus toutes les 30 min, envoyés aux pages qui les affichent (page SSB)
// Temps réel (NOAA SWPC, ionosonde de Dourbes) toutes les 5 min ; historique par jour dans logs/prop-history.json
const PROP_WATCH = new Set(); // pages /prop ouvertes (connexion à part, session d'un membre)
const PROP = new (require('./lib/prop.js').Prop)((msg) => { for (const c of ops) if (c.open && c.user && c.propSub) send(c, msg); for (const c of PROP_WATCH) send(c, msg); }, { histFile: path.join(LOG_DIR, 'prop-history.json'), grid: () => cfg.stationGrid || '' });
// Nouvelle version sur GitHub : « 🔔 Mise à jour » au dashboard des administrateurs (lib/update.js) ; updateCheck: false pour couper
const UPD = new (require('./lib/update.js').Updater)({ root: ROOT, version: VERSION, enabled: cfg.updateCheck !== false,
  onChange: (st) => { for (const c of ops) if (c.open && c.user && c.user.admin) send(c, st); } });
// Dans le dossier des journaux par défaut : le seul où le service systemd du VPS peut écrire (ReadWritePaths)
// Base SQLite logbook.db (Node.js 22.13 et plus), reprise automatique de logbook.json la première fois ; sinon logbook.json.
// nodeName : nom de ce serveur / poste dans le log commun (mise en réseau)
const book = new LB.Logbook(cfg.logbookFile ? path.resolve(ROOT, cfg.logbookFile) : path.join(LOG_DIR, 'logbook.json'), { node: cfg.nodeName || 'serveur' });
{ const bi = book.info(); console.log('Carnet de trafic : ' + bi.qsos + ' QSO, ' + (bi.engine === 'sqlite' ? 'base SQLite ' + bi.file : 'fichier ' + bi.file)); }
// Base SQLite : copie lisible logbook.json au démarrage puis chaque jour (secours si SQLite manquait un jour)
if (book.engine === 'sqlite') { setTimeout(() => book.exportJson(), 60000).unref(); setInterval(() => book.exportJson(), 24 * 3600 * 1000).unref(); }
// Mise en réseau (lib/net.js) : log commun et numéros de série partagés entre serveurs ; réglages dans net.json (jamais publié)
const NET = new (require('./lib/net.js').Net)({ book, file: cfg.netFile ? path.resolve(ROOT, cfg.netFile) : path.join(ROOT, 'net.json'), version: VERSION, clubCalls: () => stationCalls() });
NET.on('applied', (x) => {
  // QSO reçus d'un autre serveur : carnets, listes « déjà contacté » et pages RTTY / SSB / CW mis à jour
  if (x.n) { for (const c of ops) send(c, { t: 'log_changed' }); setTimeout(() => sendWorked(false), 0); }
});
setTimeout(() => NET.start(), 2000);
// Version du maître du réseau plus récente que la nôtre : le maître de secours s'aligne tout seul (sans TRX ni opérateur,
// et seulement en attente, jamais quand il remplace le maître) ; une station prévient ses administrateurs (elle choisit
// le moment : jamais de mise à jour imposée pendant un contest). autoUpdate: false dans config.json pour couper.
let netNewer = null, netAsked = '', netWarned = '';
NET.on('masterVersion', (x) => {
  const CMP = require('./lib/update.js').cmp;
  if (CMP(x.v, VERSION) <= 0) { netNewer = null; return; }
  netNewer = x;
  if (NET.isMaster() && NET.prioOf() > 0) {
    // Maître de secours en attente (le maître a repris la main) : mise à jour automatique, une fois par version
    if (NET.active() || cfg.autoUpdate === false || netAsked === x.v) return;
    netAsked = x.v;
    const e = UPD.installVersion(x.v, 'réseau (' + x.name + ')');
    journal('update_request', { call: 'réseau ' + x.name, v: x.v, err: e || undefined });
    NET.ev(e ? 'Alignement sur la version ' + x.v + ' du maître impossible : ' + e : 'Alignement sur la version ' + x.v + ' du maître : mise à jour lancée');
    return;
  }
  if (netWarned === x.v) return;
  netWarned = x.v;
  for (const c of ops) if (c.open && c.user && c.user.admin) send(c, { t: 'notice', level: 'warn', msg: 'Réseau : le maître ' + x.name + ' est en version ' + x.v + ', ce serveur en ' + VERSION + '. Pensez à le mettre à jour (🔔 Mise à jour), hors contest.' });
});
const refs = new REFDATA.RefData(path.join(ROOT, 'refdata'), (msg) => console.error(msg));
// Super Check Partial (indicatifs actifs en contest) : page TRX SSB, indicatifs probables
const SCP = new (require('./lib/scp').Scp)(path.join(ROOT, 'refdata'), (msg) => console.log(msg));
if (!process.env.RS_NO_SCP) SCP.start();
if (cfg.refData !== false) {
  setTimeout(() => refs.refresh().catch(() => {}), 20000);
  setInterval(() => refs.refresh().catch(() => {}), 6 * 3600000).unref();
}
const LOGCFG_FILE = cfg.logbookConfig ? path.resolve(ROOT, cfg.logbookConfig) : path.join(LOG_DIR, 'logbook-config.json');
const LOGCFG_DEFAULT = {
  clublog: { auto: false, email: '', password: '', api: '', delay: 15 },
  eqsl: { auto: false, user: '', password: '', nickname: '', delay: 5 },
  qrz: { auto: false, keys: {}, delay: 5, lookupUser: '', lookupPassword: '' },
  lotw: { auto: false, tqsl: process.platform === 'win32' ? 'C:\\Program Files (x86)\\TrustedQSL\\tqsl.exe' : '/usr/bin/tqsl', tqslDir: '', location: '', password: '', login: '', webPassword: '', delay: 0, lastConfirm: '' },
  udp: []
};
let logCfg = (() => {
  let c = {};
  try { c = JSON.parse(fs.readFileSync(LOGCFG_FILE, 'utf8')); } catch (e) { /* pas encore réglé */ }
  const out = {};
  for (const k of Object.keys(LOGCFG_DEFAULT)) out[k] = Array.isArray(LOGCFG_DEFAULT[k]) ? (Array.isArray(c[k]) ? c[k] : []) : Object.assign({}, LOGCFG_DEFAULT[k], c[k] || {});
  return out;
})();
function saveLogCfg() {
  fs.writeFileSync(LOGCFG_FILE, JSON.stringify(logCfg, null, 2) + '\n', { mode: 0o600 });
}
// Champs secrets : jamais renvoyés au navigateur (seulement « déjà enregistré »)
const SECRETS = { clublog: ['password', 'api'], eqsl: ['password'], lotw: ['password', 'webPassword'], qrz: ['lookupPassword'] };
// Recherche des indicatifs sur QRZ.com (nom, QTH, locator du correspondant) avec le compte QRZ réglé dans le carnet
const { Qrz } = require('./lib/qrz.js');
const qrzx = new Qrz(() => ({ user: logCfg.qrz.lookupUser, password: logCfg.qrz.lookupPassword }), 'RemoteStation-' + VERSION);
// Identifiants propres à chaque indicatif (TX call) : logCfg[service].accounts[INDICATIF] = { champs du service }.
// Les identifiants « généraux » (⚙ Configuration) restent ceux des indicatifs du club (ON5VL, OR0L) ; un indicatif
// personnel n'utilise que les siens (jamais ceux du club : ses QSO iraient sur le compte du club).
const ACCT_FIELDS = { clublog: ['email', 'password', 'api'], eqsl: ['user', 'password', 'nickname'], lotw: ['location', 'password', 'login', 'webPassword'], qrz: ['key'] };
function credFor(s, call) {
  const base = Object.assign({}, logCfg[s] || {});
  call = String(call || '').toUpperCase();
  const acct = (logCfg[s] && logCfg[s].accounts && logCfg[s].accounts[call]) || null;
  const club = !call || stationCalls().indexOf(call) >= 0;
  if (s === 'qrz') {
    const k = acct && acct.key ? acct.key : (logCfg.qrz.keys || {})[call] || '';
    return Object.assign(base, { key: k, keys: Object.assign({}, logCfg.qrz.keys || {}, k ? { [call]: k } : {}) });
  }
  // Indicatif personnel : jamais les identifiants du club… sauf la clé API Club Log, qui est celle du logiciel (une pour tous)
  if (!club) { for (const k of ACCT_FIELDS[s]) if (!(s === 'clublog' && k === 'api')) base[k] = ''; base.lastConfirm = ''; base.auto = false; }
  // … sauf si cette « clé » est un jeton Club Log (cl_…) : il ouvre le compte du club, jamais prêté à un indicatif personnel
  if (!club && s === 'clublog' && /^cl_/i.test(String(base.api || '').trim())) base.api = '';
  if (acct) for (const k of ACCT_FIELDS[s]) if (acct[k]) base[k] = acct[k];
  // Indicatif personnel : ses propres options (envoi automatique, date des dernières confirmations LoTW)
  if (!club && acct) { base.auto = acct.auto === true; base.lastConfirm = acct.lastConfirm || ''; }
  // Indicatif du club : sa propre date de dernière lecture LoTW (sinon l'ancienne date commune)
  if (club && acct && acct.lastConfirm) base.lastConfirm = acct.lastConfirm;
  return base;
}
// Envoi automatique d'un nouveau QSO : réglage du club pour ON5VL / OR0L ; pour un indicatif personnel, seulement si
// son titulaire (ou un administrateur) l'a demandé dans ses identifiants — jamais avec ceux du club
function autoFor(s, call) {
  call = String(call || '').toUpperCase();
  const acct = logCfg[s] && logCfg[s].accounts && logCfg[s].accounts[call];
  // Indicatif du club : son propre choix (fenêtre du service, cadre jaune) s'il en a un, sinon celui de ⚙ Configuration
  if (!call || stationCalls().indexOf(call) >= 0) return acct && typeof acct.auto === 'boolean' ? acct.auto : !!(logCfg[s] && logCfg[s].auto);
  if (!acct || acct.auto !== true) return false;
  const c = credFor(s, call);
  // LoTW : TQSL de ce serveur ou Agent LoTW du membre (s'il n'est pas connecté, les QSO partent dès son retour)
  return s === 'eqsl' ? !!(c.user && c.password) : s === 'clublog' ? !!(/^cl_/i.test(String(c.api || '').trim()) || (c.email && c.password && c.api)) : s === 'qrz' ? !!c.key : true;
}
// Logs en ligne en libre-service : un membre ne gère que son propre indicatif (identifiants, envois, confirmations)
function ownLogCall(conn, call) {
  call = String(call || '').toUpperCase();
  return !!call && call === String(conn.user.call || '').toUpperCase() && ownCallOk(conn.user) && stationCalls().indexOf(call) < 0;
}
function acctPublic(s, call) {
  const c = credFor(s, call);
  const out = { fields: {}, has: {} };
  const acct = (logCfg[s] && logCfg[s].accounts && logCfg[s].accounts[call]) || null;
  for (const k of ACCT_FIELDS[s]) {
    const secret = (SECRETS[s] || []).indexOf(k) >= 0 || (s === 'qrz' && k === 'key');
    if (secret) out.has[k] = !!c[k]; else out.fields[k] = c[k] || '';
  }
  const own = !!acct && Object.keys(acct).some((k) => k !== 'lastConfirm' && k !== 'auto');
  out.source = own ? 'compte' : stationCalls().indexOf(call) >= 0 ? 'club' : 'aucun';
  out.club = stationCalls().indexOf(call) >= 0;
  out.auto = out.club ? (acct && typeof acct.auto === 'boolean' ? acct.auto : !!(logCfg[s] && logCfg[s].auto)) : !!(acct && acct.auto === true);
  out.autoOwn = !!(acct && typeof acct.auto === 'boolean');
  return out;
}
function logCfgPublic() {
  const o = JSON.parse(JSON.stringify(logCfg));
  for (const sv of Object.keys(ACCT_FIELDS)) if (o[sv]) delete o[sv].accounts; // jamais les identifiants par indicatif
  for (const [s, keys] of Object.entries(SECRETS)) for (const k of keys) { o[s]['has_' + k] = !!o[s][k]; o[s][k] = ''; }
  o.qrz.has_keys = {};
  for (const [c, v] of Object.entries(o.qrz.keys || {})) o.qrz.has_keys[c] = !!v;
  o.qrz.keys = {};
  // TQSL présent sur ce serveur (serveur Windows du club) : sinon, l'Agent LoTW ou l'export à la main
  try { o.lotw.tqslHere = !!logCfg.lotw.tqsl && fs.existsSync(logCfg.lotw.tqsl); } catch (e) { o.lotw.tqslHere = false; }
  return o;
}
function setLogCfg(n) {
  if (!n || typeof n !== 'object') return;
  const str = (v, max) => String(v == null ? '' : v).slice(0, max || 200);
  for (const s of ['clublog', 'eqsl', 'qrz', 'lotw']) {
    const src = n[s];
    if (!src || typeof src !== 'object') continue;
    const dst = logCfg[s];
    dst.auto = !!src.auto;
    const d = Number(src.delay);
    if (Number.isFinite(d)) dst.delay = Math.max(0, Math.min(120, Math.round(d)));
    for (const k of Object.keys(LOGCFG_DEFAULT[s])) {
      if (k === 'auto' || k === 'delay' || k === 'keys' || k === 'lastConfirm' || src[k] === undefined) continue;
      const secret = (SECRETS[s] || []).indexOf(k) >= 0;
      if (secret && src[k] === '') continue;               // champ laissé vide : on garde l'ancien
      dst[k] = src[k] === '__effacer__' ? '' : str(src[k], 300);
    }
    if (s === 'qrz' && src.keys && typeof src.keys === 'object') {
      for (const [c, v] of Object.entries(src.keys)) {
        const call = String(c).toUpperCase().replace(/[^A-Z0-9/]/g, '').slice(0, 15);
        if (!call || v === '') continue;
        if (v === '__effacer__') delete dst.keys[call]; else dst.keys[call] = str(v, 80);
      }
    }
  }
  // Le serveur n'exécute que TQSL (pas n'importe quel programme choisi depuis le dashboard)
  if (!/^tqsl(\.exe)?$/i.test(path.basename(String(logCfg.lotw.tqsl || '').replace(/\\/g, '/')))) logCfg.lotw.tqsl = LOGCFG_DEFAULT.lotw.tqsl;
  if (Array.isArray(n.udp)) {
    logCfg.udp = n.udp.slice(0, 8).map((u) => ({
      enabled: !!u.enabled, host: str(u.host, 100).trim(), port: Math.max(0, Math.min(65535, parseInt(u.port, 10) || 0)),
      format: ['wsjtx-adif', 'wsjtx-qso', 'n1mm', 'adif'].indexOf(u.format) >= 0 ? u.format : 'wsjtx-adif', label: str(u.label, 40)
    })).filter((u) => u.host && u.port);
  }
  saveLogCfg();
  sync.resetStops();
}
// Créneaux FT8 / FT4 / FT2 où la station a émis { mode, slot, text } (pour écarter le décodage de notre propre signal)
const ftTxSlots = [];
const norm = (s) => String(s || '').toUpperCase().replace(/\s+/g, ' ').trim();
// « Émettre sous » (modes numériques) : indicatif de celui qui a la main s'il l'a choisi, sinon celui de la station (digiCall)
const txChoice = new Map(); // indicatif du membre → TX call choisi (un indicatif du club, ou le sien)
const ownCallOk = (u) => !!(u && u.tx && !u.rxOnly && /^[A-Z0-9]{1,3}[0-9][A-Z0-9]{0,4}[A-Z](\/[A-Z0-9]{1,4})?$/.test(String(u.call || '')));
/** TX call que ce membre utiliserait (choix valable, sinon l'indicatif principal de la station) */
function txCallFor(u) {
  const ch = u ? txChoice.get(u.call) : '';
  if (ch && ch === String(u.call).toUpperCase() && ownCallOk(u)) return ch;
  if (ch && stationCalls().indexOf(ch) >= 0) return ch;
  return String(cfg.digiCall || 'ON5VL').toUpperCase();
}
function txCall() {
  return controller ? txCallFor(controller.user) : String(cfg.digiCall || 'ON5VL').toUpperCase();
}
// Indicatifs « à nous » pour les modes numériques : ceux de la station + celui sous lequel on émet en ce moment
const myCalls = () => Array.from(new Set(stationCalls().concat(txCall())));
const stationCalls = () => Array.from(new Set([cfg.digiCall].concat(Array.isArray(cfg.clubCalls) ? cfg.clubCalls : [], String(cfg.stationCall || '').split(/[\s/,]+/)).map((c) => String(c || '').toUpperCase()).filter((c) => /^[A-Z0-9]{3,10}$/.test(c))));
// Agent LoTW (agent/agent-lotw.js) : TQSL du PC d'un membre, relié à ce serveur ; registre lotw-agents.json (jamais publié)
const { LotwAgents } = require('./lib/lotw-agent.js');
let agentUsers = { t: 0, u: {} };
function agentOwner(call) {
  if (Date.now() - agentUsers.t > 10000) { try { agentUsers = { t: Date.now(), u: auth.loadUsers(USERS_FILE) }; } catch (e) { /* fichier en cours d'écriture */ } }
  const rec = agentUsers.u[call];
  if (!rec || auth.userOff(rec)) return null;
  const rxOnly = auth.isRxOnly(call, cfg.rxOnlyPrefixes);
  return { call, admin: !!rec.admin, tx: rec.tx !== false && !rxOnly, rxOnly };
}
const AGENTS = new LotwAgents({
  file: path.join(LOG_DIR, 'lotw-agents.json'),
  owner: agentOwner,
  // Indicatifs qu'un agent peut signer : celui de son titulaire (s'il émet sous son indicatif) ; un administrateur aussi ceux du club
  calls: (owner) => {
    const u = agentOwner(owner);
    if (!u) return [];
    const l = ownCallOk(u) && stationCalls().indexOf(owner) < 0 ? [owner] : [];
    return Array.from(new Set(l.concat(u.admin ? stationCalls() : [])));
  },
  send: (c, m) => send(c, m),
  journal: (ev, d) => journal(ev, d)
});
AGENTS.on('change', () => { for (const c of ops) if (c.wantAgents) send(c, { t: 'log_agents', list: AGENTS.list(c.user) }); });
// Lecture automatique des confirmations LoTW : 3 min après le démarrage puis toutes les heures, pour chaque indicatif dont
// l'identifiant et le mot de passe du site LoTW sont réglés (club et comptes personnels). Les QSO confirmés passent en
// « C » dans les statistiques et le tableau DXCC de la page FT, et l'alerte « pas encore confirmé » se met à jour.
// Coupée par « lotw.autoConfirm »: false dans logbook-config.json.
let lotwAutoBusy = false;
async function lotwAutoConfirm() {
  if (lotwAutoBusy || logCfg.lotw.autoConfirm === false) return;
  lotwAutoBusy = true;
  try {
    const calls = Array.from(new Set(stationCalls().concat(Object.keys(logCfg.lotw.accounts || {})).map((c) => String(c).toUpperCase())));
    for (const call of calls) {
      const c = credFor('lotw', call);
      if (!c.login || !c.webPassword || sync.isStopped('lotw', call)) continue;
      const r = await sync.confirmLotw('', call, true).catch((e) => ({ ok: false, msg: e.message }));
      if (r && r.n) journal('lotw_confirm_auto', { call, n: r.n });
      if (r && !r.ok) console.error('LoTW, lecture automatique des confirmations de ' + call + ' : ' + r.msg);
    }
  } finally { lotwAutoBusy = false; }
}
setTimeout(lotwAutoConfirm, 3 * 60000).unref();
setInterval(lotwAutoConfirm, 3600000).unref();
// Agent qui (re)vient : QSO récents (30 jours) jamais présentés à LoTW des indicatifs en envoi automatique
AGENTS.on('ready', (ag) => setTimeout(() => {
  const since = Date.now() - 30 * 86400000;
  for (const call of AGENTS.servedCalls(ag)) {
    if (!autoFor('lotw', call) || sync.isStopped('lotw', call)) continue;
    const list = book.qsos.filter((q) => String(q.station_callsign || '').toUpperCase() === call && !(q.up && q.up.lotw) && (Number(q.created) || 0) >= since);
    if (list.length) sync.run('lotw', list, { auto: true });
  }
}, 8000));
const sync = new Sync({
  lotwAgent: (call) => AGENTS.forCall(call),
  book, version: VERSION, station: String(cfg.digiCall || 'ON5VL').toUpperCase(), urls: cfg.logUrls, // logUrls : essais seulement
  getCfg: () => logCfg,
  getCred: (s, call) => credFor(s, call),
  clubCalls: () => stationCalls(),
  getAuto: (s, call) => autoFor(s, call),
  setClublogFw: (t) => { logCfg.clublog.fwUntil = t; saveLogCfg(); },
  setLastConfirm: (d, call) => {
    call = String(call || '').toUpperCase();
    // Date de la dernière lecture gardée par indicatif (chacun son compte LoTW : ON5VL, OR0L, ON6DP…)
    if (!call) logCfg.lotw.lastConfirm = d;
    else {
      logCfg.lotw.accounts = logCfg.lotw.accounts || {};
      const acct = logCfg.lotw.accounts[call] || (logCfg.lotw.accounts[call] = {});
      acct.lastConfirm = d;
    }
    saveLogCfg();
  },
  log: (m) => console.error('Logs : ' + m),
  onJob: (job, ev) => {
    const msg = { t: 'log_job', job: { id: job.id, service: job.service, name: job.name, total: job.total, done: job.done, ok: job.ok, fail: job.fail, auto: job.auto, by: job.by }, line: ev.line, fin: !!ev.fin, step: ev.step };
    for (const c of ops) if (c.user.admin || (job.by && c.user.call === job.by)) send(c, msg);
    if (ev.fin) {
      if (job.fail && job.auto) journal('log_sync_fail', { service: job.service, line: ev.line });
      for (const c of ops) send(c, { t: 'log_changed' });
      sendWorked(false);
    }
  }
});
function logCtx(conn, m) {
  const calls = logCalls(conn);
  const st = String((m && m.station) || cfg.digiCall || calls[0] || '').toUpperCase();
  const sc = calls.indexOf(st) >= 0 ? st : calls[0];
  // Locator du QSO : celui du lieu de station TQSL de ce TX call (déjà connu de LoTW), sinon celui de la station
  return { operator: conn.user.call, stationCallsign: sc, myGrid: myGridFor(sc) };
}
function myGridFor(call) {
  try { const g = AGENTS.gridFor(call, (credFor('lotw', call) || {}).location); if (/^[A-R]{2}\d{2}([A-X]{2})?$/i.test(g)) return g.toUpperCase(); } catch (e) { /* */ }
  return cfg.stationGrid || '';
}
// Indicatifs de station proposés dans le carnet : ceux du club, plus le sien (QSO faits sous son indicatif)
// Page qui a envoyé le QSO (page TRX SSB…) : renvoyée avec la réponse, chaque page ne traite que les siennes
const logTag = (m) => (typeof m.tag === 'string' && /^[a-z]{1,16}$/.test(m.tag) ? m.tag : undefined);
function logCalls(conn) { return Array.from(new Set(stationCalls().concat(ownCallOk(conn.user) ? [String(conn.user.call).toUpperCase()] : []))); }
// Stations déjà contactées sous l'indicatif d'émission actuel (TX CALL) : « INDICATIF|BANDE|MODE », pour les marquer
// dans les listes des modes numériques (vert barré). Renvoyé quand le carnet ou le TX CALL change.
let workedSig = '';
// Stations déjà contactées sous le TX call en service : « INDICATIF|bande|mode » (barrées dans les listes FT, et jamais
// reprises toutes seules par la séquence automatique)
let workedCache = { sig: '', has: () => false };
const Z_KEY = Array.from({ length: 41 }, (x, i) => 'Z' + i);
const D_KEY = new Map(), G_KEY = new Map();
function workedNow() {
  const st = txCall();
  const sig = st + ':' + book.rev;
  if (workedCache.sig !== sig) {
    // Par bande puis par mode : indicatifs contactés, et pour les alertes des listes FT (comme JTDX) pays DXCC « D… »,
    // zones CQ « Z… », locators « G… » déjà contactés, pays confirmés (LoTW ou QSL papier). Sans fabriquer une chaîne
    // par QSO : un carnet de 200 000 QSO se parcourt en quelques dizaines de ms.
    const B = new Map();
    const t0 = Date.now();
    for (const q of book.qsos) {
      const sc = q.station_callsign;
      if (sc !== st && String(sc || '').toUpperCase() !== st) continue;
      let mb = B.get(q.band);
      if (!mb) B.set(q.band, (mb = new Map()));
      const md = q.submode || q.mode;
      let e = mb.get(md);
      if (!e) mb.set(md, (e = { bm: q.band + '|' + md, calls: new Set(), keys: new Set(), conf: new Set() }));
      e.calls.add(q.call);
      const d = DXCC.peekDxcc(q.call);
      if (d) {
        let dk = D_KEY.get(d.pfx);
        if (!dk) D_KEY.set(d.pfx, (dk = 'D' + d.pfx));
        e.keys.add(dk);
        if (q.lotw_qsl_rcvd === 'Y' || q.qsl_rcvd === 'Y') e.conf.add(dk);
      }
      const z = Number(q.cqz) || (d && d.cq);
      if (z >= 1 && z <= 40) e.keys.add(Z_KEY[z]);
      const gs = q.gridsquare;
      if (gs && gs.length >= 4) {
        let gk = G_KEY.get(gs);
        if (gk === undefined) { const g = gs.slice(0, 4).toUpperCase(); gk = /^[A-R]{2}\d{2}$/.test(g) ? 'G' + g : ''; if (G_KEY.size < 200000) G_KEY.set(gs, gk); }
        if (gk) e.keys.add(gk);
      }
    }
    const ent = {}, conf = {}, bms = {};
    for (const mb of B.values()) for (const e of mb.values()) {
      bms[e.bm] = Array.from(e.calls).join(' ');
      for (const k of e.keys) (ent[k] || (ent[k] = [])).push(e.bm);
      for (const k of e.conf) (conf[k] || (conf[k] = [])).push(e.bm);
    }
    const has = (call, band, mode) => { const mb = B.get(band); const e = mb && mb.get(mode); return !!e && e.calls.has(call); };
    workedCache = { sig, has, st, ent, conf, bms, ms: Date.now() - t0, json: '' };
  }
  return workedCache;
}
function isDupeNow(call, mode) {
  const f = (seq && seq.side === 'B' ? radio.freqB : radio.freq) || txFreq();
  return !!f && workedNow().has(String(call || '').toUpperCase(), LB.bandOf(f / 1e6), mode);
}
// Envoi aux pages : une seule mise en forme pour toutes (« bande|mode » → indicatifs séparés par des espaces : 3 fois
// plus court qu'une liste « INDICATIF|bande|mode »). Plusieurs changements rapprochés (QSO enregistré, puis complété
// par QRZ.com, puis noté envoyé à LoTW…) : un seul calcul et un seul envoi, au plus tôt 1,5 s après le premier.
let workedTimer = null;
function sendWorked(force, only) {
  if (only) return workedSend(only);
  if (force) { clearTimeout(workedTimer); workedTimer = null; return workedSend(); }
  if (txCall() + ':' + book.rev === workedSig || workedTimer) return;
  workedTimer = setTimeout(() => { workedTimer = null; if (txCall() + ':' + book.rev !== workedSig) workedSend(); }, 1500);
}
function workedSend(only) {
  const w = workedNow();
  workedSig = w.sig;
  if (!w.json) w.json = JSON.stringify({ t: 'worked', station: w.st, bm: w.bms, ent: w.ent, conf: w.conf });
  if (only) { if (only.open) only.send(w.json); return; }
  for (const c of ops) if (c.open) c.send(w.json);
}
const DXCC = require('./lib/dxcc.js');
let txcallsCache = { rev: -1, list: [] }; // TX call présents dans le carnet (liste du carnet)
let ftDxccCache = { k: '', v: null }; // tableau DXCC de la page FT (ft_dxcc) : dernier calcul
const IMPORT = require('./lib/adifimport.js');

// Spot vers le DX cluster (case « Spot au log » cochée à l'enregistrement du QSO, ou bouton SPOT) : envoyé sous
// l'INDICATIF DE L'OPÉRATEUR (son compte, ex. ON6DP), pas sous le TX CALL ni l'indicatif de connexion de la carte de
// bande : une courte liaison telnet au même cluster est ouverte avec cet indicatif, le spot est envoyé, puis « bye ».
// Réservé aux comptes qui émettent ; au plus 1 spot / 20 s et 30 / heure par opérateur.
// asTx : spot envoyé sous le TX call choisi par ce membre (ON5VL, OR0L… ou son propre indicatif) au lieu de son compte
function clusterSpot(conn, callIn, khzIn, cmtIn, asTx) {
  if (!conn.user.tx || conn.user.rxOnly) return send(conn, { t: 'notice', level: 'error', msg: 'Spot : réservé aux comptes autorisés à émettre' });
  if (cfg.clusterSpot === false) return send(conn, { t: 'notice', level: 'warn', msg: 'Spot non envoyé : les spots au DX cluster sont coupés sur ce serveur (instance de test)' });
  const host = String(cfg.clusterHost || '').trim();
  if (!host) return send(conn, { t: 'notice', level: 'error', msg: 'Spot impossible : DX cluster non configuré' });
  const op = String(asTx ? txCallFor(conn.user) : conn.user.call || '').toUpperCase();
  if (!/^[A-Z0-9]{1,3}[0-9][A-Z0-9]{0,4}(\/[A-Z0-9]{1,4})?$/.test(op)) return send(conn, { t: 'notice', level: 'error', msg: 'Spot : le compte ' + op + ' n’est pas un indicatif radioamateur' });
  const call = String(callIn || '').toUpperCase().trim();
  const khz = Math.round(Number(khzIn) * 10) / 10;
  if (!/^(?=.*\d)[A-Z0-9/]{3,15}$/.test(call)) return send(conn, { t: 'notice', level: 'error', msg: 'Spot : indicatif du correspondant ?' });
  if (!(khz >= 1800 && khz <= 450000)) return send(conn, { t: 'notice', level: 'error', msg: 'Spot : fréquence ?' });
  const nowS = Date.now();
  conn.user.spots = (conn.user.spots || []).filter((t) => nowS - t < 3600000);
  if (conn.user.spots.length && nowS - conn.user.spots[conn.user.spots.length - 1] < 20000) return send(conn, { t: 'notice', level: 'warn', msg: 'Spot de ' + call + ' non envoyé : un seul toutes les 20 secondes' });
  if (conn.user.spots.length >= 30) return send(conn, { t: 'notice', level: 'warn', msg: 'Spot de ' + call + ' non envoyé : 30 par heure au plus' });
  const cmt = String(cmtIn || '').replace(/[^A-Za-z0-9 +\-./:#?!]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 30);
  conn.user.spots.push(nowS);
  const line = 'DX ' + khz.toFixed(1) + ' ' + call + (cmt ? ' ' + cmt : '');
  send(conn, { t: 'notice', level: 'info', msg: 'Spot de ' + call + ' ' + khz.toFixed(1) + ' kHz en cours (de ' + op + ')…' });
  spotOnce({ host, port: Number(cfg.clusterPort) || 8000, call: op, line }).then((r) => {
    journal('spot', { call: op, ip: conn.ip, dx: call, khz, cmt, ok: r.ok, why: r.why || undefined });
    if (r.ok) send(conn, { t: 'notice', level: 'ok', msg: 'Spot envoyé au cluster de ' + op + ' : ' + call + ' ' + khz.toFixed(1) + ' kHz' + (cmt ? ' « ' + cmt + ' »' : '') });
    else send(conn, { t: 'notice', level: 'error', msg: 'Spot de ' + call + ' non envoyé : ' + (r.why || 'refus du cluster') });
  });
}
// QSO enregistré avec « Spot au log » : commentaire = mode (+ contest)
function spotOfQso(conn, q) {
  const mode = String(LB.modeName(q) || q.mode || '').toUpperCase();
  clusterSpot(conn, q.call, Number(q.freq) * 1000, (mode + (q.contest_id ? ' ' + q.contest_id : ' TNX QSO')).slice(0, 30));
}
// ---------------------------------------------------------------- PSK Reporter (rapports de réception FT8 / FT4 / FT2)
// Activé par défaut (pskReporter: false dans config.json pour le couper) ; sous digiCall et stationGrid
const PSKR = cfg.pskReporter === false ? null : new (require('./lib/pskreporter').PskReporter)({
  call: () => cfg.digiCall || cfg.stationCall || '', grid: () => cfg.stationGrid || '', software: 'RemoteStation ' + VERSION,
  antenna: () => String(cfg.pskAntenna || ''), log: (msg) => console.error(msg)
});
if (PSKR && !process.env.RS_NO_PSKR) PSKR.start();
// ---------------------------------------------------------------- DX cluster (carte de bande)
const { Cluster, spotOnce } = require('./lib/cluster.js');
let cluster = null;
let spotBatch = [];
let spotTimer = null;
let clusterState = '';
// Chaque membre peut choisir son cluster telnet (liste de lib/data/clusters.json + cfg.clusterList) pour SES spots
// (carte de bande, pages des modes) ; choix gardé par indicatif (logs/cluster-pref.json). Par défaut : le cluster du club.
// Une seule liaison par cluster, partagée par les membres qui l'ont choisi ; fermée 10 min après le départ du dernier.
const CLUSTER_PREF_FILE = path.join(LOG_DIR, 'cluster-pref.json');
let clusterPref = {};
try { clusterPref = JSON.parse(fs.readFileSync(CLUSTER_PREF_FILE, 'utf8')) || {}; } catch (e) { clusterPref = {}; }
const clusterKeyOf = (host, port) => String(host || '').trim().toLowerCase() + ':' + (Number(port) || 23);
const clusterDefKey = () => clusterKeyOf(cfg.clusterHost, Number(cfg.clusterPort) || 8000);
function clusterList() {
  let base = [];
  try { base = JSON.parse(fs.readFileSync(path.join(ROOT, 'lib', 'data', 'clusters.json'), 'utf8')); } catch (e) { base = []; }
  const extra = Array.isArray(cfg.clusterList) ? cfg.clusterList : [];
  const out = [], seen = new Set();
  const def = String(cfg.clusterHost || '').trim();
  if (def) { out.push({ name: cfg.clusterName || (/op0p\.be$/i.test(def) ? 'OP0P' : def), host: def, port: Number(cfg.clusterPort) || 8000, key: clusterDefKey(), def: true }); seen.add(clusterDefKey()); }
  for (const c of extra.concat(base)) {
    if (!c || !c.host || !/^[a-z0-9.-]{3,80}$/i.test(String(c.host))) continue;
    const port = Number(c.port) || 23;
    if (!(port > 0 && port < 65536)) continue;
    const key = clusterKeyOf(c.host, port);
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({ name: String(c.name || c.host).slice(0, 40), host: String(c.host), port, key, info: String(c.info || '').slice(0, 60) });
  }
  return out;
}
const clPool = new Map(); // clé « hôte:port » → { c: Cluster, idle: date du départ du dernier membre }
const connClusterKey = (conn) => {
  const k = conn && conn.user && clusterPref[String(conn.user.call || '').toUpperCase()];
  return k && clusterList().some((x) => x.key === k) ? k : clusterDefKey();
};
function clusterLoginCall() {
  return String(cfg.clusterCall || ((cfg.digiCall || cfg.stationCall || '') + '-7')).toUpperCase().replace(/[^A-Z0-9/-]/g, '');
}
function clusterOpen(key) {
  if (clPool.has(key)) return clPool.get(key);
  const e = clusterList().find((x) => x.key === key);
  if (!e) return null;
  const ent = { c: null, idle: 0, batch: [], timer: null };
  ent.c = new Cluster({
    host: e.host, port: e.port, call: clusterLoginCall(),
    // commandes après connexion (set/skimmer…) : seulement pour le cluster du club
    cmds: e.def && Array.isArray(cfg.clusterCmds) ? cfg.clusterCmds.map(String).filter((c) => c && c.length < 80) : [],
    log: (m) => console.log(m + (e.def ? '' : ' [' + e.name + ']')),
    onSpot: (sp) => {
      ent.batch.push(sp);
      if (ent.timer) return;
      ent.timer = setTimeout(() => {
        ent.timer = null;
        const list = ent.batch; ent.batch = [];
        const msg = JSON.stringify({ t: 'spot', list, state: ent.c.state, host: e.name });
        for (const c of ops) if (c.open && connClusterKey(c) === key) c.send(msg);
      }, 1500);
    }
  });
  ent.c.start();
  ent.state = '';
  clPool.set(key, ent);
  return ent;
}
// Spots du cluster choisi par ce membre (à la connexion et quand il change de cluster)
function sendClusterSpots(conn) {
  const key = connClusterKey(conn), ent = clusterOpen(key), e = clusterList().find((x) => x.key === key);
  send(conn, { t: 'spots', list: ent ? ent.c.list() : [], state: ent ? ent.c.state : 'non configuré', host: e ? e.name : '', key });
}
function clusterStart() {
  if (!String(cfg.clusterHost || '').trim()) return;
  const ent = clusterOpen(clusterDefKey());
  cluster = ent && ent.c;
  // état de chaque liaison annoncé quand il change ; liaisons sans membre depuis 10 min fermées (sauf celle du club)
  setInterval(() => {
    const used = new Set();
    for (const c of ops) if (c.open) used.add(connClusterKey(c));
    for (const [key, ent] of clPool) {
      if (key !== clusterDefKey() && !used.has(key)) {
        if (!ent.idle) ent.idle = Date.now();
        else if (Date.now() - ent.idle > 600000) { ent.c.stop(); clPool.delete(key); continue; }
      } else ent.idle = 0;
      if (ent.c.state === ent.state) continue;
      ent.state = ent.c.state;
      const msg = JSON.stringify({ t: 'spot', list: [], state: ent.state });
      for (const c of ops) if (c.open && connClusterKey(c) === key) c.send(msg);
    }
  }, 5000);
}
// Choix du cluster par un membre : seulement dans la liste ; « » = cluster du club
function clusterPick(conn, key) {
  const call = String(conn.user.call || '').toUpperCase();
  const list = clusterList();
  const e = key ? list.find((x) => x.key === key) : null;
  if (key && !e) return send(conn, { t: 'notice', level: 'error', msg: 'Cluster inconnu' });
  if (!e || e.def) delete clusterPref[call]; else clusterPref[call] = e.key;
  fs.writeFile(CLUSTER_PREF_FILE, JSON.stringify(clusterPref), { mode: 0o600 }, (er) => { if (er) console.error('cluster-pref.json : ' + er.message); });
  for (const c of ops) if (c.open && c.user && String(c.user.call || '').toUpperCase() === call) { sendClusterSpots(c); send(c, { t: 'cluster_list', list: list.map(({ name, key: k, info, def, host, port }) => ({ name, key: k, info, def: !!def, host, port })), cur: connClusterKey(c) }); }
  send(conn, { t: 'notice', level: 'ok', msg: 'Spots : ' + (e ? e.name + ' (' + e.host + ':' + e.port + ')' : 'cluster du club') });
}

const DX_CALL_RE = /^(?=.*\d)(?=.*[A-Z])[A-Z0-9/]{3,15}$/;
/** Ajoute à un décodage FT8 / FT4 / FT2 : cty (pays DXCC), km et az (depuis le locator de la station) ; kmc = d'après le pays seulement */
function dxInfo(d) {
  if (!d || !d.msg) return;
  const w = String(d.msg).toUpperCase().split(/\s+/).map((x) => x.replace(/^<|>$/g, ''));
  const call = w[0] === 'CQ' ? (DX_CALL_RE.test(w[1] || '') ? w[1] : w[2]) : w[1];
  if (!call || !DX_CALL_RE.test(call)) return;
  const e = DXCC.lookup(call);
  if (!e) return;
  d.cty = e.name;
  d.pfx = e.pfx; // préfixe DXCC (colonne « Préf. » des listes FT)
  const ed = DXCC.lookupDxcc(call);
  if (ed && ed.pfx !== e.pfx) d.dxp = ed.pfx; // entité DXCC (WAE ramenée à son pays) : statistiques DXCC de la page FT
  if (e.cq) d.cqz = e.cq; // zone CQ (alertes « nouvelle zone » des listes FT)
  const me = DXCC.gridLL(String(cfg.stationGrid || '').slice(0, 6));
  if (!me) return;
  const last = w[w.length - 1];
  const g = /^[A-R]{2}\d{2}$/.test(last) && last !== 'RR73' ? DXCC.gridLL(last) : null;
  const r = DXCC.distAz(me, g || { lat: e.lat, lon: e.lon });
  d.km = r.km;
  d.az = r.az;
  if (!g) d.kmc = true;
}
// Filtres par colonne du carnet : valeur d'un QSO pour chaque colonne affichée
const refsOf = (q, pre) => Object.keys(LB.REF_FIELDS).filter((k) => q[(pre || '') + k]).map((k) => LB.REF_FIELDS[k]);
const LG_COL = {
  date: (q) => q.qso_date || '', utc: (q) => String(q.time_on || '').slice(0, 2), call: (q) => q.call || '', band: (q) => q.band || '',
  mhz: (q) => (Number(q.freq) > 0 ? (Math.round(Number(q.freq) * 1000) / 1000).toFixed(3) : ''), mode: (q) => LB.modeName(q), env: (q) => q.rst_sent || '', stx: (q) => q.stx_string || q.stx || '', recu: (q) => q.rst_rcvd || '', srx: (q) => q.srx_string || q.srx || '',
  nom: (q) => q.name || '', qth: (q) => q.qth || '', loc: (q) => q.gridsquare || '', dxcc: (q) => q.country || ((DXCC.lookup(q.call) || {}).name || ''),
  pfx: (q) => (DXCC.lookupDxcc(q.call) || {}).pfx || '', ctst: (q) => q.contest_id || '',
  txc: (q) => q.station_callsign || '', op: (q) => q.operator || q.by || '',
  refs: (q) => { const a = refsOf(q), b = refsOf(q, 'my_'); return a.concat(b.map((x) => 'ma ' + x)).join(' + '); },
  lotw: (q) => lgUp(q, 'lotw'), eqsl: (q) => lgUp(q, 'eqsl'), cl: (q) => lgUp(q, 'clublog'), qrz: (q) => lgUp(q, 'qrz')
};
function lgUp(q, s) {
  if (s === 'lotw' && q.lotw_qsl_rcvd === 'Y') return 'confirmé';
  const u = q.up && q.up[s];
  return !u ? 'pas envoyé' : u.ok ? 'envoyé' : 'refusé';
}
const lgKey = (q, col) => String(LG_COL[col](q));
function lgFilter(list, f) {
  const fs = Object.entries(f && typeof f === 'object' ? f : {}).filter(([k, v]) => (LG_COL[k] || k === 'aw') && v != null && v !== '');
  if (!fs.length) return list;
  // « aw » = « DIPLÔME:clé » (case du tableau des statistiques : zone CQ 14, préfixe WPX ON4, île EU-005…)
  const aw = (q, v) => { const i = String(v).indexOf(':'); const a = String(v).slice(0, i); const d = AWARDS[a] && awardKey(q, a); return !!d && d.k === String(v).slice(i + 1); };
  return list.filter((q) => fs.every(([k, v]) => (k === 'aw' ? aw(q, v) : lgKey(q, k) === String(v))));
}
// ---------------------------------------------------------------- diplômes des statistiques du carnet (façon Swisslog)
/** Préfixe WPX d'un indicatif (règles du CQ WPX) : ON4ABC → ON4, HG19ABC → HG19, EA8/ON4ABC → EA8, K1ABC/4 → K4, PA/ON4ABC → PA0 */
function wpxPrefix(call) {
  let c = String(call || '').toUpperCase().replace(/^<|>$/g, '').trim();
  const parts = c.split('/').filter((p) => p && !/^(P|M|MM|AM|QRP|A|R|B|J|LH|T)$/.test(p));
  if (!parts.length) return '';
  const base = parts.slice().sort((a, b) => b.length - a.length)[0];
  const pre = (x) => { const m = /^(.*\d)[A-Z]*$/.exec(x); return m ? m[1] : x.slice(0, 2) + '0'; };
  if (parts.length > 1) {
    const o = parts.find((p) => p !== base) || '';
    if (/^\d$/.test(o)) { const bp = pre(base); return bp.replace(/\d+$/, '') + o; } // K1ABC/4 → K4
    if (o.length <= 4) return /\d$/.test(o) ? o : /\d/.test(o) ? pre(o) : o + '0';   // EA8/… → EA8 ; PA/… → PA0
  }
  return pre(base);
}
const CONTS = [['AF', 'Afrique'], ['AS', 'Asie'], ['EU', 'Europe'], ['NA', 'Amérique du Nord'], ['OC', 'Océanie'], ['SA', 'Amérique du Sud']];
const US_STATES = [['AL', 'Alabama'], ['AK', 'Alaska'], ['AZ', 'Arizona'], ['AR', 'Arkansas'], ['CA', 'California'], ['CO', 'Colorado'], ['CT', 'Connecticut'], ['DE', 'Delaware'], ['FL', 'Florida'], ['GA', 'Georgia'],
  ['HI', 'Hawaii'], ['ID', 'Idaho'], ['IL', 'Illinois'], ['IN', 'Indiana'], ['IA', 'Iowa'], ['KS', 'Kansas'], ['KY', 'Kentucky'], ['LA', 'Louisiana'], ['ME', 'Maine'], ['MD', 'Maryland'],
  ['MA', 'Massachusetts'], ['MI', 'Michigan'], ['MN', 'Minnesota'], ['MS', 'Mississippi'], ['MO', 'Missouri'], ['MT', 'Montana'], ['NE', 'Nebraska'], ['NV', 'Nevada'], ['NH', 'New Hampshire'], ['NJ', 'New Jersey'],
  ['NM', 'New Mexico'], ['NY', 'New York'], ['NC', 'North Carolina'], ['ND', 'North Dakota'], ['OH', 'Ohio'], ['OK', 'Oklahoma'], ['OR', 'Oregon'], ['PA', 'Pennsylvania'], ['RI', 'Rhode Island'], ['SC', 'South Carolina'],
  ['SD', 'South Dakota'], ['TN', 'Tennessee'], ['TX', 'Texas'], ['UT', 'Utah'], ['VT', 'Vermont'], ['VA', 'Virginia'], ['WA', 'Washington'], ['WV', 'West Virginia'], ['WI', 'Wisconsin'], ['WY', 'Wyoming']];
const pad2 = (n) => String(n).padStart(2, '0');
/** Diplômes : libellé, intitulé de la 1re colonne, liste complète (lignes jamais contactées) */
const AWARDS = {
  DXCC: { label: 'DXCC (pays)', col: 'Pays DXCC', all: () => DXCC.entities().map((e) => ({ k: e.pfx, name: e.name, cont: e.cont })) },
  WAZ: { label: 'WAZ (zones CQ)', col: 'Zone CQ', all: () => Array.from({ length: 40 }, (x, i) => ({ k: pad2(i + 1), name: 'Zone CQ ' + (i + 1) })) },
  ITU: { label: 'ITU (zones UIT)', col: 'Zone UIT', all: () => Array.from({ length: 90 }, (x, i) => ({ k: pad2(i + 1), name: 'Zone UIT ' + (i + 1) })) },
  WAE: { label: 'WAE (Europe)', col: 'Pays WAE', all: () => DXCC.entitiesAll().filter((e) => e.cont === 'EU').map((e) => ({ k: e.pfx, name: e.name, cont: 'EU' })) },
  WAC: { label: 'WAC (continents)', col: 'Continent', all: () => CONTS.map(([k, name]) => ({ k, name, cont: k })) },
  WAS: { label: 'WAS (États US)', col: 'État US', all: () => US_STATES.map(([k, name]) => ({ k, name, cont: 'NA' })) },
  WPX: { label: 'WPX (préfixes)', col: 'Préfixe WPX', all: () => [] },
  IOTA: { label: 'IOTA (îles)', col: 'Île IOTA', all: () => [] },
  GRID: { label: 'Locators (carrés)', col: 'Locator', all: () => [] }
};
/** Clé d'un QSO pour un diplôme : { k, name, cont } ou null (QSO qui ne compte pas) */
function awardKey(q, award) {
  const call = q.call;
  switch (award) {
    case 'DXCC': { const d = DXCC.peekDxcc(call); return d ? { k: d.pfx, name: d.name, cont: d.cont } : null; }
    case 'WAZ': { const z = Number(q.cqz) || (DXCC.peek(call) || {}).cq; return z >= 1 && z <= 40 ? { k: pad2(z), name: 'Zone CQ ' + z } : null; }
    case 'ITU': { const z = Number(q.ituz) || (DXCC.peek(call) || {}).itu; return z >= 1 && z <= 90 ? { k: pad2(z), name: 'Zone UIT ' + z } : null; }
    case 'WAE': { const e = DXCC.peek(call); return e && e.cont === 'EU' ? { k: e.pfx, name: e.name, cont: 'EU' } : null; }
    case 'WAC': { const c = String(q.cont || (DXCC.peek(call) || {}).cont || '').toUpperCase(); const x = CONTS.find((y) => y[0] === c); return x ? { k: x[0], name: x[1], cont: x[0] } : null; }
    case 'WAS': {
      const d = DXCC.peekDxcc(call);
      const st = String(q.state || '').toUpperCase().trim();
      if (!d || ['K', 'KL', 'KH6'].indexOf(d.pfx) < 0) return null;
      const x = US_STATES.find((y) => y[0] === st);
      return x ? { k: x[0], name: x[1], cont: 'NA' } : null;
    }
    case 'WPX': { const p = wpxPrefix(call); return p ? { k: p, name: (DXCC.peek(call) || {}).name || '', cont: (DXCC.peek(call) || {}).cont || '' } : null; }
    case 'IOTA': { const r = String(q.iota || '').toUpperCase().trim(); return /^[A-Z]{2}-\d{3}$/.test(r) ? { k: r, name: (DXCC.peek(call) || {}).name || '', cont: r.slice(0, 2) } : null; }
    case 'GRID': { const g = String(q.gridsquare || '').toUpperCase().slice(0, 4); return /^[A-R]{2}\d{2}$/.test(g) ? { k: g, name: (DXCC.peek(call) || {}).name || '', cont: '' } : null; }
  }
  return null;
}
// Modifier, compléter ou supprimer un QSO : administrateurs, ou l'auteur du QSO (compte qui l'a enregistré) qui a la main.
// Sans la main (membre ou écouteur) : consultation seulement ; jamais le QSO d'un autre indicatif.
function logCanEdit(conn, q) { return conn.user.admin || (!!q && !conn.user.rxOnly && q.by === conn.user.call && controller === conn); }
function logEditWhy(conn, q) {
  if (conn.user.rxOnly) return 'Indicatif d’écouteur : consultation du carnet seulement';
  if (q && q.by !== conn.user.call) return 'QSO enregistré par ' + (q.by || q.operator || '?') + ' : seul son auteur (avec la main) ou un administrateur peut le modifier ou le supprimer';
  return 'Prenez la main pour modifier ou supprimer vos QSO (sans la main : consultation seulement)';
}
// Pays DXCC du correspondant : enregistré avec le QSO (champ ADIF COUNTRY), ou calculé pour les anciens QSO
// Nouveau QSO sans nom, QTH ou locator (contest, FT8 automatique…) : complété avec la fiche QRZ.com du correspondant
// (prénom et nom, ville, locator), cases vides seulement, si un compte QRZ.com est réglé
const titleCase = (x) => String(x || '').toLowerCase().replace(/(^|[\s'-])(\p{L})/gu, (m0, a, b) => a + b.toUpperCase()).trim();
function qrzFill(q) {
  if (!q || !q.id || (q.name && q.qth && q.gridsquare) || !qrzx.configured()) return;
  qrzx.lookup(q.call).then((v) => {
    if (!v) return;
    const add = { name: titleCase([v.fname || v.nick, v.name].filter(Boolean).join(' ')).slice(0, 40), qth: String(v.qth || '').slice(0, 60), gridsquare: String(v.grid || '').toUpperCase().slice(0, 6) };
    // État US (diplôme WAS des statistiques) : seulement pour les États-Unis, Alaska et Hawaï
    const dx = DXCC.lookupDxcc(q.call);
    if (dx && ['K', 'KL', 'KH6'].indexOf(dx.pfx) >= 0 && /^[A-Z]{2}$/.test(String(v.state || '').toUpperCase())) add.state = String(v.state).toUpperCase();
    const done = book.merge(q.id, add);
    if (done && done.length) for (const c of ops) send(c, { t: 'log_changed' });
  }).catch(() => {});
}
// Log d'un contest : pays DXCC et continent du correspondant et de la station (calcul du score dans la page)
function ctstCty(q) {
  const e = DXCC.lookup(q.call) || {};
  const me = DXCC.lookup(q.station_callsign || cfg.callsign || '') || {};
  return { dx: e.pfx || '', ct: e.cont || '', mp: me.pfx || '', mc: me.cont || '', cn: q.country || e.name || '' };
}
function qsoForClient(q) {
  const o = Object.assign({}, q);
  const e = DXCC.lookup(o.call);
  if (!o.country && e) o.country = e.name;
  if (e) o.dxcc_pfx = e.pfx;
  return o;
}

// Messages entre membres (mémoire seulement, perdus au redémarrage) : discussion, demandes de main, passages de main
const chatLog = [];
function chatPush(item) {
  item.ts = Date.now();
  chatLog.push(item);
  while (chatLog.length > 40) chatLog.shift();
  for (const c of ops) send(c, { t: 'chat', m: item });
}
let connSeq = 0;
let lastCtrlActivity = 0;
// Équité de la main : depuis quand cet indicatif l'a, et avertissement en cours (voir controlMaxMinutes)
let fair = { call: '', since: 0, warnAt: 0, to: null };
/** Plus ancienne demande de main encore valable (membre toujours connecté, autre indicatif). */
function fairAsker(now) {
  let best = null;
  const valid = (Number(cfg.controlAskMinutes) || 15) * 60000;
  for (const c of ops) {
    if (!controller || c.user.call === controller.user.call || !c.lastAsk || now - c.lastAsk > valid) continue;
    if (!best || c.lastAsk < best.lastAsk) best = c;
  }
  return best;
}
/** Membre jamais déconnecté pour inactivité (idleExempt : ON6DP, ON4LUC, ON5VL par défaut). */
function idleExempt(c) {
  const l = Array.isArray(cfg.idleExempt) ? cfg.idleExempt.map((x) => String(x).toUpperCase()) : [];
  return !!(c && c.user && l.indexOf(c.user.call) >= 0);
}
/** Décompte affiché à l'opérateur qui a la main : libération sans action, déconnexion, passage de main (équité). */
function ctlTimer(now) {
  const c = controller;
  if (!c || now - (c.ctlTimerAt || 0) < 1000) return;
  c.ctlTimerAt = now;
  const busy = !!(ptt.active || radio.tx || ftxPend || cwJob || (seq && seq.on));
  let idle = cfg.controlIdleMinutes * 60000 - (now - lastCtrlActivity);
  const lim = Number(cfg.sessionIdleMinutes) * 60000;
  if (lim > 0 && !idleExempt(c)) idle = Math.min(idle, lim - (now - (c.lastActive || now)));
  const warnS = Math.max(15, Number(cfg.controlWarnSeconds) || 120);
  send(c, { t: 'ctl_timer', idle: busy ? null : Math.max(0, Math.round(idle)), busy,
    fair: fair.warnAt ? Math.max(0, Math.round(fair.warnAt + warnS * 1000 - now)) : 0, to: fair.warnAt && fair.to ? fair.to.user.call : '',
    held: fair.since ? Math.round(now - fair.since) : 0 });
}
/** Appelé toutes les 250 ms hors émission : avertit puis passe la main au demandeur après controlMaxMinutes. */
function fairCheck(now) {
  if (!controller) { fair = { call: '', since: 0, warnAt: 0, to: null }; return; }
  if (fair.call !== controller.user.call) fair = { call: controller.user.call, since: now, warnAt: 0, to: null };
  const max = Number(cfg.controlMaxMinutes) || 0;
  if (!max || now - fair.since < max * 60000) return;
  const asker = fairAsker(now);
  if (!asker) { fair.warnAt = 0; fair.to = null; return; } // personne n'attend : on peut continuer
  const warnS = Math.max(15, Number(cfg.controlWarnSeconds) || 120);
  if (!fair.warnAt) {
    fair.warnAt = now;
    fair.to = asker;
    const mins = Math.round((now - fair.since) / 60000);
    send(controller, { t: 'notice', level: 'warn', msg: asker.user.call + ' attend la main : vous l’avez depuis ' + mins + ' min. Elle lui sera passée dans ' + Math.round(warnS / 60 * 10) / 10 + ' min (après votre émission en cours).' });
    send(asker, { t: 'notice', level: 'info', msg: controller.user.call + ' a la main depuis ' + mins + ' min : elle vous sera passée dans ' + Math.round(warnS / 60 * 10) / 10 + ' min.' });
    journal('control_fair_warn', { call: controller.user.call, to: asker.user.call, minutes: mins });
    return;
  }
  if (now - fair.warnAt < warnS * 1000) return;
  if (ptt.active || radio.tx || ftxPend || cwJob) return; // émission en cours : la main passe à la fin (FT8 auto : entre deux périodes)
  const to = ops.has(fair.to) && fair.to.lastAsk ? fair.to : asker;
  const prev = controller;
  stopPtt('main passée à ' + to.user.call + ' (équité)');
  controller = to;
  to.lastAsk = 0;
  lastCtrlActivity = now;
  journal('control_take', { call: to.user.call, from: prev.user.call, reason: 'équité (' + max + ' min)' });
  chatPush({ kind: 'give', call: prev.user.call, to: to.user.call });
  send(prev, { t: 'notice', level: 'warn', msg: 'Main passée à ' + to.user.call + ' après ' + max + ' min (il l’avait demandée). Vous pourrez la redemander.' });
  send(to, { t: 'notice', level: 'warn', msg: prev.user.call + ' vous passe la main (' + max + ' min écoulées)' });
  limitPower(to, 'prise de main');
  broadcast();
}
let ptt = { active: false, conn: null, since: 0, lastBeat: 0 };
// Pendant une émission, la BF du TRX contient notre propre signal : le décodage RTTY / JTTY l'afficherait
// une deuxième fois. Rien n'est affiché pendant l'émission ni juste après (retard de la BF + fin du caractère).
let pttEndAt = 0;
const rxMuted = (tailMs) => ptt.active || Date.now() - pttEndAt < tailMs + (Number(digi.latency) || 150);
const fails = new Map(); // ip -> { n, until }

// ---------------------------------------------------------------- macros personnelles (RTTY, CW…) de chaque membre
// Comme dans FLDIGI : chaque opérateur garde ses propres messages, quel que soit le PC d'où il se connecte.
const MACROS_FILE = path.join(ROOT, 'macros.json');
let macros = {};
try { macros = JSON.parse(fs.readFileSync(MACROS_FILE, 'utf8')) || {}; } catch (e) { macros = {}; }
// Depuis 0.19.1, une macro RTTY / JTTY commençant par <TX> part tout de suite à l'émission (comme FLDIGI).
// Les macros déjà personnalisées sont mises à jour une fois : <TX> en tête, <RX> en fin (repère _tx).
{
  let changed = false;
  for (const call of Object.keys(macros)) {
    const mc = macros[call];
    if (!mc || typeof mc !== 'object' || mc._tx) continue;
    for (const mode of ['RTTY', 'JTTY']) {
      if (!Array.isArray(mc[mode])) continue;
      mc[mode] = mc[mode].map((m) => {
        const t = String((m && m.text) || '');
        if (!t.trim() || /<TX>|<RX>/i.test(t)) return m;
        return Object.assign({}, m, { text: '<TX>' + t + '<RX>' });
      });
    }
    mc._tx = 1;
    changed = true;
  }
  // Depuis 0.22.98, la CW émet aussi : les macros CW personnalisées avant (qui ne pouvaient que remplir le texte)
  // reçoivent une fois <TX> en tête, pour partir au clic comme les macros d'origine (repère _cwtx)
  for (const call of Object.keys(macros)) {
    const mc = macros[call];
    if (!mc || typeof mc !== 'object' || mc._cwtx) continue;
    if (Array.isArray(mc.CW)) {
      mc.CW = mc.CW.map((m) => {
        const t = String((m && m.text) || '');
        if (!t.trim() || /<TX>/i.test(t)) return m;
        return Object.assign({}, m, { text: '<TX>' + t });
      });
    }
    mc._cwtx = 1;
    changed = true;
  }
  if (changed) setTimeout(() => saveMacros(), 0);
}
// ---------------------------------------------------------------- profils de micro de chaque membre (phonie à distance)
// profiles.json (sur le VPS seulement) : { INDICATIF: { mics: { « nom de l'entrée son » : réglages de l'égaliseur } } }
const PROFILES_FILE = path.join(ROOT, 'profiles.json');
let profiles = {};
try { profiles = JSON.parse(fs.readFileSync(PROFILES_FILE, 'utf8')) || {}; } catch (e) { profiles = {}; }
function saveProfiles() {
  fs.writeFile(PROFILES_FILE, JSON.stringify(profiles), { mode: 0o600 }, (e) => { if (e) console.error('profiles.json : ' + e.message); });
}
const micLabel = (l) => String(l || '').replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, 120);
// Égaliseur du navigateur : 3 bandes (fréquence, gain, Q), coupe-bas, coupe-haut, gain, options du micro
function micEqClean(e) {
  if (!e || typeof e !== 'object') return null;
  const num = (v, lo, hi, d) => { const n = Number(v); return Number.isFinite(n) ? Math.max(lo, Math.min(hi, n)) : d; };
  const bands = (Array.isArray(e.bands) ? e.bands : []).slice(0, 3).map((b) => ({
    f: Math.round(num(b && b.f, 80, 4000, 1000)), g: Math.round(num(b && b.g, -15, 15, 0) * 10) / 10, q: Math.round(num(b && b.q, 0.3, 8, 1) * 100) / 100
  }));
  return {
    on: e.on !== false, bands, lo: Math.round(num(e.lo, 0, 600, 100)), hi: Math.round(num(e.hi, 1800, 4000, 2900)),
    gain: Math.round(num(e.gain, 10, 400, 100)), ns: !!e.ns, ec: !!e.ec, agc: !!e.agc, name: String(e.name || '').slice(0, 30)
  };
}
// ---------------------------------------------------------------- égaliseur paramétrique du TRX (Yaesu)
// Profil de chaque membre (profiles[INDICATIF].trx[modèle]) mis au TRX quand il prend la main ; réglage du club
// (profiles._club[modèle], lu sur le TRX la première fois ou enregistré par un administrateur) remis quand il la rend.
// profiles._eqOn : profil actuellement au TRX (gardé si le serveur redémarre, pour pouvoir remettre celui du club).
const eqs = { busy: null, seq: 0, retryAt: 0 };
const trxEqAvail = () => !!(station && station.caps.indexOf('exrw') >= 0 && rig().TRX_EQ && radio.connected);
const clubEq = () => (profiles._club && profiles._club[rig().ID]) || null;
const userEq = (call) => (profiles[call] && profiles[call].trx && profiles[call].trx[rig().ID]) || null;
const eqOn = () => (profiles._eqOn && profiles._eqOn.rig === rig().ID ? profiles._eqOn : null);
function setEqOn(v) { if (v) profiles._eqOn = v; else delete profiles._eqOn; saveProfiles(); }
function exCall(op, extra, cb) {
  const id = ++eqs.seq;
  const timer = setTimeout(() => { if (eqs.busy && eqs.busy.id === id) { eqs.busy = null; cb(null, 'la page Station n’a pas répondu'); } }, 25000);
  eqs.busy = { id, op, cb, timer };
  toStation(Object.assign({ t: 'cmd', op, id }, extra));
}
function exReply(m) {
  const b = eqs.busy;
  if (!b || b.id !== m.id) return;
  clearTimeout(b.timer);
  eqs.busy = null;
  if (m.t === 'exread_reply') b.cb(m.err ? null : m.values || {}, m.err || '');
  else b.cb(!!m.ok, m.ok ? '' : 'TRX occupé');
}
const eqTxBusy = () => ptt.active || radio.tx || ftxPend || cwJob || (seq && seq.on);
// Réglage du club lu sur le TRX avant la toute première écriture (sinon on ne pourrait jamais le remettre)
function ensureClub(cb) {
  if (clubEq()) return cb(true);
  const E = rig().TRX_EQ;
  exCall('exread', { cmds: E.read }, (vals, err) => {
    const pr = vals && E.fromValues(vals);
    if (!pr) { journal('trx_eq', { err: err || 'lecture incomplète' }); return cb(false, err || 'lecture incomplète'); }
    profiles._club = profiles._club || {};
    profiles._club[rig().ID] = pr;
    saveProfiles();
    journal('trx_eq', { club: 'lu sur le TRX', rig: rig().ID });
    if (controller) trxEqInfo(controller);
    cb(true);
  });
}
function eqTick(now) {
  if (!trxEqAvail() || eqs.busy || eqTxBusy() || now < eqs.retryAt) return;
  const E = rig().TRX_EQ;
  const on = eqOn();
  const call = controller ? controller.user.call : null;
  // Profil voulu au TRX : celui de l'opérateur qui a la main (enregistré, ou en essai), sinon celui du club
  const want = call && (userEq(call) || (on && on.call === call)) ? call : null;
  const cur = on ? on.call : null;
  if (want === cur) return;
  if (want && !(on && on.call === call)) {
    // Première fois : réglage actuel du TRX gardé comme réglage du club, pour pouvoir le remettre ensuite
    if (!clubEq()) return ensureClub((ok) => { if (!ok) eqs.retryAt = Date.now() + 60000; });
    const pr = userEq(want);
    return exCall('exwrite', { cmds: E.write(pr) }, (ok) => {
      if (!ok) { eqs.retryAt = Date.now() + 5000; return; }
      setEqOn({ call: want, rig: rig().ID });
      journal('trx_eq', { on: want, rig: rig().ID });
      if (controller && controller.user.call === want) send(controller, { t: 'notice', level: 'ok', msg: 'Votre égaliseur du TRX est en place (profil ' + want + ')' });
      broadcast();
    });
  }
  const club = clubEq();
  if (!club) { setEqOn(null); return; }
  exCall('exwrite', { cmds: E.write(club) }, (ok) => {
    if (!ok) { eqs.retryAt = Date.now() + 5000; return; }
    setEqOn(null);
    journal('trx_eq', { on: 'club', rig: rig().ID });
    broadcast();
  });
}
function trxEqInfo(conn) {
  const c = conn.user.call;
  const on = eqOn();
  send(conn, { t: 'trxeq', avail: trxEqAvail(), rig: station ? rig().ID : null, mine: station ? userEq(c) : null, club: station ? clubEq() : null, on: on ? on.call : null, admin: !!conn.user.admin });
}
// ---------------------------------------------------------------- menus du TRX (FUNC → … SETTING de la face avant)
// Lecture d'un sous-menu (EX…; un par un, ceux que le TRX refuse restent vides) ; écriture d'un réglage permis, par
// l'opérateur qui a la main, jamais pendant une émission, puis relecture. Réglages « ro » (liaison, puissance…) : jamais écrits.
function menuMsg(conn, m) {
  const M = station && rig().MENU;
  const no = (msg) => send(conn, { t: 'notice', level: 'warn', msg: 'Menu du TRX : ' + msg });
  if (!M) return no('pas disponible sur le ' + (station ? rig().NAME : 'TRX'));
  // FTX-1 : menus … SETTING réservés aux administrateurs (ON6DP, ON4LUC) — paramètres essentiels du TRX
  if (M.admin && !conn.user.admin) return no('réservé aux administrateurs (ON6DP, ON4LUC)');
  if (station.caps.indexOf('exrw') < 0 || !radio.connected) return no('page Station du club à recharger, ou TRX non relié');
  const quiet = !!m.quiet; // relecture automatique de la page (FTX-1) : ni message, ni lecture si occupé ou en émission
  const read = (ids, cb) => {
    if (eqs.busy || (quiet && eqTxBusy())) return quiet ? send(conn, { t: 'menu_vals', values: {}, ids: [], quiet: true }) : no('lecture ou écriture déjà en cours, un instant');
    exCall('exread', { cmds: ids.map((i) => (/^DT[01]$/.test(i) ? i : 'EX' + i) + ';'), soft: true }, (vals, err) => {
      send(conn, { t: 'menu_vals', values: vals || {}, ids, err: quiet ? '' : err || '', quiet });
      if (cb) cb();
    });
  };
  if (m.t === 'menu_read') {
    const g = M.groups.find((x) => x.id === String(m.sub || ''));
    if (!g) return;
    const ids = [];
    for (const it of g.items) {
      if (it.d.src) { if (ids.indexOf(it.d.src) < 0) ids.push(it.d.src); } // date / heure du TRX (DT0 / DT1)
      else if (it.d.k !== 't' || it.d.read) ids.push(it.id);
    }
    return read(ids);
  }
  // FTX-1 : date et heure du TRX mises à celles du PC de l'administrateur (DT0 aaaammjj, DT1 hhmmss, heure locale)
  if (m.t === 'menu_dt') {
    if (!M.admin || rig().ID !== 'ftx1') return;
    if (controller !== conn) return no('prenez d’abord la main');
    const d = String(m.date || ''), h = String(m.time || '');
    if (!/^20\d{2}(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])$/.test(d) || !/^([01]\d|2[0-3])[0-5]\d[0-5]\d$/.test(h)) return no('date ou heure refusée');
    if (eqTxBusy()) return no('pas pendant une émission');
    if (eqs.busy) return no('lecture ou écriture déjà en cours, un instant');
    journal('trx_menu', { by: conn.user.call, id: 'DT', label: 'DATE&TIME', v: d + ' ' + h });
    return exCall('exwrite', { cmds: ['DT0' + d + ';', 'DT1' + h + ';'] }, (ok, err) => {
      if (!ok) return no('date / heure : ' + (err || 'pas écrites'));
      setTimeout(() => read(['DT0', 'DT1']), 600);
    });
  }
  const it = M.item(String(m.id || ''));
  if (!it) return;
  if (controller !== conn) return no('prenez d’abord la main');
  if (it.d.ro) return no(it.label + ' : ' + it.d.ro);
  if (!M.ok(it.d, m.v)) return no(it.label + ' : valeur refusée');
  if (eqTxBusy()) return no('pas pendant une émission');
  if (eqs.busy) return no('lecture ou écriture déjà en cours, un instant');
  journal('trx_menu', { by: conn.user.call, id: it.id, label: it.label, v: String(m.v) });
  exCall('exwrite', { cmds: ['EX' + it.id + String(m.v) + ';'] }, (ok, err) => {
    if (!ok) return no(it.label + ' : ' + (err || 'pas écrit'));
    setTimeout(() => read([it.id]), 500); // relecture : si le TRX a refusé (« ?; »), la page retrouve la vraie valeur
  });
}
// FTX-1 : mémoires DTMF 1 à 10 (FUNC → DTMF, écran DTMF CODE) = menus EX010328 à EX010337 (RADIO SETTING → MODE FM,
// manuel CAT FTX-1, Table 3) : 0-9, A-D, *, #, « - » (espace), 16 caractères au plus. Lecture pour tous ; écriture par
// l'opérateur qui a la main, jamais pendant une émission. Les tonalités DTMF elles-mêmes ne passent pas par le CAT (rien n'est émis).
const DTMF_IDS = Array.from({ length: 10 }, (_, i) => '0103' + (28 + i));
function dtmfMsg(conn, m) {
  const no = (msg) => send(conn, { t: 'notice', level: 'warn', msg: 'DTMF : ' + msg });
  if (!station || rig().ID !== 'ftx1') return no('pas disponible sur le ' + (station ? rig().NAME : 'TRX'));
  if (station.caps.indexOf('exrw') < 0 || !radio.connected) return no('page Station du club à recharger, ou TRX non relié');
  if (eqs.busy) return no('lecture ou écriture déjà en cours, un instant');
  const read = () => exCall('exread', { cmds: DTMF_IDS.map((i) => 'EX' + i + ';'), soft: true }, (vals, err) => {
    const mem = DTMF_IDS.map((i) => (vals && vals[i] != null ? String(vals[i]) : null));
    send(conn, { t: 'dtmf_vals', mem, err: err || '' });
  });
  if (m.t === 'dtmf_read') return read();
  const n = Number(m.n), v = String(m.v || '').toUpperCase();
  if (!(n >= 1 && n <= 10)) return;
  if (controller !== conn) return no('prenez d’abord la main');
  if (!/^[0-9A-D*#-]{1,16}$/.test(v)) return no('code refusé (0-9, A-D, *, #, espace ; 16 caractères au plus ; une mémoire vide s’efface au TRX)');
  if (eqTxBusy()) return no('pas pendant une émission');
  journal('trx_menu', { by: conn.user.call, id: DTMF_IDS[n - 1], label: 'DTMF MEMORY' + n, v });
  exCall('exwrite', { cmds: ['EX' + DTMF_IDS[n - 1] + v + ';'] }, (ok, err) => {
    if (!ok) return no('mémoire ' + n + ' : ' + (err || 'pas écrite'));
    setTimeout(() => { if (!eqs.busy) read(); }, 500); // relecture : la page retrouve ce que le TRX a vraiment gardé
  });
}
function trxEqMsg(conn, m) {
  const c = conn.user.call;
  const E = station && rig().TRX_EQ;
  const no = (msg) => send(conn, { t: 'notice', level: 'warn', msg: 'Égaliseur du TRX : ' + msg });
  if (m.t === 'trxeq_get') return trxEqInfo(conn);
  if (!E || !trxEqAvail()) return no(station && station.caps.indexOf('exrw') < 0 ? 'page Station du club à recharger' : 'pas disponible sur le ' + (station ? rig().NAME : 'TRX'));
  if (m.t === 'trxeq_save' || m.t === 'trxeq_club') {
    const pr = E.clean(m.profile);
    if (!pr) return;
    if (m.t === 'trxeq_club') {
      if (!conn.user.admin) return no('réservé aux administrateurs');
      profiles._club = profiles._club || {};
      profiles._club[rig().ID] = pr;
      if (!eqOn()) setEqOn({ call: '#club', rig: rig().ID }); // remis au TRX au prochain passage (personne n'a son profil en place)
      journal('trx_eq', { club: 'enregistré par ' + c, rig: rig().ID });
    } else {
      const p = profiles[c] = profiles[c] || {};
      p.trx = p.trx || {};
      p.trx[rig().ID] = pr;
      // Opérateur qui a la main : le profil enregistré est (re)mis au TRX au prochain passage d'eqTick
      if (controller === conn) setEqOn({ call: '#reapply', rig: rig().ID });
    }
    saveProfiles();
    send(conn, { t: 'notice', level: 'ok', msg: m.t === 'trxeq_club' ? 'Réglage du club enregistré pour le ' + rig().NAME : '« Profil de ' + c + ' » enregistré : mis au TRX chaque fois que vous prenez la main' });
    return trxEqInfo(conn);
  }
  if (m.t === 'trxeq_del') {
    if (profiles[c] && profiles[c].trx) { delete profiles[c].trx[rig().ID]; saveProfiles(); }
    return trxEqInfo(conn);
  }
  if (controller !== conn) return no('prenez d’abord la main');
  if (eqs.busy) return no('lecture ou écriture déjà en cours, un instant');
  if (eqTxBusy()) return no('pas pendant une émission');
  if (m.t === 'trxeq_read') {
    return exCall('exread', { cmds: E.read }, (vals, err) => {
      const pr = vals && E.fromValues(vals);
      if (!pr) return no('lecture impossible (' + (err || 'réponses incomplètes') + ')');
      send(conn, { t: 'trxeq_values', profile: pr });
    });
  }
  if (m.t === 'trxeq_try') {
    const cmds = E.write(m.profile);
    if (!cmds) return;
    return ensureClub((okc, err) => {
      if (!okc) return no('réglage du club illisible (' + err + ') : essai annulé');
      if (controller !== conn || eqTxBusy()) return no('essai annulé (main perdue ou émission en cours)');
      exCall('exwrite', { cmds }, (ok) => {
        if (!ok) return no('TRX occupé, réessayez');
        setEqOn({ call: c, rig: rig().ID });
        send(conn, { t: 'notice', level: 'ok', msg: 'Égaliseur envoyé au TRX (le réglage du club sera remis quand vous rendrez la main)' });
        broadcast();
      });
    });
  }
}
// ---------------------------------------------------------------- mémoires vocales T1 … T8 de chaque membre (VOICE TX de la face avant)
// L'IC-7300 garde les siennes sur une carte SD : à distance, elles sont enregistrées au micro de l'opérateur (page Face avant)
// et gardées ici, dossier voicemem/ (µ-law 12 kHz, 30 s au plus) ; le serveur les émet lui-même en phonie, au rythme réel.
const VM_DIR = path.join(ROOT, 'voicemem');
const VM_MAX = 30 * 12000; // 30 s
const VM_FRAME = 240;      // 20 ms à 12 kHz
const vmSafe = (call) => String(call || '').toUpperCase().replace(/[^A-Z0-9]/g, '_').slice(0, 20);
function vmMeta(call) {
  let m = null;
  try { m = JSON.parse(fs.readFileSync(path.join(VM_DIR, vmSafe(call) + '.json'), 'utf8')); } catch (e) { m = null; }
  m = m && typeof m === 'object' ? m : {};
  const t = Array.isArray(m.t) ? m.t : [];
  return { t: Array.from({ length: 8 }, (_, i) => ({ name: String((t[i] && t[i].name) || '').slice(0, 16), ms: Math.max(0, Number(t[i] && t[i].ms) || 0) })),
    level: Number.isFinite(m.level) ? Math.max(0, Math.min(255, m.level)) : 128, mon: m.mon === 0 ? 0 : 1, rep: Number.isFinite(m.rep) ? Math.max(1, Math.min(15, m.rep)) : 5 };
}
function vmSave(call, m) {
  try { fs.mkdirSync(VM_DIR, { recursive: true, mode: 0o700 }); } catch (e) { /* */ }
  fs.writeFile(path.join(VM_DIR, vmSafe(call) + '.json'), JSON.stringify(m), { mode: 0o600 }, (e) => { if (e) console.error('voicemem : ' + e.message); });
}
const vmFile = (call, n) => path.join(VM_DIR, vmSafe(call) + '-T' + n + '.ul');
function vmSend(conn) { send(conn, { t: 'vm', meta: vmMeta(conn.user.call), tts: ttsGet(conn.user.call), ttsVoices: TTS.kokoroVoices().concat(TTS.piperVoices()), playing: vmPlay && vmPlay.conn === conn ? { n: vmPlay.n, rep: !!vmPlay.rep } : null }); }
// Messages vocaux en anglais fabriqués par espeak-ng (lib/tts.js) : texte, voix et vitesse gardés pour chaque mémoire
// (voicemem/<INDICATIF>-tts.json) ; l'indicatif dit est toujours le TX call de l'opérateur : refaits quand il change
const TTS = require('./lib/tts');
const ttsFile = (call) => path.join(VM_DIR, vmSafe(call) + '-tts.json');
function ttsGet(call) { try { const o = JSON.parse(fs.readFileSync(ttsFile(call), 'utf8')); return o && typeof o === 'object' ? o : {}; } catch (e) { return {}; } }
function ttsPut(call, o) { try { fs.mkdirSync(VM_DIR, { recursive: true, mode: 0o700 }); fs.writeFileSync(ttsFile(call), JSON.stringify(o), { mode: 0o600 }); } catch (e) { console.error('tts : ' + e.message); } }
// Prononciations de l'opérateur { mot: dit comme } : 60 au plus, gardées avec le message
const ttsPron = (o) => (o && typeof o === 'object' && !Array.isArray(o) ? Object.fromEntries(Object.entries(o).slice(0, 60).map(([k, v]) => [String(k).slice(0, 40), String(v).slice(0, 60)])) : undefined);
const ttsBusy = new Map(); // indicatif → Promise en cours (une fabrication à la fois par opérateur)
function ttsMake(conn, items, quiet) {
  const call = conn.user.call;
  const run = async () => {
    const tc = txCallFor(conn.user);
    const store = ttsGet(call);
    const meta = vmMeta(call);
    let ok = 0;
    for (const it of items) {
      const n = Math.round(Number(it.n));
      if (!(n >= 1 && n <= 8)) continue;
      if (vmPlay && vmPlay.conn.user.call === call && vmPlay.n === n) continue; // en cours d'émission : au prochain changement
      try {
        const r = await TTS.synth(it.text, tc, { voice: it.voice, speed: it.speed, gap: it.gap, pron: it.pron });
        const data = r.data.subarray(0, VM_MAX);
        fs.mkdirSync(VM_DIR, { recursive: true, mode: 0o700 });
        fs.writeFileSync(vmFile(call, n), data, { mode: 0o600 });
        meta.t[n - 1].ms = Math.round(data.length / 12);
        if (it.name != null) meta.t[n - 1].name = String(it.name || '').replace(/[^\x20-\x7E]/g, '').slice(0, 16);
        store[n] = { text: String(it.text).slice(0, 300), voice: it.voice || 'en-us', speed: Number(it.speed) || 160, gap: Number.isFinite(Number(it.gap)) ? Number(it.gap) : 70, pron: ttsPron(it.pron), call: tc };
        ok++;
      } catch (e) {
        send(conn, { t: 'notice', level: 'error', msg: 'T' + n + ' : ' + e.message });
        break;
      }
    }
    ttsPut(call, store);
    // Noms et durées : écrits d'un coup (vmSave écrit en différé, vmSend relit le fichier)
    if (ok) { try { fs.writeFileSync(path.join(VM_DIR, vmSafe(call) + '.json'), JSON.stringify(meta), { mode: 0o600 }); } catch (e) { console.error('voicemem : ' + e.message); } }
    if (ok && !quiet) send(conn, { t: 'notice', level: 'ok', msg: ok + ' mémoire(s) vocale(s) de synthèse pour ' + tc + '.' });
    else if (ok) send(conn, { t: 'notice', level: 'info', msg: 'Mémoires vocales refaites pour le TX call ' + tc + '.' });
    vmSend(conn);
  };
  const prev = ttsBusy.get(call) || Promise.resolve();
  const p = prev.then(run, run).finally(() => { if (ttsBusy.get(call) === p) ttsBusy.delete(call); });
  ttsBusy.set(call, p);
  return p;
}
// TX call changé : les messages fabriqués avec l'ancien indicatif sont refaits
function ttsRefresh(conn) {
  const store = ttsGet(conn.user.call), tc = txCallFor(conn.user);
  const items = Object.keys(store).filter((n) => store[n] && store[n].call !== tc).map((n) => Object.assign({ n: Number(n) }, store[n]));
  return items.length ? ttsMake(conn, items, true) : Promise.resolve();
}
// Lecture en cours : { conn, n, buf, tab (gain TX LEVEL), pos, t0, rep, since, wait }
let vmPlay = null;
function vmTable(level) {
  // TX LEVEL 0 – 255 : 128 = niveau de l'enregistrement ; table µ-law → µ-law
  const g = level / 128, tab = new Uint8Array(256);
  for (let i = 0; i < 256; i++) { const one = new Uint8Array([0x03, i]), v = ULAW.decodeFrame(one); tab[i] = ULAW.encodeFrame([Math.max(-1, Math.min(1, v[0] * g))], 12000, 0x05)[1]; }
  return tab;
}
function vmStop(reason, quiet) {
  const p = vmPlay;
  if (!p) return;
  vmPlay = null;
  clearInterval(p.timer); clearTimeout(p.wait);
  if (ptt.active && ptt.conn === p.conn && ptt.vm) { stopPtt(reason || 'relâché'); p.conn.needRelease = false; }
  if (!quiet && p.conn.open !== false) send(p.conn, { t: 'notice', level: 'info', msg: 'VOICE TX T' + p.n + ' : ' + (reason || 'fin') });
  if (p.conn.open !== false) vmSend(p.conn);
}
function vmStart(conn, n, rep) {
  const call = conn.user.call, meta = vmMeta(call);
  let buf;
  try { buf = fs.readFileSync(vmFile(call, n)); } catch (e) { buf = null; }
  if (!buf || !buf.length) return send(conn, { t: 'notice', level: 'warn', msg: 'T' + n + ' : mémoire vide (MENU → VOICE → REC/SET → REC pour l’enregistrer)' });
  if (controller !== conn) return send(conn, { t: 'notice', level: 'error', msg: 'Prenez la main pour émettre' });
  if (ptt.active || ftxPend || (seq && seq.on) || vmPlay) return send(conn, { t: 'notice', level: 'error', msg: 'VOICE TX refusé : émission déjà en cours ou prévue' });
  vmPlay = { conn, n, buf, tab: vmTable(meta.level), rep: !!rep, repS: meta.rep, mon: !!meta.mon, since: Date.now() };
  vmGo();
}
function vmGo() {
  const p = vmPlay;
  if (!p) return;
  // Mêmes contrôles que la phonie (main, bandes, puissance, VOX, ROS…) : startPtt les fait
  startPtt(p.conn, true);
  if (!ptt.active || ptt.conn !== p.conn || !ptt.voice) { vmPlay = null; return vmSend(p.conn); }
  ptt.vm = true;
  journal('voicetx', { call: p.conn.user.call, ip: p.conn.ip, freq: txFreq(), watts: radio.power, mem: p.n, local: 1 });
  p.pos = 0; p.t0 = Date.now() + 250; // un peu d'avance : la page Station met la modulation sur USB
  vmSend(p.conn);
  p.timer = setInterval(() => {
    if (vmPlay !== p) return clearInterval(p.timer);
    if (!ptt.active || ptt.conn !== p.conn) { vmPlay = null; clearInterval(p.timer); return vmSend(p.conn); } // émission coupée (ROS, durée, main…)
    const now = Date.now();
    ptt.lastBeat = now; lastCtrlActivity = now;
    const due = Math.floor((now - p.t0) / 20);
    // 8 trames (160 ms) d'avance : la page Station a de quoi absorber les à-coups du réseau sans trou dans la modulation
    while (p.pos < p.buf.length && p.pos / VM_FRAME < due + 8) {
      const len = Math.min(VM_FRAME, p.buf.length - p.pos), fr = Buffer.alloc(len + 1);
      fr[0] = 0x05;
      for (let i = 0; i < len; i++) fr[i + 1] = p.tab[p.buf[p.pos + i]];
      p.pos += len;
      if (station && station.conn.backlog < 262144) { station.conn.send(fr); ptt.voiceFrames = (ptt.voiceFrames || 0) + 1; }
      if (p.mon && p.conn.open) { const mf = Buffer.from(fr); mf[0] = 0x03; p.conn.send(mf); } // Auto Monitor : l'opérateur s'entend
    }
    if (p.pos >= p.buf.length && now - p.t0 > p.buf.length / 12 + 300) {
      clearInterval(p.timer);
      // Fin de la mémoire : retour en réception ; en répétition, nouvel envoi après Repeat Time, 2 minutes au plus
      stopPtt('mémoire vocale terminée'); p.conn.needRelease = false;
      if (p.rep && Date.now() - p.since + p.repS * 1000 + p.buf.length / 12 < 120000) { p.wait = setTimeout(() => { if (vmPlay === p) vmGo(); }, p.repS * 1000); vmSend(p.conn); }
      else vmStop(p.rep ? 'répétition arrêtée (2 minutes au plus)' : 'fin', !p.rep);
    }
  }, 20);
}
function onVm(conn, m) {
  const call = conn.user.call, n = Math.round(Number(m.n));
  const okN = n >= 1 && n <= 8;
  switch (m.t) {
    case 'vm_list': TTS.kokoroWarm(); return vmSend(conn); // page TRX SSB ouverte : Kokoro chargé d'avance
    case 'vm_put': {
      // Enregistrement envoyé en morceaux (36 ko, 48 ko en base64 : sous la limite de 64 ko d'un message) : { n, i, total, d (base64) }
      if (!okN || !conn.user.tx) return send(conn, { t: 'notice', level: 'warn', msg: 'Votre compte est en écoute seule : pas de mémoire vocale' });
      const i = Number(m.i), total = Number(m.total);
      if (!(total >= 1 && total <= 12 && i >= 0 && i < total)) return;
      if (i === 0 || !conn.vmUp || conn.vmUp.n !== n) conn.vmUp = { n, parts: [] };
      const part = Buffer.from(String(m.d || ''), 'base64');
      if (part.length > 49152) { conn.vmUp = null; return; }
      conn.vmUp.parts[i] = part;
      if (i !== total - 1) return;
      const all = Buffer.concat(conn.vmUp.parts.filter(Boolean)).subarray(0, VM_MAX);
      conn.vmUp = null;
      if (vmPlay && vmPlay.conn.user.call === call && vmPlay.n === n) vmStop('enregistrement remplacé', true);
      try { fs.mkdirSync(VM_DIR, { recursive: true, mode: 0o700 }); fs.writeFileSync(vmFile(call, n), all, { mode: 0o600 }); } catch (e) { return send(conn, { t: 'notice', level: 'error', msg: 'T' + n + ' : enregistrement impossible sur le serveur' }); }
      const meta = vmMeta(call); meta.t[n - 1].ms = Math.round(all.length / 12); vmSave(call, meta);
      { const st = ttsGet(call); if (st[n]) { delete st[n]; ttsPut(call, st); } } // enregistrée au micro : plus un message fabriqué
      send(conn, { t: 'notice', level: 'ok', msg: 'T' + n + ' enregistrée (' + (all.length / 12000).toFixed(1) + ' s)' });
      return vmSend(conn);
    }
    case 'vm_get': {
      // Écoute de la mémoire dans la page (▶ du VOICE TX RECORD)
      if (!okN) return;
      let buf;
      try { buf = fs.readFileSync(vmFile(call, n)); } catch (e) { buf = Buffer.alloc(0); }
      const total = Math.max(1, Math.ceil(buf.length / 45000));
      const tag = m.tag === 'ssb' ? 'ssb' : undefined; // page TRX SSB : la face avant ne la joue pas aussi
      for (let i = 0; i < total; i++) send(conn, { t: 'vm_data', n, i, total, tag, d: buf.subarray(i * 45000, (i + 1) * 45000).toString('base64') });
      return;
    }
    case 'vm_del': {
      if (!okN) return;
      try { fs.unlinkSync(vmFile(call, n)); } catch (e) { /* */ }
      const meta = vmMeta(call); meta.t[n - 1].ms = 0; vmSave(call, meta);
      { const st = ttsGet(call); if (st[n]) { delete st[n]; ttsPut(call, st); } }
      return vmSend(conn);
    }
    case 'vm_name': {
      if (!okN) return;
      const meta = vmMeta(call); meta.t[n - 1].name = String(m.name || '').replace(/[^\x20-\x7E]/g, '').slice(0, 16); vmSave(call, meta);
      return vmSend(conn);
    }
    case 'vm_set': {
      const meta = vmMeta(call);
      if (m.level != null && Number.isFinite(Number(m.level))) meta.level = Math.max(0, Math.min(255, Math.round(Number(m.level))));
      if (m.mon != null) meta.mon = m.mon ? 1 : 0;
      if (m.rep != null && Number.isFinite(Number(m.rep))) meta.rep = Math.max(1, Math.min(15, Math.round(Number(m.rep))));
      vmSave(call, meta);
      if (vmPlay && vmPlay.conn === conn) { vmPlay.tab = vmTable(meta.level); vmPlay.mon = !!meta.mon; vmPlay.repS = meta.rep; } // TX LEVEL réglé pendant l'émission
      return vmSend(conn);
    }
    case 'vm_tts': {
      // Messages vocaux en anglais (page TRX SSB) : [{ n, text, name, voice, speed }] ; l'indicatif est le TX call
      if (!conn.user.tx) return send(conn, { t: 'notice', level: 'warn', msg: 'Votre compte est en écoute seule : pas de mémoire vocale' });
      const items = (Array.isArray(m.items) ? m.items : []).slice(0, 8).filter((it) => it && typeof it.text === 'string' && it.text.trim());
      if (!items.length) return;
      ttsMake(conn, items, false);
      return;
    }
    case 'vm_tts_try': {
      // Essai d'une voix (rien n'est émis ni gardé) : le son revient à la page qui l'a demandé
      if (typeof m.text !== 'string' || !m.text.trim()) return;
      if (conn.ttsTryAt && Date.now() - conn.ttsTryAt < 1500) return;
      conn.ttsTryAt = Date.now();
      TTS.synth(m.text, txCallFor(conn.user), { voice: m.voice, speed: m.speed, gap: m.gap, pron: ttsPron(m.pron) })
        .then((r) => send(conn, { t: 'tts_audio', d: r.data.subarray(0, 12000 * 15).toString('base64'), words: r.words }))
        .catch((e) => send(conn, { t: 'notice', level: 'error', msg: 'Voix : ' + e.message }));
      return;
    }
    case 'vm_tts_del': {
      // Mémoire redevenue « enregistrée au micro » ou effacée : plus refaite au changement de TX call
      if (!okN) return;
      const st = ttsGet(call); delete st[n]; ttsPut(call, st);
      return vmSend(conn);
    }
    case 'vm_play': {
      if (!okN) return;
      // Message fabriqué avec un autre indicatif que le TX call actuel : refait d'abord
      const st = ttsGet(call)[n];
      if (st && st.call !== txCallFor(conn.user)) return ttsMake(conn, [Object.assign({ n }, st)], true).then(() => vmStart(conn, n, !!m.rep));
      return vmStart(conn, n, !!m.rep);
    }
    case 'vm_stop': if (vmPlay && vmPlay.conn === conn) vmStop('arrêtée'); return;
  }
}
// Main perdue, station ou TRX hors ligne : la lecture s'arrête
setInterval(() => { if (vmPlay && (controller !== vmPlay.conn || !station || !radio.connected || vmPlay.conn.open === false)) vmStop('main perdue ou station hors ligne'); }, 500);
function saveMacros() {
  fs.writeFile(MACROS_FILE, JSON.stringify(macros), { mode: 0o600 }, (e) => { if (e) console.error('macros.json : ' + e.message); });
}
function setMacros(call, mode, list) {
  if (['RTTY', 'RTTYC', 'CW', 'CWC', 'FT8', 'JTTY'].indexOf(mode) < 0 || !Array.isArray(list)) return false; // RTTYC / CWC : macros contest RTTY / CW
  const clean = list.slice(0, 24).map((m) => ({
    name: String((m && m.name) || '').replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, 14),
    text: String((m && m.text) || '').replace(/\r/g, '').replace(/[\u0000-\u0009\u000b-\u001f]/g, ' ').slice(0, 600)
  }));
  macros[call] = Object.assign({}, macros[call], { [mode]: clean, _tx: 1, _cwtx: 1 });
  saveMacros();
  return true;
}

// ---------------------------------------------------------------- sessions mémorisées (« rester connecté »)
// Seule l'empreinte SHA-256 du jeton de session est gardée (sessions.json) : le fichier ne permet pas de se connecter.
const SESS_FILE = path.join(ROOT, 'sessions.json');
let sessions = {};
try { sessions = JSON.parse(fs.readFileSync(SESS_FILE, 'utf8')) || {}; } catch (e) { sessions = {}; }
let sessSaveTimer = null;
function saveSessions() {
  clearTimeout(sessSaveTimer);
  sessSaveTimer = setTimeout(() => {
    const now = Date.now();
    for (const h in sessions) if (!sessions[h] || sessions[h].exp < now) delete sessions[h];
    fs.writeFile(SESS_FILE, JSON.stringify(sessions), { mode: 0o600 }, (e) => { if (e) console.error('sessions.json : ' + e.message); });
  }, 500);
}
const sessHash = (tok) => crypto.createHash('sha256').update(String(tok)).digest('hex');
function newSession(call) {
  if (!(cfg.rememberDays > 0)) return null;
  const tok = crypto.randomBytes(32).toString('base64url');
  sessions[sessHash(tok)] = { call, exp: Date.now() + cfg.rememberDays * 86400000 };
  saveSessions();
  return tok;
}
function dropSession(conn) {
  if (conn.sessHash && sessions[conn.sessHash]) { delete sessions[conn.sessHash]; saveSessions(); }
  conn.sessHash = null;
}

// Empreinte du programme de la page Station (page, pilotes des TRX) : après une mise à jour du serveur, la page Station
// ouverte au club la compare à celle qu'elle a chargée et se recharge toute seule si le programme a changé
// (sinon elle continuerait à envoyer au TRX les commandes de l'ancienne version).
let catAsk = null; // dernière lecture CAT demandée par un administrateur (réponse renvoyée à lui seul)
let stationBounce = null; // rechargement à distance d'une ancienne page Station en cours
const STATION_CODE = (() => {
  const h = crypto.createHash('sha256');
  for (const f of ['station.html', 'js/station.js', 'js/station-core.js', 'js/yaesu.js', 'js/ftx1.js', 'js/ftdx10.js', 'js/ftdx101.js', 'js/ftdx5000.js', 'js/ic7300.js', 'js/ic7760.js', 'js/rigs-catalog.js', 'js/ulaw.js', 'js/ftxenc.js', 'js/ftx-enc.wasm']) {
    try { h.update(fs.readFileSync(path.join(PUB, f))); } catch (e) { h.update(f); }
  }
  return h.digest('hex').slice(0, 16);
})();

// ---------------------------------------------------------------- page Station réservée aux administrateurs
// /station (et son programme) n'est envoyée qu'à un navigateur connecté avec un compte administrateur
// (indicatif + mot de passe) ; cookie HttpOnly valable un an sur le PC du club, renouvelé à chaque ouverture.
// Seule l'empreinte du cookie est gardée (logs/station-sessions.json). Le jeton de station reste exigé pour se brancher.
const ST_COOKIE = 'rs_station';
const ST_DAYS = 365;
const ST_GATED = ['station.html', 'js/station.js', 'js/station-core.js', 'outils/assistant-carte-son.zip'];
// Chemin comparé tel que le système de fichiers le comprend (Windows : majuscules, points et espaces finaux ignorés)
const pubKey = (fp) => path.relative(PUB, fp).split(path.sep).map((x) => x.replace(/[. ]+$/, '')).join('/').toLowerCase();
const ST_FILE = path.join(LOG_DIR, 'station-sessions.json');
let stSess = {};
try { stSess = JSON.parse(fs.readFileSync(ST_FILE, 'utf8')) || {}; } catch (e) { stSess = {}; }
function saveStSess() {
  const now = Date.now();
  for (const h in stSess) if (!stSess[h] || stSess[h].exp < now) delete stSess[h];
  fs.writeFile(ST_FILE, JSON.stringify(stSess), { mode: 0o600 }, (e) => { if (e) console.error('station-sessions.json : ' + e.message); });
}
function readCookie(req, name) {
  const m = new RegExp('(?:^|;\\s*)' + name + '=([A-Za-z0-9_-]{20,100})').exec(req.headers.cookie || '');
  return m ? m[1] : '';
}
const isHttps = (req) => !!(req.socket && req.socket.encrypted) || /^https$/i.test(String(req.headers['x-forwarded-proto'] || ''));
function stCookie(req, val, maxAge) {
  return ST_COOKIE + '=' + val + '; Path=/; Max-Age=' + maxAge + '; HttpOnly; SameSite=Strict' + (isHttps(req) ? '; Secure' : '');
}
/** Administrateur connecté à la page Station sur ce navigateur ? → { call } ou null */
function stationAdmin(req) {
  const tok = readCookie(req, ST_COOKIE);
  if (!tok) return null;
  const h = sessHash(tok);
  const s = stSess[h];
  const now = Date.now();
  // Session ouverte par le jeton de station : valable tant que le jeton n'a pas changé
  if (s && s.token && s.exp > now) {
    if (s.exp - now < (ST_DAYS - 1) * 86400000) { s.exp = now + ST_DAYS * 86400000; saveStSess(); }
    return { call: 'STATION' };
  }
  const rec = s && s.exp > now ? auth.loadUsers(USERS_FILE)[s.call] : null;
  if (!rec || auth.userOff(rec) || !rec.admin) {
    if (s) { delete stSess[h]; saveStSess(); }
    return null;
  }
  if (s.exp - now < (ST_DAYS - 1) * 86400000) { s.exp = now + ST_DAYS * 86400000; saveStSess(); }
  return { call: s.call };
}
function readBody(req, max) {
  return new Promise((resolve) => {
    let b = '';
    let over = false;
    req.on('data', (c) => { b += c; if (b.length > max) { over = true; req.destroy(); } });
    req.on('end', () => resolve(over ? null : b));
    req.on('error', () => resolve(null));
  });
}
function sendStationLogin(res, msg, code) {
  fs.readFile(path.join(PUB, 'station-login.html'), 'utf8', (err, html) => {
    if (err) { res.writeHead(500); return res.end(); }
    res.writeHead(code || 200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'no-referrer', 'X-Frame-Options': 'DENY' });
    res.end(html.replace('<!--MSG-->', msg ? '<p class="st-bad" role="alert">' + msg + '</p>' : ''));
  });
}
async function stationLoginPost(req, res) {
  const ip = clientIp(req);
  const origin = req.headers.origin;
  let badOrigin = false;
  try { badOrigin = !!origin && origin !== 'null' && new URL(origin).host !== req.headers.host; } catch (e) { badOrigin = true; }
  if (badOrigin) { res.writeHead(403); return res.end(); }
  const body = await readBody(req, 2048);
  if (body == null) { res.writeHead(413); return res.end(); }
  const f = new URLSearchParams(body);
  const now = Date.now();
  const fl = fails.get(ip);
  if (fl && fl.until > now) return sendStationLogin(res, 'Trop d’essais, réessayez dans quelques minutes.', 429);
  const call = auth.normCall(f.get('call'));
  const rec = auth.validCall(call, cfg.allowedPrefixes, cfg.allowedCalls) ? auth.loadUsers(USERS_FILE)[call] : null;
  const ok = rec && !auth.userOff(rec) && (await auth.verifyPassword(String(f.get('pass') || ''), rec));
  if (!ok) {
    const n = (fl && !(fl.until && fl.until <= now) ? fl.n : 0) + 1;
    fails.set(ip, { n, until: n >= 5 ? now + 10 * 60000 : 0 });
    journal('station_page_fail', { call, ip });
    return setTimeout(() => sendStationLogin(res, 'Indicatif ou mot de passe incorrect.', 401), 600);
  }
  fails.delete(ip);
  if (!rec.admin) {
    journal('station_page_refused', { call, ip });
    return sendStationLogin(res, 'La page Station est réservée aux administrateurs de Remote Station.', 403);
  }
  const tok = crypto.randomBytes(32).toString('base64url');
  stSess[sessHash(tok)] = { call, exp: now + ST_DAYS * 86400000, ip };
  saveStSess();
  journal('station_page_login', { call, ip });
  res.writeHead(303, { Location: '/station', 'Set-Cookie': stCookie(req, tok, ST_DAYS * 86400), 'Cache-Control': 'no-store' });
  res.end();
}
/**
 * Le navigateur du PC du club garde le jeton de station (localStorage) : la page de connexion le présente toute seule,
 * pour que la page Station se rouvre sans personne au club (rechargement à distance, redémarrage de Windows).
 * Le jeton est un secret de 48 caractères connu des seuls administrateurs.
 */
async function stationTokenPost(req, res) {
  const ip = clientIp(req);
  const origin = req.headers.origin;
  let badOrigin = false;
  try { badOrigin = !!origin && origin !== 'null' && new URL(origin).host !== req.headers.host; } catch (e) { badOrigin = true; }
  if (badOrigin) { res.writeHead(403); return res.end(); }
  const body = await readBody(req, 512);
  if (body == null) { res.writeHead(413); return res.end(); }
  const now = Date.now();
  const fl = fails.get(ip);
  if (fl && fl.until > now) { res.writeHead(429); return res.end(); }
  const tok = String(new URLSearchParams(body).get('token') || '');
  if (!tok || !auth.safeEqual(tok, cfg.stationToken)) {
    const n = (fl && !(fl.until && fl.until <= now) ? fl.n : 0) + 1;
    fails.set(ip, { n, until: n >= 5 ? now + 10 * 60000 : 0 });
    journal('station_page_fail', { call: 'jeton', ip });
    res.writeHead(401, { 'Cache-Control': 'no-store' });
    return res.end();
  }
  fails.delete(ip);
  const c = crypto.randomBytes(32).toString('base64url');
  stSess[sessHash(c)] = { call: 'STATION', exp: now + ST_DAYS * 86400000, ip, token: true };
  saveStSess();
  journal('station_page_login', { call: 'jeton de station', ip });
  res.writeHead(204, { 'Set-Cookie': stCookie(req, c, ST_DAYS * 86400), 'Cache-Control': 'no-store' });
  res.end();
}
function stationLogout(req, res) {
  const tok = readCookie(req, ST_COOKIE);
  if (tok && stSess[sessHash(tok)]) { journal('station_page_logout', { call: stSess[sessHash(tok)].call, ip: clientIp(req) }); delete stSess[sessHash(tok)]; saveStSess(); }
  res.writeHead(303, { Location: '/station', 'Set-Cookie': stCookie(req, 'x'.repeat(20), 0), 'Cache-Control': 'no-store' });
  res.end();
}

/** Même réseau : même adresse IPv4, ou même préfixe /64 en IPv6 (chaque appareil d'une maison a sa propre adresse IPv6). */
function sameNet(a, b) {
  const norm = (ip) => String(ip || '').replace(/^::ffff:/i, '').toLowerCase();
  a = norm(a); b = norm(b);
  if (a === b) return true;
  if (a.indexOf(':') < 0 || b.indexOf(':') < 0) return false;
  const p64 = (ip) => {
    const [h, t] = ip.split('::');
    const hs = h ? h.split(':') : [];
    const ts = t !== undefined && t ? t.split(':') : [];
    const full = t !== undefined ? hs.concat(new Array(Math.max(0, 8 - hs.length - ts.length)).fill('0'), ts) : hs;
    return full.slice(0, 4).map((x) => parseInt(x || '0', 16)).join(':');
  };
  return p64(a) === p64(b);
}
function clientIp(req) {
  const xf = req.headers['x-forwarded-for'];
  return (xf ? String(xf).split(',')[0] : req.socket.remoteAddress || '').trim();
}

function send(conn, obj) {
  if (conn && conn.open) conn.send(JSON.stringify(obj));
}

// Limites des licences belges, appliquées même si config.json ne les reprend pas (anciens fichiers de configuration) :
// ON2 (licence intermédiaire) 100 W, ON3 (licence de base) 25 W. Un réglage plus bas dans powerRules reste prioritaire.
const LICENCE_MAX_W = [{ prefix: 'ON2', maxWatts: 100 }, { prefix: 'ON3', maxWatts: 25 }];
function maxWattsFor(call) {
  let w = Number(cfg.defaultMaxWatts);
  for (const r of cfg.powerRules || []) {
    if (call.startsWith(String(r.prefix).toUpperCase())) { w = Number(r.maxWatts); break; }
  }
  for (const r of LICENCE_MAX_W) if (call.startsWith(r.prefix)) w = Math.min(w, r.maxWatts);
  return w;
}

// Ramène la puissance du TRX sous la limite de licence de cet opérateur. Retourne true si une commande a été envoyée.
let lastPowerFix = 0;
function limitPower(conn, why) {
  if (!conn || !conn.user || conn.user.rxOnly || radio.power == null || radio.power <= conn.user.maxWatts) return false;
  const range = rig().POWER_RANGE[radio.powerHead];
  if (!range || conn.user.maxWatts < range[0]) return false;
  const now = Date.now();
  if (now - lastPowerFix < 2000) return true;
  lastPowerFix = now;
  const target = Math.min(conn.user.maxWatts, range[1]);
  toStation({ t: 'cmd', op: 'power', watts: target, reason: why + ' ' + conn.user.call });
  send(conn, { t: 'notice', level: 'warn', msg: 'Puissance ramenée à ' + target + ' W (limite de votre licence : ' + conn.user.maxWatts + ' W)' });
  journal('power_limit', { call: conn.user.call, from: radio.power, to: target });
  return true;
}

function inTxRange(hz) {
  return hz != null && cfg.txRanges.some((r) => hz >= r[0] && hz <= r[1]);
}

// Fréquence réellement émise : VFO B si la radio émet sur SUB (SPLIT), plus le décalage XIT s'il est actif
// ---------------------------------------------------------------- statistiques d'utilisation
// Une ligne par minute dans logs/usage-AAAA-MM.jsonl : qui a la main, qui est connecté, bande (fréquence d'émission),
// mode (onglet numérique quand le TRX est en DATA), secondes d'émission. Lues par la page /stats (administrateurs).
const STATS = require('./lib/stats.js');
const BANDPLAN = require('./public/js/bandplan.js');
const usage = { txS: 0, last: 0 };
const VIEW_MODE = { rtty: 'RTTY', jtty: 'JTTY', wspr: 'WSPR', jt65: 'JT65', sstv: 'SSTV', cw: 'CW' };
function usageDigi() {
  const v = ctlView && controller && ctlView.conn === controller ? ctlView : null;
  if (!v) return '';
  if (v.tab === 'ftx') return v.mode || 'FT8';
  return VIEW_MODE[v.tab] || '';
}
function usageTick(now) {
  if (radio.tx || ptt.active) usage.txS += 0.25;
  const minute = Math.floor(now / 60000) * 60000;
  if (minute === usage.last) return;
  const prev = usage.last;
  usage.last = minute;
  if (!prev) { usage.txS = 0; return; } // première minute après le démarrage : incomplète
  const users = Array.from(new Set(Array.from(ops).map((c) => c.user.call)));
  if (!users.length && !controller) { usage.txS = 0; return; }
  const line = { ts: prev, c: controller ? controller.user.call : null, u: users, f: txFreq() || null,
    m: STATS.modeName(radio.txVfo === 1 ? radio.modeB : radio.mode, usageDigi()), tx: Math.round(Math.min(60, usage.txS)), rig: station ? rig().NAME : '',
    x: controller ? String(txCallFor(controller.user) || '').toUpperCase() || null : null }; // TX call en service (statistiques par TX call)
  usage.txS = 0;
  fs.appendFile(path.join(LOG_DIR, 'usage-' + new Date(prev).toISOString().slice(0, 7) + '.jsonl'), JSON.stringify(line) + '\n', { mode: 0o600 }, (e) => { if (e) console.error('usage : ' + e.message); });
}

function txFreq() {
  const base = radio.txVfo === 1 ? radio.freqB : radio.freq;
  if (base == null) return null;
  return base + (radio.xit ? radio.clar || 0 : 0);
}

// ---------------------------------------------------------------- bande latérale automatique en phonie
// Changement de bande (touche de bande, fréquence tapée, molette au club pendant qu'un membre a la main…) : un VFO
// en LSB / USB est remis dans la bande latérale d'usage — LSB sous 10 MHz, USB au-dessus, et USB sur 60 m
// (canaux 5 MHz, usage IARU). Une seule correction par changement de bande : un choix fait ensuite à la main reste.
// Les autres modes (DATA, CW, AM, FM…) ne sont jamais touchés. Coupé avec « autoSideband »: false.
const sbWatch = { A: null, B: null };
const sideFor = (hz) => (hz >= 5250000 && hz <= 5450000 ? 'USB' : hz < 10000000 ? 'LSB' : 'USB');
function sbKey(hz) {
  const b = STATS.band(hz);
  return (b === 'hors bande' || b === 'inconnue' ? 'f' + Math.floor(hz / 1e6) : b) + (hz < 10000000 ? '<' : '>');
}
// ---------------------------------------------------------------- MODE AUTO : plan de bande IARU Région 1
// Quand le VFO entre dans une autre portion du plan de bande (touche de bande, molette, flèches…), le TRX prend le mode
// de cette portion une fois : CW, modes numériques (DATA-U), phonie (LSB sous 10 MHz, USB au-dessus, 60 m en USB), FM.
// Dans la portion, un mode choisi à la main reste. Un mode envoyé par le dashboard juste avant ou juste après (onglet
// numérique, spot du DX cluster) est prioritaire. Seulement quand un membre a la main et a laissé « MODE AUTO » en
// service ; coupé pour tous avec « bandPlan »: false.
const planWatch = { A: null, B: null };
const planMode = { A: 0, B: 0 }; // dernier mode envoyé par le dashboard (heure) pour chaque VFO
const planOn = () => cfg.bandPlan !== false && !!controller && controller.planAuto !== false;
function planKey(hz) {
  const seg = BANDPLAN.segment(hz);
  return { seg, key: STATS.band(hz) + ':' + (seg && seg.mode ? seg.mode : '-') + (hz < 10000000 ? '<' : '>') };
}
function bandPlanTick() {
  if (!station || !radio.connected) return;
  const now = Date.now();
  for (const [v, fk] of [['A', 'freq'], ['B', 'freqB']]) {
    const hz = radio[fk];
    if (!(hz > 0)) continue;
    const { seg, key } = planKey(hz);
    const w = planWatch[v];
    if (!w) { planWatch[v] = { key, timer: null }; continue; } // première lecture : état pris tel quel
    if (w.key === key) continue;
    w.key = key;
    clearTimeout(w.timer);
    w.timer = null;
    if (!seg || !seg.mode || !planOn()) continue;
    const changedAt = now;
    // Petite attente : un onglet numérique ou un spot envoie son mode juste après la fréquence
    w.timer = setTimeout(() => {
      w.timer = null;
      if (!planOn() || ptt.active || radio.tx || ftxPend || cwJob || (seq && seq.on)) return;
      if (planMode[v] > changedAt - 2500) return; // mode choisi par le dashboard : il a la priorité
      const hz2 = radio[fk];
      const now2 = planKey(hz2);
      if (now2.key !== key || !now2.seg || !now2.seg.mode) return;
      const K = BANDPLAN.modeKey(rig(), now2.seg.mode, hz2);
      const cur = v === 'B' ? radio.modeB : radio.mode;
      if (!K || cur === K[1]) return;
      toStation({ t: 'cmd', op: 'mode', code: K[0], sub: v === 'B' });
      journal('band_plan', { vfo: v, freq: hz2, from: cur, to: K[1], seg: now2.seg.label });
      if (controller) send(controller, { t: 'notice', level: 'ok', msg: 'Plan de bande IARU : VFO ' + v + ' en ' + K[1] + ' (' + now2.seg.label + ', ' + (hz2 / 1e6).toFixed(3) + ' MHz)' });
    }, 900);
  }
}

function autoSideband() {
  if (cfg.autoSideband === false || !station || !radio.connected) return;
  const now = Date.now();
  for (const [v, fk, mk] of [['A', 'freq', 'mode'], ['B', 'freqB', 'modeB']]) {
    const hz = radio[fk];
    if (!(hz > 0)) continue;
    // MODE AUTO en service et portion avec un mode d'usage : c'est le plan de bande qui décide
    if (planOn()) { const sg = BANDPLAN.segment(hz); if (sg && sg.mode) { sbWatch[v] = { key: sbKey(hz), until: 0, done: true }; continue; } }
    const key = sbKey(hz);
    const w = sbWatch[v];
    // Première lecture (TRX qui vient de se connecter) : on prend l'état tel quel
    if (!w) { sbWatch[v] = { key, until: 0 }; continue; }
    // Nouvelle bande : bande latérale vérifiée pendant 4 s (le TRX rappelle aussi le mode de la bande, relu un peu après)
    if (w.key !== key) { w.key = key; w.until = now + 4000; w.done = false; }
    if (w.done || now > w.until) continue;
    const md = radio[mk];
    if (md !== 'LSB' && md !== 'USB') continue;
    w.done = true;
    const want = sideFor(hz);
    if (md === want || !controller || ptt.active || radio.tx) continue;
    const K = (rig().MODE_KEYS || []).find((x) => x[1] === want);
    if (!K) continue;
    toStation({ t: 'cmd', op: 'mode', code: K[0], sub: v === 'B' });
    journal('auto_sideband', { vfo: v, freq: hz, from: md, to: want });
    send(controller, { t: 'notice', level: 'ok', msg: 'VFO ' + v + ' : ' + want + ' mis automatiquement (' + (hz / 1e6).toFixed(3) + ' MHz, ' + (want === 'LSB' ? 'sous 10 MHz' : hz < 10000000 ? 'bande des 60 m' : 'au-dessus de 10 MHz') + ')' });
  }
}

function autoTuner() {
  if (!radio.connected || !station) { tunerAuto = { band: '', until: 0 }; return; }
  if (cfg.tunerAuto === false || !rig().CONTROL || !rig().CONTROL.tuner) return;
  if (txw) return; // TXW : VFO échangés un instant, pas un changement de bande
  const f = txFreq();
  const band = f && f < 54e6 ? LB.bandOf(f / 1e6) : '';
  const now = Date.now();
  const side = radio.vfoSel === 1 ? 1 : 0;
  // Changement de côté MAIN / SUB (la bande du VFO d'émission change sans changement de bande) : rien n'est envoyé
  // (constaté au club : tuner mis en service pendant un passage sur SUB, TRX en émission)
  if (tunerAuto.side != null && tunerAuto.side !== side) { tunerAuto = { band, until: 0, side }; return; }
  tunerAuto.side = side;
  // Nouvelle bande : 4 s pour relire l'état du tuner de cette bande
  if (band && band !== tunerAuto.band) tunerAuto = { band, until: now + 4000, side };
  if (!band) tunerAuto.band = '';
  if (tunerAuto.until && now < tunerAuto.until && radio.tuner === 0 && !radio.tx && !ptt.active && controller) {
    tunerAuto.until = 0;
    toStation({ t: 'cmd', op: 'ctl', id: 'tuner', value: 1, by: 'auto', subOk: !!cfg.ftx1SubCat });
    radio.tuner = 1; // affichage optimiste, relu ensuite
    if (controller) send(controller, { t: 'notice', level: 'info', msg: 'Tuner mis en service (' + band + ').' });
  }
}

// FTX-1 : à chaque passage en CW (CW-L / CW-U) sur le VFO sélectionné, BK-IN mis en service (BI1), une seule fois par passage
let bkinAuto = { cw: null, until: 0 };
function autoBkin() {
  const R = station && rig();
  if (!radio.connected || !R || R.ID !== 'ftx1' || !R.CONTROL || !R.CONTROL.bkin || cfg.bkinAuto === false) { bkinAuto = { cw: null, until: 0 }; return; }
  const cw = /^CW/.test((radio.vfoSel === 1 ? radio.modeB : radio.mode) || '');
  if (bkinAuto.cw === false && cw) bkinAuto.until = Date.now() + 5000;
  bkinAuto.cw = cw;
  if (!cw) bkinAuto.until = 0;
  if (bkinAuto.until && Date.now() < bkinAuto.until && radio.bkin !== 1 && !radio.tx && !ptt.active && controller) {
    bkinAuto.until = 0;
    toStation({ t: 'cmd', op: 'ctl', id: 'bkin', value: 1, by: 'auto' });
    radio.bkin = 1; // affichage optimiste, relu ensuite
    send(controller, { t: 'notice', level: 'info', msg: 'CW : BK-IN mis en service.' });
  }
}

// Suivi d'un accord lancé par TUNE : accord vu en cours (AC / RI / émission), puis fini → verdict d'après le HI-SWR du TRX
function checkTune() {
  const w = tuneWatch;
  const now = Date.now();
  const busy = !!(radio.tuning || radio.tuningRi || radio.tx);
  if (busy) { w.saw = true; w.endAt = 0; } else if (w.saw && !w.endAt) w.endAt = now;
  // Accord trop long : pas de verdict
  if (now - w.at > 60000) { tuneWatch = null; return; }
  // Accord jamais vu en cours (trop court pour les lectures) : verdict au bout de 8 s, seulement pour bloquer
  const unseen = !w.saw && now - w.at > 8000;
  // Fin d'accord : on attend une relecture de RI (1 s) avant de conclure
  if (!unseen && (!w.endAt || now - w.endAt < 1600)) return;
  tuneWatch = null;
  if (radio.hiSwr == null) return; // TRX qui ne dit pas s'il a trouvé un accord
  if (unseen && radio.hiSwr !== 1) return;
  const band = LB.bandOf(w.freq / 1e6);
  if (radio.hiSwr === 1) {
    swrLock = { freq: w.freq, swr: null, tune: true, band: band || null };
    journal('tune_fail', { call: w.call, freq: w.freq });
    const msg = 'TUNE : pas d’accord possible (HI-SWR)' + (band ? ' sur le ' + band : '') + '. Émission bloquée' + (band ? ' sur cette bande' : ' sur cette fréquence') +
      ' pour protéger le PA : refaites TUNE, essayez l’autre antenne ou prévenez un responsable de la station.';
    for (const c of ops) send(c, { t: 'notice', level: 'error', msg });
  } else if (swrLock && swrLock.tune) {
    swrLock = null;
    if (w.conn) send(w.conn, { t: 'notice', level: 'info', msg: 'Accord réussi : émission de nouveau possible' + (band ? ' sur le ' + band : '') + '.' });
  }
}

function swrLocked() {
  const f = txFreq();
  if (!swrLock || f == null) return false;
  if (swrLock.band) return LB.bandOf(f / 1e6) === swrLock.band; // accord impossible : toute la bande
  return Math.abs(f - swrLock.freq) < 25000;
}
function swrLockText() {
  if (swrLock.tune) return 'le dernier TUNE n’a pas trouvé d’accord (HI-SWR) sur le ' + swrLock.band +
    ' : émission bloquée sur cette bande — refaites TUNE, essayez l’autre antenne ou prévenez un responsable de la station';
  return 'ROS trop élevé sur cette fréquence' + (swrLock.swr != null ? ' (' + swrLock.swr.toFixed(1).replace('.', ',') + ':1)' : ' (HI-SWR du TRX)') + ' : ' +
    (radio.tuner == null ? 'changez de fréquence ou faites vérifier l’antenne' : 'faites d’abord un accord (TUNE)');
}

// Raison qui empêche cet opérateur d'émettre (PTT ou TUNE), ou null
// Limites des bandes (Hz, région 1 IARU) pour les règles de licence (licenceBands)
const LIC_BANDS = { '160m': [1810000, 2000000], '80m': [3500000, 3800000], '60m': [5351500, 5366500], '40m': [7000000, 7200000],
  '30m': [10100000, 10150000], '20m': [14000000, 14350000], '17m': [18068000, 18168000], '15m': [21000000, 21450000],
  '12m': [24890000, 24990000], '10m': [28000000, 29700000], '6m': [50000000, 52000000], '4m': [70000000, 70500000],
  '2m': [144000000, 146000000], '70cm': [430000000, 440000000], '23cm': [1240000000, 1300000000] };
/** Bande de licence interdite à cet indicatif (ON3 : 80, 40, 30, 20, 15, 10 m, 2 m et 70 cm seulement) → raison, sinon null. */
function licenceBandWhy(call, hz) {
  const rules = cfg.licenceBands && typeof cfg.licenceBands === 'object' ? cfg.licenceBands : {};
  const pre = Object.keys(rules).filter((p) => String(call).startsWith(p.toUpperCase())).sort((a, b) => b.length - a.length)[0];
  if (!pre || !Array.isArray(rules[pre]) || !(hz > 0)) return null;
  const ok = rules[pre].some((b) => { const r = LIC_BANDS[String(b).toLowerCase()]; return r && hz >= r[0] && hz <= r[1]; });
  if (ok) return null;
  const band = Object.keys(LIC_BANDS).find((b) => hz >= LIC_BANDS[b][0] && hz <= LIC_BANDS[b][1]);
  return (band ? 'bande ' + band : 'cette fréquence') + ' interdite en émission à la licence ' + pre.toUpperCase() + ' (permises : ' + rules[pre].join(', ') + ')';
}
// Mode du VFO d'émission pour les modes numériques : DATA-U / USB (Yaesu) ; sur l'IC-7300, seulement les modes DATA (USB-D…),
// car en USB simple la modulation vient du micro (DATA OFF MOD) et non de la carte son
const digiIcom = () => /^ic/.test(rig().ID || '');
function digiModeOk(md) { return digiIcom() ? /-D$/.test(md || '') : /DATA|USB|PKT|DIG/i.test(md || ''); }
function digiModeName() { return digiIcom() ? 'USB-D' : 'DATA-U'; }
function txBlockReason(conn, forTune) {
  return txw ? 'TXW enfoncé (écoute de la fréquence d’émission) : relâchez-le d’abord' :
    cwJob ? 'émission CW en cours : attendez la fin (ou « ■ Arrêter »)' :
    !cfg.allowTx ? 'émission désactivée sur ce serveur' :
    conn.user.rxOnly ? 'indicatif d’écouteur (' + conn.user.call + ') : émission interdite' :
    !conn.user.tx ? 'votre compte n’est pas autorisé à émettre' :
    controller !== conn ? 'prenez d’abord la main' :
    !station ? 'station hors ligne' :
    !radio.connected ? 'TRX non connecté' :
    radio.vox ? 'VOX actif au club : coupez-le d’abord' :
    !inTxRange(txFreq()) ? 'fréquence d’émission hors des bandes autorisées' + (radio.txVfo === 1 ? ' (VFO B en SPLIT)' : '') :
    licenceBandWhy(conn.user.call, txFreq()) ? licenceBandWhy(conn.user.call, txFreq()) :
    radio.power == null ? 'puissance du TRX inconnue' :
    radio.power > conn.user.maxWatts ? 'puissance ' + radio.power + ' W au-delà de votre limite (' + conn.user.maxWatts + ' W)' :
    forTune && radio.tuner == null ? 'pas de boîte d’accord sur ce TRX (FTX-1 : ampli SPA-1 débranché ?)' :
    !forTune && swrLocked() ? swrLockText() :
    null;
}

// Synchronisation NTP de ce serveur (référence de tous les décodages) : chrony, sinon systemd-timesyncd ; relue toutes les 5 min
const ntpState = { at: 0, synced: null, offsetMs: null, src: '', server: '' };
function ntpCheck() {
  const cp = require('child_process');
  const done = () => { ntpState.at = Date.now(); };
  cp.execFile('chronyc', ['-c', 'tracking'], { timeout: 3000 }, (e, out) => {
    const f = !e && out ? String(out).trim().split(',') : [];
    if (f.length >= 14) {
      ntpState.src = 'chrony';
      ntpState.server = f[1] || '';
      ntpState.offsetMs = Math.round(parseFloat(f[4]) * 1e5) / 100; // « System time » : avance (+) ou retard de l'horloge
      ntpState.synced = !/not/i.test(f[13] || '') && f[2] !== '0';
      return done();
    }
    cp.execFile('timedatectl', ['show', '-p', 'NTPSynchronized', '--value'], { timeout: 3000 }, (e2, o2) => {
      ntpState.synced = !e2 ? /yes/i.test(String(o2)) : null;
      cp.execFile('timedatectl', ['timesync-status'], { timeout: 3000 }, (e3, o3) => {
        const t = String(o3 || '');
        const mo = /Offset:\s*([+-]?[\d.]+)(us|ms|s)\b/.exec(t);
        ntpState.offsetMs = mo ? Math.round(parseFloat(mo[1]) * (mo[2] === 'us' ? 0.001 : mo[2] === 'ms' ? 1 : 1000) * 100) / 100 : null;
        const ms = /Server:\s*(\S+)\s*(\(([^)]+)\))?/.exec(t);
        ntpState.server = ms ? (ms[3] || ms[1]) : '';
        ntpState.src = !e3 ? 'systemd-timesyncd' : (ntpState.synced != null ? 'timedatectl' : '');
        done();
      });
    });
  });
}
setTimeout(ntpCheck, 2000);
setInterval(ntpCheck, 300000);
let cwTxSeenAt = 0; // dernière lecture « en émission » du TRX (affichage CW sans clignotement)
let cwTxHoldTimer = null;
function publicState() {
  const calls = [];
  for (const c of ops) if (calls.indexOf(c.user.call) < 0) calls.push(c.user.call);
  return {
    t: 'state',
    station: !!station,
    // CW (macro ou clé) en cours : le break-in du TRX repasse en réception entre les lettres et les mots ; pour
    // l'affichage, l'émission dure jusqu'à la fin du message (fréquence rouge sans clignoter)
    radio: !radio.tx && ((cwJob && cwJob.state === 'tx') ||
      (radio.connected && Date.now() - cwTxSeenAt < 1500 && /^CW/.test((radio.vfoSel === 1 ? radio.modeB : radio.mode) || '')))
      ? Object.assign({}, radio, { tx: radio.tx || 2, txHeld: 1 }) : radio,
    controller: controller ? controller.user.call : null,
    controllerCid: controller ? controller.cid : null,
    users: calls.sort(),
    ptt: { active: ptt.active, by: ptt.active ? ptt.conn.user.call : null, since: ptt.since, digi: !!(ptt.active && ptt.digi), voice: !!(ptt.active && ptt.voice) },
    // Phonie à distance possible : modes du TRX (LSB / USB…) ; null si la page Station ou le TRX ne le permet pas
    voice: voiceModes(),
    // Égaliseur du TRX : profil en place (indicatif, « #club » en attente) ; null si indisponible
    trxEq: trxEqAvail() ? { on: eqOn() ? eqOn().call : null } : null,
    // Émission FT8 / FT4 / FT2 programmée ou en cours
    seq: seqPublic(),
    hound: ftHound, // FT8 en DXpédition : 0 normal, 1 HOUND (FOX classique), 2 HOUND SuperFox
    cw: cwPublic(),
    ftx: ftxPend ? { id: ftxPend.id, state: ftxPend.state, mode: ftxPend.mode, text: ftxPend.sent || ftxPend.text, at: ftxPend.at, f0: ftxPend.f0, by: ftxPend.conn.user.call, seconds: ftxPend.seconds, sstv: ftxPend.sstv || undefined } : null,
    txCall: txCall(),
    txw: txw ? txw.conn.user.call : null,
    view: ctlView && controller && ctlView.conn === controller ? { tab: ctlView.tab, mode: ctlView.mode, marks: ctlView.marks || null } : null,
    faceView: ctlFace && controller && ctlFace.conn === controller ? ctlFace.v : null,
    txOk: inTxRange(txFreq()),
    txFreq: txFreq(),
    swrLock: swrLocked() ? { freq: swrLock.freq, swr: swrLock.swr != null ? Math.round(swrLock.swr * 10) / 10 : null, tune: !!swrLock.tune, band: swrLock.band || null, text: swrLockText() } : null,
    maxSwr: cfg.maxSwr,
    audio: { active: !!(station && audio.active), listeners: listeners(true), silent: !!(station && audio.silent), out: station && audio.out ? audio.out : null },
    digi: { modes: Array.from(digiModes()), latency: digi.latency, engine: digi.engine || '', ms: digi.ms || 0, timing: digi.timing || null,
      ntp: ntpState.at ? ntpState : null, club: station && station.clock ? station.clock : null, flow: flowState() },
    rigName: station ? rig().NAME : null,
    rigModel: station ? rig().ID : null,
    // TRX dont le port série est mémorisé sur le PC du club (changement à distance possible)
    rigPorts: station ? station.ports : {}
  };
}

let bcastPending = false;
function broadcast() {
  if (bcastPending) return;
  bcastPending = true;
  setTimeout(() => {
    bcastPending = false;
    const base = publicState();
    const msg = JSON.stringify(base);
    // Administrateurs : en plus, l'adresse IP de chaque membre connecté (bouton 👥 de la face avant)
    let adm = null;
    for (const c of ops) {
      if (!c.open) continue;
      if (c.user && c.user.admin) {
        if (!adm) adm = JSON.stringify(Object.assign({}, base, { usersIp: Array.from(ops).filter((o) => o.open && o.user).map((o) => ({ call: o.user.call, ip: String(o.ip || '').replace(/^::ffff:/, '') })) }));
        c.send(adm);
      } else c.send(msg);
    }
  }, 40);
}

function toStation(obj) {
  if (station) send(station.conn, obj);
}

// ---------------------------------------------------------------- PTT
function stopPtt(reason) {
  if (!ptt.active) return;
  const who = ptt.conn;
  const dur = Math.round((Date.now() - ptt.since) / 100) / 10;
  const digiEnd = !!ptt.digi && reason === FTX_END;
  const sw = !!ptt.digi && reason === FTX_SWITCH;
  let sentP = null;
  if (ptt.digi && ftxPend && ftxPend.id === ptt.digi.id) { clearTimeout(ftxPend.timer); sentP = ftxPend; ftxPend = null; }
  if (ptt.digi && !digiEnd && !sw && seq && seq.on) { seq.on = false; setTimeout(updateDigi, 0); }
  if (digiEnd && sentP) setTimeout(() => seqAfterTx(sentP), 0);
  const wasVoice = !!ptt.voice;
  const voiceFrames = ptt.voiceFrames || 0;
  ptt = { active: false, conn: null, since: 0, lastBeat: 0 };
  pttEndAt = Date.now();
  toStation({ t: 'cmd', op: 'ptt', on: false, reason });
  journal('tx_stop', { call: who.user.call, durationS: dur, reason, freq: txFreq(), voiceFrames: wasVoice ? voiceFrames : undefined });
  if (reason !== 'relâché' && !digiEnd && !sw) {
    // Coupure forcée : l'opérateur doit relâcher le PTT avant de pouvoir réémettre
    who.needRelease = true;
    send(who, { t: 'notice', level: 'warn', msg: 'Émission coupée : ' + reason, pttCut: true });
  }
  broadcast();
}

function voiceModes() {
  if (cfg.remoteVoice === false || !station || station.caps.indexOf('voicetx') < 0) return null;
  const V = rig().VOICE;
  return V ? V.modes.slice() : null;
}
// Voix de l'opérateur pendant son émission en phonie : relayée telle quelle (µ-law 12 kHz, trames de 20 ms) à la page Station
function voiceIn(conn, buf) {
  if (!buf || buf.length < 2 || buf.length > 1500 || buf[0] !== 0x05) return;
  if (!ptt.active || ptt.conn !== conn || !ptt.voice || !station) return;
  const now = Date.now();
  if (!conn.vf || now - conn.vf.t > 1000) conn.vf = { t: now, n: 0 };
  if (++conn.vf.n > 120) return; // au plus 120 trames par seconde (2,4 × le débit normal)
  if (station.conn.backlog > 262144) return;
  station.conn.send(buf);
  ptt.voiceFrames = (ptt.voiceFrames || 0) + 1;
}
// Opérateur qui a parlé en phonie à distance : quand il rend la main (ou coupe son micro), la page Station remet
// tout de suite la source de modulation du club (sinon après 20 s sans émission en phonie)
let voiceUser = null;
function voiceRelease(reason) {
  if (!voiceUser) return;
  voiceUser = null;
  toStation({ t: 'cmd', op: 'voiceoff', reason });
}

function startPtt(conn, voice) {
  if (rig().VIRTUAL_SPLIT && txSide() && station && station.caps.indexOf('txsel') < 0) {
    return send(conn, { t: 'notice', level: 'error', msg: 'PTT refusé : la page Station du club est une ancienne version (émission sur le VFO B impossible). Rechargez-la : voyant STATION → « Recharger la page Station ».' });
  }
  const why = txBlockReason(conn);
  if (why && radio.power != null && radio.power > conn.user.maxWatts) limitPower(conn, 'avant émission');
  if (why) return send(conn, { t: 'notice', level: 'error', msg: 'PTT refusé : ' + why });
  // Phonie à distance : mode du VFO d'émission (la page Station met la source de modulation de ce mode sur USB)
  let vmode = null;
  if (voice) {
    const md = (radio.txVfo === 1 ? radio.modeB : radio.mode) || '';
    const vm = voiceModes();
    if (!vm) return send(conn, { t: 'notice', level: 'error', msg: 'PTT refusé : phonie à distance indisponible (' + (cfg.remoteVoice === false ? 'coupée sur ce serveur' : !station || station.caps.indexOf('voicetx') < 0 ? 'page Station du club à recharger' : 'pas prévue sur le ' + rig().NAME) + ')' });
    if (vm.indexOf(md) < 0) return send(conn, { t: 'notice', level: 'error', msg: 'PTT refusé : phonie à distance en ' + vm.join(' / ') + ' seulement (mode actuel : ' + (md || '?') + ')' });
    vmode = md;
    voiceUser = conn;
  }
  const now = Date.now();
  ptt = { active: true, conn, since: now, lastBeat: now, voice: vmode };
  lastCtrlActivity = now;
  // SPLIT virtuel : VFO d'émission envoyé avec le PTT, sauf si le TRX est déjà en SPLIT par sa face avant (il s'en charge)
  const tv = txSide();
  ptt.rx = rxSide();
  toStation({ t: 'cmd', op: 'ptt', on: true, by: conn.user.call, txVfo: rig().VIRTUAL_SPLIT && radio.hwSplit !== 1 ? tv : undefined, voice: vmode || undefined });
  toStation({ t: 'txka' });
  journal('tx_start', { call: conn.user.call, ip: conn.ip, freq: txFreq(), mode: radio.txVfo === 1 ? radio.modeB : radio.mode, split: !!radio.split, watts: radio.power, voice: vmode ? 1 : undefined });
  broadcast();
}

// ---------------------------------------------------------------- émission FT8 / FT4 / FT2
// Clic sur un message (Tx1…Tx7) : le serveur choisit le créneau (heure du VPS, NTP), la page Station code le
// message tout de suite, puis le serveur met le TRX en émission juste avant le début du créneau ; la page joue le
// signal à l'heure dite et prévient à la fin → retour en réception. Une émission par clic.
const FTX_SLOT = { FT8: 15000, FT4: 7500, FT2: 3750 };
const FTX_T0 = 500; // début du signal après le début de la période (ms), comme WSJT-X
// Départ en retard encore accepté dans la période en cours (réponse cliquée juste après le décodage, comme WSJT-X) :
// le correspondant décode encore (DT jusqu'à +2,5 s en FT8)
const FTX_LATE = { FT8: 2300, FT4: 800, FT2: 250 };
const FTX_KEY_LEAD = 400; // passage en émission avant le début du signal (ms)
const FTX_PREP = 450;     // délai minimal entre la demande et le départ du signal (codage par la page Station ; 700 avant la 0.42.46)
// Réponse par clic sur un indicatif : PTT dès que la page Station a préparé le signal (au clic), si le départ du
// signal est assez proche ; le signal part quand même au début de la période (sinon le correspondant ne le décode pas)
// Clic pendant notre propre période d'émission : départ immédiat (comme WSJT-X), message tronqué à la fin de la période.
// Il faut au moins ce temps restant dans la période (ms) ; sinon la période suivante de même parité.
const FTX_CLICK_MIN = { FT8: 2500, FT4: 1500, FT2: 900 };
const FTX_END = 'fin du message';
const FTX_SWITCH = 'message suivant'; // émission coupée pour repartir aussitôt avec le message suivant de la séquence
let ftxPend = null; // { id, conn, mode, text, f0, at, state: 'wait' | 'tx', ready, seconds, sent, timer }
let ftxSeq = 0;

// ---------------------------------------------------------------- émission CW (manipulateur du TRX, par le CAT)
// Le texte part dans la mémoire du manipulateur du TRX (Yaesu : KM puis KY ; Icom : commande 17), avec le
// « break-in » en service : le TRX émet tout seul, sans PTT. La page Station suit l'émission et répond « cw_state ».
let cwJob = null; // { id, conn, text, wpm, seconds, state: 'wait' | 'tx', at, timer }
const MORSE = {
  A: '.-', B: '-...', C: '-.-.', D: '-..', E: '.', F: '..-.', G: '--.', H: '....', I: '..', J: '.---', K: '-.-', L: '.-..', M: '--',
  N: '-.', O: '---', P: '.--.', Q: '--.-', R: '.-.', S: '...', T: '-', U: '..-', V: '...-', W: '.--', X: '-..-', Y: '-.--', Z: '--..',
  0: '-----', 1: '.----', 2: '..---', 3: '...--', 4: '....-', 5: '.....', 6: '-....', 7: '--...', 8: '---..', 9: '----.',
  '/': '-..-.', '?': '..--..', '.': '.-.-.-', ',': '--..--', '=': '-...-', '+': '.-.-.', '-': '-....-'
};
/** Texte CW accepté par les manipulateurs : majuscules, chiffres, / ? . , = + - et espaces (prosignes : <AR> = +, <BT> = =, <KN> retiré). */
function cwClean(t) {
  return String(t || '').toUpperCase().replace(/<AR>/g, '+').replace(/<BT>/g, '=').replace(/<[A-Z]{2}>/g, ' ')
    .replace(/[^A-Z0-9 /?.,=+-]/g, ' ').replace(/\s+/g, ' ').trim();
}
/** Durée du texte en ms à wpm mots/minute (PARIS : 1 point = 1200 / wpm ms). */
function cwMs(t, wpm) {
  let u = 0;
  for (const ch of t) {
    if (ch === ' ') { u += 4; continue; } // espace entre mots : 7 points (3 déjà comptés après la lettre)
    const c = MORSE[ch];
    if (!c) continue;
    for (const x of c) u += (x === '.' ? 1 : 3) + 1;
    u += 2; // espace entre lettres : 3 points en tout
  }
  return Math.round(u * 1200 / wpm);
}
/** Fin de chaque caractère (ms depuis le début du texte), pour suivre l'émission lettre par lettre sur le dashboard. */
function cwCharMs(t, wpm) {
  const out = [];
  let u = 0;
  for (const ch of t) {
    if (ch === ' ') u += 4;
    else if (MORSE[ch]) { for (const x of MORSE[ch]) u += (x === '.' ? 1 : 3) + 1; u += 2; }
    out.push(Math.round(u * 1200 / wpm));
  }
  return out;
}
function cwPublic() {
  return cwJob ? { id: cwJob.id, by: cwJob.conn.user.call, text: cwJob.text, state: cwJob.state, seconds: cwJob.seconds, wpm: cwJob.wpm,
    ms: cwJob.ms, pos: cwJob.pos || null, live: !!cwJob.live } : null;
}
/**
 * Clé de l'opérateur (palettes ou pioche branchées chez lui) : fronts horodatés { t:'cwk', b, e:[[ms, 1|0]…], h, end }.
 * b : numéro de rafale (nouvelle rafale après une pause de l'opérateur). Mêmes contrôles qu'une macro CW ; une macro
 * de l'opérateur en cours est arrêtée (la clé prend la main). Les fronts partent vers la page Station qui les rejoue.
 */
function cwkFeed(conn, m) {
  const b = Math.round(Number(m.b)) || 0;
  if (conn.cwkDead === b) return; // rafale refusée ou arrêtée : ignorée jusqu'à la pause suivante de l'opérateur
  const now = Date.now();
  // Débit : 80 messages par seconde au plus
  if (!conn.cwkRate || now - conn.cwkRate.at > 1000) conn.cwkRate = { at: now, n: 0 };
  if (++conn.cwkRate.n > 80) return;
  const ev = [];
  for (const e of Array.isArray(m.e) ? m.e.slice(0, 64) : []) {
    const t = Math.round(Number(e && e[0]) * 10) / 10;
    if (Number.isFinite(t) && t >= 0) ev.push([t, e[1] ? 1 : 0]);
  }
  const h = Number.isFinite(Number(m.h)) ? Math.max(0, Number(m.h)) : null;
  const end = !!m.end;
  let j = cwJob;
  const fail = (msg) => { conn.cwkDead = b; send(conn, { t: 'notice', level: 'error', msg: 'Clé CW : ' + msg }); };
  if (!(j && j.live && j.conn === conn && j.b === b)) {
    if (!ev.some((x) => x[1])) return; // rafale qui commence sans top : rien à faire
    if (controller !== conn) return fail('prenez d’abord la main');
    if (!station || station.caps.indexOf('cwkey') < 0) {
      return fail('la page Station du club ne connaît pas encore la clé à distance : ' +
        (conn.user.admin ? 'rechargez-la (voyant STATION → « Recharger la page Station »).' : 'un administrateur doit la recharger.'));
    }
    if (!rig().CW || !rig().CW.dtr) return fail('manipulation à la clé pas prévue sur le ' + rig().NAME);
    if (j && j.conn === conn) cwEnd('', true); // macro (ou rafale précédente) de l'opérateur : la clé prend la main
    else if (j) return fail('émission CW déjà en cours');
    if (ptt.active || ftxPend) return fail('émission déjà en cours ou prévue : attendez la fin');
    if (seq && seq.on) return fail('émission automatique FT8 / FT4 / FT2 en cours : arrêtez-la d’abord');
    const why = txBlockReason(conn);
    if (why && radio.power != null && radio.power > conn.user.maxWatts) limitPower(conn, 'avant émission');
    if (why) return fail('émission refusée : ' + why);
    if (radio.split || radio.txVfo === 1) return fail('coupez d’abord le SPLIT');
    const md = (radio.vfoSel === 1 ? radio.modeB : radio.mode) || '';
    if (!/^CW/.test(md)) return fail('mettez d’abord le TRX en CW (mode actuel : ' + (md || '?') + ')');
    const wpm = Math.max(5, Math.min(60, Math.round(Number(m.wpm) || 0))) || null;
    const id = ++ftxSeq;
    j = cwJob = { id, conn, live: true, b, text: '', wpm, seconds: 0, state: 'wait', at: now, timer: null, ms: null, pos: null, lastT: -1, edges: 0 };
    journal('tx_start', { call: conn.user.call, ip: conn.ip, freq: txFreq(), mode: 'CW', text: '(clé)', wpm, watts: radio.power });
    broadcast();
  }
  const fresh = ev.filter((x) => x[0] > j.lastT);
  if (fresh.length) j.lastT = fresh[fresh.length - 1][0];
  j.edges += fresh.length;
  // Durée maximale d'une rafale (limite d'émission du serveur)
  if (j.lastT > cfg.maxTxSeconds * 1000 || (h != null && h > cfg.maxTxSeconds * 1000)) {
    conn.cwkDead = b;
    return cwEnd('durée maximale atteinte (' + cfg.maxTxSeconds + ' s sans pause)', false);
  }
  if (j.edges > 120 * (1 + (now - j.at) / 1000)) { conn.cwkDead = b; return cwEnd('trop de signes par seconde', false); }
  lastCtrlActivity = now;
  clearTimeout(j.timer);
  // Filet : plus de nouvelles de la clé (4 s) ou fin non confirmée par la page Station
  j.timer = setTimeout(() => { if (cwJob === j) { conn.cwkDead = b; cwEnd(end ? 'fin de manipulation non confirmée par la page Station' : 'plus de nouvelles de la clé de l’opérateur', false); } }, end ? 8000 : 4000);
  toStation({ t: 'cmd', op: 'cwk', id: j.id, e: fresh, h, end, by: conn.user.call });
}
function cwRequest(conn, m) {
  const err = (msg) => send(conn, { t: 'notice', level: 'error', msg });
  if (controller !== conn) return err('Prenez d’abord la main');
  if (!station || station.caps.indexOf('cwtx') < 0) {
    return err('La page Station du club ne sait pas encore émettre en CW (ancienne version) : ' +
      (conn.user.admin ? 'rechargez-la (voyant STATION → « Recharger la page Station »).' : 'un administrateur doit la recharger.'));
  }
  if (!rig().CW) return err('Émission CW par le CAT pas encore prévue sur le ' + rig().NAME);
  // Nouveau message de l'opérateur pendant un message CW (ou un message dont le TRX n'a pas confirmé l'émission) :
  // il remplace le précédent ; la page Station arrête la lecture en cours avant de lancer le nouveau
  if (cwJob && cwJob.conn === conn) cwEnd('', true);
  if (cwJob) return err('Émission CW déjà en cours : attendez la fin (ou « ■ Arrêter »)');
  if (ptt.active || ftxPend) return err('Émission déjà en cours ou prévue : attendez la fin');
  if (seq && seq.on) return err('Émission automatique FT8 / FT4 / FT2 en cours : arrêtez-la d’abord');
  const why = txBlockReason(conn);
  if (why && radio.power != null && radio.power > conn.user.maxWatts) limitPower(conn, 'avant émission');
  if (why) return err('Émission refusée : ' + why);
  if (radio.split || radio.txVfo === 1) return err('Émission CW : coupez d’abord le SPLIT (le manipulateur émet sur le VFO écouté)');
  const md = (radio.vfoSel === 1 ? radio.modeB : radio.mode) || '';
  if (!/^CW/.test(md)) return err('Mettez d’abord le TRX en CW (mode actuel : ' + (md || '?') + ')');
  const text = cwClean(m.text);
  if (!text) return err('Rien à émettre : tapez un texte ou choisissez une macro');
  if (text.length > 300) return err('Texte trop long (300 caractères au plus)');
  const wpm = Math.max(5, Math.min(cwWpmMax(), Math.round(Number(m.wpm) || 22)));
  const seconds = cwMs(text, wpm) / 1000;
  if (seconds > cfg.maxTxSeconds - 2) return err('Texte trop long : ' + Math.round(seconds) + ' s d’émission à ' + wpm + ' mots/min (limite du serveur : ' + cfg.maxTxSeconds + ' s)');
  const id = ++ftxSeq;
  cwJob = { id, conn, text, wpm, seconds: Math.round(seconds * 10) / 10, state: 'wait', at: Date.now(), timer: null, ms: cwCharMs(text, wpm), pos: null };
  lastCtrlActivity = Date.now();
  journal('tx_start', { call: conn.user.call, ip: conn.ip, freq: txFreq(), mode: 'CW', text: text.slice(0, 60), wpm, watts: radio.power });
  toStation({ t: 'cmd', op: 'cw', id, text, wpm, by: conn.user.call });
  // Filet : fin non signalée par la page Station (marge pour les morceaux et le retour en réception)
  // (envoi mot par mot si le TRX refuse les espaces en mémoire : ~1,5 s de plus par mot)
  cwJob.timer = setTimeout(() => cwEnd('fin du message non confirmée par la page Station', false), Math.round(seconds * 1300 + 5000 + 1500 * text.split(' ').length));
  broadcast();
}
/** Fin de l'émission CW ; fromStation : la page Station l'a déjà arrêtée (sinon on lui demande de couper). */
function cwEnd(reason, fromStation) {
  const j = cwJob;
  if (!j) return;
  cwJob = null;
  if (j.live && reason) j.conn.cwkDead = j.b; // rafale de la clé arrêtée : la suite est ignorée jusqu'à la pause
  clearTimeout(j.timer);
  if (!fromStation) toStation({ t: 'cmd', op: 'cwstop', reason });
  journal('tx_end', { call: j.conn.user.call, mode: 'CW', reason, s: Math.round((Date.now() - j.at) / 1000) });
  if (reason && reason !== 'fin du message' && !(j.live && reason === 'fin de manipulation')) send(j.conn, { t: 'notice', level: /arrêt demandé/.test(reason) ? 'info' : 'warn', msg: 'Émission CW arrêtée : ' + reason });
  lastCtrlActivity = Date.now();
  broadcast();
}

/** Prochain départ du signal : début de période + 0,5 s, parité imposée ou non, au plus tôt dans 0,9 s. */
function ftxSlot(mode, parity, now, lateMax) {
  const P = FTX_SLOT[mode];
  const earliest = now + FTX_PREP; // le temps que la page Station fabrique le signal (s'il tarde : ftxKey l'attend un peu)
  const late = lateMax != null ? lateMax : FTX_LATE[mode];
  for (let k = Math.floor(now / P); k < Math.floor(now / P) + 4; k++) {
    if (parity != null && k % 2 !== parity) continue;
    const nominal = k * P + FTX_T0;
    if (earliest <= nominal) return { at: nominal, parity: k % 2 };
    if (earliest - nominal <= late) return { at: earliest, parity: k % 2 };
  }
  return null;
}

function ftxCancel(reason, quiet) {
  const p = ftxPend;
  if (!p) return;
  clearTimeout(p.timer);
  clearTimeout(p.holdT);
  ftxPend = null;
  if (!quiet && seq && seq.on && seq.conn === p.conn) { seq.on = false; updateDigi(); }
  if (ptt.active && ptt.digi && ptt.digi.id === p.id) stopPtt(reason);
  else if (!quiet) send(p.conn, { t: 'notice', level: 'warn', msg: 'Émission ' + p.mode + ' annulée : ' + reason });
  broadcast();
}

function ftxRequest(conn, m) {
  const err = (msg) => msg;
  const mode = String(m.mode || '');
  if (!FTX_SLOT[mode]) return err('Mode numérique inconnu');
  const text = String(m.text || '').toUpperCase().replace(/[^ -~]/g, '').replace(/\s+/g, ' ').trim().slice(0, 37);
  if (!text || /[{}]/.test(text)) return err('Message incomplet : ' + (text || '(vide)') + ' — choisissez d’abord le correspondant');
  const f0 = Math.round(Number(m.f0));
  if (!(f0 >= 200 && f0 <= 2900)) return err('Fréquence d’émission audio hors plage (200 à 2900 Hz)');
  if (!station || station.caps.indexOf('ftxtx') < 0) {
    return err('La page Station du club ne sait pas encore émettre en ' + mode + ' (ancienne version) : ' +
      (conn.user.admin ? 'rechargez-la (voyant STATION → « Recharger la page Station »).' : 'un administrateur doit la recharger.'));
  }
  if (ptt.active) return err('Émission déjà en cours : attendez la fin');
  const why = txBlockReason(conn);
  if (why && radio.power != null && radio.power > conn.user.maxWatts) limitPower(conn, 'avant émission');
  if (why) return err('Émission refusée : ' + why);
  const md = (radio.txVfo === 1 ? radio.modeB : radio.mode) || '';
  if (!digiModeOk(md)) return err('Mettez d’abord le VFO d’émission en ' + digiModeName() + ' (mode actuel : ' + (md || '?') + ')');
  const now = Date.now();
  // Réponse cliquée : on peut partir en retard dans notre période (le message est coupé à la fin de la période)
  const lateMax = m.keyNow ? FTX_SLOT[mode] - FTX_T0 - FTX_PREP - FTX_CLICK_MIN[mode] : null;
  const slot = ftxSlot(mode, m.parity === 0 || m.parity === 1 ? m.parity : null, now, lateMax);
  if (!slot) return err('Aucun créneau trouvé');
  if (ftxPend) ftxCancel('remplacée par le nouveau message', true);
  const p = { id: ++ftxSeq, conn, mode, text, f0, at: slot.at, parity: slot.parity, state: 'wait', ready: false, seconds: 0, sent: null, timer: null, ntx: m.ntx || 0,
    // PTT tout de suite seulement si le signal part tout de suite (jamais d'émission « à vide » avant la période)
    keyNow: !!m.keyNow && slot.at - now <= 1000 };
  ftxPend = p;
  toStation({ t: 'cmd', op: 'ftxprep', id: p.id, mode, text, f0 });
  p.timer = setTimeout(() => ftxKey(p), Math.max(0, p.at - FTX_KEY_LEAD - now));
  broadcast();
  return null;
}

// ---------------------------------------------------------------- séquence automatique (comme WSJT-X)
// Clic sur Tx1…Tx7 = « Enable Tx » : le message part à chaque période de l'opérateur (paire / impaire) jusqu'à
// la fin du QSO, « ■ Arrêter », la perte de la main ou le chien de garde (même message depuis 6 min).
// « Auto Seq » : les réponses du correspondant décodées font avancer le message (règles de WSJT-X 3.x,
// DecodedMessageReaction::planProcessMessage) ; « Répondre au 1er » (Call 1st) : en appel CQ, celui qui
// répond devient le correspondant. Après l'envoi d'un 73 ou d'un RR73 : fin du QSO, émission auto coupée,
// retour sur Tx6 (CQ) et proposition d'enregistrer le QSO dans le carnet (comme « Prompt me to log QSO »).
const PROG = { CALLING: 0, REPLYING: 1, REPORT: 2, ROGER_REPORT: 3, ROGERS: 4, SIGNOFF: 5 };
const NTX_PROG = { 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 0 };
// HOUND (FT8, DXpédition en FOX / SuperFox) : réglage de la station, choisi par celui qui a la main.
// Règles de WSJT-X 3.x (HoundTransmissionPolicy) : le HOUND émet en 2e période (le FOX en 1re), appelle au-dessus
// de 1000 Hz (FOX classique : fréquence tirée au hasard entre 1000 et 2900 Hz si plus bas), n'envoie que Tx1
// (« FOX MOI LOCATOR ») et Tx3 (« FOX MOI R+report ») ; FOX classique : le R+report part sur la fréquence où le FOX
// nous a appelés, puis à ±300 Hz s'il faut le répéter ; SuperFox : tout le QSO sur la fréquence d'appel. Le RR73 du
// FOX termine le QSO (pas de 73). Sans RR73 dans les 11 périodes qui suivent son report : arrêt.
let ftHound = 0;
const HOUND_WAIT_PERIODS = 11;
let seq = null; // { conn, on, mode, f0, parity, ntx, progress, dx: { call, grid }, rptSent, rptRcvd, free, call1st, watchMsg, watchSince, qsoStart }
const seqMe = () => txCall();
const seqGrid = () => String(cfg.stationGrid || '').toUpperCase().slice(0, 4);
const baseCall = (c) => String(c || '').toUpperCase().replace(/[<>]/g, '').split('/').reduce((a, x) => (x.length > a.length ? x : a), '');
const fmtRpt = (v) => {
  const n = Math.round(Number(v));
  if (!Number.isFinite(n)) return '-10';
  const k = Math.max(-30, Math.min(30, n));
  return (k >= 0 ? '+' : '-') + String(Math.abs(k)).padStart(2, '0');
};
const RPT_RE = /^[+-]\d{2}$/;
const RRPT_RE = /^R[+-]\d{2}$/;
const GRID4_RE = /^[A-R]{2}[0-9]{2}$/;
const SEQ_CALL_RE = /^[A-Z0-9]{1,3}[0-9][A-Z0-9]{0,4}[A-Z]$/;
// Appel d'un indicatif composé (« <ON5VL> HA/ES3H », sans locator : le format ne le permet pas), comme un appel avec locator
const NSCALL = (w) => w.length === 2 && w[1].indexOf('/') > 0 && SEQ_CALL_RE.test(baseCall(w[1]));

function seqText(s) {
  const me = seqMe();
  const c = s.dx.call;
  const r = s.rptSent || '-10';
  switch (s.ntx) {
    case 1: return c + ' ' + me + ' ' + seqGrid();
    case 2: return c + ' ' + me + ' ' + r;
    case 3: return c + ' ' + me + ' R' + r;
    // Réponse double (MSHV, FOX de WSJT-X) : RR73 au correspondant et report au suivant de la file, dans la même émission
    case 4: return s.dual2 ? c + ' RR73; ' + s.dual2.call + ' <' + me + '> ' + s.dual2.rpt : c + ' ' + me + ' RR73';
    case 5: return s.dual2 ? c + ' RR73; ' + s.dual2.call + ' <' + me + '> ' + s.dual2.rpt : c + ' ' + me + ' 73'; // son RR73 reçu : notre RR73 vaut 73
    case 6: return 'CQ ' + me + ' ' + seqGrid();
    default: return String(s.free || '');
  }
}
function seqPublic() {
  if (!seq) return null;
  return { on: !!seq.on, mode: seq.mode, ntx: seq.ntx, dx: seq.dx.call, grid: seq.dx.grid, rpt: seq.rptSent, rptRcvd: seq.rptRcvd || '',
    parity: seq.parity, call1st: !!seq.call1st, dual: !!seq.dual, dual2: seq.dual2 ? seq.dual2.call : '', by: seq.conn.user.call, text: seqText(seq), side: seq.side || 'A', hound: seq.hound || 0, f0: seq.f0, rxf: seq.rxf || 0,
    queue: seqQueue(seq) };
}
/** File d'attente visible (page FT) : ceux qui appellent pendant un QSO + ceux ajoutés à la main, dans l'ordre où ils seront pris */
function seqQueue(s) {
  if (!s || !s.waiting || !s.waiting.size) return [];
  const P = FTX_SLOT[s.mode] || 15000;
  const now = Date.now();
  const out = [];
  for (const [k, v] of s.waiting) {
    if (!v.manual && now - v.at > 2 * P + 2000) continue; // n'appelle plus : retiré au prochain choix
    out.push({ call: v.w[1], db: v.d.db, f: Math.round(v.d.f || 0), at: v.at, manual: !!v.manual, top: !!v.top, msg: String(v.w.slice(0, 3).join(' ')), dupe: s.worked.has(k) || isDupeNow(v.w[1], s.mode) });
  }
  return out.sort((a, b) => (b.top - a.top) || (b.manual - a.manual) || (b.db - a.db)).slice(0, 12);
}
/** Ordres de la file d'attente (celui qui a la main) : ajouter une station décodée, la retirer, la mettre en tête, tout vider */
function seqQueueCmd(conn, m) {
  const err = (msg) => send(conn, { t: 'notice', level: 'error', msg });
  if (controller !== conn) return err('Prenez d’abord la main');
  if (!seq || seq.conn !== conn || !seq.on) return err('File d’attente : lancez d’abord CQ ou un QSO (Tx1 à Tx6), elle se remplit pendant l’émission');
  const call = String(m.call || '').toUpperCase().replace(/[^A-Z0-9/]/g, '').slice(0, 13);
  const k = baseCall(call);
  if (m.op === 'clear') { seq.waiting.clear(); broadcast(); return; }
  if (!SEQ_CALL_RE.test(k)) return err('File d’attente : indicatif invalide');
  if (m.op === 'del') { seq.waiting.delete(k); broadcast(); return; }
  if (m.op === 'top') {
    const v = seq.waiting.get(k);
    if (!v) return;
    for (const x of seq.waiting.values()) x.top = false;
    v.top = true;
    v.at = Date.now(); // gardé jusqu'à son tour
    v.manual = true;
    broadcast();
    return;
  }
  if (m.op === 'add') {
    if (baseCall(seq.dx.call) === k) return err(call + ' est déjà le correspondant en cours');
    const P = FTX_SLOT[seq.mode] || 15000;
    const slot = Number(m.slot) || Date.now();
    const db = Math.max(-30, Math.min(30, Math.round(Number(m.db) || -10)));
    const f = Math.round(Number(m.f) || 0);
    const grid = /^[A-R]{2}\d{2}$/.test(String(m.grid || '').toUpperCase()) ? String(m.grid).toUpperCase() : '';
    // Ajout à la main : on l'appellera (Tx1) à son tour, sur la période opposée à la sienne
    seq.waiting.set(k, { d: { db, f }, w: [seqMe(), call, grid || ''], at: Date.now(), parity: Math.round(slot / P) % 2, manual: true, call1: true, grid });
    if (seq.waiting.size > 40) seq.waiting.delete(seq.waiting.keys().next().value);
    send(conn, { t: 'notice', level: 'info', msg: call + ' ajouté à la file d’attente : appelé après le QSO en cours' });
    broadcast();
  }
}
/**
 * Réponse double (comme MSHV en « Multi Answering » ou le FOX de WSJT-X, sur une seule tonalité) : au moment d'envoyer
 * RR73 au correspondant, le suivant de la file qui nous a appelés (avec son locator, sur la même période) reçoit son
 * report dans le même message : « A RR73; B <MOI> -08 » (message DXpédition 0.1 : indicatifs standard, report pair).
 * Rien si la page Station ne sait pas coder ce message, en FT4 / FT2, en HOUND, ou si une station passée en tête à la
 * main doit être appelée d'abord.
 */
function seqDualPick(s) {
  if (!s || !s.dual || s.hound || s.mode !== 'FT8' || !s.cqRun || s.autoCq === false || (s.ntx !== 4 && s.ntx !== 5) || s.parity == null) return null;
  if (!station || station.caps.indexOf('ftxdx') < 0) return null;
  // Indicatif composé (F5OYA/P, HA/ES3H) : transmis par son empreinte (« <HA/ES3H> »), page Station 0.42.58 et plus
  const cx = station.caps.indexOf('ftxdx2') >= 0;
  const okCall = (c) => /^[A-Z0-9]{3,6}$/.test(c) || (cx && /^[A-Z0-9/]{3,11}$/.test(c) && c.indexOf('/') > 0);
  if (!okCall(s.dx.call) || !/^[A-Z0-9/]{3,11}$/.test(seqMe())) return null;
  const P = FTX_SLOT[s.mode] || 15000, now = Date.now();
  let best = null;
  for (const [k, v] of s.waiting) {
    const ok = !v.manual && !v.call1 && okCall(v.w[1]) && SEQ_CALL_RE.test(baseCall(v.w[1])) && ((GRID4_RE.test(v.w[2]) && v.w[2] !== 'RR73') || (v.w[2] === '' && v.w[1].indexOf('/') > 0))
      && now - v.at <= 2 * P + 2000 && v.parity === 1 - s.parity && !s.worked.has(k) && !isDupeNow(v.w[1], s.mode);
    if (v.top && !ok) return null; // station mise en tête à la main : elle passe d'abord, seule
    if (!ok) continue;
    if (!best || (v.top && !best.top) || (v.top === best.top && v.d.db > best.d.db)) best = v;
  }
  if (!best) return null;
  const db = Math.max(-30, Math.min(30, 2 * Math.round(Number(best.d.db) / 2)));
  return { call: best.w[1], rpt: fmtRpt(db), key: baseCall(best.w[1]) };
}
function seqOff(reason, level) {
  if (!seq || !seq.on) return;
  seq.on = false;
  if (ftxPend && ftxPend.state === 'wait' && ftxPend.conn === seq.conn) ftxCancel(reason || 'arrêt', true);
  if (reason) send(seq.conn, { t: 'notice', level: level || 'warn', msg: 'Émission auto arrêtée : ' + reason });
  updateDigi();
  broadcast();
}
/** VFO d'émission = côté du QSO (FTDX101 : TX sur MAIN pour les colonnes A, sur SUB pour les colonnes B). */
function seqTxSide() {
  if (!seq || !seq.on || ptt.active || !station || !station.rig || !station.rig.DUAL_TX) return;
  const want = seq.side === 'B' ? 1 : 0;
  if (radio.txVfo === want) return;
  if (seq.side !== 'B' && radio.txVfo == null) return;
  toStation({ t: 'cmd', op: 'ctl', id: 'txVfo', value: want });
  radio.txVfo = want; // relu ensuite sur le TRX
}
/** Prochaine émission de la séquence (message courant, période de l'opérateur). */
function seqNext() {
  if (!seq || !seq.on || ftxPend || ptt.active) return;
  if (controller !== seq.conn) return seqOff('main perdue');
  seqTxSide();
  if (seq.ntx >= 1 && seq.ntx <= 5 && !SEQ_CALL_RE.test(baseCall(seq.dx.call))) return seqOff('pas de correspondant (double-clic sur son message)', 'error');
  const now = Date.now();
  if (seq.hound) {
    seq.parity = 1; // HOUND : toujours en 2e période (le FOX émet en 1re)
    if (seq.ntx === 3 && seq.houndRptAt && now - seq.houndRptAt > HOUND_WAIT_PERIODS * FTX_SLOT[seq.mode]) {
      seq.houndRptAt = 0;
      return seqOff('pas de RR73 du FOX ' + seq.dx.call + ' après ' + HOUND_WAIT_PERIODS + ' périodes (rappelez-le avec Tx1)');
    }
    // FOX classique : appel au-dessus de 1000 Hz (sous 1000 Hz, c'est la zone du FOX) → fréquence tirée au hasard
    if (seq.hound === 1 && seq.ntx === 1 && seq.f0 < 1000) {
      seq.f0 = 1000 + Math.floor(Math.random() * 1900);
      send(seq.conn, { t: 'notice', level: 'info', msg: 'HOUND : appel du FOX au-dessus de 1000 Hz → émission à ' + seq.f0 + ' Hz' });
    }
  }
  seq.dual2 = seq.ntx === 4 || seq.ntx === 5 ? seqDualPick(seq) : null;
  const text = seqText(seq);
  // Même message déjà envoyé « maxRep » fois sans réponse (Tx1 à Tx3) : on attend encore les décodages de la période
  // qui suit, puis on abandonne ce correspondant (appel CQ : station suivante qui appelait, sinon CQ ; sinon arrêt)
  if (text !== seq.repText && seq.giveUp) { clearTimeout(seq.giveUpT); seq.giveUp = false; }
  if (!seq.hound && seq.maxRep > 0 && seq.ntx >= 1 && seq.ntx <= 3 && text === seq.repText && seq.rep >= seq.maxRep) {
    if (!seq.giveUp) {
      const s = seq, P = FTX_SLOT[s.mode] || 15000;
      s.giveUp = true;
      // filet de sécurité si aucun décodage n'arrive : fin de la période de réception suivante + 4 s
      s.giveUpT = setTimeout(() => seqGiveUp(s), (Math.floor(now / P) + 2) * P - now + 4000);
    }
    return;
  }
  if (text !== seq.watchMsg) { seq.watchMsg = text; seq.watchSince = now; }
  else if (now - seq.watchSince > cfg.ftxWatchdogMinutes * 60000) {
    return seqOff('même message depuis ' + cfg.ftxWatchdogMinutes + ' min sans réponse (chien de garde, comme WSJT-X)');
  }
  const err = ftxRequest(seq.conn, { mode: seq.mode, text, f0: seq.f0, parity: seq.parity, ntx: seq.ntx, keyNow: seq.keyNow });
  seq.keyNow = false; // seulement pour la première émission après le clic
  if (err) seqOff(err, 'error');
}
/** Message changé par une réponse : l'émission prévue (pas encore partie) est remplacée. */
function seqChanged() {
  if (seq && seq.on && ftxPend && ftxPend.state === 'wait' && ftxPend.conn === seq.conn
      && (ftxPend.text !== seqText(seq) || ftxPend.parity !== seq.parity || ftxPend.f0 !== seq.f0)) ftxCancel('message changé', true);
  // Réponse décodée alors que notre émission de cette période vient de partir (ex. RR73 reçu pendant qu'on renvoie
  // R-report) : si le nouveau message peut encore partir dans cette période (départ en retard accepté), on coupe
  // et on repart aussitôt avec lui, au lieu de perdre une période (comme le changement de message en cours de WSJT-X)
  const p = ftxPend;
  if (seq && seq.on && p && p.state === 'tx' && p.conn === seq.conn && FTX_SLOT[p.mode] && p.text !== seqText(seq)
      && ptt.active && ptt.digi && ptt.digi.id === p.id) {
    const P = FTX_SLOT[p.mode];
    const nominal = Math.floor(p.at / P) * P + FTX_T0;
    if (Date.now() + FTX_PREP + 300 - nominal <= FTX_LATE[p.mode]) {
      stopPtt(FTX_SWITCH);
      seq.parity = Math.floor(p.at / P) % 2;
    }
  }
  seqNext();
  broadcast();
}
function seqSetNtx(n) {
  seq.ntx = n;
  if (NTX_PROG[n] != null) seq.progress = NTX_PROG[n];
}
/** Réponse du correspondant (« MOI LUI xxx ») : message suivant selon WSJT-X. Renvoie true si le QSO est terminé. */
function seqReact(payload, d) {
  const p = String(payload || '').toUpperCase();
  // « RR73 » a la forme d'un locator (RR73 = carré au milieu de l'océan) : c'est toujours la fin de QSO, comme dans WSJT-X
  if (p === 'RR73' || p === 'RRR') {
    seqSetNtx(5);
  } else if (GRID4_RE.test(p) || (p === '' && seq.progress <= PROG.REPORT)) {
    // Réponse à notre CQ avec son locator (indicatif composé : sans locator) → on lui donne son report
    if (p) seq.dx.grid = p;
    seq.rptSent = fmtRpt(d.db);
    seqSetNtx(2);
  } else if (RPT_RE.test(p)) {
    // Son report → R + notre report
    seq.rptRcvd = p;
    if (seq.progress <= PROG.REPLYING) seq.rptSent = fmtRpt(d.db);
    seqSetNtx(3);
  } else if (RRPT_RE.test(p)) {
    // R + report → RR73
    seq.rptRcvd = p.slice(1);
    seqSetNtx(4);
  } else if (p === 'RRR' || p === 'RR73') {
    seqSetNtx(5);
  } else if (p === '73') {
    if (seq.progress >= PROG.ROGERS) return true; // il confirme notre RR73 : QSO terminé
    seqSetNtx(5);
  } else return false;
  if (!seq.qsoStart) seq.qsoStart = Date.now();
  return false;
}
/** Décodages d'une période : la séquence avance si le correspondant (ou, en appel CQ, celui qui répond) nous écrit. */
function seqOnDecodes(mode, slot, list, side) {
  if (!seq || !seq.on || seq.mode !== mode || !Array.isArray(list) || !FTX_SLOT[mode]) return;
  if ((seq.side || 'A') !== (side || 'A')) return; // QSO sur l'autre récepteur (FTDX101 : MAIN / SUB)
  if (seq.hound) return seqHoundDecodes(list);
  const me = baseCall(seqMe());
  const theirParity = Math.round(slot / FTX_SLOT[mode]) % 2;
  const words = (d) => String(d.msg || '').toUpperCase().replace(/[<>]/g, '').split(/\s+/).filter(Boolean);
  const dxBase = baseCall(seq.dx.call);
  // 0) Ceux qui nous appellent pendant un QSO (« MOI LUI locator / report ») : file d'attente pour la fin du QSO
  let qChanged = false;
  if (seq.cqRun || seq.waiting.size) {
    for (const d of list) {
      const w = words(d);
      if (baseCall(w[0]) !== me || (w.length < 3 && !NSCALL(w)) || !SEQ_CALL_RE.test(baseCall(w[1])) || baseCall(w[1]) === dxBase) continue;
      if (w.length >= 3 && !((GRID4_RE.test(w[2]) && w[2] !== 'RR73') || RPT_RE.test(w[2]) || RRPT_RE.test(w[2]))) continue;
      if (w.length < 3) w.push('');
      const old = seq.waiting.get(baseCall(w[1]));
      seq.waiting.set(baseCall(w[1]), { d, w, at: Date.now(), parity: theirParity, top: !!(old && old.top) });
      qChanged = true;
    }
    if (seq.waiting.size > 40) seq.waiting.delete(seq.waiting.keys().next().value);
  }
  if (qChanged) setTimeout(broadcast, 0); // file d'attente visible dans la page FT
  // RR73 pas encore parti et quelqu'un vient d'appeler : il reçoit son report dans le même message (réponse double)
  if (qChanged && seq.dual && (seq.ntx === 4 || seq.ntx === 5) && !seq.dual2) { const d2 = seqDualPick(seq); if (d2) { seq.dual2 = d2; setTimeout(seqChanged, 0); } }
  // 1) le correspondant
  if (dxBase && seq.ntx !== 6) {
    for (const d of list) {
      const w = words(d);
      if (w.length < 2 || baseCall(w[1]) !== dxBase) continue;
      if (baseCall(w[0]) === me) {
        seq.heardSlot = slot;
        seq.parity = 1 - theirParity;
        if (d.f >= 100 && d.f <= 3000) seq.rxf = Math.round(d.f);
        if (seqReact(w[2], d)) return seqQsoDone('73 reçu');
        // RR73 / RRR reçu : la fiche de fin de QSO s'ouvre tout de suite (le 73 part quand même)
        const pl = String(w[2] || '');
        if ((pl === 'RR73' || pl === 'RRR') && seq.qsoStart) seqLogPrompt(seq, pl + ' reçu');
        return seqChanged();
      }
      // On l'appelait (Tx1) et il termine un QSO avec quelqu'un d'autre : on continue d'appeler (sur notre tonalité, sans
      // gêner ce QSO), et ces appels ne comptent pas dans « Sans réponse » tant qu'il est occupé (WSJT-X s'arrêtait ici)
      if (seq.progress === PROG.REPLYING && !/^(CQ|QRZ|DE)$/.test(w[0]) && baseCall(w[0]) !== me) {
        seq.repText = ''; seq.rep = 0;
        if (seq.giveUp) { clearTimeout(seq.giveUpT); seq.giveUp = false; setTimeout(seqChanged, 0); } // l'abandon prévu est annulé : on rappelle
        if (seq.busyNote !== baseCall(w[0])) {
          seq.busyNote = baseCall(w[0]);
          send(seq.conn, { t: 'notice', level: 'info', msg: seq.dx.call + ' termine un QSO avec ' + w[0] + ' : on continue de l’appeler (« ' + seqText(seq) + ' »)' });
        }
      }
    }
  }
  // 2) Appel CQ + « Répondre au 1er » : le plus fort de ceux qui nous répondent devient le correspondant
  if (seq.ntx === 6 && seq.call1st) {
    let best = null;
    for (const d of list) {
      const w = words(d);
      if (baseCall(w[0]) !== me || (w.length < 3 && !NSCALL(w)) || !SEQ_CALL_RE.test(baseCall(w[1]))) continue;
      if (w.length >= 3 && !((GRID4_RE.test(w[2]) && w[2] !== 'RR73') || RPT_RE.test(w[2]) || RRPT_RE.test(w[2]))) continue;
      if (w.length < 3) w.push('');
      // Déjà contacté (même bande, même mode, ce TX call) : pas de réponse automatique (double-clic pour lui répondre quand même)
      if (seq.worked.has(baseCall(w[1])) || isDupeNow(w[1], mode)) { seqDupeNote(w[1]); continue; }
      if (!best || d.db > best.d.db) best = { d, w };
    }
    if (best) {
      seq.heardSlot = slot;
      seq.dx = { call: best.w[1], grid: '' };
      if (best.d.f >= 100 && best.d.f <= 3000) seq.rxf = Math.round(best.d.f);
      seq.rptSent = fmtRpt(best.d.db);
      seq.rptRcvd = '';
      seq.qsoStart = 0;
      seq.parity = 1 - theirParity;
      seq.progress = PROG.CALLING;
      seq.cqRun = true;
      seq.waiting.delete(baseCall(best.w[1]));
      seqReact(best.w[2], best.d);
      send(seq.conn, { t: 'notice', level: 'info', msg: best.w[1] + ' répond à votre CQ : réponse automatique « ' + seqText(seq) + ' »' });
      return seqChanged();
    }
  }
  // 3) Décodages de la période qui suit le dernier essai, toujours sans réponse du correspondant : on l'abandonne
  if (seq.giveUp && seq.parity != null && theirParity !== seq.parity) seqGiveUp(seq);
}
/** Correspondant muet après « maxRep » essais du même message : station suivante qui appelait, CQ relancé, ou arrêt. */
function seqGiveUp(s) {
  if (!s || seq !== s || !s.on || !s.giveUp) return;
  clearTimeout(s.giveUpT);
  s.giveUp = false;
  const who = s.dx.call, n = s.rep;
  s.rep = 0; s.repText = '';
  if (ftxPend && ftxPend.state === 'wait' && ftxPend.conn === s.conn) ftxCancel('sans réponse', true);
  const manualQ = Array.from(s.waiting.values()).some((v) => v.manual && baseCall(v.w[1]) !== baseCall(who));
  if ((s.cqRun || manualQ) && s.autoCq && controller === s.conn) {
    s.waiting.delete(baseCall(who));
    s.qsoStart = 0;
    s.rptRcvd = '';
    return seqNextCaller(s, who + ' ne répond plus (' + n + ' essais)', !s.cqRun);
  }
  seqOff('pas de réponse de ' + who + ' après ' + n + ' essais du même message');
}
/** Appel CQ : réponse à la station suivante de la file (la plus forte, pas déjà contactée), sinon CQ relancé. */
function seqNextCaller(s, why, manualOnly) {
  const P = FTX_SLOT[s.mode] || 15000;
  let next = null;
  const rank = (v) => (v.top ? 2 : 0) + (v.manual ? 1 : 0);
  // Réponse double qui vient de partir : le suivant est celui qui a reçu son report dans le RR73 (il n'est pas rappelé),
  // même si son dernier appel date de plus de 2 périodes (il attend maintenant notre report, il n'appelle plus)
  const take = s.dualTake;
  s.dualTake = null;
  for (const [k, v] of s.waiting) {
    if (take && k === take.key) continue;
    if (manualOnly && !v.manual) continue;
    if ((!v.manual && Date.now() - v.at > 2 * P + 2000) || s.worked.has(k) || isDupeNow(v.w[1], s.mode)) { s.waiting.delete(k); continue; }
    if (!next || rank(v) > rank(next) || (rank(v) === rank(next) && v.d.db > next.d.db)) next = v;
  }
  if (take && s.waiting.has(take.key)) next = s.waiting.get(take.key);
  s.on = true;
  s.watchMsg = ''; s.watchSince = 0;
  s.rep = 0; s.repText = '';
  if (next && take && baseCall(next.w[1]) === take.key) {
    s.waiting.delete(take.key);
    s.dx = { call: next.w[1], grid: GRID4_RE.test(next.w[2]) ? next.w[2] : '' };
    if (next.d.f >= 100 && next.d.f <= 3000) s.rxf = Math.round(next.d.f);
    s.rptSent = take.rpt;
    s.rptRcvd = '';
    s.parity = 1 - next.parity;
    s.progress = PROG.CALLING;
    seqSetNtx(2);
    s.qsoStart = Date.now();
    // Son report est déjà parti une fois (dans le RR73) : s'il ne répond pas, il le reçoit à nouveau en message normal
    s.repText = seqText(s); s.rep = 1;
    send(s.conn, { t: 'notice', level: 'info', msg: 'Réponse double : RR73 envoyé et report ' + take.rpt + ' donné à ' + next.w[1] + ' dans la même émission' });
  } else if (next) {
    s.waiting.delete(baseCall(next.w[1]));
    s.dx = { call: next.w[1], grid: '' };
    if (next.d.f >= 100 && next.d.f <= 3000) s.rxf = Math.round(next.d.f);
    s.rptSent = fmtRpt(next.d.db);
    s.parity = 1 - next.parity;
    s.progress = PROG.CALLING;
    if (next.call1) {
      // Ajouté à la main (il ne nous appelait pas) : on l'appelle (Tx1)
      s.dx.grid = next.grid || '';
      s.rptRcvd = '';
      s.qsoStart = 0;
      seqSetNtx(1);
      send(s.conn, { t: 'notice', level: 'info', msg: (why ? why + ' : ' : '') + 'file d’attente → appel de ' + next.w[1] + ' « ' + seqText(s) + ' »' });
    } else {
      seqReact(next.w[2], next.d);
      send(s.conn, { t: 'notice', level: 'info', msg: (why ? why + ' : ' : '') + next.w[1] + ' vous appelait aussi : réponse automatique « ' + seqText(s) + ' »' });
    }
  } else if (manualOnly) {
    s.on = false;
    updateDigi();
    broadcast();
    return;
  } else {
    s.dx = { call: '', grid: '' };
    s.rptSent = '';
    seqSetNtx(6);
    send(s.conn, { t: 'notice', level: 'info', msg: (why ? why + ' : p' : 'P') + 'ersonne d’autre ne vous appelle : CQ relancé' });
  }
  updateDigi();
  broadcast();
  setTimeout(seqNext, 50);
}
/**
 * Message du FOX découpé en parties « DESTINATAIRE FOX CONTENU » : message DXpédition (FOX classique, jusqu'à deux
 * stations par message : « K1ABC RR73; W9XYZ <KH7Z> -08 »), message standard (« W9XYZ KH7Z -08 ») ou partie SuperFox.
 */
function houndParts(msg) {
  const t = String(msg || '').toUpperCase().trim();
  const x = /^(\S+) RR73; (\S+) (\S+) ([+-]\d{2})$/.exec(t);
  if (x) return [[x[1], x[3], 'RR73'], [x[2], x[3], x[4]]];
  const w = t.split(/\s+/);
  return w.length >= 3 ? [[w[0], w[1], w[2]]] : [];
}
/** HOUND : le FOX nous appelle (report → R+report) ou confirme (RR73 → QSO terminé et enregistré). */
function seqHoundDecodes(list) {
  const me = baseCall(seqMe());
  const fox = baseCall(seq.dx.call);
  for (const d of list) {
    for (const [to, from, pl] of houndParts(d.msg)) {
      if (baseCall(to) !== me) continue;
      // Indicatif du FOX haché et pas encore connu (« <...> ») : c'est forcément lui (un seul FOX sur la fréquence)
      if (baseCall(from) !== fox && !/^<?\.\.\.>?$/.test(from)) continue;
      if (pl === 'RR73' || pl === 'RRR' || pl === '73') {
        if (!seq.qsoStart) seq.qsoStart = Date.now();
        send(seq.conn, { t: 'notice', level: 'info', msg: 'RR73 du FOX ' + seq.dx.call + ' : QSO confirmé !' });
        return seqQsoDone('RR73 du FOX reçu');
      }
      if (!RPT_RE.test(pl)) continue;
      seq.rptRcvd = pl;
      seq.rptSent = fmtRpt(d.db); // notre report : le signal du FOX
      seqSetNtx(3);
      seq.houndRptAt = Date.now();
      if (!seq.qsoStart) seq.qsoStart = Date.now();
      if (seq.hound === 1 && d.f >= 200 && d.f <= 2900) { seq.houndFox = Math.round(d.f); seq.f0 = seq.houndFox; }
      send(seq.conn, { t: 'notice', level: 'info', msg: 'Le FOX ' + seq.dx.call + ' vous appelle (' + pl + ') : réponse « ' + seqText(seq) + ' » à ' + seq.f0 + ' Hz' });
      return seqChanged();
    }
  }
}
/** Proposition d'enregistrement du QSO dans le carnet (une seule fois par QSO). */
function seqLogPrompt(s, why, again) {
  const call = s.dx.call;
  if (!SEQ_CALL_RE.test(baseCall(call)) || !s.qsoStart || (s.prompted === s.qsoStart && !again)) return;
  s.prompted = s.qsoStart;
  const start = new Date(s.qsoStart);
  const end = new Date();
  const d8 = (x) => x.toISOString().slice(0, 10).replace(/-/g, '');
  const t6 = (x) => x.toISOString().slice(11, 19).replace(/:/g, '');
  const dial = s.txDial || txFreq() || 0;
  send(s.conn, { t: 'ftx_qso', why, again: !!again, qso: { call, gridsquare: s.dx.grid || '', mode: s.mode, station: seqMe(),
    freq: ((dial + s.f0) / 1e6).toFixed(6), rst_sent: s.rptSent || '', rst_rcvd: s.rptRcvd || '',
    qso_date: d8(start), time_on: t6(start), qso_date_off: d8(end), time_off: t6(end), tx_pwr: radio.power || '' } });
}
/** Station déjà contactée qui répond au CQ : prévenir une fois (pas de réponse automatique). */
function seqDupeNote(call) {
  if (!seq) return;
  seq.dupeNoted = seq.dupeNoted || new Set();
  const k = baseCall(call);
  if (seq.dupeNoted.has(k)) return;
  seq.dupeNoted.add(k);
  send(seq.conn, { t: 'notice', level: 'warn', msg: call + ' vous appelle mais est déjà contacté sur cette bande dans ce mode : pas de réponse automatique (double-clic sur son message pour lui répondre quand même)' });
}
/** Fin du QSO : émission auto coupée, retour sur CQ, proposition d'enregistrement dans le carnet. */
function seqQsoDone(why) {
  const s = seq;
  if (!s) return;
  const call = s.dx.call;
  if (ftxPend && ftxPend.state === 'wait' && ftxPend.conn === s.conn) ftxCancel('QSO terminé', true);
  const wasOn = s.on;
  s.on = false;
  seqSetNtx(s.hound ? 1 : 6); // HOUND : pas de CQ, on reste prêt à rappeler un FOX
  // Fiche déjà proposée (RR73 reçu) : la fin du QSO est signalée aussi (log automatique « à l'envoi du 73 »)
  seqLogPrompt(s, why, s.prompted === s.qsoStart);
  s.qsoStart = 0;
  s.rptRcvd = '';
  if (s.worked && SEQ_CALL_RE.test(baseCall(call))) s.worked.add(baseCall(call));
  // Appel CQ (comme WSJT-X, Tx non coupé après le 73) : réponse au suivant de la file, sinon CQ relancé
  if (wasOn && s.cqRun && s.autoCq && !s.hound && controller === s.conn) return seqNextCaller(s, '');
  // Pas en appel CQ (on appelait quelqu'un) : stations ajoutées à la main à la file d'attente, appelées l'une après l'autre
  if (wasOn && !s.hound && s.autoCq !== false && controller === s.conn && Array.from(s.waiting.values()).some((v) => v.manual)) return seqNextCaller(s, '', true);
  updateDigi();
  broadcast();
}
/** Fin d'une émission de la séquence : 73 / RR73 envoyé → fin du QSO ; sinon la même chose à la prochaine période. */
function seqAfterTx(p) {
  if (!seq || !seq.on || !p || p.conn !== seq.conn) return;
  seq.txDial = txFreq();
  // Période « auto » sans correspondant (CQ) : on garde celle de la première émission (une période sur deux)
  if (seq.parity == null) seq.parity = p.parity;
  if (p.ntx >= 1 && p.ntx <= 5 && !seq.qsoStart) seq.qsoStart = Date.now();
  // RR73 / 73 d'un QSO déjà fini (73 reçu pendant l'émission, QSO suivant commencé) : rien à terminer
  if ((p.ntx === 4 || p.ntx === 5) && seq.dx && String(p.text || '').indexOf(seq.dx.call + ' ') !== 0) return setTimeout(seqNext, 50);
  if ((p.ntx === 4 || p.ntx === 5) && seq.dual2 && String(p.text || '').indexOf('RR73; ' + seq.dual2.call + ' ') > 0) seq.dualTake = seq.dual2;
  if (p.ntx === 4 || p.ntx === 5) return seqQsoDone(p.ntx === 4 ? 'RR73 envoyé' : '73 envoyé');
  // Essais du même message (Tx1 à Tx3) : compte remis à zéro dès que le message change (réponse reçue)
  if (p.ntx >= 1 && p.ntx <= 3) {
    if (p.text === seq.repText) seq.rep++;
    else { seq.repText = p.text; seq.rep = 1; }
  } else { seq.repText = ''; seq.rep = 0; }
  // FOX classique : R+report à répéter → à 300 Hz de la fréquence du FOX (comme WSJT-X)
  if (seq.hound === 1 && p.ntx === 3 && seq.houndFox) seq.f0 = seq.houndFox <= 600 ? seq.houndFox + 300 : seq.houndFox - 300;
  setTimeout(seqNext, 50);
}
/** Clic sur Tx1…Tx7 : émission auto de ce message. */
function seqMaxRep(v) { v = Number(v); return Number.isInteger(v) && v >= 0 && v <= 20 ? v : 4; }
function seqStart(conn, m) {
  if (seq && seq.giveUpT) clearTimeout(seq.giveUpT);
  const err = (msg) => send(conn, { t: 'notice', level: 'error', msg });
  if (controller !== conn) return err('Prenez d’abord la main');
  const mode = String(m.mode || '');
  if (!FTX_SLOT[mode]) return err('Mode numérique inconnu');
  const ntx = Math.round(Number(m.ntx));
  if (!(ntx >= 1 && ntx <= 7)) return err('Message inconnu');
  const dx = m.dx && typeof m.dx === 'object' ? m.dx : {};
  const call = String(dx.call || '').toUpperCase().trim().slice(0, 13);
  const grid = String(dx.grid || '').toUpperCase().trim().slice(0, 4);
  const free = String(m.free || '').toUpperCase().replace(/[^A-Z0-9 +\-./?]/g, '').trim().slice(0, 13);
  const hound = mode === 'FT8' ? ftHound : 0;
  if (hound && ntx !== 1 && ntx !== 3 && ntx !== 5) return err('HOUND : seulement Tx1 (appel du FOX), Tx3 (R + report) et Tx5 (73). Pas de CQ : le FOX termine le QSO par RR73.');
  if (ntx <= 5 && !SEQ_CALL_RE.test(baseCall(call))) return err('Choisissez d’abord le correspondant (double-clic sur son message)');
  if (ntx === 7 && !free) return err('Texte libre vide');
  if ((ntx === 1 || ntx === 6) && !GRID4_RE.test(seqGrid())) return err('Locator de la station non configuré sur le serveur (stationGrid)');
  if (ptt.active && !ptt.digi) return err('Émission en cours : attendez la fin');
  const f0 = Math.round(Number(m.f0));
  if (!(f0 >= 200 && f0 <= 2900)) return err('Fréquence d’émission audio hors plage (200 à 2900 Hz)');
  const same = seq && seq.conn === conn && baseCall(seq.dx.call) === baseCall(call) && seq.mode === mode;
  seq = {
    conn, on: true, mode, f0,
    parity: hound ? 1 : m.parity === 0 || m.parity === 1 ? m.parity : null,
    hound, houndFox: 0, houndRptAt: 0,
    ntx, progress: NTX_PROG[ntx] != null ? NTX_PROG[ntx] : (same ? seq.progress : 0),
    dx: { call, grid: GRID4_RE.test(grid) ? grid : '' },
    rptSent: RPT_RE.test(String(m.rpt || '')) ? String(m.rpt) : fmtRpt(m.rpt),
    rptRcvd: same ? seq.rptRcvd : '', free, call1st: !hound && m.call1st !== false,
    // Appel CQ en cours (Tx6, ou QSO d'un CQ) : à la fin du QSO, réponse au suivant qui appelle, sinon CQ relancé (autoCq)
    // « Toujours CQ » (cqAlways) : même un QSO commencé en répondant à un CQ se termine par le CQ relancé (ou le suivant)
    cqRun: !hound && (ntx === 6 || m.cqAlways === true || (same && !!seq.cqRun && ntx >= 2)), autoCq: !hound && m.autoCq !== false, cqAlways: !hound && m.cqAlways === true,
    dual: !hound && m.dual === true, dual2: null, dualTake: null,
    waiting: (seq && seq.conn === conn && seq.mode === mode && seq.waiting) || new Map(),
    worked: (seq && seq.conn === conn && seq.mode === mode && seq.worked) || new Set(),
    watchMsg: '', watchSince: 0, qsoStart: same ? seq.qsoStart : 0, txDial: 0, keyNow: !!m.keyNow,
    // Abandon d'un correspondant muet : après « maxRep » envois du même message (0 = jamais, comme WSJT-X)
    maxRep: seqMaxRep(m.maxRep), rep: 0, repText: '', giveUp: false, giveUpT: null, fresh: true,
    // Fréquence audio du correspondant (fréquence RX) : l'aide AP du décodeur pour ce QSO s'y applique (comme WSJT-X)
    rxf: Number(m.rxf) >= 100 && Number(m.rxf) <= 3000 ? Math.round(Number(m.rxf)) : (same && seq.rxf) || 0,
    // Récepteur du correspondant (FTDX101 en double réception) : l'émission part sur ce VFO (A = MAIN, B = SUB)
    side: m.side === 'B' && ftTxBOk() ? 'B' : 'A'
  };
  seqTxSide();
  lastCtrlActivity = Date.now();
  // Émission en cours (message précédent) : le nouveau message part à la période suivante
  if (ftxPend && ftxPend.state === 'wait') ftxCancel('remplacée par le nouveau message', true);
  updateDigi();
  seqNext();
  broadcast();
}
/** Réglages changés pendant l'émission auto (fréquence audio, période, répondre au 1er). */
function seqCfg(conn, m) {
  if (!seq || seq.conn !== conn) return;
  const f0 = Math.round(Number(m.f0));
  // FOX classique : pendant le R+report, la fréquence est celle que fixe le FOX (pas le repère TX)
  if (f0 >= 200 && f0 <= 2900 && !(seq.hound === 1 && seq.ntx === 3)) {
    seq.f0 = f0;
    // Émission en cours : le signal change de fréquence tout de suite (page Station : refait et repris au même instant)
    const p = ftxPend;
    if (p && p.state === 'tx' && p.conn === seq.conn && p.f0 !== f0 && FTX_SLOT[p.mode]) {
      p.f0 = f0;
      toStation({ t: 'cmd', op: 'ftxretune', id: p.id, f0 });
    }
  }
  if (seq.hound) seq.parity = 1;
  // Période imposée (liste « Période » : paire / impaire) seulement. Jamais remise à « auto » en cours de séquence :
  // la page envoie ses réglages à chaque clic (fréquence RX, cases…) et la période du QSO repartait au plus tôt —
  // CQ ou report émis dans la même période que le correspondant (jamais entendus).
  else if (m.parity === 0 || m.parity === 1) seq.parity = m.parity;
  if (typeof m.call1st === 'boolean' && !seq.hound) seq.call1st = m.call1st;
  if (typeof m.autoCq === 'boolean' && !seq.hound) seq.autoCq = m.autoCq;
  if (typeof m.dual === 'boolean' && !seq.hound) seq.dual = m.dual;
  if (m.maxRep != null) seq.maxRep = seqMaxRep(m.maxRep);
  if (typeof m.cqAlways === 'boolean' && !seq.hound) { seq.cqAlways = m.cqAlways; if (m.cqAlways) seq.cqRun = true; }
  // Fréquence RX changée (clic sur la cascade) : l'aide AP du décodeur pour le QSO s'y applique tout de suite
  if (Number(m.rxf) >= 100 && Number(m.rxf) <= 3000 && Math.round(Number(m.rxf)) !== seq.rxf) { seq.rxf = Math.round(Number(m.rxf)); updateDigi(); }
  // VFO d'émission changé pendant la séquence (FTDX101 en double réception) : pris en compte dès que le TRX est en réception
  if (m.side === 'A' || m.side === 'B') {
    const side = m.side === 'B' && ftTxBOk() ? 'B' : 'A';
    if (side !== seq.side) {
      seq.side = side;
      if (ftxPend && ftxPend.state === 'wait' && ftxPend.conn === seq.conn) ftxCancel('VFO d’émission changé', true); // repart à la bonne fréquence
      updateDigi();
      seqTxSide();
    }
  }
  seqChanged();
}

// ---------------------------------------------------------------- émission RTTY / JTTY
// Pas de créneau : le serveur fabrique le signal (RTTY : AFSK ; JTTY : codeur de WSJT-X, lib/bin/jttygen),
// l'envoie à la page Station, puis met le TRX en émission dès que la page l'a reçu ; retour en réception à la fin.
const RTTY_GEN = require('./lib/rtty.js').generate;
const SSTV_ENC = require('./public/js/sstv.js');
/** Durée maximale d'une émission SSTV (s) : réglage, sans dépasser le chien de garde de la page Station. */
function sstvMaxSeconds() {
  return Math.max(30, Math.min(Number(cfg.maxSstvSeconds) || 300, (Number(cfg.txHardMaxSeconds) || 300) - 5));
}
const JTTY_GEN = path.join(ROOT, 'lib', 'bin', 'jttygen' + (process.platform === 'win32' ? '.exe' : ''));
const AUDIO_RATE = 12000;
function jttyWave(text, f0) {
  return new Promise((resolve, reject) => {
    const { execFile } = require('child_process');
    execFile(JTTY_GEN, [String(Math.round(f0)), text], { encoding: 'buffer', maxBuffer: 64 * 1024 * 1024, timeout: 10000 }, (err, out, errout) => {
      if (err) return reject(new Error(err.code === 2 ? 'message JTTY impossible à coder : « ' + text + ' »' : 'codeur JTTY indisponible sur le serveur'));
      resolve(new Int16Array(out.buffer.slice(out.byteOffset, out.byteOffset + (out.length & ~1))));
    });
  });
}
async function audioRequest(conn, m) {
  const err = (msg) => send(conn, { t: 'notice', level: 'error', msg });
  const mode = String(m.mode || '');
  if (mode !== 'RTTY' && mode !== 'JTTY' && mode !== 'SSTV') return err('Mode inconnu');
  // SSTV : image envoyée avant par morceaux (sstv_up), au format du mode (largeur × hauteur × 3 octets RGB)
  let sstv = null;
  if (mode === 'SSTV') {
    const M = SSTV_ENC.MODES[String(m.sstv || '')];
    if (!M) return err('Mode SSTV inconnu');
    const up = conn.sstvUp;
    if (!up || up.id !== String(m.up || '') || up.got !== up.n) return err('Image SSTV incomplète : réessayez');
    const rgb = Buffer.concat(up.parts);
    conn.sstvUp = null;
    if (rgb.length !== M.w * M.h * 3) return err('Image SSTV au mauvais format (' + M.w + ' × ' + M.h + ' attendu)');
    const d = SSTV_ENC.duration(M.id);
    if (d > sstvMaxSeconds()) return err('Mode ' + M.name + ' trop long : ' + Math.round(d) + ' s (limite du serveur : ' + sstvMaxSeconds() + ' s) ; choisissez un mode plus court');
    sstv = { M, rgb };
  }
  if (controller !== conn) return err('Prenez d’abord la main');
  if (!station || station.caps.indexOf('audiotx') < 0) {
    return err('La page Station du club ne sait pas encore émettre en ' + mode + ' (ancienne version) : ' +
      (conn.user.admin ? 'rechargez-la (voyant STATION → « Recharger la page Station »).' : 'un administrateur doit la recharger.'));
  }
  if (ptt.active || ftxPend) return err('Émission déjà en cours ou prévue : attendez la fin');
  if (seq && seq.on) return err('Émission automatique FT8 / FT4 / FT2 en cours : arrêtez-la d’abord');
  const why = txBlockReason(conn);
  if (why && radio.power != null && radio.power > conn.user.maxWatts) limitPower(conn, 'avant émission');
  if (why) return err('Émission refusée : ' + why);
  const md = (radio.txVfo === 1 ? radio.modeB : radio.mode) || '';
  if (!digiModeOk(md)) return err('Mettez d’abord le VFO d’émission en ' + digiModeName() + ' (mode actuel : ' + (md || '?') + ') : le signal ' + mode + ' passe par la carte son');
  const f0 = sstv ? 1900 : Math.round(Number(m.f0));
  if (!(f0 >= 300 && f0 <= 2800)) return err('Fréquence d’émission audio hors plage (300 à 2800 Hz)');
  let text = sstv ? 'image ' + sstv.M.name : String(m.text || '').toUpperCase().replace(/\r/g, '').replace(/[^\n -~]/g, '').replace(/[ \t]+/g, ' ');
  text = mode === 'JTTY' ? text.replace(/\s*\n\s*/g, ' ').trim() : text.replace(/^\n+|\s+$/g, '');
  if (!text) return err('Rien à émettre : tapez un texte ou choisissez une macro');
  if (text.length > (mode === 'JTTY' ? 160 : 600)) return err('Texte trop long (' + (mode === 'JTTY' ? 160 : 600) + ' caractères au plus)');
  let pcm;
  let charMs = null; // RTTY : fin de chaque caractère (ms depuis le début du signal), pour la page de l'opérateur
  try {
    if (sstv) {
      // Image entière : en-tête VOX + VIS puis lignes (mêmes fréquences que l'aperçu « Écouter » du dashboard)
      const w = SSTV_ENC.encode(sstv.M.id, sstv.rgb, AUDIO_RATE, 3);
      pcm = new Int16Array(w.length);
      const ramp = Math.round(AUDIO_RATE * 0.005);
      for (let i = 0; i < w.length; i++) {
        const g = Math.min(1, i / ramp, (w.length - 1 - i) / ramp);
        pcm[i] = Math.round(w[i] / 0.8 * g * 0.85 * 32767); // crête 0,85 comme RTTY
      }
    } else if (mode === 'RTTY') {
      const shift = [170, 200, 425, 850].indexOf(Number(m.shift)) >= 0 ? Number(m.shift) : 170;
      const baud = [45.45, 50, 75, 100].indexOf(Number(m.baud)) >= 0 ? Number(m.baud) : 45.45;
      // Début de ligne propre chez le correspondant : retour chariot + saut de ligne avant le texte
      const w = RTTY_GEN('\n' + text + ' ', { f: f0, shift, baud, rev: !!m.rev, rate: AUDIO_RATE });
      charMs = w.charMs ? w.charMs.slice(1, 1 + text.length) : null;
      pcm = new Int16Array(w.length);
      const ramp = Math.round(AUDIO_RATE * 0.005);
      for (let i = 0; i < w.length; i++) {
        const g = Math.min(1, i / ramp, (w.length - 1 - i) / ramp);
        pcm[i] = Math.round(w[i] * g * 0.85 * 32767);
      }
    } else {
      // JTTY : 80 caractères au plus par message (WSJT-X) ; au-delà, deux messages à la suite
      const parts = [];
      let rest = text;
      while (rest.length > 80) { let cut = rest.lastIndexOf(' ', 80); if (cut < 20) cut = 80; parts.push(rest.slice(0, cut).trim()); rest = rest.slice(cut).trim(); }
      if (rest) parts.push(rest);
      const waves = [];
      for (const t of parts) waves.push(await jttyWave(t, f0));
      const gap = Math.round(AUDIO_RATE * 0.1);
      pcm = new Int16Array(waves.reduce((a, w) => a + w.length + gap, 0));
      let o = 0;
      for (const w of waves) { pcm.set(w, o); o += w.length + gap; }
    }
  } catch (e) {
    return err('Émission ' + mode + ' impossible : ' + e.message);
  }
  const seconds = pcm.length / AUDIO_RATE;
  if (!sstv && seconds > cfg.maxTxSeconds - 2) return err('Texte trop long : ' + Math.round(seconds) + ' s d’émission (limite du serveur : ' + cfg.maxTxSeconds + ' s)');
  if (controller !== conn || ptt.active || ftxPend) return; // situation changée pendant la fabrication du signal
  const p = { id: ++ftxSeq, conn, mode, text, f0, at: 0, parity: 0, state: 'wait', ready: false, seconds, sent: text.replace(/\n/g, ' ').slice(0, 60), timer: null, ntx: 0, kind: 'audio',
    maxS: sstv ? Math.ceil(seconds) + 5 : 0, sstv: sstv ? sstv.M.id : null };
  ftxPend = p;
  lastCtrlActivity = Date.now();
  // Texte exact émis et minutage lettre par lettre : la page de l'opérateur colore chaque lettre une fois partie
  send(conn, { t: 'dtx_text', id: p.id, mode, text, ms: charMs, seconds: Math.round(seconds * 10) / 10 });
  toStation({ t: 'cmd', op: 'audioprep', id: p.id, mode, rate: AUDIO_RATE, data: Buffer.from(pcm.buffer, pcm.byteOffset, pcm.byteLength).toString('base64') });
  // Page Station trop lente à recevoir le signal : abandon
  p.timer = setTimeout(() => { if (ftxPend === p && !p.ready) ftxCancel('la page Station n’a pas reçu le signal à temps'); }, sstv ? 45000 : 20000);
  broadcast();
}

/** Juste avant le créneau : dernières vérifications puis passage en émission avec le signal préparé. */
/**
 * Séquence automatique (QSO en cours, ou CQ en attente d'une réponse) : avant de partir, on attend la passe normale du
 * décodeur pour la période qui vient de finir (elle arrive ~0,5 à 1,5 s après le début de la nôtre : audio venu du
 * club par internet, puis calcul). Sinon le message part « comme si rien n'était reçu » puis est remplacé 1 s plus tard.
 * Attente bornée : départ en retard d'au plus ~1,1 s en FT8 (le décodeur d'en face l'accepte, DT un peu plus grand).
 */
function ftxHoldUntil(p) {
  const P = FTX_SLOT[p.mode];
  if (!P || p.mode === 'FT2' || !seq || !seq.on || seq.conn !== p.conn || seq.hound) return 0;
  // Premier message après un clic (bouton Tx, touche F1…F7, double-clic) : l'opérateur vient de choisir, il part sans attendre
  if (seq.fresh) return 0;
  // Seulement si une réponse peut changer le message : QSO en cours (Tx1 à Tx5), ou CQ avec « répondre au 1er »
  if (!((p.ntx >= 1 && p.ntx <= 5) || (p.ntx === 6 && seq.call1st))) return 0;
  if (!digi.worker || Date.now() - (digi.last || 0) > 60000) return 0; // pas de décodeur actif : on n'attend rien
  const k = Math.floor(p.at / P);
  const prev = (k - 1) * P;
  const got = (digi.normal || {})[(seq.side || 'A') + p.mode] || 0;
  if (got >= prev) return 0; // déjà reçue
  if ((seq.heardSlot || 0) >= prev) return 0; // réponse du correspondant déjà décodée (passe anticipée) : message à jour
  // Attente réglée sur les dernières périodes : juste le temps qu'il faut à la passe normale (+ 0,3 s), 1 s au plus.
  // Décodages trop tardifs pour arriver dans ce délai (serveur bloqué, audio en retard) : on n'attend pas du tout —
  // attendre ne ferait que retarder l'émission sans la réponse.
  const late = ((digi.normalLate || {})[(seq.side || 'A') + p.mode] || []).slice().sort((a, b) => a - b);
  const cap = Math.min(FTX_LATE[p.mode] - 500, 1000);
  let wait = cap;
  if (late.length >= 3) {
    if (late[late.length >> 1] > cap) return 0;
    wait = Math.max(300, Math.min(cap, late[late.length - 1] + 300));
  }
  const until = k * P + FTX_T0 + wait - FTX_KEY_LEAD;
  return until > Date.now() + 50 ? until : 0;
}
function ftxHoldCheck() {
  const p = ftxPend;
  if (!p || !p.hold || p.state !== 'wait') return;
  if (ftxHoldUntil(p)) return; // toujours rien
  clearTimeout(p.holdT);
  p.hold = false;
  p.holdDone = true;
  p.at = Math.max(p.at, Date.now() + FTX_KEY_LEAD); // départ un peu après le début nominal
  ftxKey(p);
}
function ftxKey(p) {
  if (ftxPend !== p) return;
  if (!p.holdDone) {
    const until = ftxHoldUntil(p);
    if (until) {
      p.hold = true;
      p.holdT = setTimeout(() => { if (ftxPend !== p || !p.hold) return; p.hold = false; p.holdDone = true; p.at = Math.max(p.at, Date.now() + FTX_KEY_LEAD); ftxKey(p); }, until - Date.now());
      return;
    }
  }
  if (!p.ready) {
    // Signal pas encore revenu de la page Station : on l'attend jusqu'à 0,8 s (départ décalé d'autant), puis abandon
    if (!p.waitReady) { p.waitReady = true; clearTimeout(p.timer); p.timer = setTimeout(() => { if (ftxPend === p && !p.ready) ftxCancel('la page Station n’a pas préparé le signal à temps'); }, 800); }
    return;
  }
  if (seq && seq.conn === p.conn) seq.fresh = false; // les messages suivants de la séquence attendent le décodage
  if (controller !== p.conn) return ftxCancel('main perdue');
  if (ptt.active) return ftxCancel('émission déjà en cours');
  const why = txBlockReason(p.conn);
  if (why) return ftxCancel(why);
  const now = Date.now();
  p.state = 'tx';
  if (['FT8', 'FT4', 'FT2'].indexOf(p.mode) >= 0) {
    ftTxSlots.push({ mode: p.mode, slot: Math.floor(p.at / FTX_SLOT[p.mode]) * FTX_SLOT[p.mode], text: p.sent || p.text });
    while (ftTxSlots.length > 30) ftTxSlots.shift();
  }
  ptt = { active: true, conn: p.conn, since: now, lastBeat: now, digi: { id: p.id, mode: p.mode, maxS: p.maxS || 0 } };
  lastCtrlActivity = now;
  const tv = txSide();
  ptt.rx = radio.vfoSel === 1 ? 1 : 0;
  toStation({ t: 'cmd', op: 'ptt', on: true, by: p.conn.user.call, txVfo: rig().VIRTUAL_SPLIT && radio.hwSplit !== 1 ? tv : undefined, digi: { id: p.id, at: p.at } });
  toStation({ t: 'txka' });
  journal('tx_start', { call: p.conn.user.call, ip: p.conn.ip, freq: txFreq(), mode: p.mode, text: p.sent || p.text, f0: p.f0, split: !!radio.split, watts: radio.power });
  // FT8 / FT4 / FT2 : jamais au-delà de la fin de notre période (départ en retard → message tronqué, comme WSJT-X)
  const P = FTX_SLOT[p.mode];
  if (P) {
    const pend = Math.floor(p.at / P) * P + P - 60;
    if (p.at + p.seconds * 1000 > pend) {
      p.cut = setTimeout(() => { if (ptt.active && ptt.digi && ptt.digi.id === p.id) stopPtt(FTX_END); }, Math.max(0, pend - Date.now()));
    }
  }
  // Filet : fin du message non signalée par la page Station
  p.timer = setTimeout(() => { if (ptt.active && ptt.digi && ptt.digi.id === p.id) stopPtt('fin du message non confirmée par la page Station'); },
    Math.max(1000, p.at + p.seconds * 1000 + 2500 - Date.now()));
  broadcast();
}

setInterval(() => {
  const now = Date.now();
  if (txw) {
    if (controller !== txw.conn) txwOff('main perdue');
    else if (!station || !radio.connected) txwOff('station ou TRX hors ligne');
    else if (now - txw.beat > 2500) txwOff('perte de liaison');
    else if (now - txw.since > 15000) txwOff('15 s au plus');
  }
  if (ptt.active) {
    if (!ptt.digi && now - ptt.lastBeat > cfg.pttHeartbeatMs) stopPtt('perte de liaison avec l’opérateur');
    else if (now - ptt.since > ((ptt.digi && ptt.digi.maxS) || cfg.maxTxSeconds) * 1000) stopPtt('durée maximale atteinte (' + ((ptt.digi && ptt.digi.maxS) || cfg.maxTxSeconds) + ' s)');
    else toStation({ t: 'txka' });
  }
  // Émission numérique programmée : annulée si l'opérateur n'a plus la main ou si la station a disparu
  if (ftxPend && ftxPend.state === 'wait' && (controller !== ftxPend.conn || !station)) ftxCancel(!station ? 'station hors ligne' : 'main perdue');
  if (seq && seq.on && (controller !== seq.conn || !station)) seqOff(!station ? 'station hors ligne' : 'main perdue');
  if (cwJob && (controller !== cwJob.conn || !station)) cwEnd(!station ? 'station hors ligne' : 'main perdue', false);
  if (voiceUser && controller !== voiceUser && !ptt.active) voiceRelease('main rendue');
  eqTick(now);
  fairCheck(now);
  ctlTimer(now);
  usageTick(now);
  // Aucune libération ni déconnexion pour inactivité tant que le TRX est en émission
  if (ptt.active || radio.tx || ftxPend || cwJob || (seq && seq.on)) return;
  if (controller && now - lastCtrlActivity > cfg.controlIdleMinutes * 60000) {
    const c = controller;
    stopPtt('inactivité');
    controller = null;
    send(c, { t: 'notice', level: 'warn', msg: 'Main libérée après ' + cfg.controlIdleMinutes + ' min d’inactivité' });
    journal('control_release', { call: c.user.call, reason: 'inactivité' });
    broadcast();
  }
  const lim = Number(cfg.sessionIdleMinutes) * 60000;
  if (lim > 0) {
    for (const c of ops) {
      if (idleExempt(c)) continue;
      const idle = now - (c.lastActive || now);
      const warnMs = Math.min(60000, lim / 4);
      if (idle > lim - warnMs && !c.idleWarned) {
        // Toujours un avertissement une minute avant (même juste après une émission qui a retardé l'échéance)
        c.idleWarned = true;
        c.lastActive = now - Math.min(idle, lim - warnMs);
        send(c, { t: 'idle_warn', seconds: Math.round(warnMs / 1000) });
      } else if (idle > lim) {
        send(c, { t: 'session_end', msg: 'Déconnecté après ' + cfg.sessionIdleMinutes + ' min sans activité' });
        journal('session_idle', { call: c.user.call, ip: c.ip });
        dropSession(c); // après une déconnexion pour inactivité, mot de passe exigé
        c.close(4005, 'inactivité');
      }
    }
  }
}, 250);

// ---------------------------------------------------------------- messages opérateurs
const offMsg = (call, why) => 'Compte ' + call + ' ' + (why === 'désactivé' ? 'désactivé' : why) + ' : l’accès à la Remote Station est réservé aux membres en ordre d’affiliation à la section. Contactez un administrateur (' +
  (Array.isArray(cfg.stationEditors) ? cfg.stationEditors.join(', ') : 'ON6DP') + ').';
// Compte désactivé, supprimé ou expiré pendant qu'il est connecté : session fermée dans la minute
setInterval(() => {
  if (!ops.size) return;
  let users;
  try { users = auth.loadUsers(USERS_FILE); } catch (e) { return; }
  for (const c of Array.from(ops)) {
    const rec = users[c.user.call];
    const off = rec ? auth.userOff(rec) : 'supprimé';
    if (!off) continue;
    if (controller === c) { stopPtt('compte ' + off); controller = null; }
    send(c, { t: 'session_end', level: 'error', msg: offMsg(c.user.call, off) });
    journal('session_off', { call: c.user.call, ip: c.ip, why: off });
    dropSession(c);
    ops.delete(c);
    try { c.close(4007, 'compte hors service'); } catch (e) { /* */ }
    broadcast();
  }
}, 30000);

async function onLogin(conn, m) {
  const now = Date.now();
  if (typeof m.session === 'string' && m.session) {
    // Retour d'un membre déjà identifié sur ce navigateur (page actualisée, reconnexion…)
    const h = sessHash(m.session);
    const s = sessions[h];
    const rec = s && s.exp > now ? auth.loadUsers(USERS_FILE)[s.call] : null;
    if (!rec || auth.userOff(rec) || !auth.validCall(s.call, cfg.allowedPrefixes, cfg.allowedCalls)) {
      if (s) { delete sessions[h]; saveSessions(); }
      return send(conn, { t: 'login_fail', session: true, msg: '' });
    }
    s.exp = now + cfg.rememberDays * 86400000;
    saveSessions();
    conn.sessHash = h;
    return loggedIn(conn, s.call, rec, m.session);
  }
  const f = fails.get(conn.ip);
  if (f && f.until > now) {
    return send(conn, { t: 'login_fail', msg: 'Trop d’essais, réessayez dans quelques minutes' });
  }
  const call = auth.normCall(m.call);
  const users = auth.loadUsers(USERS_FILE);
  if (!auth.validCall(call, cfg.allowedPrefixes, cfg.allowedCalls)) {
    journal('login_refused_prefix', { call, ip: conn.ip });
    return setTimeout(() => send(conn, { t: 'login_fail', msg: 'Accès réservé aux indicatifs belges (' + cfg.allowedPrefixes.join(', ') + ')' }), 600);
  }
  const rec = users[call];
  const ok = rec && (await auth.verifyPassword(m.pass, rec));
  if (!ok) {
    const expired = f && f.until && f.until <= now;
    const n = (f && !expired ? f.n : 0) + 1;
    fails.set(conn.ip, { n, until: n >= 5 ? now + 10 * 60000 : 0 });
    journal('login_fail', { call, ip: conn.ip });
    return setTimeout(() => send(conn, { t: 'login_fail', msg: 'Indicatif ou mot de passe incorrect' }), 600);
  }
  fails.delete(conn.ip);
  // Bon mot de passe mais compte hors service (affiliation non renouvelée…) : on le dit clairement
  const off = auth.userOff(rec);
  if (off) {
    journal('login_refused_off', { call, ip: conn.ip, why: off });
    return send(conn, { t: 'login_fail', msg: offMsg(call, off) });
  }
  const tok = newSession(call);
  if (tok) conn.sessHash = sessHash(tok);
  return loggedIn(conn, call, rec, tok);
}

/** Page /stats : session mémorisée d'un administrateur (celle du dashboard sur ce navigateur), statistiques calculées ici. */
function onStats(conn, m, authTimer) {
  const now = Date.now();
  const s = typeof m.session === 'string' && m.session ? sessions[sessHash(m.session)] : null;
  const rec = s && s.exp > now ? auth.loadUsers(USERS_FILE)[s.call] : null;
  if (!rec || auth.userOff(rec)) return send(conn, { t: 'stats_fail', msg: 'Connectez-vous d’abord au dashboard dans ce navigateur (compte administrateur), puis rechargez cette page.' });
  if (!rec.admin) return send(conn, { t: 'stats_fail', msg: 'Statistiques réservées aux administrateurs.' });
  clearTimeout(authTimer);
  conn.statsCall = s.call;
  const day = 86400000;
  let to = Number(m.to) > 0 ? Number(m.to) : now;
  let from = Number(m.from) > 0 ? Number(m.from) : to - 30 * day;
  to = Math.min(to, now + day);
  if (to - from > 400 * day) from = to - 400 * day;
  const call = typeof m.call === 'string' ? m.call.toUpperCase().replace(/[^A-Z0-9/]/g, '').slice(0, 12) : '';
  let data;
  try { data = STATS.compute({ dir: LOG_DIR, from, to, tz: cfg.stationTz || 'Europe/Brussels', call, qsos: book.qsos }); } catch (e) { return send(conn, { t: 'stats_fail', msg: 'Calcul impossible : ' + e.message }); }
  journal('stats_view', { call: s.call, ip: conn.ip });
  send(conn, { t: 'stats', data, by: s.call, clubName: cfg.clubName, stationCall: cfg.stationCall });
}

function loggedIn(conn, call, rec, sessionTok) {
  const now = Date.now();
  const rxOnly = auth.isRxOnly(call, cfg.rxOnlyPrefixes);
  conn.user = { call, admin: !!rec.admin, tx: rec.tx !== false && !rxOnly, rxOnly, maxWatts: rxOnly ? 0 : maxWattsFor(call) };
  // Un compte = une adresse IP à la fois : onglets et appareils d'un même réseau permis ; une connexion depuis une autre
  // adresse ferme les anciennes (prêt de compte), qui devront retaper le mot de passe. Les administrateurs sont prévenus.
  const kicked = [];
  for (const c of ops) {
    if (c === conn || !c.user || c.user.call !== call || !c.ip || !conn.ip || sameNet(c.ip, conn.ip)) continue;
    kicked.push(c);
  }
  for (const c of kicked) {
    if (controller === c) { stopPtt('compte ouvert depuis une autre adresse'); controller = null; }
    send(c, { t: 'session_end', level: 'error', msg: 'Votre compte ' + call + ' vient d’être ouvert depuis une autre adresse internet : session fermée ici. Un compte ne peut servir qu’à un seul opérateur à la fois.' });
    dropSession(c);
    ops.delete(c);
    try { c.close(4006, 'autre adresse'); } catch (e) { /* déjà fermée */ }
  }
  if (kicked.length) {
    journal('session_kicked', { call, ip: conn.ip, old: Array.from(new Set(kicked.map((c) => c.ip))) });
    const msg = 'Sécurité : le compte ' + call + ' a été ouvert depuis une autre adresse (' + conn.ip + ') ; ancienne session fermée (' + Array.from(new Set(kicked.map((c) => c.ip))).join(', ') + ').';
    setTimeout(() => { for (const c of ops) if (c.user && c.user.admin) send(c, { t: 'notice', level: 'warn', msg }); }, 300);
    setTimeout(broadcast, 0);
  }
  ops.add(conn);
  conn.lastActive = now;
  conn.idleWarned = false;
  journal('login', { call, ip: conn.ip });
  send(conn, {
    t: 'hello',
    call,
    cid: conn.cid,
    admin: conn.user.admin,
    editor: isEditor(call),
    canTx: conn.user.tx,
    rxOnly: conn.user.rxOnly,
    allowTx: cfg.allowTx,
    maxTxSeconds: cfg.maxTxSeconds,
    maxWatts: conn.user.maxWatts,
    clubName: cfg.clubName,
    stationCall: cfg.stationCall,
    rigs: Object.keys(DRIVERS).map((id) => ({ id, name: DRIVERS[id].NAME })),
    sessionIdleMinutes: idleExempt(conn) ? 0 : cfg.sessionIdleMinutes,
    digiCall: String(cfg.digiCall || '').toUpperCase(),
    clubCalls: stationCalls(),
    subCat: !!cfg.ftx1SubCat,
    subSingle: !!cfg.ftx1SubSingle,
    qsyOrigins: qsyOrigins(),
    stationGrid: String(cfg.stationGrid || '').toUpperCase(),
    stationQth: String(cfg.stationQth || '').toUpperCase(),
    qo100If: cfg.qo100If && typeof cfg.qo100If === 'object' ? cfg.qo100If : DEFAULTS.qo100If,
    session: sessionTok || null,
    version: VERSION
  });
  sendClusterSpots(conn);
  send(conn, { t: 'cluster_list', list: clusterList().map(({ name, key, info, def, host, port }) => ({ name, key, info, def: !!def, host, port })), cur: connClusterKey(conn) });
  send(conn, { t: 'macros', data: macros[call] || {} });
  send(conn, { t: 'events', list: recentEvents });
  send(conn, { t: 'chatlog', list: chatLog });
  sendWorked(true, conn);
  if (conn.user.admin) {
    const us = UPD.state();
    if (us.latest || us.job) send(conn, us);
    // Administrateur qui se connecte : nouvelle recherche si la dernière date de plus de 5 minutes (le bouton apparaît dès qu'il y en a une)
    else if (UPD.enabled && Date.now() - (UPD.checked || 0) > 5 * 60000) UPD.check().then(() => { const s2 = UPD.state(); if (s2.latest && conn.open) send(conn, s2); }).catch(() => {});
  }
  if (conn.user.admin && netNewer && !(NET.isMaster() && NET.prioOf() > 0)) send(conn, { t: 'notice', level: 'warn', msg: 'Réseau : le maître ' + netNewer.name + ' est en version ' + netNewer.v + ', ce serveur en ' + VERSION + '. Pensez à le mettre à jour (🔔 Mise à jour), hors contest.' });
  broadcast();
}

function onOperator(conn, m) {
  const now = Date.now();
  switch (m.t) {
    case 'scope_sub':
      // Page Face avant (IC-7300) : veut le scope du TRX ; renouvelé toutes les 20 s, false à la fermeture de l'onglet
      conn.scopeSub = m.on ? now : 0;
      return updateScopeWant();
    case 'take':
      if (controller && controller !== conn && controller.user.call === conn.user.call) {
        // même indicatif dans un autre onglet ou sur un autre appareil : la main passe ici, sans forcer
        stopPtt('main passée sur un autre onglet');
        send(controller, { t: 'notice', level: 'warn', msg: 'La main est passée sur un autre onglet ou appareil' });
      } else if (controller && controller !== conn) {
        if (!(m.force && conn.user.admin)) {
          return send(conn, { t: 'notice', level: 'error', msg: controller.user.call + ' a déjà la main' });
        }
        const prev = controller;
        stopPtt('reprise de la main par ' + conn.user.call);
        send(prev, { t: 'notice', level: 'warn', msg: conn.user.call + ' (admin) a repris la main' });
      }
      if (controller !== conn) tunerAuto.until = Date.now() + 4000; // prise de main : tuner remis en service s'il est coupé (HF / 6 m)
      controller = conn;
      conn.lastAsk = 0; // demande satisfaite
      lastCtrlActivity = now;
      journal('control_take', { call: conn.user.call, force: !!m.force });
      limitPower(conn, 'prise de main');
      return broadcast();

    case 'cat_query': {
      // Console CAT de diagnostic (administrateurs) : lectures seulement, réponse brute du TRX
      if (!conn.user.admin) return send(conn, { t: 'notice', level: 'error', msg: 'Réservé aux administrateurs' });
      const cmd = String(m.cmd || '').toUpperCase().replace(/\s+/g, '');
      const q = cmd.endsWith(';') ? cmd : cmd + ';';
      if (!station || station.caps.indexOf('catq') < 0) return send(conn, { t: 'notice', level: 'error', msg: 'Page Station sans console CAT : rechargez-la' });
      if (!rig().CAT_QUERIES || rig().CAT_QUERIES.indexOf(q) < 0) return send(conn, { t: 'notice', level: 'error', msg: 'Lecture non autorisée : ' + q.slice(0, 12) + ' (lectures possibles : ' + (rig().CAT_QUERIES || []).join(' ') + ')' });
      if (catAsk) clearTimeout(catAsk.timer);
      catAsk = { conn, at: Date.now(), timer: setTimeout(() => { if (catAsk && catAsk.conn === conn) { send(conn, { t: 'cat_answer', cmd: q, reply: 'pas de réponse du TRX' }); catAsk = null; } }, 2500) };
      toStation({ t: 'cmd', op: 'query', cmd: q, id: Date.now() });
      return;
    }

    case 'station_reload': {
      // Recharger à distance la page Station du club (administrateurs, jamais pendant une émission)
      if (!conn.user.admin) return send(conn, { t: 'notice', level: 'error', msg: 'Réservé aux administrateurs' });
      if (!station) return send(conn, { t: 'notice', level: 'error', msg: 'Station hors ligne' });
      if (ptt.active || radio.tx) return send(conn, { t: 'notice', level: 'error', msg: 'Impossible pendant une émission' });
      journal('station_reload', { call: conn.user.call, old: station.caps.indexOf('autoreload') < 0 });
      if (station.caps.indexOf('autoreload') >= 0) send(station.conn, { t: 'reload', by: conn.user.call });
      else {
        // Page d'avant la 0.15.7 : elle ne connaît que « switch ». On la fait passer un instant sur un autre pilote
        // (dont le port n'est pas ouvert : rien n'est envoyé au TRX), ce qui la recharge avec le programme actuel,
        // puis elle est renvoyée tout de suite sur son TRX (voir onStationAuth).
        const back = rig().ID;
        const temp = Object.keys(DRIVERS).find((id) => id !== back && !station.ports[id]) || Object.keys(DRIVERS).find((id) => id !== back);
        stationBounce = { back, temp, at: Date.now() };
        send(station.conn, { t: 'switch', model: temp, by: conn.user.call });
      }
      return send(conn, { t: 'notice', level: 'warn', msg: 'Rechargement de la page Station demandé : la station revient dans une dizaine de secondes' });
    }

    case 'time_sync': {
      // Mettre à l'heure Windows sur le PC du club (assistant version 4, comme NetTime)
      if (!isEditor(conn.user.call)) return send(conn, { t: 'notice', level: 'error', msg: 'Réservé aux responsables de la station' });
      // Le décodeur repart aussi de zéro : horloge de l'audio et délai de la liaison recalculés
      if (digi.worker) { digi.worker.postMessage({ t: 'reset' }); digi.timing = null; }
      if (!station) return send(conn, { t: 'notice', level: 'error', msg: 'Station hors ligne' });
      if (station.caps.indexOf('timesync') < 0) return send(conn, { t: 'notice', level: 'error', msg: 'Page Station trop ancienne : rechargez-la d’abord' });
      journal('time_sync', { call: conn.user.call });
      send(station.conn, { t: 'time_sync', by: conn.user.call });
      return send(conn, { t: 'notice', level: 'info', msg: 'Mise à l’heure du PC du club demandée (une dizaine de secondes)…' });
    }
    case 'audio_reset': {
      // Relancer à distance la carte son USB du TRX (figée en silence), par l'assistant Windows du PC du club
      if (!isEditor(conn.user.call)) return send(conn, { t: 'notice', level: 'error', msg: 'Réservé aux responsables de la station' });
      if (!station) return send(conn, { t: 'notice', level: 'error', msg: 'Station hors ligne' });
      if (station.caps.indexOf('audioreset') < 0) return send(conn, { t: 'notice', level: 'error', msg: 'Page Station trop ancienne : rechargez-la d’abord' });
      if (ptt.active || radio.tx) return send(conn, { t: 'notice', level: 'error', msg: 'Impossible pendant une émission' });
      journal('audio_reset', { call: conn.user.call });
      send(station.conn, { t: 'audio_reset', by: conn.user.call });
      return send(conn, { t: 'notice', level: 'warn', msg: 'Relance de la carte son du TRX demandée : le son est coupé une dizaine de secondes' });
    }

    case 'switch_rig': {
      // Changement de TRX à distance : administrateurs seulement, jamais pendant une émission
      const model = typeof m.model === 'string' ? m.model : '';
      if (!conn.user.admin) return send(conn, { t: 'notice', level: 'error', msg: 'Changement de TRX réservé aux administrateurs' });
      if (!station) return send(conn, { t: 'notice', level: 'error', msg: 'Station hors ligne : changement impossible' });
      if (!Object.prototype.hasOwnProperty.call(DRIVERS, model)) return send(conn, { t: 'notice', level: 'error', msg: 'Modèle inconnu' });
      if (ptt.active || radio.tx) return send(conn, { t: 'notice', level: 'error', msg: 'Impossible pendant une émission' });
      if (model === rig().ID) return;
      if (!station.ports[model]) return send(conn, { t: 'notice', level: 'error', msg: 'Port du ' + DRIVERS[model].NAME + ' jamais choisi sur le PC du club : à faire une fois sur place' });
      journal('rig_switch', { call: conn.user.call, from: rig().ID, to: model, name: DRIVERS[model].NAME });
      send(station.conn, { t: 'switch', model, by: conn.user.call });
      return send(conn, { t: 'notice', level: 'warn', msg: 'Passage au ' + DRIVERS[model].NAME + ' demandé : la station redémarre (quelques secondes)' });
    }

    case 'digi': {
      // Fenêtre de décodage ouverte (FT8 / FT4) ou fermée (null) par ce membre
      let mode = DIGI_MODES.indexOf(m.mode) >= 0 ? m.mode : null;
      const rc = mode === 'RTTY' ? rttyCfg(m.rtty) : null;
      const rc2 = mode === 'RTTY' && rc ? rttyCfg(m.rtty2) : null; // 2e décodeur RTTY (VFO-B), facultatif
      // 3e et 4e décodeurs RTTY (A3, A4 : même récepteur que A1, page RTTY en réception simple), facultatifs
      const rc3 = mode === 'RTTY' && rc && !m.rtDual ? rttyCfg(m.rtty3) : null;
      const rc4 = mode === 'RTTY' && rc && !m.rtDual ? rttyCfg(m.rtty4) : null;
      if (mode === 'RTTY' && !rc) mode = null;
      const cc = mode === 'CW' ? cwCfg(m.cw) : null;
      if (mode === 'CW' && !cc) mode = null;
      const cc2 = mode === 'CW' && m.ftDual ? cwCfg(m.cw2) : null; // 2e décodeur CW (VFO-B, double réception)
      // 2e décodeur RTTY sur la voie droite (récepteur SUB) : la page l'affiche avec sa propre cascade (double réception)
      const rtDual = mode === 'RTTY' && !!m.rtDual;
      const changed = conn.digi !== mode || !!conn.rtDual !== rtDual || (conn.rtty && conn.rtty.key) !== (rc && rc.key) || (conn.rtty2 && conn.rtty2.key) !== (rc2 && rc2.key) ||
        (conn.rtty3 && conn.rtty3.key) !== (rc3 && rc3.key) || (conn.rtty4 && conn.rtty4.key) !== (rc4 && rc4.key) ||
        (conn.cw && conn.cw.key) !== (cc && cc.key) || (conn.cw2 && conn.cw2.key) !== (cc2 && cc2.key);
      const dual = !!m.ftDual && FT_DUAL_MODES.indexOf(mode) >= 0;
      if (dual !== !!conn.ftDual) { conn.ftDual = dual; if (!changed) updateDigi(); }
      conn.digi = mode;
      conn.rtty = rc;
      conn.rtty2 = rc2;
      conn.rtty3 = rc3;
      conn.rtty4 = rc4;
      conn.rtDual = rtDual;
      conn.cw = cc;
      conn.cw2 = cc2;
      if (changed) updateDigi();
      // Historique : à l'ouverture, ou sur demande (fenêtre séparée qui s'ouvre, retour dans le dashboard)
      if (digi.hist[mode] && (changed || m.hist)) send(conn, { t: 'ftx_hist', mode, items: digi.hist[mode] });
      if (m.hist) sendWorked(true, conn); // fenêtre séparée qui s'ouvre : stations déjà contactées (barrées) et alertes
      if (conn.ftDual && digi.histB[mode] && (changed || m.hist)) send(conn, { t: 'ftx_hist', mode, items: digi.histB[mode], side: 'B' });
      if (mode === 'JTTY' && (changed || m.hist)) send(conn, { t: 'jtty_hist', items: Array.from(digi.jtty.values()) });
      if (mode === 'JTTY' && conn.ftDual && (changed || m.hist)) send(conn, { t: 'jtty_hist', items: Array.from(digi.jttyB.values()), side: 'B' });
      if (mode === 'SSTV' && (changed || m.hist)) send(conn, { t: 'sstv_list', items: sstvStore.list() });
      return;
    }

    case 'sstv_get': {
      // Image demandée par un membre (galerie, ou image recalculée en fin de réception)
      const it = conn.digi === 'SSTV' && sstvStore.get(Number(m.id));
      if (it) sstvSendImage(conn, it);
      return;
    }

    // ------------------------------------------------------------ carnet de trafic
    case 'log_refs_search': {
      // Recherche dans une liste de références (fiche du QSO) : début de référence ou morceau du nom ; le pays du
      // correspondant (préfixe DXCC de son indicatif) passe en premier
      const prog = String(m.prog || '').toUpperCase();
      if (!REFDATA.SOURCES[prog]) return;
      const hint = m.call ? ((DXCC.lookup(String(m.call).slice(0, 15)) || {}).pfx || '') : '';
      const st = refs.status[prog];
      return send(conn, { t: 'log_refs', id: m.id, prog, list: refs.search(prog, String(m.q || '').slice(0, 40), hint, 20),
        note: st.count ? '' : st.busy ? 'liste ' + prog + ' en cours de téléchargement par le serveur' : 'liste ' + prog + ' pas encore téléchargée par le serveur' + (st.err ? ' (' + st.err + ')' : '') });
    }
    case 'log_refs_status':
      return send(conn, { t: 'log_refs_status', status: refs.summary() });
    case 'log_refs_refresh':
      if (!conn.user.admin) return;
      refs.refresh(true).then(() => send(conn, { t: 'log_refs_status', status: refs.summary() })).catch(() => {});
      return send(conn, { t: 'notice', level: 'info', msg: 'Listes de références : téléchargement relancé (quelques minutes)' });
    case 'log_net_get':
      if (!conn.user.admin) return;
      return send(conn, { t: 'log_net', st: NET.status() });
    case 'log_net_set':
      // Écran Réseau (administrateurs) : mode, nom du poste, maîtres, clé (jamais renvoyée aux navigateurs)
      if (!conn.user.admin) return;
      try { NET.set(m.cfg || {}); } catch (e) { return send(conn, { t: 'log_net', st: NET.status(), err: e.message }); }
      journal('net_set', { call: conn.user.call, mode: NET.cfg.mode, name: NET.cfg.name });
      return send(conn, { t: 'log_net', st: NET.status(), ok: true });
    case 'serial': {
      // Numéros de série de contest tenus par la base (lib/logbook.js serialOp) : deux navigateurs (ou, plus tard, deux
      // postes du réseau) ne reçoivent jamais le même numéro ; « holder » = ce serveur / l'opérateur / son navigateur
      if (!conn.user || conn.user.rxOnly) return;
      const contest = String(m.contest || '').toUpperCase().replace(/[^A-Z0-9-]/g, '').slice(0, 40);
      const txc = String(m.txc || '').toUpperCase().replace(/[^A-Z0-9/]/g, '').slice(0, 20);
      const sid = String(m.sid || '').replace(/[^a-z0-9]/gi, '').slice(0, 16);
      const op = ['lease', 'used', 'set', 'reset'].indexOf(m.op) >= 0 ? m.op : 'lease';
      if (!contest || !txc || !sid || book.engine !== 'sqlite') return send(conn, { t: 'serial', contest, txc, nr: 0, off: true });
      // Nouvelle édition (série remise à 1 pour tout le monde) : administrateur, ou l'opérateur qui a la main
      if (op === 'reset' && !conn.user.admin && controller !== conn) return send(conn, { t: 'serial', contest, txc, nr: 0, warn: 'Remise à 1 de la série : administrateur, ou l’opérateur qui a la main.' });
      // Réseau : le maître actif donne le numéro (poste : demandé au maître, provisoire si la liaison manque)
      if (op === 'reset') journal('serial_reset', { call: conn.user.call, contest, txc });
      NET.serial(op, contest, txc, conn.user.call + '/' + sid, Math.round(Number(m.nr)) || 0, String(m.call || ''))
        .then((r) => send(conn, Object.assign({ t: 'serial', contest, txc }, r)))
        .catch((e) => send(conn, { t: 'notice', level: 'error', msg: 'Numéro de série : ' + e.message }));
      return;
    }
    case 'log_stats': {
      // Statistiques DXCC du carnet (fenêtre du carnet en grand), à la manière de Swisslog : pour un TX call, chaque pays
      // DXCC (entités WAE ramenées à leur pays) × bande, contacté / confirmé (LoTW ou QSL papier), par groupe de modes
      const txc = String(m.txc || '').toUpperCase();
      const want = String(m.mode || '');
      // Diplôme : DXCC (par défaut), WAZ (zones CQ), ITU (zones UIT), WAE, WPX, IOTA, WAC (continents), locators, WAS (États US)
      const award = AWARDS[m.award] ? m.award : 'DXCC';
      const grp = (q) => { const md = String(LB.modeName(q) || '').toUpperCase(); return md === 'CW' ? 'C' : /^(SSB|USB|LSB|AM|FM|DIGITALVOICE|C4FM|DSTAR|DMR)$/.test(md) ? 'P' : 'D'; };
      const BORD = ['2190m', '630m', '160m', '80m', '60m', '40m', '30m', '20m', '17m', '15m', '12m', '10m', '6m', '4m', '2m', '1.25m', '70cm', '33cm', '23cm', '13cm', '9cm', '6cm', '3cm', '1.25cm', 'SAT'];
      const rows = new Map(), bands = new Set(), modes = new Set(), txcs = new Set(), mcols = new Set();
      let n = 0;
      for (const q of book.qsos) {
        const sc = String(q.station_callsign || '').toUpperCase();
        if (sc) txcs.add(sc);
        if (txc && sc !== txc) continue;
        const md = String(LB.modeName(q) || '').toUpperCase();
        if (md) modes.add(md);
        const g = grp(q);
        if (want && !(want === g || want === md)) continue;
        const d = awardKey(q, award);
        if (!d) continue;
        const b = q.prop_mode === 'SAT' ? 'SAT' : String(q.band || '').toLowerCase();
        if (!b) continue;
        n++;
        bands.add(b);
        const conf = q.lotw_qsl_rcvd === 'Y' || q.qsl_rcvd === 'Y';
        let r = rows.get(d.k);
        if (!r) { r = { pfx: d.k, name: d.name, cont: d.cont || '', n: 0, b: {} }; rows.set(d.k, r); }
        r.n++;
        // Par bande : groupes de modes contactés (C / P / D) et confirmés
        const c = r.b[b] || (r.b[b] = { w: '', c: '', m: {} });
        if (c.w.indexOf(g) < 0) c.w += g;
        if (conf && c.c.indexOf(g) < 0) c.c += g;
        // Par mode (colonnes SSB, CW, RTTY, FT8, FT4, FT2, autres) : 1 contacté, 2 confirmé
        // Colonnes de chaque bande, dans l'ordre : SSB (phonie), CW, FT8, FT4, FT2, RTTY, DATA (tous les modes numériques)
        const v = conf ? 2 : 1;
        const set = (k) => { c.m[k] = Math.max(c.m[k] || 0, v); mcols.add(k); };
        if (g === 'P') set('SSB');
        else if (g === 'C') set('CW');
        else { if (['FT8', 'FT4', 'FT2', 'RTTY'].indexOf(md) >= 0) set(md); set('DATA'); }
        if (!r.first || String(q.qso_date) < r.first) r.first = String(q.qso_date || '');
      }
      // Bandes toujours montrées (HF + 6 m + satellite), plus celles du carnet en dehors de cette liste (2 m, 70 cm…)
      for (const b of ['160m', '80m', '60m', '40m', '30m', '20m', '17m', '15m', '12m', '10m', '6m', 'SAT']) bands.add(b);
      const bl = BORD.filter((b) => bands.has(b)).concat(Array.from(bands).filter((b) => BORD.indexOf(b) < 0).sort());
      // Toute la liste du diplôme, même jamais contactée (cases rouges), comme Swisslog (WPX, IOTA, locators : contactés seulement)
      for (const e of AWARDS[award].all()) if (!rows.has(e.k)) rows.set(e.k, { pfx: e.k, name: e.name, cont: e.cont || '', n: 0, b: {} });
      const mc = ['SSB', 'CW', 'FT8', 'FT4', 'FT2', 'RTTY', 'DATA']; // toujours les mêmes colonnes, dans cet ordre
      return send(conn, { t: 'log_stats', txc, mode: want, award, awards: Object.keys(AWARDS).map((k) => [k, AWARDS[k].label, AWARDS[k].col]), bands: bl, rows: Array.from(rows.values()), qsos: n,
        mcols: mc, txcalls: Array.from(txcs).sort(), modes: Array.from(modes).sort(), tag: logTag(m) });
    }
    case 'ft_dxcc': {
      // Page FT8 / FT4 / FT2 : pays DXCC contactés / confirmés par bande en FT (sous un TX call), à côté des listes
      // TX call choisi dans le tableau (un de ceux du carnet de ce membre : indicatifs de la station et le sien), sinon celui en service
      const mine = logCalls(conn);
      let txc = String(m.txc || '').toUpperCase().slice(0, 15);
      if (!txc || (mine.indexOf(txc) < 0 && !conn.user.admin)) txc = String(txCallFor(conn.user) || '').toUpperCase();
      const want = ['FT8', 'FT4', 'FT2'].indexOf(m.mode) >= 0 ? [m.mode] : ['FT8', 'FT4', 'FT2'];
      const BANDS = ['160m', '80m', '60m', '40m', '30m', '20m', '17m', '15m', '12m', '10m', '6m'];
      // Même carnet, même TX call, même mode : réponse déjà calculée (plusieurs pages ouvertes, chaque QSO)
      const ck = txc + '|' + want.join(',') + '|' + book.rev;
      if (ftDxccCache.k === ck) return send(conn, Object.assign({}, ftDxccCache.v, { calls: mine }));
      const rows = new Map();
      let n = 0;
      for (const q of book.qsos) {
        const sc = q.station_callsign;
        if (sc !== txc && String(sc || '').toUpperCase() !== txc) continue;
        const md = String(LB.modeName(q) || '').toUpperCase();
        if (want.indexOf(md) < 0) continue;
        const b = String(q.band || '').toLowerCase();
        const d = DXCC.peekDxcc(q.call);
        if (!d || !b) continue;
        n++;
        const conf = q.lotw_qsl_rcvd === 'Y' || q.qsl_rcvd === 'Y'; // comme les statistiques du carnet (eQSL ne compte pas pour le DXCC)
        let r = rows.get(d.pfx);
        if (!r) { r = { p: d.pfx, n: d.name, b: {} }; rows.set(d.pfx, r); }
        r.b[b] = Math.max(r.b[b] || 0, conf ? 2 : 1);
      }
      const v = { t: 'ft_dxcc', txc, mode: want.length === 1 ? want[0] : 'FT', bands: BANDS, rows: Array.from(rows.values()), qsos: n, total: DXCC.entities().length };
      ftDxccCache = { k: ck, v };
      return send(conn, Object.assign({}, v, { calls: mine }));
    }
    case 'log_values': {
      // Valeurs d'une colonne du carnet (choix proposés sous son titre), avec leur nombre de QSO
      const col = String(m.col || '');
      if (!LG_COL[col]) return;
      const f = Object.assign({}, m.f || {});
      delete f[col];
      const cnt = new Map();
      for (const q of lgFilter(book.query({ q: m.q }), f)) { const v = lgKey(q, col); cnt.set(v, (cnt.get(v) || 0) + 1); }
      let vals = Array.from(cnt.entries());
      if (col === 'date') vals.sort((a, b) => b[0].localeCompare(a[0]));
      else if (col === 'utc' || col === 'mhz') vals.sort((a, b) => Number(a[0]) - Number(b[0]));
      else vals.sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
      return send(conn, { t: 'log_values', col, values: vals.slice(0, 400), tag: logTag(m) });
    }
    case 'log_list': {
      const all = lgFilter(book.query({ q: m.q, from: m.from, to: m.to }), m.f);
      // TX call présents dans le carnet (export par indicatif)
      if (txcallsCache.rev !== book.rev) {
        const t = new Set();
        for (const q of book.qsos) if (q.station_callsign) t.add(String(q.station_callsign).toUpperCase());
        txcallsCache = { rev: book.rev, list: Array.from(t).sort() };
      }
      const txcalls = txcallsCache.list;
      const lim = Math.max(1, Math.min(1000, Number(m.limit) || 200));
      return send(conn, { t: 'log_list', total: book.qsos.length, count: all.length, items: all.slice(-lim).reverse().map(qsoForClient),
        calls: logCalls(conn), txcalls: conn.user.admin ? txcalls : undefined, stationCalls: stationCalls(), admin: !!conn.user.admin, services: LOG_SERVICES, auto: Object.fromEntries(LOG_SERVICES.map((s) => [s, !!logCfg[s].auto])), tag: logTag(m), engine: book.engine });
    }
    case 'log_merge': {
      // Doublon : la fiche déjà au carnet (ex. enregistrée en fin de QSO) est complétée (nom, QTH…) au lieu d'un 2e QSO
      if (conn.user.rxOnly) return;
      const old = book.get(String(m.id || ''));
      if (!old) return send(conn, { t: 'notice', level: 'error', msg: 'QSO introuvable' });
      if (!logCanEdit(conn, old)) return send(conn, { t: 'notice', level: 'error', msg: logEditWhy(conn, old) });
      let q;
      try { q = LB.clean(m.qso, logCtx(conn, m.qso)); } catch (e) { return send(conn, { t: 'notice', level: 'error', msg: 'QSO non complété : ' + e.message }); }
      const added = book.merge(old.id, q);
      journal('log_edit', { call: conn.user.call, qso: old.call });
      send(conn, { t: 'notice', level: 'info', msg: added.length ? 'QSO avec ' + old.call + ' complété (' + added.join(', ') + ').' : 'QSO avec ' + old.call + ' : rien à ajouter.' });
      for (const c of ops) send(c, { t: 'log_changed' });
      sendWorked(false);
      return;
    }
    case 'log_add':
    case 'log_edit': {
      if (conn.user.rxOnly) return send(conn, { t: 'notice', level: 'error', msg: 'Indicatif d’écouteur : pas d’enregistrement de QSO' });
      let q;
      try { q = LB.clean(m.qso, logCtx(conn, m.qso)); } catch (e) { return send(conn, { t: 'notice', level: 'error', msg: 'QSO non enregistré : ' + e.message }); }
      if (m.t === 'log_edit') {
        const old = book.get(m.id);
        if (!old) return send(conn, { t: 'notice', level: 'error', msg: 'QSO introuvable' });
        if (!logCanEdit(conn, old)) return send(conn, { t: 'notice', level: 'error', msg: logEditWhy(conn, old) });
        q.operator = old.operator;
        if (!q.country) { const e = DXCC.lookup(q.call); if (e) q.country = e.name; }
        q = book.update(m.id, q);
        journal('log_edit', { call: conn.user.call, qso: q.call });
        send(conn, { t: 'log_saved', qso: qsoForClient(q), edited: true, tag: logTag(m) });
      } else {
        const d = !m.force && book.dupe(q);
        if (d) return send(conn, { t: 'log_dupe', qso: m.qso, prev: qsoForClient(d), tag: logTag(m) });
        if (!q.country) { const e = DXCC.lookup(q.call); if (e) q.country = e.name; }
        q = book.add(q, conn.user.call);
        if (book.error) send(conn, { t: 'notice', level: 'error', msg: 'ATTENTION : carnet non écrit sur le disque du serveur (' + book.error + ')' });
        journal('log_add', { call: conn.user.call, qso: q.call, band: q.band, mode: q.mode });
        // QSO fait sous un indicatif personnel : gardé dans le carnet, pas d'envoi automatique vers les comptes du club
        // (ni UDP vers le logbook du PC du club) ; ses propres logs en ligne seulement si son titulaire l'a demandé
        const club = stationCalls().indexOf(q.station_callsign) >= 0;
        const auto = Object.fromEntries(LOG_SERVICES.map((s) => [s, autoFor(s, q.station_callsign) && !sync.isStopped(s, q.station_callsign)]));
        sync.auto(q, { udp: club, by: club ? '' : String(q.station_callsign || '') });
        // Logbook du PC de l'opérateur (Swisslog, Log4OM…) par son Agent LoTW, même derrière un CGNAT
        try { AGENTS.forward(q, (fmt) => udpPacket(q, fmt)); } catch (e) { console.error('Agent UDP : ' + e.message); }
        if (!club && !LOG_SERVICES.some((s) => auto[s])) send(conn, { t: 'notice', level: 'info', msg: 'QSO enregistré sous ' + q.station_callsign + ' : pas d’envoi vers les logs en ligne du club. Vos propres logs en ligne : Synchronisation ▾ (vos identifiants, envoi automatique possible).' });
        send(conn, { t: 'log_saved', qso: qsoForClient(q), auto, tag: logTag(m) });
        qrzFill(q);
        if (m.spot === true) spotOfQso(conn, q); // « Spot au log » coché dans la page qui enregistre
      }
      for (const c of ops) send(c, { t: 'log_changed' });
      sendWorked(false);
      return;
    }
    case 'log_get': {
      // Un QSO complet (page TRX SSB : détails d'un QSO du log du contest, pour le corriger)
      const q = book.get(String(m.id || ''));
      if (!q) return send(conn, { t: 'notice', level: 'error', msg: 'QSO introuvable' });
      return send(conn, { t: 'log_one', qso: qsoForClient(q), can: !!logCanEdit(conn, q), why: logCanEdit(conn, q) ? '' : logEditWhy(conn, q), tag: logTag(m) });
    }
    case 'log_del': {
      const q = book.get(m.id);
      if (!q) return;
      if (!logCanEdit(conn, q)) return send(conn, { t: 'notice', level: 'error', msg: logEditWhy(conn, q) });
      book.remove(m.id);
      journal('log_del', { call: conn.user.call, qso: q.call, date: q.qso_date });
      for (const c of ops) send(c, { t: 'log_changed' });
      sendWorked(false);
      return;
    }
    case 'log_del_many': {
      // Plusieurs QSO d'un coup (Ctrl+clic / Maj+clic dans le carnet) : chacun selon les droits habituels
      if (!Array.isArray(m.ids)) return;
      let n = 0, refused = 0, why = '';
      for (const id of m.ids.slice(0, 5000)) {
        const q = book.get(String(id));
        if (!q) continue;
        if (!logCanEdit(conn, q)) { refused++; if (!why) why = logEditWhy(conn, q); continue; }
        book.remove(q.id);
        n++;
      }
      if (n) {
        journal('log_del_many', { call: conn.user.call, n });
        for (const c of ops) send(c, { t: 'log_changed' });
        sendWorked(false);
      }
      return send(conn, { t: 'notice', level: refused ? 'warn' : 'info', msg: n + ' QSO supprimé' + (n > 1 ? 's' : '') + (refused ? ' ; ' + refused + ' refusé' + (refused > 1 ? 's' : '') + ' (' + why + ')' : '') });
    }
    case 'log_pending':
      if (LOG_SERVICES.indexOf(m.service) < 0) return;
      if (!conn.user.admin && !ownLogCall(conn, m.callsign)) return;
    {
      const pl = sync.pending(m.service, { from: m.from, to: m.to, callsign: m.callsign, all: !!m.all });
      // Détail : jamais envoyés / en échec (par motif) / déjà envoyés (« Renvoyer aussi »), et dates du plus ancien au plus récent
      const why = {};
      let never = 0, done = 0, d0 = '', d1 = '';
      for (const q of pl) {
        const u = q.up && q.up[m.service];
        if (!u) never++;
        else if (u.ok) done++;
        else { const k = String(u.msg || 'échec').replace(/\s*\(Agent LoTW[^)]*\)/, '').replace(/ — .*/, '').slice(0, 70); why[k] = (why[k] || 0) + 1; }
        if (!d0 || q.qso_date < d0) d0 = q.qso_date;
        if (!d1 || q.qso_date > d1) d1 = q.qso_date;
      }
      return send(conn, { t: 'log_pending', service: m.service, n: pl.length, never, done, why: Object.entries(why).sort((a, b) => b[1] - a[1]).slice(0, 4), d0, d1,
        busy: !!sync.busy[m.service], stopped: sync.isStopped(m.service, m.callsign) });
    }
    case 'log_mark': {
      // QSO signés à la main avec TQSL (serveur sans certificat, ex. le VPS) : notés « envoyés »
      if (LOG_SERVICES.indexOf(m.service) < 0 || !Array.isArray(m.ids)) return;
      // Membre : seulement les QSO de son propre indicatif
      const mineOnly = !conn.user.admin;
      if (mineOnly && !ownLogCall(conn, conn.user.call)) return;
      let n = 0;
      for (const id of m.ids.slice(0, 20000)) {
        const q = book.get(id);
        if (!q || (mineOnly && String(q.station_callsign || '').toUpperCase() !== String(conn.user.call).toUpperCase())) continue;
        sync.mark(q, m.service, { ok: true, msg: 'envoyé à la main (' + conn.user.call + ')' });
        n++;
      }
      book.flush();
      journal('log_mark', { call: conn.user.call, service: m.service, n });
      send(conn, { t: 'notice', level: 'info', msg: n + ' QSO notés comme envoyés à ' + m.service.toUpperCase() });
      for (const c of ops) send(c, { t: 'log_changed' });
      sendWorked(false);
      return;
    }
    case 'scp': {
      // Indicatifs probables (Super Check Partial) pour le morceau tapé
      const q = String(m.q || '').toUpperCase().replace(/[^A-Z0-9/]/g, '').slice(0, 15);
      return send(conn, { t: 'scp', q, list: SCP.search(q, Number(m.n) || 30), n: SCP.calls.length });
    }
    case 'ssb_list': {
      // Page TRX SSB sans contest : les derniers QSO en phonie BLU (SSB, LSB, USB) hors contest, ceux du carnet général
      const n = Math.max(10, Math.min(1000, Number(m.n) || 300));
      const items = [];
      for (let i = book.qsos.length - 1; i >= 0 && items.length < n; i--) {
        const q = book.qsos[i];
        if (q.contest_id || !/^(SSB|LSB|USB)$/.test(String(q.mode || '')) && !/^(LSB|USB)$/.test(String(q.submode || ''))) continue;
        items.push({ id: q.id, call: q.call, band: q.band, mode: LB.modeName(q), d: q.qso_date, t: q.time_on, freq: q.freq, rs: q.rst_sent || '', rr: q.rst_rcvd || '',
          name: q.name || '', qth: q.qth || '', grid: q.gridsquare || '', country: (DXCC.lookup(q.call) || {}).name || q.country || '', op: q.operator || q.by || '', st: q.station_callsign || '' });
      }
      return send(conn, { t: 'ssb_list', items });
    }
    case 'cluster_spot': return clusterSpot(conn, m.call, m.khz, m.cmt, m.asTx === true);
    case 'cluster_pick': return clusterPick(conn, String(m.key || ''));
    case 'mode_list': {
      // Derniers QSO d'un mode (page RTTY : cadre LOG RTTY) : hors contest (contest vide) ou ceux d'un contest ;
      // le carnet général reste la seule base
      const mode = String(m.mode || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 12);
      const id = String(m.contest || '').toUpperCase().replace(/[^A-Z0-9-]/g, '').slice(0, 40);
      const lim = Math.max(1, Math.min(1000, Number(m.limit) || 300));
      const all = mode ? book.qsos.filter((q) => String(q.mode || '').toUpperCase() === mode && (id ? q.contest_id === id : !q.contest_id)) : [];
      const items = all.slice(-lim).reverse().map((q) => ({
        id: q.id, call: q.call, band: q.band, d: q.qso_date, t: q.time_on, freq: q.freq, rs: q.rst_sent || '', rr: q.rst_rcvd || '',
        stx: q.stx_string || q.stx || '', srx: q.srx_string || q.srx || '', name: q.name || '', qth: q.qth || '', grid: q.gridsquare || '',
        cn: q.country || '', dx: ctstCty(q).dx, cc: ctstCty(q).ct, mp: ctstCty(q).mp, mc: ctstCty(q).mc, st: q.station_callsign || '', op: q.operator || '', ct: q.contest_id || '' }));
      return send(conn, { t: 'mode_list', mode, contest: id, total: all.length, items, tag: String(m.tag || '').slice(0, 20) });
    }
    case 'ctst_list': {
      // Log d'un contest (page TRX CW) : QSO du carnet avec cet identifiant, depuis la date donnée, pour les doublons,
      // les compteurs et la liste ; le carnet général reste la seule base
      const id = String(m.contest || '').toUpperCase().replace(/[^A-Z0-9-]/g, '').slice(0, 40);
      const from = String(m.from || '').replace(/\D/g, '').slice(0, 8);
      const items = id ? book.qsos.filter((q) => q.contest_id === id && (!from || q.qso_date >= from)).slice(-5000).map((q) => ({
        id: q.id, call: q.call, band: q.band, mode: q.mode, d: q.qso_date, t: q.time_on, freq: q.freq, stx: q.stx_string || q.stx || '', srx: q.srx_string || q.srx || '',
        rs: q.rst_sent || '', rr: q.rst_rcvd || '', op: q.operator || '', st: q.station_callsign || '', ...ctstCty(q) })) : [];
      return send(conn, { t: 'ctst_list', contest: id, from, items });
    }
    case 'log_export': {
      // Chaque opérateur récupère ses QSO : son indicatif personnel (TX call), ou ses QSO faits sous l'indicatif du club
      // (« mine ») ; les administrateurs exportent tout, par TX call ou en entier
      const me = String(conn.user.call).toUpperCase();
      m.callsign = String(m.callsign || '').toUpperCase();
      if (!conn.user.admin) {
        if (m.pending && !ownLogCall(conn, m.callsign)) return send(conn, { t: 'notice', level: 'error', msg: 'Export pour les carnets en ligne : votre propre indicatif seulement' });
        if (m.callsign !== me && !(m.mine && stationCalls().indexOf(m.callsign) >= 0)) { m.callsign = me; m.mine = false; }
      }
      let list = book.query({ from: m.from, to: m.to }).filter((q) => (!m.callsign || q.station_callsign === m.callsign) && (!m.mine || q.operator === me || q.by === me));
      // Carnet (onglet Logbooks) : « Vue affichée » = les QSO de la liste (recherche, TX call et filtres de colonne) ;
      // un membre n'en reçoit que ses propres QSO (son indicatif, ou faits par lui sous l'indicatif du club)
      if (m.view) {
        list = lgFilter(book.query({ q: m.q, from: m.from, to: m.to }), m.f);
        if (!conn.user.admin) list = list.filter((q) => String(q.station_callsign || '').toUpperCase() === me || q.operator === me || q.by === me);
        m.callsign = String((m.f && m.f.txc) || m.callsign || '').toUpperCase();
        m.mine = false;
        m.pending = '';
      }
      if (m.pending && LOG_SERVICES.indexOf(m.pending) >= 0) list = sync.pending(m.pending, { from: m.from, to: m.to, callsign: m.callsign });
      // Log d'un contest (TRX CW) : seulement les QSO de ce contest
      if (m.contestOnly && m.contest) { const cid = String(m.contest).toUpperCase(); list = list.filter((q) => q.contest_id === cid); }
      // Page TRX SSB sans contest : les QSO en phonie BLU hors contest
      if (m.phoneOnly) list = list.filter((q) => (m.allContests || !q.contest_id) && (/^(SSB|LSB|USB)$/.test(String(q.mode || '')) || /^(LSB|USB)$/.test(String(q.submode || ''))));
      // Page RTTY : les QSO d'un mode (hors contest, sauf si un contest est demandé)
      const modeOnly = String(m.modeOnly || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 12);
      if (modeOnly) list = list.filter((q) => String(q.mode || '').toUpperCase() === modeOnly && (m.contestOnly || m.allContests ? true : !q.contest_id));
      // Administrateur : les QSO d'un opérateur choisi (plusieurs opérateurs se partagent la station)
      if (conn.user.admin && m.operator) { const op = String(m.operator).toUpperCase(); list = list.filter((q) => String(q.operator || '').toUpperCase() === op); }
      const stamp = new Date().toISOString().slice(0, 10).replace(/-/g, '');
      const who = (String(m.callsign || 'TOUS').toUpperCase().replace(/[^A-Z0-9]/g, '')) + (m.mine ? '-' + me.replace(/[^A-Z0-9]/g, '') : '');
      if (m.fmt === 'cabrillo') {
        return send(conn, { t: 'log_export', name: (m.contestOnly && m.contest ? String(m.contest).toUpperCase().replace(/[^A-Z0-9-]/g, '') + '-' : '') + who + '-' + stamp + '.log', mime: 'text/plain', data: LB.toCabrillo(list, { callsign: m.callsign || cfg.digiCall, contest: m.contest, grid: cfg.stationGrid, club: cfg.clubName && /UBA/.test(cfg.clubName) ? 'UBA-LGE' : '', version: VERSION, cat: m.cat && typeof m.cat === 'object' ? m.cat : null, location: m.location }), count: list.length, tag: m.tag === 'cwpage' || m.tag === 'ssbpage' || m.tag === 'rttypage' || m.tag === 'big' ? m.tag : undefined });
      }
      return send(conn, { t: 'log_export', name: (m.view ? 'VUE-' : '') + (m.contestOnly && m.contest ? String(m.contest).toUpperCase().replace(/[^A-Z0-9-]/g, '') + '-' : m.phoneOnly ? 'SSB-' : modeOnly ? modeOnly + '-' : '') + who + (conn.user.admin && m.operator ? '-OP' + String(m.operator).toUpperCase().replace(/[^A-Z0-9]/g, '') : '') + '-' + stamp + (m.pending ? '-' + m.pending : '') + '.adi', mime: 'text/plain', data: LB.toAdif(list, 'RemoteStation', VERSION), count: list.length,
        pending: m.pending || '', ids: m.pending ? list.map((q) => q.id) : undefined, tag: m.tag === 'cwpage' || m.tag === 'ssbpage' || m.tag === 'rttypage' || m.tag === 'big' ? m.tag : undefined });
    }
    case 'log_cfg_get':
      if (!conn.user.admin) {
        if (m.quiet) return send(conn, { t: 'log_cfg', cfg: null, calls: logCalls(conn), quiet: true }); // fenêtre de synchronisation d'un membre
        return send(conn, { t: 'notice', level: 'error', msg: 'Réglages des carnets en ligne : administrateurs seulement' });
      }
      return send(conn, { t: 'log_cfg', cfg: logCfgPublic(), calls: logCalls(conn), quiet: !!m.quiet });
    case 'log_cfg_set':
      if (!conn.user.admin) return send(conn, { t: 'notice', level: 'error', msg: 'Réglages des carnets en ligne : administrateurs seulement' });
      setLogCfg(m.cfg);
      qrzx.reset();
      journal('log_cfg', { call: conn.user.call });
      send(conn, { t: 'log_cfg', cfg: logCfgPublic(), calls: logCalls(conn), saved: true });
      return;
    case 'qrz': {
      // Fiche QRZ.com d'un indicatif (correspondant) : pour tous les membres connectés, une demande par seconde au plus
      const call = String(m.call || '').toUpperCase().replace(/[^A-Z0-9/]/g, '').slice(0, 15);
      if (!/^[A-Z0-9/]{3,15}$/.test(call)) return;
      const now = Date.now();
      if (now - (conn.qrzAt || 0) < 400) return;
      conn.qrzAt = now;
      if (!qrzx.configured()) return send(conn, { t: 'qrz_info', call, ok: false, off: true });
      qrzx.lookup(call).then((v) => send(conn, { t: 'qrz_info', call, ok: !!v, info: v, msg: v ? '' : call + ' : inconnu sur QRZ.com' }))
        .catch((e) => send(conn, { t: 'qrz_info', call, ok: false, msg: String(e.message || e).slice(0, 200) }));
      return;
    }
    case 'qrz_test':
      if (!conn.user.admin) return;
      qrzx.reset();
      qrzx.login().then((r) => send(conn, { t: 'log_test', service: 'qrzxml', ok: true, msg: 'Connexion QRZ.com réussie' + (r.sub && !/non-subscriber/i.test(r.sub) ? ' (abonnement XML jusqu’au ' + r.sub + ')' : ' — sans abonnement XML : prénom, nom, ville et pays seulement') }))
        .catch((e) => send(conn, { t: 'log_test', service: 'qrzxml', ok: false, msg: String(e.message || e).slice(0, 200) }));
      return;
    case 'log_test':
      if (!conn.user.admin || LOG_SERVICES.indexOf(m.service) < 0) return;
      sync.test(m.service).then((r) => send(conn, { t: 'log_test', service: m.service, ok: r.ok, msg: r.msg }));
      return;
    case 'log_agents':
      conn.wantAgents = true;
      return send(conn, { t: 'log_agents', list: AGENTS.list(conn.user) });
    case 'log_agent_code': {
      // Administrateur, ou membre qui émet sous son propre indicatif (ses QSO, son certificat)
      if (!conn.user.admin && !ownLogCall(conn, conn.user.call)) return send(conn, { t: 'notice', level: 'error', msg: 'Agent LoTW : réservé aux administrateurs et aux membres qui émettent sous leur propre indicatif' });
      const r = AGENTS.newCode(conn.user.call);
      journal('lotw_agent_code', { call: conn.user.call, ip: conn.ip });
      conn.wantAgents = true;
      // Lien de l'installateur Windows : le dernier construit (il n'y en a pas à chaque version ; l'agent se met ensuite à jour seul)
      return send(conn, { t: 'log_agent_code', code: r.code, exp: r.exp, version: VERSION, installer: WIN_INSTALLER });
    }
    case 'log_agent_udp':
      if (!AGENTS.setUdp(String(m.id || ''), conn.user, m.udp, m.all)) return send(conn, { t: 'notice', level: 'error', msg: 'Agent LoTW introuvable' });
      return send(conn, { t: 'notice', level: 'info', msg: 'Logbook du PC enregistré : chaque nouveau QSO lui sera transmis par l’Agent LoTW.' });
    case 'log_agent_del':
      if (!AGENTS.remove(String(m.id || ''), conn.user)) return send(conn, { t: 'notice', level: 'error', msg: 'Agent LoTW introuvable' });
      return send(conn, { t: 'notice', level: 'info', msg: 'Agent LoTW retiré : ce PC ne peut plus signer (appairez-le à nouveau pour le reprendre).' });
    case 'log_acct_get': {
      const sv = String(m.service || ''), call = String(m.call || '').toUpperCase().replace(/[^A-Z0-9/]/g, '').slice(0, 15);
      if (!ACCT_FIELDS[sv] || !call) return;
      if (!conn.user.admin && !ownLogCall(conn, call)) return;
      return send(conn, Object.assign({ t: 'log_acct', service: sv, call }, acctPublic(sv, call)));
    }
    case 'log_acct_set': {
      const sv = String(m.service || ''), call = String(m.call || '').toUpperCase().replace(/[^A-Z0-9/]/g, '').slice(0, 15);
      if (!ACCT_FIELDS[sv] || !call || !m.fields || typeof m.fields !== 'object') return;
      if (!conn.user.admin && !ownLogCall(conn, call)) return send(conn, { t: 'notice', level: 'error', msg: 'Identifiants des carnets en ligne : votre propre indicatif seulement' });
      logCfg[sv].accounts = logCfg[sv].accounts || {};
      const a = Object.assign({}, logCfg[sv].accounts[call] || {});
      for (const k of ACCT_FIELDS[sv]) {
        const v = m.fields[k];
        if (v === undefined) continue;
        const secret = (SECRETS[sv] || []).indexOf(k) >= 0 || (sv === 'qrz' && k === 'key');
        if (secret && v === '') continue;                    // vide : on garde l'ancien
        if (v === '__effacer__' || v === '') delete a[k]; else a[k] = String(v).slice(0, 300);
      }
      // Envoi automatique des nouveaux QSO de cet indicatif (indicatif personnel ; pour le club : ⚙ Configuration)
      // Indicatif du club (administrateurs) : oui / non propre à cet indicatif, à la place du réglage commun de ⚙ Configuration
      const clubCall = stationCalls().indexOf(call) >= 0;
      if (clubCall && conn.user.admin && typeof m.auto === 'boolean') a.auto = m.auto;
      else if (!clubCall && typeof m.auto === 'boolean') { if (m.auto) a.auto = true; else delete a.auto; }
      if (Object.keys(a).some((k) => k !== 'lastConfirm' && k !== 'auto') || (clubCall && typeof a.auto === 'boolean') || a.lastConfirm) logCfg[sv].accounts[call] = a; else delete logCfg[sv].accounts[call];
      saveLogCfg();
      sync.resetStops();
      journal('log_acct', { call: conn.user.call, service: sv, for: call });
      send(conn, { t: 'notice', level: 'info', msg: 'Identifiants ' + sv + ' de ' + call + ' enregistrés.' });
      return send(conn, Object.assign({ t: 'log_acct', service: sv, call, saved: true }, acctPublic(sv, call)));
    }
    case 'log_sync': {
      // Membre : son propre indicatif seulement (jamais « tous », jamais l'effacement du log Club Log)
      if (!conn.user.admin) {
        if (m.action === 'stop') return sync.jobBy[m.service] === conn.user.call ? sync.stop(m.service) : undefined;
        if (!ownLogCall(conn, m.callsign)) return send(conn, { t: 'notice', level: 'error', msg: 'Synchronisation : votre propre indicatif seulement' });
        m.clear = false;
      }
      if (m.action === 'stop') return sync.stop(m.service);
      if (m.service === 'lotw' && m.action === 'confirm') { sync.confirmLotw(conn.user.call, m.callsign); return; }
      if (LOG_SERVICES.indexOf(m.service) < 0) return;
      // Club Log « effacer le log existant » : tout le carnet de l'indicatif, en un seul fichier
      const f = { from: m.from, to: m.to, callsign: m.callsign, all: !!m.all || !!m.clear };
      const list = sync.pending(m.service, f);
      journal('log_sync', { call: conn.user.call, service: m.service, n: list.length, clear: !!m.clear });
      sync.run(m.service, list, { by: conn.user.call, clear: m.service === 'clublog' && !!m.clear, delay: m.delay });
      return;
    }

    case 'menu_read':
    case 'menu_write':
    case 'menu_dt':
      return menuMsg(conn, m);
    case 'dtmf_read':
    case 'dtmf_write':
      return dtmfMsg(conn, m);
    case 'trxeq_get':
    case 'trxeq_read':
    case 'trxeq_try':
    case 'trxeq_save':
    case 'trxeq_club':
    case 'trxeq_del':
      return trxEqMsg(conn, m);
    case 'plan_pref':
      conn.planAuto = m.on !== false;
      return;
    case 'mic_off':
      if (voiceUser === conn && !(ptt.active && ptt.conn === conn)) voiceRelease('micro coupé');
      return;
    case 'profile_get': {
      // Profil enregistré (bouton « Profil de … » de la face avant) : le sien, ou celui de l'opérateur qui a la main (lecture seule)
      const own = conn.user.call;
      const who = m.call && controller && controller.user && m.call === controller.user.call ? m.call : own;
      const p = profiles[who] || {};
      const mics = Object.keys(p.mics || {}).slice(0, 20).map((k) => {
        const e = p.mics[k] || {};
        return { label: k, name: e.name || '', on: e.on !== false, gain: e.gain || 100, ns: !!e.ns, ec: !!e.ec, agc: !!e.agc,
          lo: e.lo, hi: e.hi, bands: Array.isArray(e.bands) ? e.bands : [] };
      });
      const trx = Object.keys(p.trx || {});
      const on = eqOn();
      return send(conn, { t: 'profile', call: who, mine: who === own, mics, trx, rig: station ? rig().ID : null, rigName: station ? rig().NAME : '',
        trxHere: !!(station && p.trx && p.trx[rig().ID]), trxPr: station && p.trx ? p.trx[rig().ID] || null : null, clubHere: !!(station && clubEq()), eqOn: on ? on.call : null });
    }
    case 'mic_get': {
      // Réglages de l'égaliseur gardés pour ce micro (nom de l'entrée son) : repris tout seuls sur n'importe quel PC
      const label = micLabel(m.label);
      const p = profiles[conn.user.call];
      const all = p && p.mics ? p.mics : {};
      return send(conn, { t: 'mic_profile', label, eq: label && all[label] ? all[label] : null, known: Object.keys(all).slice(0, 20) });
    }
    case 'mic_set': {
      const label = micLabel(m.label);
      const eq = micEqClean(m.eq);
      if (!label || !eq) return;
      const p = profiles[conn.user.call] = profiles[conn.user.call] || {};
      p.mics = p.mics || {};
      if (!p.mics[label] && Object.keys(p.mics).length >= 20) return send(conn, { t: 'notice', level: 'warn', msg: '20 micros gardés au plus : supprimez-en un d’abord' });
      p.mics[label] = eq;
      saveProfiles();
      return;
    }
    case 'mic_del': {
      const label = micLabel(m.label);
      const p = profiles[conn.user.call];
      if (p && p.mics && p.mics[label]) { delete p.mics[label]; saveProfiles(); }
      return;
    }
    case 'macros_set':
      if (!setMacros(conn.user.call, m.mode, m.list)) return;
      // Toutes les fenêtres de ce membre reçoivent la nouvelle liste
      for (const c of ops) if (c.user.call === conn.user.call) send(c, { t: 'macros', data: macros[conn.user.call] || {} });
      return;

    case 'listen': {
      const was = conn.listen && !conn.listenMute;
      conn.listen = !!m.on;
      conn.listenStereo = !!m.stereo;  // MAIN à gauche, SUB à droite (TRX à deux récepteurs, double réception)
      conn.listenMute = !!m.mute;      // cascade seulement (son coupé dans le navigateur)
      const now2 = conn.listen && !conn.listenMute;
      if (now2 !== was) journal(now2 ? 'listen_on' : 'listen_off', { call: conn.user.call });
      updateAudioWant();
      return broadcast();
    }

    case 'chat': {
      const text = String(m.text || '').replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, 300);
      if (!text) return;
      if (now - (conn.lastChat || 0) < 1000) return send(conn, { t: 'notice', level: 'warn', msg: 'Un message par seconde au maximum' });
      conn.lastChat = now;
      journal('chat', { call: conn.user.call, text });
      return chatPush({ kind: 'msg', call: conn.user.call, text });
    }

    case 'ask': {
      // Demande de la main à celui qui pilote
      if (!controller || controller.user.call === conn.user.call) return;
      if (now - (conn.lastAsk || 0) < 15000) return send(conn, { t: 'notice', level: 'warn', msg: 'Demande déjà envoyée, patientez un peu' });
      conn.lastAsk = now;
      journal('control_ask', { call: conn.user.call, to: controller.user.call });
      return chatPush({ kind: 'ask', call: conn.user.call, cid: conn.cid, to: controller.user.call });
    }

    case 'handover': {
      // Celui qui a la main la passe directement à un membre qui l'a demandée (jamais pendant une émission)
      if (controller !== conn) return send(conn, { t: 'notice', level: 'error', msg: 'Vous n’avez pas la main' });
      if (ptt.active || radio.tx) return send(conn, { t: 'notice', level: 'error', msg: 'Terminez d’abord votre émission' });
      let target = null;
      for (const c of ops) if (c.cid === Number(m.cid)) target = c;
      if (!target || target === conn) return send(conn, { t: 'notice', level: 'error', msg: 'Ce membre n’est plus connecté' });
      controller = target;
      target.lastAsk = 0;
      lastCtrlActivity = now;
      journal('control_take', { call: target.user.call, from: conn.user.call });
      chatPush({ kind: 'give', call: conn.user.call, to: target.user.call });
      send(target, { t: 'notice', level: 'warn', msg: conn.user.call + ' vous passe la main' });
      limitPower(target, 'prise de main');
      return broadcast();
    }

    case 'txcall': {
      // Choix « TX call » : un indicatif du club (ON5VL, OR0L…) ou le sien (anciennes pages : own = true / false)
      const mine = String(conn.user.call).toUpperCase();
      let want = typeof m.call === 'string' ? m.call.toUpperCase().trim() : m.own ? mine : String(cfg.digiCall || 'ON5VL').toUpperCase();
      if (want === mine && stationCalls().indexOf(want) < 0 && !ownCallOk(conn.user)) return send(conn, { t: 'notice', level: 'error', msg: 'Votre indicatif ne peut pas émettre (compte d’écouteur ou sans émission).' });
      if (want !== mine && stationCalls().indexOf(want) < 0) return send(conn, { t: 'notice', level: 'error', msg: 'Indicatif ' + want + ' non prévu comme TX call' });
      const before = txCallFor(conn.user);
      if (seq && seq.on && controller === conn && before !== want) return send(conn, { t: 'notice', level: 'warn', msg: 'Arrêtez d’abord l’émission automatique en cours (■ Arrêter) pour changer d’indicatif.' });
      txChoice.set(conn.user.call, want);
      if (before !== want) ttsRefresh(conn); // messages vocaux en anglais : dits avec le nouveau TX call
      return broadcast();
    }

    case 'faceview': {
      // Affichage de la face avant de celui qui a la main (DISP, MONO, EXPAND, MULTI, 3DSS, FUNC) : suivi par les autres
      if (controller !== conn || !m.v || typeof m.v !== 'object') return;
      const v = { disp: [0, 1, 2, 3].indexOf(m.v.disp) >= 0 ? m.v.disp : 0 };
      for (const k of ['mono', 'expand', 'multi', 'd3', 'func']) v[k] = !!m.v[k];
      const key = JSON.stringify(v);
      if (ctlFace && ctlFace.conn === conn && ctlFace.key === key) return;
      ctlFace = { conn, v, key };
      return broadcast();
    }

    case 'view': {
      // Onglet des modes numériques affiché par celui qui a la main : les autres peuvent le suivre (formation à distance)
      if (controller !== conn) return;
      const TABS_OK = ['events', 'ftx', 'rtty', 'wspr', 'jt65', 'jtty', 'cw', 'sstv', 'sync', 'log'];
      const tab = TABS_OK.indexOf(m.tab) >= 0 ? m.tab : null;
      const mode = ['FT8', 'FT4', 'FT2', 'JT65'].indexOf(m.mode) >= 0 ? m.mode : null;
      if (!tab) return;
      // Repères de la cascade (RTTY A / B, CW, RX / TX) : nombres seulement
      const num = (v, lo, hi) => { const n = Number(v); return Number.isFinite(n) && n >= lo && n <= hi ? Math.round(n * 100) / 100 : null; };
      let marks = null;
      const mk = m.marks;
      if (mk && typeof mk === 'object') {
        const rt = (x) => (x && typeof x === 'object' ? { f: num(x.f, 100, 4000), shift: num(x.shift, 50, 1000), baud: num(x.baud, 10, 300), rev: !!x.rev } : null);
        marks = { rtty: Array.isArray(mk.rtty) ? mk.rtty.slice(0, 2).map(rt) : null, rtTx: mk.rtTx === 1 ? 1 : 0,
          cw: mk.cw && typeof mk.cw === 'object' ? { f: num(mk.cw.f, 100, 4000), bw: num(mk.cw.bw, 10, 1000) } : null, cwB: mk.cwB && typeof mk.cwB === 'object' ? { f: num(mk.cwB.f, 100, 4000), bw: num(mk.cwB.bw, 10, 1000) } : null, rx: num(mk.rx, 0, 4000), tx: num(mk.tx, 0, 4000) };
      }
      const mkKey = JSON.stringify(marks);
      if (ctlView && ctlView.conn === conn && ctlView.tab === tab && ctlView.mode === mode && ctlView.mkKey === mkKey) return;
      ctlView = { conn, tab, mode, marks, mkKey };
      return broadcast();
    }

    case 'release':
      if (controller !== conn) return;
      stopPtt('main libérée');
      controller = null;
      journal('control_release', { call: conn.user.call, reason: 'volontaire' });
      return broadcast();

    case 'set':
      if (controller !== conn) return send(conn, { t: 'notice', level: 'error', msg: 'Prenez d’abord la main' });
      if (!station) return send(conn, { t: 'notice', level: 'error', msg: 'Station hors ligne' });
      if (ptt.active) return send(conn, { t: 'notice', level: 'error', msg: 'Impossible pendant l’émission' });
      lastCtrlActivity = now;
      if (m.freq != null) {
        const hz = Math.round(Number(m.freq));
        if (!(hz >= rig().FREQ_MIN && hz <= rig().FREQ_MAX)) {
          return send(conn, { t: 'notice', level: 'error', msg: 'Fréquence hors de la couverture du TRX' });
        }
        toStation({ t: 'cmd', op: 'freq', hz });
        radio.freq = hz; // affichage optimiste, corrigé au prochain polling
        freqCmd.A = { hz, at: Date.now() };
      }
      if (m.freqB != null) {
        const hz = Math.round(Number(m.freqB));
        if (!(hz >= rig().FREQ_MIN && hz <= rig().FREQ_MAX)) {
          return send(conn, { t: 'notice', level: 'error', msg: 'Fréquence hors de la couverture du TRX' });
        }
        toStation({ t: 'cmd', op: 'freqB', hz });
        radio.freqB = hz;
        freqCmd.B = { hz, at: Date.now() };
      }
      if (m.band != null) {
        const R = rig();
        if (!R.cmdBand || !R.BAND_CODES || !Object.prototype.hasOwnProperty.call(R.BAND_CODES, String(m.band))) {
          return send(conn, { t: 'notice', level: 'error', msg: 'Cette bande : pas disponible sur le ' + rig().NAME + '.' });
        }
        toStation({ t: 'cmd', op: 'band', band: String(m.band), sub: !!m.sub });
      }
      if (m.ctl != null) {
        const R = rig();
        const c = R.CONTROL[m.ctl];
        // LOCK de la face avant du TRX : réservé aux administrateurs (un membre qui verrouille le TRX bloque le club)
        if ((m.ctl === 'lock' || m.ctl === 'lockB') && !conn.user.admin) return send(conn, { t: 'notice', level: 'error', msg: 'LOCK : réservé aux administrateurs' });
        // IC-7760 : SET → Network (adresses du réseau du club) : lecture réservée aux administrateurs, jamais d'écriture
        if (m.ctl === 'exRead' && R.EX && R.EX[Number(m.value)] && R.EX[Number(m.value)].admin && !conn.user.admin) return send(conn, { t: 'notice', level: 'error', msg: 'Network : réservé aux administrateurs' });
        // IC-7760 : MENU → ANTENNA (ANTENNA MEMORY, TEMP-M, [ANT] Switch) : quelle antenne pour quelle tranche = installation du club → administrateurs
        if (m.ctl === 'exSet' && R.EX && R.EX[Math.floor(Number(m.value) / 100000)] && R.EX[Math.floor(Number(m.value) / 100000)].wAdmin && !conn.user.admin) return send(conn, { t: 'notice', level: 'error', msg: 'ANTENNA : réglages réservés aux administrateurs' });
        // FTX-1 : ATT / IPO du SUB pas réglables à distance — envoyés après passage sur SUB, ils changeaient quand même ceux du MAIN
        // (constaté au club le 06/11 : clic sur ATT du SUB → ATT du MAIN changé sur le TRX)
        if (R.ID === 'ftx1' && (m.ctl === 'attB' || m.ctl === 'preampB')) {
          return send(conn, { t: 'notice', level: 'error', msg: (m.ctl === 'attB' ? 'ATT' : 'IPO') + ' du SUB : pas réglable à distance — par CAT, le FTX-1 change celui du MAIN. Réglez-le sur la face avant du TRX.' });
        }
        // FTX-1 : aucun passage sur SUB par CAT (VS1) tant que ftx1SubCat n'est pas activé
        if (R.ID === 'ftx1' && !cfg.ftx1SubCat && ((m.ctl === 'vfoSel' && Number(m.value) === 1) || (c && c.viaSub && radio.vfoSel !== 1) || (c && c.viaMain && radio.vfoSel === 1))) {
          return send(conn, { t: 'notice', level: 'error', msg: 'Passage MAIN ↔ SUB par le dashboard désactivé : il mettait le FTX-1 en émission. Choisissez MAIN / SUB sur la face avant du TRX ; le dashboard suit.' });
        }
        // FTX-1 en réception simple (DUAL RX coupé) : passage MAIN ↔ SUB par CAT refusé (constaté au club le 24/10 :
        // clic sur SUB → le TRX passe en émission) ; DUAL RX d'abord, ou face avant
        const sideMove = (m.ctl === 'vfoSel' && Number(m.value) !== (radio.vfoSel === 1 ? 1 : 0)) || (c && c.viaSub && radio.vfoSel !== 1) || (c && c.viaMain && radio.vfoSel === 1);
        if (R.ID === 'ftx1' && radio.dualRx !== 1 && sideMove && !cfg.ftx1SubSingle) { // réception simple (ou état inconnu) : refusé sauf ftx1SubSingle
          return send(conn, { t: 'notice', level: 'error', msg: 'Passage MAIN ↔ SUB refusé en réception simple (DUAL RX coupé) : le 25/10, il a mis le FTX-1 en émission. En HF, le FTX-1 n’écoute qu’un côté à la fois ; pour écouter la fréquence du VFO B, utilisez A ⇄ B. Un administrateur peut l’autoriser pour des essais (ftx1SubSingle).' });
        }
        let v;
        try {
          v = R.validate(m.ctl, m.value, radio);
        } catch (e) {
          return send(conn, { t: 'notice', level: 'error', msg: e.message });
        }
        // SPLIT virtuel (FTX-1) : rien n'est envoyé au TRX, le choix sert au prochain passage en émission
        if (m.ctl === 'split' && R.VIRTUAL_SPLIT) {
          if (ptt.active || radio.tx) return send(conn, { t: 'notice', level: 'error', msg: 'Changement du VFO d’émission impossible pendant une émission' });
          txSel = v ? 1 : 0;
          radio.txVfo = txSide();
          radio.split = txSel;
          // SPLIT de la face avant encore actif : on le coupe (ST0 ; ST1 n'est jamais envoyé)
          if (!txSel && radio.hwSplit === 1) toStation({ t: 'cmd', op: 'ctl', id: 'splitHw', value: 0 });
          return broadcast();
        }
        // FTX-1 : une page Station d'avant la 0.15.5 enverrait ST1 pour le SPLIT, ce qui met le TRX en émission
        if (m.ctl === 'split' && R.ID === 'ftx1' && station && station.caps.indexOf('ftsplit') < 0) {
          return send(conn, { t: 'notice', level: 'error', msg: 'SPLIT refusé : la page Station du club est une ancienne version (elle mettrait le FTX-1 en émission). ' +
          (conn.user.admin ? 'Rechargez-la à distance : voyant STATION en haut à gauche → « Recharger la page Station ».' : 'Un administrateur doit la recharger (voyant STATION → « Recharger la page Station »).') });
        }
        // Changer d'antenne pendant une émission : jamais (le PA verrait un circuit ouvert)
        if (c.noTx && (ptt.active || radio.tx)) return send(conn, { t: 'notice', level: 'error', msg: c.label + ' : impossible pendant une émission' });
        if (c.transmits === 'voice') {
          // Mémoire vocale du TRX (IC-7300 VOICE TX) : contrôles de la phonie ; coupée si l'opérateur perd la main ou au bout de 2 min
          const why = ptt.active || ftxPend || (seq && seq.on) ? 'émission déjà en cours ou prévue' : txBlockReason(conn, false);
          if (why) {
            if (radio.power != null && radio.power > conn.user.maxWatts) limitPower(conn, 'avant ' + c.label);
            return send(conn, { t: 'notice', level: 'error', msg: c.label + ' refusé : ' + why });
          }
          journal('voicetx', { call: conn.user.call, ip: conn.ip, freq: txFreq(), watts: radio.power, mem: v });
          vtx = { conn, at: Date.now(), saw: false };
        } else if (c.transmits) {
          const why = txBlockReason(conn, true);
          if (why) {
            if (radio.power != null && radio.power > conn.user.maxWatts) limitPower(conn, 'avant ' + c.label);
            return send(conn, { t: 'notice', level: 'error', msg: c.label + ' refusé : ' + why });
          }
          journal('tune', { call: conn.user.call, ip: conn.ip, freq: txFreq(), watts: radio.power });
          // ROS mesuré trop haut : l'accord est justement ce qu'il fallait faire (si le ROS reste mauvais, la coupure recommencera).
          // Accord impossible (HI-SWR) : le blocage ne tombe que si ce nouvel accord réussit.
          if (!(swrLock && swrLock.tune)) swrLock = null;
          tuneWatch = { freq: txFreq(), at: Date.now(), saw: false, endAt: 0, call: conn.user.call, conn };
        }
        toStation({ t: 'cmd', op: 'ctl', id: m.ctl, value: v, by: conn.user.call, subOk: !!cfg.ftx1SubCat, subSingle: !!cfg.ftx1SubSingle });
        if (c.type !== 'action') radio[m.ctl] = v; // affichage optimiste
        if (R.VIRTUAL_SPLIT && m.ctl === 'vfoSel') radio.txVfo = txSide(); // l'émission suit la réception (ou l'autre VFO en SPLIT)
      }
      if (m.power != null) {
        const w = Number(m.power);
        const range = rig().POWER_RANGE[radio.powerHead];
        if (!range) return send(conn, { t: 'notice', level: 'error', msg: 'Puissance non réglable : type de tête du TRX inconnu' });
        if (conn.user.rxOnly) return send(conn, { t: 'notice', level: 'error', msg: 'Indicatif d’écouteur : réglage de puissance non autorisé' });
        if (!(w <= conn.user.maxWatts)) return send(conn, { t: 'notice', level: 'error', msg: 'Limite de votre licence : ' + conn.user.maxWatts + ' W' });
        if (!(w >= range[0] && w <= range[1])) return send(conn, { t: 'notice', level: 'error', msg: 'Puissance possible : ' + range[0] + ' à ' + range[1] + ' W' });
        toStation({ t: 'cmd', op: 'power', watts: w });
        radio.power = w; // affichage optimiste
      }
      if (m.mode != null) {
        planMode[m.sub ? 'B' : 'A'] = now; // mode choisi par le dashboard : prioritaire sur le plan de bande
        const code = String(m.mode).toUpperCase();
        if (rig().SETTABLE.indexOf(code) < 0) return send(conn, { t: 'notice', level: 'error', msg: 'Ce mode : pas disponible sur le ' + rig().NAME + '.' });
        toStation({ t: 'cmd', op: 'mode', code, sub: !!m.sub });
      }
      return broadcast();

    case 'txw': {
      if (m.on) {
        if (controller !== conn) return send(conn, { t: 'notice', level: 'warn', msg: 'Prenez la main pour utiliser TXW.' });
        if (txw && txw.conn === conn) { txw.beat = now; return; }
        if (txw || conn.txwRelease) return;
        if (ptt.active || radio.tx || (ftxPend && ftxPend.state === 'tx')) return send(conn, { t: 'notice', level: 'warn', msg: 'TXW : impossible pendant une émission.' });
        if (!txwSwap(conn.user.call)) return send(conn, { t: 'notice', level: 'warn', msg: 'TXW (échange des VFO) : pas disponible sur le ' + rig().NAME + '.' });
        txw = { conn, since: now, beat: now };
        lastCtrlActivity = now;
        return broadcast();
      }
      conn.txwRelease = false;
      if (txw && txw.conn === conn) txwOff('');
      return;
    }

    case 'upd_install': {
      // Mise à jour depuis le dashboard : administrateurs seulement ; le serveur ne fait qu'écrire la demande (update/request)
      if (!conn.user.admin) return send(conn, { t: 'notice', level: 'warn', msg: 'Mise à jour : réservée aux administrateurs' });
      const e = UPD.install(String(m.v || ''), conn.user.call);
      journal('update_request', { call: conn.user.call, v: String(m.v || '').slice(0, 20), err: e || undefined });
      if (e) return send(conn, { t: 'notice', level: 'warn', msg: e });
      for (const c of ops) if (c.open && c.user && c !== conn) send(c, { t: 'notice', level: 'warn', msg: 'Mise à jour du serveur vers ' + m.v + ' lancée par ' + conn.user.call + ' : la station sera coupée environ une minute.' });
      return;
    }
    case 'wspr_heard': return wsprHeard(conn, m);
    case 'prop_get':
      conn.propSub = true;
      if (!PROP.data && Date.now() - PROP.at > 60000) { PROP.at = Date.now(); PROP.fetch(); }
      return send(conn, PROP.msg());
    case 'tx_set': {
      // Administrateurs : limite d'ALC (émission numérique) et niveau BF envoyé au TRX par la page Station
      if (!conn.user.admin) return send(conn, { t: 'notice', level: 'error', msg: 'Réglage de l’émission : réservé aux administrateurs' });
      if (!station) return send(conn, { t: 'notice', level: 'error', msg: 'Page Station du club hors ligne' });
      const o = {};
      if (m.alcMax != null && ALC_CHOICES.indexOf(Number(m.alcMax)) >= 0) {
        o.alcMax = cfg.digiAlcMax = Number(m.alcMax);
        try { fs.writeFileSync(TXSET_FILE, JSON.stringify({ alcMax: o.alcMax }) + '\n', { mode: 0o600 }); } catch (e) { /* gardé jusqu'au redémarrage */ }
      }
      if (m.level != null && Number(m.level) >= 1 && Number(m.level) <= 100) o.level = Math.round(Number(m.level));
      if (!Object.keys(o).length) return;
      toStation(Object.assign({ t: 'tx_set' }, o));
      journal('tx_set', Object.assign({ call: conn.user.call }, o));
      return;
    }
    case 'upd_check':
      if (!conn.user.admin) return;
      return UPD.check().then(() => send(conn, Object.assign(UPD.state(), { asked: true })));
    case 'vm_list': case 'vm_put': case 'vm_get': case 'vm_del': case 'vm_name': case 'vm_set': case 'vm_play': case 'vm_stop': case 'vm_tts': case 'vm_tts_del': case 'vm_tts_try':
      return onVm(conn, m);
    case 'ptt':
      if (vmPlay && vmPlay.conn === conn && !m.on) return vmStop('arrêtée'); // PTT relâché : arrête la mémoire vocale
      if (m.on && vmPlay && vmPlay.conn === conn) return; // la mémoire vocale émet déjà
      if (m.on) {
        if (conn.needRelease) return; // relâcher d'abord après une coupure forcée
        if (ptt.active && ptt.conn === conn) {
          ptt.lastBeat = now;
          lastCtrlActivity = now;
        } else if (!ptt.active) {
          startPtt(conn, !!m.voice);
        }
      } else {
        conn.needRelease = false;
        if (ptt.active && ptt.conn === conn) stopPtt('relâché');
      }
      return;

    case 'ftx_tx':
      return seqStart(conn, m);

    case 'ftx_cfg':
      return seqCfg(conn, m);

    case 'ftx_queue':
      return seqQueueCmd(conn, m);

    case 'log_import': {
      // Import d'un log ADIF par lots (fenêtre « Importer un fichier ADIF » du carnet) : administrateurs (tous les
      // indicatifs), membres (leur propre indicatif seulement)
      const fail = (msg) => { conn.logImport = null; return send(conn, { t: 'log_import', op: 'fail', msg, tag: logTag(m) }); };
      if (conn.user.rxOnly) return fail('Indicatif d’écouteur : pas d’import');
      if (m.op === 'start') {
        const mine = String(conn.user.call || '').toUpperCase();
        const allowed = (c) => !!c && (conn.user.admin || (c === mine && ownCallOk(conn.user)));
        const txc = String(m.txc || '').toUpperCase().replace(/[^A-Z0-9/]/g, '').slice(0, 15);
        if (txc && !allowed(txc)) return fail('Vous ne pouvez importer que des QSO faits sous votre propre indicatif');
        if (Number(m.size) > 150 * 1024 * 1024) return fail('Fichier trop gros (150 Mo au plus) : importez-le année par année');
        conn.logImport = new IMPORT.ImportJob({ book, by: mine, txc, force: m.force ? txc : '', allowed });
        journal('log_import_start', { call: mine, txc, size: Number(m.size) || 0, records: Number(m.records) || 0 });
        return send(conn, { t: 'log_import', op: 'ready', tag: logTag(m) });
      }
      const job = conn.logImport;
      if (!job) return fail('Import non commencé (ou interrompu) : recommencez');
      if (m.op === 'data') {
        try { job.feed(String(m.data || '')); } catch (e) { return fail('Lecture impossible : ' + e.message); }
        return send(conn, { t: 'log_import', op: 'ack', part: m.part, st: job.state(), tag: logTag(m) });
      }
      if (m.op === 'end' || m.op === 'cancel') {
        try { job.flush(); } catch (e) { return fail('Écriture impossible : ' + e.message); }
        conn.logImport = null;
        const st = job.state();
        journal('log_import', { call: conn.user.call, added: st.added, dupes: st.dupes, bad: st.bad, cancel: m.op === 'cancel' });
        if (book.error) send(conn, { t: 'notice', level: 'error', msg: 'ATTENTION : carnet non écrit sur le disque du serveur (' + book.error + ')' });
        for (const c of ops) send(c, { t: 'log_changed' });
        sendWorked(false);
        return send(conn, { t: 'log_import', op: 'done', cancel: m.op === 'cancel', st, tag: logTag(m) });
      }
      return;
    }

    case 'ftx_hound': {
      // HOUND (FT8) : 0 normal, 1 FOX classique, 2 SuperFox — choisi par celui qui a la main, pour toute la station
      if (controller !== conn) return send(conn, { t: 'notice', level: 'error', msg: 'Prenez d’abord la main' });
      const v = [0, 1, 2].indexOf(Number(m.v)) >= 0 ? Number(m.v) : 0;
      if (v === ftHound) return;
      ftHound = v;
      if (seq && seq.on && seq.mode === 'FT8') seqOff('mode ' + (v ? 'HOUND' : 'normal') + ' choisi');
      journal('hound', { by: conn.user.call, v });
      broadcast();
      return;
    }

    case 'cw':
      return cwRequest(conn, m);

    case 'cw_prep': {
      // Préparation d'une macro CW survolée (ou du texte tapé) : la page Station écrit déjà le texte dans la mémoire
      // du manipulateur, sans émettre, pour que le clic n'ait plus qu'à lancer la lecture
      if (controller !== conn || !station || station.caps.indexOf('cwprep') < 0 || !rig().CW) return;
      if (cwJob || ptt.active || ftxPend || (seq && seq.on) || radio.tx) return;
      const md = (radio.vfoSel === 1 ? radio.modeB : radio.mode) || '';
      if (!/^CW/.test(md)) return;
      const text = cwClean(m.text);
      if (!text || text.length > 300) return;
      if (Date.now() - (conn.cwPrepAt || 0) < 100) return;
      conn.cwPrepAt = Date.now();
      return toStation({ t: 'cmd', op: 'cwprep', text, wpm: Math.max(5, Math.min(cwWpmMax(), Math.round(Number(m.wpm) || 22))) });
    }

    case 'cwk':
      return cwkFeed(conn, m);

    case 'cw_stop':
      if (cwJob && (cwJob.conn === conn || controller === conn || conn.user.admin)) cwEnd('arrêt demandé par ' + conn.user.call, false);
      return;

    case 'sstv_up': {
      // Image SSTV à émettre, envoyée par morceaux (messages de 64 Ko au plus) : rassemblée ici avant « dtx »
      if (controller !== conn) return;
      const id = String(m.id || '').slice(0, 40);
      const n = Math.round(Number(m.n));
      const i = Math.round(Number(m.i));
      if (!id || !(n >= 1 && n <= 64) || !(i >= 0 && i < n)) return;
      if (!conn.sstvUp || conn.sstvUp.id !== id) conn.sstvUp = { id, n, got: 0, parts: new Array(n), bytes: 0 };
      const up = conn.sstvUp;
      if (up.n !== n || up.parts[i]) return;
      const b = Buffer.from(String(m.data || ''), 'base64');
      up.bytes += b.length;
      if (up.bytes > 2 * 1024 * 1024) { conn.sstvUp = null; return send(conn, { t: 'notice', level: 'error', msg: 'Image SSTV trop grande' }); }
      up.parts[i] = b;
      up.got++;
      return;
    }

    case 'dtx':
      audioRequest(conn, m).catch((e) => send(conn, { t: 'notice', level: 'error', msg: 'Émission impossible : ' + e.message }));
      return;

    case 'ftx_stop':
      if (seq && seq.conn === conn && seq.on) { seq.on = false; updateDigi(); }
      if (ftxPend && ftxPend.conn === conn) ftxCancel('arrêt demandé', true);
      if (ptt.active && ptt.digi && ptt.conn === conn) stopPtt('arrêt demandé');
      return broadcast();

    case 'ping':
      return send(conn, { t: 'pong', ts: m.ts, now: Date.now() }); // now : horloge du serveur (onglet Synchro)
  }
}

// ---------------------------------------------------------------- messages station
function onStationAuth(conn, m) {
  if (!auth.safeEqual(m.token || '', cfg.stationToken)) {
    journal('station_auth_fail', { ip: conn.ip });
    send(conn, { t: 'error', msg: 'Jeton de station invalide' });
    return setTimeout(() => conn.close(4001, 'jeton invalide'), 300);
  }
  const model = typeof m.model === 'string' ? m.model : 'ftx1';
  if (!Object.prototype.hasOwnProperty.call(DRIVERS, model)) {
    send(conn, { t: 'error', msg: 'Modèle de radio non pris en charge par ce serveur : ' + model });
    return setTimeout(() => conn.close(4003, 'modèle inconnu'), 300);
  }
  if (station) {
    // Une station vivante avec son TRX connecté garde la place : une 2e page Station (autre onglet, autre PC)
    // ne peut pas la déloger, sinon une page sans radio pourrait prendre la place de celle qui a le TRX.
    const alive = station.conn.open && Date.now() - (station.lastMsg || 0) < 10000;
    const samePage = typeof m.page === 'string' && m.page && station.page === m.page;
    // Même adresse IP = même PC du club (page rechargée avec Ctrl+F5, reconnexion…) : il reprend toujours la place.
    // Le refus ne vise qu'une page Station ouverte ailleurs pendant que celle qui a le TRX tourne.
    const sameSite = station.ip === conn.ip;
    if (alive && radio.connected && !samePage && !sameSite) {
      journal('station_refused', { ip: conn.ip, reason: 'déjà en service' });
      send(conn, { t: 'error', msg: 'Une autre page Station, avec le TRX connecté, est déjà en service. Fermez l’une des deux.' });
      return setTimeout(() => conn.close(4004, 'station déjà en service'), 300);
    }
    const old = station.conn;
    old.isStation = false; // sa fermeture ne doit pas annoncer « station hors ligne »
    send(old, { t: 'error', msg: 'Remplacée par une nouvelle connexion station' });
    old.close(4002, 'remplacée');
    journal('station_replaced', { ip: old.ip });
  }
  const ports = {};
  if (m.ports && typeof m.ports === 'object') for (const id in DRIVERS) ports[id] = m.ports[id] === true;
  station = { conn, ip: conn.ip, since: Date.now(), rig: DRIVERS[model], ports, lastMsg: Date.now(), page: typeof m.page === 'string' ? m.page.slice(0, 40) : '',
    caps: Array.isArray(m.caps) ? m.caps.map(String).slice(0, 20) : [] };
  conn.isStation = true;
  conn.everStation = true;
  journal('station_online', { ip: conn.ip, model });
  // Fin d'un rechargement à distance d'une ancienne page : retour sur le TRX d'origine
  if (stationBounce && model === stationBounce.temp && Date.now() - stationBounce.at < 120000) {
    const b = stationBounce;
    stationBounce = null;
    send(conn, { t: 'switch', model: b.back, by: 'rechargement' });
  } else if (stationBounce && model === stationBounce.back) stationBounce = null;
  send(conn, { t: 'welcome', stationCall: cfg.stationCall, txSilenceSeconds: cfg.txSilenceSeconds, txHardMaxSeconds: cfg.txHardMaxSeconds, code: STATION_CODE, alcMax: Number(cfg.digiAlcMax) || 0 });
  audio.active = false;
  audio.silent = false;
  // BF voulue s'il y a un écouteur ou une fenêtre FT8/FT4 ouverte (même règle que updateAudioWant)
  audio.want = audioWanted();
  send(conn, { t: 'audio_want', on: audio.want });
  scopeWant = false;
  updateScopeWant(true);
  broadcast();
}

function onStation(conn, m) {
  // Seule la station en service est écoutée (une ancienne connexion remplacée ne doit rien écraser)
  if (!station || station.conn !== conn) return;
  station.lastMsg = Date.now();
  if (m.t === 'ping') return send(conn, { t: 'pong', ts: m.ts, now: Date.now() }); // contrôle de vie de la liaison (+ horloge du VPS)
  if (m.t === 'scope') {
    // Image du scope du TRX : relayée telle quelle aux pages abonnées (un client trop lent saute des images)
    if (typeof m.d !== 'string' || m.d.length > 1200 || !Number.isFinite(m.f0) || !Number.isFinite(m.f1)) return;
    const now = Date.now();
    const out = JSON.stringify({ t: 'scope', m: [0, 1, 2, 3].indexOf(m.m) >= 0 ? m.m : 0, f0: m.f0, f1: m.f1, oor: m.oor ? 1 : 0, d: m.d, s: m.s === 1 ? 1 : 0 }); // s : 1 = scope du SUB (IC-7760)
    for (const c of ops) if (c.scopeSub && now - c.scopeSub < 45000 && (c.backlog || 0) < 65536) c.send(out);
    return;
  }
  if (m.t === 'diag') {
    // Rapport de la page Station après une reconnexion : cause de la coupure vue côté club
    journal('station_diag', {
      how: String(m.how || '?').slice(0, 80),
      code: Number.isFinite(m.code) ? m.code : null,
      reason: String(m.reason || '').slice(0, 80),
      down_s: Number.isFinite(m.down) ? m.down : null,
      tries: Number.isFinite(m.tries) ? m.tries : 0
    });
    return;
  }
  if (m.t === 'ftx_retuned') {
    if (ftxPend && ftxPend.id === m.id && controller) send(controller, { t: 'notice', level: m.ok ? 'info' : 'warn', msg: m.ok ? 'Émission : fréquence changée tout de suite, ' + m.f0 + ' Hz' : 'Émission : nouvelle fréquence (' + m.f0 + ' Hz) à la prochaine période (page Station du club à recharger, ou message presque fini)' });
    return;
  }
  if (m.t === 'ftx_ready') {
    const p = ftxPend;
    if (!p || p.id !== m.id) return;
    if (!m.ok) return ftxCancel(String(m.err || 'message refusé par la page Station').slice(0, 160));
    p.ready = true;
    if (p.kind === 'audio') {
      // RTTY / JTTY : départ 0,6 s après la réception du signal par la page Station
      clearTimeout(p.timer);
      p.at = Date.now() + 600;
      p.timer = setTimeout(() => ftxKey(p), 600 - FTX_KEY_LEAD);
      return broadcast();
    }
    p.seconds = Number(m.seconds) || 0;
    p.sent = String(m.text || p.text).slice(0, 40);
    // Le départ attendait ce signal : il part tout de suite (un peu en retard sur l'heure prévue)
    if (p.waitReady && p.state === 'wait') { p.waitReady = false; clearTimeout(p.timer); p.at = Math.max(p.at, Date.now() + FTX_KEY_LEAD); ftxKey(p); return; }
    // Réponse cliquée : le TRX passe en émission tout de suite (le signal part à l'heure prévue)
    if (p.keyNow && p.state === 'wait' && !ptt.active && p.at - Date.now() > FTX_KEY_LEAD) { clearTimeout(p.timer); ftxKey(p); return; }
    return broadcast();
  }
  if (m.t === 'exread_reply' || m.t === 'exwrite_reply') return exReply(m);
  if (m.t === 'ftx_done') {
    if (ptt.active && ptt.digi && ptt.digi.id === m.id) stopPtt(FTX_END);
    return;
  }
  if (m.t === 'cat_reply') {
    if (catAsk && Date.now() - catAsk.at < 5000) {
      clearTimeout(catAsk.timer);
      send(catAsk.conn, { t: 'cat_answer', cmd: String(m.cmd).slice(0, 12), reply: String(m.reply).slice(0, 60) });
    }
    catAsk = null;
    return;
  }
  if (m.t === 'trx_note') {
    // Déroulé d'un changement de côté MAIN / SUB (FTX-1) : affiché à celui qui pilote, gardé dans le journal
    const text = String(m.text || '').replace(/[\u0000-\u001f]/g, ' ').slice(0, 500);
    journal('side_diag', { text });
    // Affiché seulement s'il s'est passé quelque chose d'anormal (émission, FT qui n'a pas suivi, commande refusée « ? »)
    // (un « ? » du TRX pendant un passage MAIN / SUB réussi n'est pas affiché : seulement gardé dans le journal)
    if (controller && /TX[12]|n’a pas suivi|refusé la commande|^ALC/.test(text)) send(controller, { t: 'notice', level: 'warn', msg: 'Station : ' + text });
    return;
  }
  if (m.t === 'safety') {
    const reason = String(m.reason || 'sécurité de la station').slice(0, 400);
    journal('tx_watchdog', { reason });
    if (ptt.active) stopPtt(reason);
    else for (const c of ops) send(c, { t: 'notice', level: 'error', msg: 'Station : ' + reason });
    return;
  }
  if (m.t === 'cw_state') {
    if (!cwJob || m.id !== cwJob.id) return;
    if (m.state === 'tx') { cwJob.state = 'tx'; if (!cwJob.pos) cwJob.pos = { chars: 0, at: Date.now() }; return broadcast(); }
    if (m.state === 'pos') {
      // Début d'un morceau joué par le TRX : position dans le texte et moment (heure du serveur) pour le suivi lettre par lettre
      const chars = Math.max(0, Math.min(cwJob.text.length, Math.round(Number(m.chars) || 0)));
      cwJob.pos = { chars, at: Date.now() - Math.max(0, Math.min(5000, Math.round(Number(m.ago) || 0))) };
      return broadcast();
    }
    if (m.state === 'info') {
      // Étapes de l'émission CW (diagnostic) : affichées à l'opérateur et gardées dans le journal
      const msg = String(m.msg || '').replace(/[\x00-\x1f]/g, ' ').slice(0, 200);
      journal('cw_step', { msg });
      return send(cwJob.conn, { t: 'notice', level: /refusé|pas de réponse/.test(msg) ? 'warn' : 'info', msg: 'CW : ' + msg });
    }
    if (cwJob.live && m.state === 'done') return cwEnd(m.msg ? String(m.msg).slice(0, 200) : 'fin de manipulation', true);
    return cwEnd(m.state === 'done' ? 'fin du message' : String(m.msg || 'arrêtée par la page Station').slice(0, 200), true);
  }
  if (m.t === 'audio_silent') {
    const on = !!m.on;
    if (on !== audio.silent) {
      journal('audio_silent', { on });
      if (on) for (const c of ops) if (isEditor(c.user.call) || c === controller) send(c, { t: 'notice', level: 'warn', msg: 'Station : plus de son du TRX depuis 45 s (carte son USB figée ?)' + (isEditor(c.user.call) ? ' — menu du TRX › Relancer la carte son' : '') });
    }
    audio.silent = on;
    return broadcast();
  }
  if (m.t === 'clock' && station && station.conn === conn) {
    // Écart de l'horloge du PC du club avec ce serveur (mesuré par la page Station) : onglet Synchro
    const off = Number(m.off), rtt = Number(m.rtt);
    if (Number.isFinite(off) && Math.abs(off) < 86400000) station.clock = { off: Math.round(off), rtt: Number.isFinite(rtt) ? Math.round(rtt) : null, at: Date.now() };
    return;
  }
  if (m.t === 'time_sync_result') {
    const ok = !!m.ok;
    const msg = String(m.msg || '').replace(/[\x00-\x1f]/g, ' ').slice(0, 300);
    journal('time_sync_result', { ok, msg });
    for (const c of ops) if (isEditor(c.user.call) || c === controller) send(c, { t: 'notice', level: ok ? 'info' : 'error', msg: 'Heure du PC du club : ' + msg });
    return;
  }
  if (m.t === 'audio_reset_result') {
    const ok = !!m.ok;
    const msg = String(m.msg || '').replace(/[\x00-\x1f]/g, ' ').slice(0, 300);
    journal('audio_reset_result', { ok, msg });
    if (ok) audio.silent = false;
    for (const c of ops) if (isEditor(c.user.call) || c === controller) send(c, { t: 'notice', level: ok ? 'info' : 'error', msg: 'Carte son du TRX : ' + msg });
    return broadcast();
  }
  if (m.t === 'audio_state') {
    audio.active = !!m.active;
    return broadcast();
  }
  // Sortie son vers le TRX (émission FT8 / FT4 / FT2, RTTY…) : affichée sur la page FT
  if (m.t === 'tx_out') {
    audio.out = { ok: !!m.ok, paused: !!m.paused, label: String(m.label || '').slice(0, 80), level: Math.round(Number(m.level)) || 0, alcMax: Math.round(Number(m.alcMax)) || 0 };
    return broadcast();
  }
  if (m.t === 'ports' && m.ports && typeof m.ports === 'object' && station && station.conn === conn) {
    for (const id in DRIVERS) station.ports[id] = m.ports[id] === true;
    return broadcast();
  }
  if (m.t !== 'radio' || !m.radio) return;
  const r = m.radio;
  const was = radio.connected;
  const wasDual = radio.dualRx;
  const prevStr = radio || {};
  radio = {
    connected: !!r.connected,
    freq: Number.isFinite(r.freq) ? r.freq : null,
    mode: typeof r.mode === 'string' ? r.mode.slice(0, 12) : null,
    modeCode: typeof r.modeCode === 'string' && /^[0-9A-Z]{1,3}$/.test(r.modeCode) ? r.modeCode : null,
    freqB: Number.isFinite(r.freqB) ? r.freqB : null,
    modeB: typeof r.modeB === 'string' ? r.modeB.slice(0, 12) : null,
    modeCodeB: typeof r.modeCodeB === 'string' && /^[0-9A-Z]{1,3}$/.test(r.modeCodeB) ? r.modeCodeB : null,
    tx: [0, 1, 2].indexOf(r.tx) >= 0 ? r.tx : 0,
    smeter: Number.isFinite(r.smeter) ? r.smeter : 0,
    power: Number.isFinite(r.power) ? r.power : null,
    powerHead: typeof r.powerHead === 'string' && Object.prototype.hasOwnProperty.call(rig().POWER_RANGE, r.powerHead) ? r.powerHead : null,
    model: station && station.rig ? station.rig.ID : null
  };
  // Fréquence demandée il y a moins de 2,5 s : une lecture du TRX encore à l'ancienne fréquence (polling parti avant la
  // commande) ne la fait pas revenir un instant (aller-retour à l'écran entre l'ancienne et la nouvelle fréquence)
  for (const w of ['A', 'B']) {
    const c = freqCmd[w], k = w === 'A' ? 'freq' : 'freqB';
    if (!c) continue;
    if (radio[k] === c.hz || Date.now() - c.at > FREQ_CMD_HOLD) freqCmd[w] = null;
    else if (radio[k] != null) radio[k] = c.hz;
  }
  // Réglages propres au pilote (SPLIT, filtres, mesures…) : nombres uniquement
  for (const k of rig().STATE_KEYS || []) radio[k] = Number.isFinite(r[k]) ? r[k] : null;
  // CW manipulée sur le TRX lui-même (ou break-in rapide) : la réception entre les lettres ne fait pas clignoter
  // l'affichage ; il reste « émission » 1,5 s après la dernière lecture en émission
  if (radio.tx) cwTxSeenAt = Date.now();
  else if (prevStr.tx && /^CW/.test((radio.vfoSel === 1 ? radio.modeB : radio.mode) || '')) {
    clearTimeout(cwTxHoldTimer);
    cwTxHoldTimer = setTimeout(broadcast, 1600);
  }
  // Textes propres au pilote (mémoires du manipulateur de l'IC-7300…) : ASCII affichable, 70 caractères au plus ; gardés d'une lecture à l'autre
  for (const k of rig().STR_KEYS || []) radio[k] = typeof r[k] === 'string' ? r[k].replace(/[^\x20-\x7E]/g, '').slice(0, 70) : (prevStr[k] != null ? prevStr[k] : null);
  if (rig().derive) rig().derive(radio);
  if (rig().VIRTUAL_SPLIT) {
    // SPLIT mis ou retiré sur la face avant du TRX : suivi par le dashboard
    if (radio.hwSplit === 1 && lastHwSplit !== 1) txSel = 1;
    if (radio.hwSplit === 0 && lastHwSplit === 1) txSel = 0;
    lastHwSplit = radio.hwSplit;
    // VFO qui émet réellement d'après le TRX (FT relu), pour afficher la vérité pendant l'émission
    radio.txReal = radio.txVfo === 0 || radio.txVfo === 1 ? radio.txVfo : null;
    if (radio.tx && radio.txReal != null && radio.hwSplit !== 1 && radio.txReal !== txSide()) {
      if (!txMismatchAt) txMismatchAt = Date.now();
      else if (Date.now() - txMismatchAt > 1500 && ptt.active) stopPtt('le TRX émet sur ' + (radio.txReal ? 'SUB (VFO B)' : 'MAIN (VFO A)') + ' au lieu de ' + (txSide() ? 'SUB (VFO B)' : 'MAIN (VFO A)'));
    } else txMismatchAt = 0;
    radio.txVfo = txSide();
    radio.split = txSel; // affichage et contrôles : choix de l'opérateur
  }
  if (was !== radio.connected) journal(radio.connected ? 'trx_online' : 'trx_offline', {});
  // Fréquence du VFO pour les fréquences WSPR affichées
  if (digi.worker && radio.freq && (radio.freq !== digi.dial || (radio.freqB || 0) !== digi.dialB)) {
    digi.dial = radio.freq;
    digi.dialB = radio.freqB || 0;
    digi.worker.postMessage({ t: 'dial', hz: radio.freq, hzB: radio.freqB || 0 }); // WSPR : fréquences des stations (VFO-A, VFO-B)
  }
  sendWorked(false);
  // Contexte AP du décodeur WSJT-X (comme WSJT-X / JTDX) : notre indicatif, le correspondant du QSO en cours, l'étape du QSO
  if (digi.worker) {
    const on = !!(seq && seq.on);
    const ap = { t: 'ap', mycall: txCall(), mygrid: String(cfg.stationGrid || ''), hiscall: on ? seq.dx.call : '', hisgrid: on ? seq.dx.grid : '',
      qp: on ? seq.progress || 0 : 0, rx: seq ? seq.rxf || seq.f0 : 1500, tx: seq ? seq.f0 : 1500, hound: ftHound };
    // Le correspondant n'aide le décodeur que du côté de son QSO (MAIN ou SUB) ; l'autre côté garde notre indicatif
    const onB = on && seq.side === 'B';
    const apA = onB ? Object.assign({}, ap, { hiscall: '', hisgrid: '', qp: 0, rx: 1500, tx: 1500 }) : ap;
    const apB = Object.assign({}, onB ? ap : apA, { ch: 1 });
    const k = JSON.stringify(apA);
    if (k !== digi.apKey) { digi.apKey = k; digi.worker.postMessage(apA); }
    const kB = JSON.stringify(apB);
    if (kB !== digi.apKeyB) { digi.apKeyB = kB; digi.worker.postMessage(apB); }
  }
  // Sécurité : la radio est en CAT TX alors qu'aucun PTT n'est actif côté serveur
  if (radio.tx === 1 && !ptt.active) toStation({ t: 'cmd', op: 'ptt', on: false, reason: 'incohérence serveur' });
  // Sécurité : sortie de bande pendant l'émission
  if (ptt.active && !inTxRange(txFreq())) stopPtt('fréquence d’émission hors bande');
  if (ptt.active && radio.vox) stopPtt('VOX activé au club');
  // Sécurité : puissance au-delà de la licence (ex. bouton tourné au club pendant l'émission)
  if (ptt.active && radio.power != null && radio.power > ptt.conn.user.maxWatts) {
    const c = ptt.conn;
    stopPtt('puissance au-delà de la limite de licence (' + c.user.maxWatts + ' W)');
    limitPower(c, 'dépassement');
  } else if (controller && radio.power != null && radio.power > controller.user.maxWatts) {
    limitPower(controller, 'dépassement');
  }
  // TRX à deux récepteurs en stéréo : la double réception change la voie du décodeur RTTY B (gauche ↔ droite)
  if (station && station.rig && station.rig.DUAL_AUDIO && radio.dualRx !== wasDual) updateDigi();
  // Tuner remis en service tout seul : à la connexion du TRX et à chaque nouvelle bande HF / 6 m (une seule fois par bande)
  autoTuner();
  // FTX-1 : BK-IN mis en service à chaque passage en CW-L / CW-U
  autoBkin();
  // Phonie : LSB sous 10 MHz, USB au-dessus, remis tout seul à chaque changement de bande
  autoSideband();
  // MODE AUTO : mode de la portion du plan de bande IARU Région 1
  bandPlanTick();
  // Protection du PA : résultat de l'accord. Le TRX signale HI-SWR après le TUNE → émission bloquée sur toute la bande
  if (tuneWatch) checkTune();
  if (vtx) vtxCheck();
  // Protection du PA : le TRX signale lui-même HI-SWR pendant une émission par le PTT
  if (ptt.active && radio.hiSwr === 1 && !radio.tuning && !radio.tuningRi && !tuneWatch) {
    swrLock = { freq: txFreq(), swr: null };
    journal('swr_cut', { call: ptt.conn.user.call, freq: txFreq(), swr: null, hi: true });
    stopPtt('le TRX signale HI-SWR — ' + (radio.tuner == null ? 'changez de fréquence ou faites vérifier l’antenne' : 'faites un accord (TUNE) avant de réémettre'));
  }
  // Protection du PA : ROS trop élevé pendant une émission par le PTT (pas pendant un accord)
  const swr = ptt.active && !radio.tuning && radio.m6 != null && rig().swrValue ? rig().swrValue(radio.m6) : null;
  if (swr != null && cfg.maxSwr > 0 && swr >= cfg.maxSwr) {
    const now = Date.now();
    if (!swrHighSince) swrHighSince = now;
    else if (now - swrHighSince >= cfg.swrHoldMs) {
      swrHighSince = 0;
      swrLock = { freq: txFreq(), swr };
      journal('swr_cut', { call: ptt.conn.user.call, freq: txFreq(), swr: Math.round(swr * 10) / 10 });
      stopPtt('ROS trop élevé (' + swr.toFixed(1).replace('.', ',') + ':1) — ' +
        (radio.tuner == null ? 'pas de boîte d’accord : changez de fréquence ou faites vérifier l’antenne' : 'faites un accord (TUNE) avant de réémettre'));
    }
  } else {
    swrHighSince = 0;
  }
  broadcast();
}

// ---------------------------------------------------------------- connexions WebSocket
ws.attach(server, {
  path: '/ws',
  maxPayload: 64 * 1024,
  onConnection(conn, req) {
    conn.ip = clientIp(req);
    conn.openedAt = Date.now();
    conn.cid = ++connSeq; // identifie l'onglet : la main appartient à une connexion, pas seulement à un indicatif
    conn.user = null;
    conn.isStation = false;
    const authTimer = setTimeout(() => {
      if (!conn.user && !conn.isStation) conn.close(4000, 'pas d’authentification');
    }, 15000);

    conn.on('message', (data, isBinary) => {
      if (isBinary) {
        // Seule la station envoie du binaire : la BF du TRX
        if (conn.isStation && station && station.conn === conn) relayAudio(data);
        else if (conn.user) voiceIn(conn, data); // voix de l'opérateur (phonie à distance)
        return;
      }
      let m;
      try {
        m = JSON.parse(data);
      } catch (e) {
        return;
      }
      if (!m || typeof m.t !== 'string') return;
      // Liaison d'un autre serveur Remote Station (mise en réseau) : même chemin /ws que les navigateurs
      if (conn.isNet) return NET.onConn(conn, m);
      if (m.t === 'net_hello' && !conn.user && !conn.isStation) { clearTimeout(authTimer); conn.isNet = true; return NET.accept(conn, m); }
      // Agent LoTW (TQSL du PC d'un membre)
      if (conn.isAgent) return AGENTS.onMsg(conn, m);
      if ((m.t === 'lotw_agent' || m.t === 'lotw_agent_pair') && !conn.user && !conn.isStation) { clearTimeout(authTimer); return AGENTS.accept(conn, m); }
      if (conn.isStation) return onStation(conn, m);
      if (conn.user) {
        // Toute action du membre compte comme activité (sauf les pings automatiques)
        if (m.t !== 'ping') { conn.lastActive = Date.now(); conn.idleWarned = false; }
        if (m.t === 'stay') return;
        if (m.t === 'logout') { dropSession(conn); return conn.close(1000, 'déconnexion'); }
        return onOperator(conn, m);
      }
      if (m.t === 'login') return onLogin(conn, m).catch((e) => console.error(e));
      if (m.t === 'stats') return onStats(conn, m, authTimer);
      if (m.t === 'prop_watch') {
        // Page Propagation (/prop) : tout membre connecté dans ce navigateur ; mises à jour envoyées à chaque relecture
        const s = typeof m.session === 'string' && m.session ? sessions[sessHash(m.session)] : null;
        const rec = s && s.exp > Date.now() ? auth.loadUsers(USERS_FILE)[s.call] : null;
        if (!rec || auth.userOff(rec)) return send(conn, { t: 'prop_fail', msg: 'Connectez-vous d’abord au dashboard dans ce navigateur, puis rechargez cette page.' });
        clearTimeout(authTimer);
        if (!conn.propWatch) { conn.propWatch = true; PROP_WATCH.add(conn); conn.on('close', () => PROP_WATCH.delete(conn)); }
        return send(conn, PROP.msg());
      }
      if (m.t === 'station') return onStationAuth(conn, m);
    });

    conn.on('close', () => {
      clearTimeout(authTimer);
      if (conn.isNet) return NET.connClosed(conn);
      if (conn.isAgent) return AGENTS.closed(conn);
      // Connexion fermée avant toute identification (page Station qui n'arrive pas à s'annoncer, robot…)
      if (!conn.user && !conn.everStation) journal('ws_noauth', { ip: conn.ip, by: conn.closeBy || '?', code: conn.closeCode || null, s: Math.round((Date.now() - conn.openedAt) / 1000) });
      if (conn.isStation && station && station.conn === conn) {
        if (ptt.active) stopPtt('station déconnectée');
        if (cwJob) cwEnd('station déconnectée', true);
        station = null;
        radio = Object.assign({}, radio, { connected: false, tx: 0 });
        // 1001 = page Station fermée, rechargée ou remplacée par une autre adresse dans son onglet
        const why = conn.closeCode === 1001 ? 'page Station fermée ou quittée'
          : conn.closeBy === 'client' ? 'page Station déconnectée'
          : conn.closeBy === 'serveur' ? 'coupée par le serveur' : 'coupure réseau';
        journal('station_offline', { ip: conn.ip, by: conn.closeBy || '?', code: conn.closeCode || null, why });
        broadcast();
      }
      if (conn.user) {
        ops.delete(conn);
        if (conn.digi) updateDigi();
        else if (conn.listen) updateAudioWant();
        if (ptt.active && ptt.conn === conn) stopPtt('opérateur déconnecté');
        if (controller === conn) {
          controller = null;
          journal('control_release', { call: conn.user.call, reason: 'déconnexion' });
        }
        journal('logout', { call: conn.user.call });
        broadcast();
      }
    });
  }
});

// Détection des connexions mortes (ping toutes les 15 s)
const allConns = () => {
  const s = new Set(ops);
  if (station) s.add(station.conn);
  for (const c of AGENTS.conns()) s.add(c); // Agents LoTW : un PC éteint d'un coup ne doit pas rester « connecté »
  return s;
};
setInterval(() => {
  for (const c of allConns()) {
    if (!c.isAlive) {
      // Plus de réponse depuis 15 à 30 s : liaison morte (coupure réseau, changement d'adresse IP…)
      journal('link_timeout', { who: c.isStation ? 'station' : c.isAgent ? 'agent LoTW' : (c.user ? c.user.call : '?'), ip: c.ip });
      c.terminate();
      continue;
    }
    c.isAlive = false;
    c.ping();
  }
}, 15000);

server.listen(cfg.port, cfg.listen, () => {
  console.log('Remote Station à l’écoute sur ' + (server instanceof require('https').Server ? 'https://' : 'http://') + cfg.listen + ':' + cfg.port + ' — TX ' + (cfg.allowTx ? 'AUTORISÉ' : 'désactivé'));
  clusterStart();
});

// Arrêt (systemd : SIGTERM ; service Windows : Ctrl+C / SIGINT) : on coupe d'abord une émission en cours
for (const sig of ['SIGTERM', 'SIGINT']) {
  process.on(sig, () => {
    if (ptt.active) stopPtt('arrêt du serveur');
    try { book.close(); } catch (e) { /* carnet déjà fermé */ }
    setTimeout(() => process.exit(0), 300);
  });
}
