/*
 * logbook.js — onglet « Logs » du dashboard (version extended).
 *
 *  - Saisie d'un QSO, pré-remplie avec la fréquence et le mode du TRX et la ligne Correspondant.
 *  - Carnet de trafic de la station (serveur : logbook.json), état des envois LoTW / eQSL / Club Log / QRZ.
 *  - Menu Synchronisation (administrateurs) : fenêtres « Télécharger vers … » (Détails / Traitement), comme Swisslog.
 *  - Exporter : ADIF (.adi) ou Cabrillo (.log).
 *  - Configuration (administrateurs) : un onglet par service + UDP vers les logbooks du PC (Swisslog, N1MM, Log4OM…).
 *    Les mots de passe et clés restent sur le serveur : la page ne reçoit que « enregistré / non enregistré ».
 * app.js appelle RSLOG.init(api), onHello(m), onMessage(m) ; digi.js crée l'onglet et appelle mount(el) et show().
 */
(function () {
  'use strict';
  const SV = ['lotw', 'eqsl', 'clublog', 'qrz'];
  const NAMES = { lotw: 'LoTW', eqsl: 'eQSL', clublog: 'Club Log', qrz: 'QRZ.com' };
  const SHORT = { lotw: 'LoTW', eqsl: 'eQSL', clublog: 'CL', qrz: 'QRZ' };
  const MODES = ['SSB', 'USB', 'LSB', 'CW', 'AM', 'FM', 'RTTY', 'FT8', 'FT4', 'FT2', 'JT65', 'JTTY', 'SSTV', 'PSK31', 'WSPR', 'C4FM', 'DATA'];
  const DIGI = ['FT8', 'FT4', 'FT2', 'JT65', 'JTTY', 'WSPR'];
  const PHONE = ['SSB', 'USB', 'LSB', 'AM', 'FM', 'C4FM'];
  const CONTESTS = ['DX', 'UBA-DX-CW', 'UBA-DX-SSB', 'UBA-SPRING-CW', 'UBA-SPRING-SSB', 'ON-CONTEST', 'IARU-HF', 'CQ-WW-CW', 'CQ-WW-SSB', 'CQ-WPX-CW',
    'CQ-WPX-SSB', 'ARRL-DX-CW', 'ARRL-DX-SSB', 'WAE-CW', 'WAE-SSB', 'EU-HF', 'IARU-VHF', 'IARU-UHF',
    'CQ-WW-RTTY', 'CQ-WPX-RTTY', 'ARRL-RTTY', 'BARTG-RTTY', 'BARTG-SPRINT', 'SARTG-RTTY', 'DARC-WAEDC-RTTY', 'EA-RTTY', 'SP-DX-RTTY', 'VOLTA-RTTY',
    'ANATOLRTTY', 'BAR75RTTYS', 'CISDXRTTY', 'DLDXRTTY', 'DMCRTTY', 'DRCGWWRTTY', 'JARLWWRTY', 'JTDXRTTY', 'LOTWRTTY', 'MAKRORTTY', 'NAQPRTTY', 'OKDXRTTY',
    'RFCDIGI', 'RRRTTY', 'RUS-WW-DIG', 'RUS-WW-MM', 'RUSDXRTTY', 'SARTGNYRTY', 'SCCRTTY', 'SKIRMRTTY', 'SPRINTRTTY', 'TARAGRID', 'TARARTTY', 'UKDXRTTY',
    'UKRAINDIGI', 'UKRAINDX', 'UKRAINRTTY', 'UKRRTTYOPEN', 'XERTTY'];

  let api = null;
  let root = null;
  let me = { call: '', admin: false, rxOnly: false };
  let calls = [];
  // Fiche seule (page TRX SSB) : tag des QSO envoyés, pour que chaque page ne traite que ses réponses (doublon, enregistré)
  let TAG = '';
  let FORM = false;
  let SSBP = false; // page TRX SSB : mode USB ou LSB seulement
  let items = [];
  let total = 0;
  // Colonnes du carnet : largeur par défaut (px), réglable à la souris (bord droit de l'en-tête), gardée dans ce navigateur
  const LG_COLS = [['date', 98], ['utc', 58], ['call', 96], ['band', 70], ['mhz', 82], ['mode', 66], ['env', 58], ['stx', 78], ['recu', 64], ['srx', 78], ['nom', 116],
    ['qth', 136], ['loc', 70], ['dxcc', 116], ['pfx', 76], ['txc', 84], ['op', 84], ['refs', 150], ['ctst', 112], ['lotw', 62], ['eqsl', 62], ['cl', 46], ['qrz', 54], ['fill', 0]];
  // Références des programmes « on the air » : [champ du carnet, programme, exemple]
  const REF_KEYS = [['iota', 'IOTA', 'EU-005'], ['wwff_ref', 'WWFF', 'ONFF-0001'], ['pota_ref', 'POTA', 'BE-0001'], ['bota_ref', 'BOTA', 'B/ON-0001'], ['llota_ref', 'LLOTA', 'CE-0001'], ['sota_ref', 'SOTA', 'ON/ON-001']];
  let editing = null;      // QSO en cours de modification
  let lastTxCall = '';     // dernier TX call de la ligne Correspondant reporté dans la fiche
  let filt = {};           // filtres par colonne { date: '20261025', band: '20m', … }
  let fltMenu = null;      // menu ouvert : { col, el }
  let stale = true;        // liste à recharger à la prochaine ouverture de l'onglet
  let listTimer = 0;
  let sdlg = null;         // fenêtre de synchronisation ouverte { service, el, job }
  let cdlg = null;         // fenêtre de configuration ouverte
  let lastExport = null;   // dernier export « QSO non envoyés à LoTW » (identifiants, pour les marquer envoyés)
  let pendingDupe = null;
  let lastLogged = '';     // dernier indicatif enregistré : pas repris de la ligne Correspondant juste après
  let lastSaved = null;    // fiche seule (FORM) : dernier QSO enregistré d'ici (« Modifier le QSO », « Supprimer le QSO »)

  // Fréquence affichée en MHz avec 3 décimales (au kHz près) : 7.057, 14.087, 21.190 (la valeur exacte reste dans le carnet et l'ADIF)
  const mhz3 = (f) => { const n = Number(f); return n > 0 ? (Math.round(n * 1000) / 1000).toFixed(3) : ''; };
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const q$ = (sel, el) => (el || root).querySelector(sel);
  const pad = (n, l) => String(n).padStart(l || 2, '0');
  const say = (t, lvl) => { if (api) api.say(t, lvl || '', 6000); };
  function utcNow() {
    const d = new Date();
    return { date: d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate()), time: pad(d.getUTCHours()) + ':' + pad(d.getUTCMinutes()) };
  }
  function loadDx() { try { return JSON.parse(localStorage.getItem('rs.dg.dx') || '{}') || {}; } catch (e) { return {}; } }
  const fmtDate = (d) => d.slice(6, 8) + '/' + d.slice(4, 6) + '/' + d.slice(0, 4);
  const fmtTime = (t) => t.slice(0, 2) + ':' + t.slice(2, 4);
  const modeName = (q) => (q.submode && q.mode !== 'SSB' ? q.submode : q.submode || q.mode);
  function mhz(v) {
    const n = Number(String(v).replace(',', '.'));
    return Number.isFinite(n) ? n : NaN;
  }

  // ------------------------------------------------------------------ onglet
  const PANE = `
    <form class="lg-form" id="lgForm" autocomplete="off" spellcheck="false">
      <div class="lg-row">
        <label class="lg-call">Indicatif <input name="call" maxlength="15" required placeholder="ON4XX"></label>
        <label>Date UTC <input name="date" type="date" required></label>
        <label class="lg-w5">Heure UTC <input name="time" maxlength="5" required placeholder="HH:MM"></label>
        <button class="btn" type="button" data-a="now" title="Date et heure actuelles (UTC)">⟳ Maintenant</button>
        <label class="lg-w8">Fréquence MHz <input name="freq" inputmode="decimal" required placeholder="14.074"></label>
        <label>Mode <select name="mode"></select></label>
        <button class="btn" type="button" data-a="trx" title="Fréquence et mode du TRX, ligne Correspondant">⇩ TRX</button>
        <label class="lg-w5">RST env. <input name="rst_sent" maxlength="8"></label>
        <label class="lg-w5">RST reçu <input name="rst_rcvd" maxlength="8"></label>
        <label class="lg-txc">TX call <select name="station" title="Indicatif sous lequel le QSO a été fait (STATION_CALLSIGN)"></select></label>
        <label class="lg-chk lg-qo" title="QSO via le satellite QO-100 : fréquence de montée 2400,xxx MHz (la FI du convertisseur est convertie)"><input type="checkbox" name="qo100"> QO-100</label>
        <button class="btn lg-myref-btn" type="button" data-a="myrefs" aria-pressed="false" title="Afficher les références de la station (le club active un parc, une île…) ; elles restent remplies d'un QSO à l'autre">＋ Ma référence (activation)</button>
      </div>
      <div class="lg-row">
        <label>Nom <input name="name" maxlength="40" title="Prénom et nom (QRZ.com)"></label>
        <label>QTH <input name="qth" maxlength="60"></label>
        <label class="lg-w6">Locator <input name="gridsquare" maxlength="8"></label>
        <button class="btn lg-qrz" type="button" data-a="qrz" title="Nom et prénom, QTH et locator du correspondant repris de QRZ.com (remplace ce qui est écrit)">⇩ QRZ</button>
        <label class="lg-w5">Puiss. W <input name="tx_pwr" inputmode="decimal" maxlength="5"></label>
        <label class="lg-rem">Remarque <input name="comment" maxlength="200"></label>
        <span class="lg-gap"></span>
        ${REF_KEYS.map(([k, p, ph]) => '<label class="lg-ref" title="Référence ' + p + ' du correspondant : tapez le début de la référence ou un morceau du nom, puis choisissez dans la liste">' + p + ' <input name="' + k + '" data-prog="' + p + '" maxlength="80" placeholder="' + ph + '" autocomplete="off"></label>').join('')}
      </div>
      <div class="lg-row lg-refs lg-myrefs" hidden>
        <span class="lg-refs-t" title="Références de la station pendant une activation : gardées d'un QSO à l'autre jusqu'à ce que vous les effaciez">Ma réf. (activation)</span>
        ${REF_KEYS.map(([k, p, ph]) => '<label class="lg-ref">' + p + ' <input name="my_' + k + '" data-prog="' + p + '" data-my="1" maxlength="80" placeholder="' + ph + '" autocomplete="off"></label>').join('')}
      </div>
      <div class="lg-row lg-act">
        <button class="btn btn-primary" type="submit" data-a="save">Enregistrer le QSO</button>
        <button class="btn" type="button" data-a="cancel" hidden>Annuler</button>
        <button class="btn" type="button" data-a="del" hidden>Supprimer</button>
        <button class="btn lg-last" type="button" data-a="editlast" hidden disabled title="Rouvre le dernier QSO enregistré depuis cette fiche pour le corriger">Modifier le QSO</button>
        <button class="btn lg-last" type="button" data-a="dellast" hidden disabled title="Supprime du carnet le dernier QSO enregistré depuis cette fiche">Supprimer le QSO</button>
        <label class="spotlog" title="Cochée : le QSO enregistré est aussi spoté sur le DX cluster sous votre indicatif d’opérateur — pas le TX CALL. Même réglage dans toutes les pages."><input type="checkbox" data-spotlog> Spot cluster</label>
        <span class="lg-fmsg" id="lgFmsg"></span>
      </div>
    </form>
    <div class="lg-bar">
      <input class="lg-search" id="lgSearch" placeholder="Rechercher (indicatif, nom, opérateur)" aria-label="Rechercher dans le carnet">
      <label class="lg-txf" title="Ne montrer que les QSO faits sous cet indicatif (TX call) ; Import/Export ▾ → « Vue affichée » les exporte ensuite">TX call <select id="lgTxf" aria-label="Filtrer le carnet par TX call"><option value="">Tous</option></select></label>
      <span class="lg-count" id="lgCount"></span>
      <button class="btn lg-fclr" type="button" id="lgFclr" hidden title="Retirer tous les filtres de colonne">✕ Filtres</button>
      <span class="lg-msel" id="lgMsel" hidden><b id="lgMselN"></b><button class="btn" type="button" id="lgMselAll" title="Sélectionner tous les QSO affichés">Tout sélectionner</button><button class="btn lg-mdel" type="button" id="lgMselDel">🗑 Supprimer la sélection</button><button class="btn" type="button" id="lgMselX" title="Désélectionner (Échap)">✕</button></span>
      <span class="lg-sp"></span>
      <div class="lg-menu">
        <button class="btn" type="button" data-m="sync" aria-haspopup="true" aria-expanded="false">Synchronisation ▾</button>
        <div class="lg-mlist" role="menu" hidden>
          <button type="button" role="menuitem" data-s="lotw">Synchronisation LoTW…</button>
          <button type="button" role="menuitem" data-s="eqsl">Synchronisation eQSL…</button>
          <button type="button" role="menuitem" data-s="clublog">Club Log…</button>
          <button type="button" role="menuitem" data-s="qrz">QRZ…</button>
          <hr class="lg-msep">
          <button type="button" role="menuitem" data-a="cfg" title="Réglages des carnets en ligne, de QRZ.com et des ports UDP">⚙ Configuration…</button>
          <button type="button" role="menuitem" data-a="refs" title="Listes IOTA, WWFF, POTA, BOTA, LLOTA, SOTA téléchargées par le serveur : état et mise à jour">Listes de références…</button>
          <button type="button" role="menuitem" data-a="net" title="Mise en réseau des serveurs Remote Station (à la manière de N1MM) : log commun et numéros de série partagés, maître et maître de secours">🌐 Réseau…</button>
        </div>
      </div>
      <div class="lg-menu">
        <button class="btn" type="button" data-m="exp" aria-haspopup="true" aria-expanded="false">Import/Export ▾</button>
        <div class="lg-mlist" role="menu" hidden>
          <div class="lg-mhd">EXPORT</div>
          <button type="button" role="menuitem" data-xm="1">Mes QSO (.adi)</button>
          <button type="button" role="menuitem" data-xv="adif" title="Exactement les QSO de la liste : TX call choisi, recherche et filtres de colonne (tout le carnet, pas seulement les lignes affichées)">Vue affichée (.adi)</button>
          <button type="button" role="menuitem" data-xv="cabrillo" title="Les QSO de la liste en Cabrillo (un seul TX call : choisissez-le d'abord)">Vue affichée (Cabrillo)…</button>
          <hr class="lg-msep">
          <button type="button" role="menuitem" data-x="adif">ADIF (.adi)…</button>
          <button type="button" role="menuitem" data-x="cabrillo">Cabrillo (.log)…</button>
          <div class="lg-mhd">IMPORT</div>
          <button type="button" role="menuitem" data-a="imp" title="Importer un log ADIF (Swisslog, Log4OM, WSJT-X…) dans le carnet : tout le fichier ou certaines années, doublons ignorés, rien n'est renvoyé aux logs en ligne">📥 Importer .ADI…</button>
        </div>
      </div>
    </div>
    <div class="lg-tw">
      <table class="lg-table">
        <colgroup>${LG_COLS.map(([k]) => '<col data-c="' + k + '">').join('')}</colgroup>
        <thead><tr><th>Date</th><th>UTC</th><th>Indicatif</th><th>Bande</th><th class="r">MHz</th><th>Mode</th><th>Env.</th><th title="Contest : échange envoyé (n° de série, zone… selon le règlement)">TX #</th><th>Reçu</th><th title="Contest : échange reçu (n° de série, zone… selon le règlement)">RX #</th><th class="grow">Nom</th><th class="lg-qth">QTH</th><th title="Locator (Maidenhead) du correspondant">Locator</th><th class="lg-cty" title="Pays DXCC (fichier cty.dat)">DXCC</th><th title="Préfixe principal de l'entité DXCC (ex. ON pour la Belgique, LA pour la Norvège)">Préfixe</th><th title="Indicatif sous lequel le QSO a été fait (celui de TX CALL du dashboard)">TX call</th><th title="Opérateur : indicatif personnel du membre qui a fait le QSO (même sous l'indicatif du club)">OP</th><th title="Références IOTA, WWFF, POTA, BOTA, LLOTA, SOTA du correspondant ; ▲ = référence de la station (activation)">Réf.</th><th title="Contest pendant lequel le QSO a été fait (identifiant Cabrillo) ; au survol : échange envoyé / reçu">Contest</th>
          <th class="c" title="LoTW (★ = confirmé)">LoTW</th><th class="c">eQSL</th><th class="c" title="Club Log">CL</th><th class="c">QRZ</th><th class="lg-fill"></th></tr></thead>
        <tbody id="lgBody"><tr><td colspan="24" class="lg-empty">Chargement du carnet…</td></tr></tbody>
      </table>
    </div>
    <p class="lg-job" id="lgJob" aria-live="polite"></p>`;

  // Liste du carnet à la hauteur de l'écran : son ascenseur horizontal (colonnes de droite) reste en bas de ce qu'on voit,
  // et l'ascenseur de droite fait descendre la liste (au lieu d'une liste plus haute que l'écran). Aussi : Maj + molette
  function hScroll() {
    const tw = q$('.lg-tw');
    if (!tw) return;
    let last = '';
    const fit = () => {
      if (tw.hidden || tw.style.display === 'none' || !tw.offsetParent) return;
      const top = tw.getBoundingClientRect().top;
      const h = Math.max(220, Math.floor(window.innerHeight - Math.max(0, top) - 14)) + 'px';
      if (h !== last) { last = h; tw.style.height = h; tw.style.maxHeight = h; tw.style.flex = 'none'; }
    };
    window.addEventListener('resize', fit);
    document.addEventListener('scroll', () => requestAnimationFrame(fit), true); // colonne du dashboard qui défile
    if (window.ResizeObserver) new ResizeObserver(() => requestAnimationFrame(fit)).observe(document.body);
    setInterval(fit, 1000); // onglet Logbooks ouvert, fiche DÉTAILS QSO montrée / cachée
    fit();
  }
  function mount(el) {
    root = el;
    root.innerHTML = PANE;
    if (FORM) root.querySelectorAll('.lg-bar, .lg-tw, .lg-job').forEach((x) => { x.hidden = true; x.style.display = 'none'; });
    // Carnet général (onglet Logbooks) : fiche du QSO cachée par défaut ; bouton jaune DÉTAILS QSO (affiche / cache) au début
    // de la barre de recherche ; elle s'ouvre au clic sur un QSO de la liste et se cache 2 s après l'enregistrement
    if (!FORM && !SSBP) {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'btn lg-dbtn';
      b.id = 'lgDetails';
      b.textContent = 'DÉTAILS QSO';
      b.title = 'Affiche ou cache la fiche du QSO (nouveau QSO, ou détails d’un QSO de la liste : clic sur sa ligne)';
      b.addEventListener('click', () => fShow(root.classList.contains('lg-fhid')));
      q$('.lg-bar').prepend(b);
      fShow(false);
    }
    if (getComputedStyle(root).position === 'static') root.style.position = 'relative'; // menus des filtres de colonne
    if (!FORM) hScroll();
    initCols();
    applyOrder();
    document.addEventListener('click', () => closeFlt());
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeFlt(); });
    q$('#lgFclr').addEventListener('click', () => { filt = {}; reload(); });
    const f = q$('#lgForm');
    for (const m of SSBP ? ['USB', 'LSB'] : MODES) f.mode.add(new Option(m, m));
    f.addEventListener('submit', (e) => { e.preventDefault(); save(false); });
    f.querySelector('[data-a="now"]').addEventListener('click', () => { const n = utcNow(); f.date.value = n.date; f.time.value = n.time; });
    f.querySelector('[data-a="trx"]').addEventListener('click', () => fromTrx(true));
    f.querySelector('[data-a="cancel"]').addEventListener('click', () => { endEdit(); fShow(false); });
    f.querySelector('[data-a="del"]').addEventListener('click', () => {
      if (!editing) return;
      if (!window.confirm('Supprimer le QSO avec ' + editing.call + ' du ' + fmtDate(editing.qso_date) + ' ' + fmtTime(editing.time_on) + ' UTC ?\nLes carnets en ligne ne sont pas modifiés.')) return;
      api.send({ t: 'log_del', id: editing.id });
      endEdit();
      fShow(false, 2000);
    });
    f.mode.addEventListener('change', () => defaultRst(true));
    // Fiche seule (pages TRX SSB, TRX DIGI) : le dernier QSO enregistré d'ici peut être corrigé ou supprimé
    f.querySelector('[data-a="editlast"]').addEventListener('click', () => {
      if (!lastSaved || !lastSaved.id) return;
      if (!items.some((x) => x.id === lastSaved.id)) items = [lastSaved].concat(items);
      startEdit(lastSaved.id);
    });
    f.querySelector('[data-a="dellast"]').addEventListener('click', () => {
      const q = lastSaved;
      if (!q || !q.id) return;
      if (!window.confirm('Supprimer le QSO avec ' + q.call + ' du ' + fmtDate(q.qso_date) + ' ' + fmtTime(q.time_on) + ' UTC ?\nLes carnets en ligne ne sont pas modifiés.')) return;
      api.send({ t: 'log_del', id: q.id });
      lastSaved = null;
      lastBtns();
      fmsg('QSO avec ' + q.call + ' supprimé du carnet.', 'ok');
    });
    lastBtns();
    initRefs(f);
    f.call.addEventListener('input', () => {
      f.call.value = f.call.value.toUpperCase();
      // Début du QSO : l'heure est prise à la première lettre tapée (sauf si elle a été écrite à la main)
      if (!editing && f.call.value.length === 1 && !f.time.dataset.manual) { const n = utcNow(); f.date.value = n.date; f.time.value = n.time; }
    });
    f.time.addEventListener('input', () => { f.time.dataset.manual = '1'; });
    // Indicatif tapé : nom, QTH et locator cherchés sur QRZ.com (si un compte QRZ est réglé), cases vides seulement
    // (aussi après une pause dans la frappe, et à l'ouverture d'un QSO sans nom ou sans locator)
    f.call.addEventListener('change', () => qrzAsk(false));
    f.call.addEventListener('input', () => { clearTimeout(qrzT); qrzT = setTimeout(() => qrzAsk(false), 900); });
    f.querySelector('[data-a="qrz"]').addEventListener('click', () => qrzAsk(true));
    // TX call du carnet = TX call de la ligne Correspondant : avec la main, le choix fait ici change aussi l'indicatif d'émission
    f.station.addEventListener('change', () => {
      if (editing) return;
      // Sans la main : choix gardé pour ce QSO seulement (l'indicatif d'émission est celui de l'opérateur qui a la main)
      if (!api || !api.iControl || !api.iControl()) { f.station.dataset.manual = '1'; return; }
      const v = f.station.value;
      const mine = String(me.call || '').toUpperCase();
      const clubs = (Array.isArray(me.clubCalls) && me.clubCalls.length ? me.clubCalls : [me.digiCall || '']).map((c) => String(c).toUpperCase());
      if (v !== mine && clubs.indexOf(v) < 0) return;
      try { localStorage.setItem('rs.txcall', v); } catch (e) { /* */ }
      api.send({ t: 'txcall', call: v });
    });
    f.gridsquare.addEventListener('input', () => { f.gridsquare.value = f.gridsquare.value.toUpperCase(); });
    f.freq.addEventListener('change', qoCheck);
    // Fréquence ou mode tapés à la main : ils ne suivent plus le TRX jusqu'au prochain QSO (ou ⇩ TRX)
    f.freq.addEventListener('input', () => { f.freq.dataset.manual = '1'; });
    f.mode.addEventListener('change', () => { f.mode.dataset.manual = '1'; });
    const search = q$('#lgSearch');
    search.addEventListener('input', () => { clearTimeout(listTimer); listTimer = setTimeout(reload, 300); });
    // Menus déroulants
    root.querySelectorAll('.lg-menu > .btn').forEach((b) => b.addEventListener('click', (e) => {
      e.stopPropagation();
      const l = b.nextElementSibling;
      const open = l.hidden;
      closeMenus();
      l.hidden = !open;
      b.setAttribute('aria-expanded', String(open));
    }));
    document.addEventListener('click', closeMenus);
    root.querySelectorAll('[data-s]').forEach((b) => b.addEventListener('click', () => { closeMenus(); openSync(b.dataset.s); }));
    root.querySelectorAll('[data-x]').forEach((b) => b.addEventListener('click', () => { closeMenus(); openExport(b.dataset.x); }));
    // « Mes QSO » : tous les QSO faits sous mon indicatif personnel (TX call), en ADIF, tout de suite
    root.querySelectorAll('[data-xm]').forEach((b) => b.addEventListener('click', () => { closeMenus(); api.send({ t: 'log_export', fmt: 'adif', callsign: me.call }); }));
    // TX call : filtre de la liste (le même que celui de la colonne TX call) ; « Vue affichée » exporte ce que la liste montre
    q$('#lgTxf').addEventListener('change', () => { const v = q$('#lgTxf').value; if (v) filt.txc = v; else delete filt.txc; reload(); });
    root.querySelectorAll('[data-xv]').forEach((b) => b.addEventListener('click', () => {
      closeMenus();
      const v = { t: 'log_export', view: true, q: q$('#lgSearch').value.trim(), f: Object.assign({}, filt), callsign: filt.txc || '' };
      if (b.dataset.xv === 'adif') return api.send(Object.assign(v, { fmt: 'adif' }));
      if (!filt.txc) return say('Cabrillo : choisissez d’abord un TX call (un seul indicatif par fichier).', 'warn');
      const c = prompt('Concours (CONTEST, identifiant Cabrillo)', filt.ctst || 'DX');
      if (c == null) return;
      api.send(Object.assign(v, { fmt: 'cabrillo', contest: String(c).trim().toUpperCase() || 'DX' }));
    }));
    root.querySelector('.lg-mlist [data-a="cfg"]').addEventListener('click', () => { closeMenus(); openCfg(); });
    root.querySelector('.lg-mlist [data-a="refs"]').addEventListener('click', () => { closeMenus(); openRefsDlg(); });
    root.querySelector('.lg-mlist [data-a="net"]').addEventListener('click', () => { closeMenus(); openNetDlg(); });
    root.querySelector('.lg-mlist [data-a="imp"]').addEventListener('click', () => { closeMenus(); openImport(); });
    q$('#lgBody').addEventListener('click', (e) => {
      const tr = e.target.closest('tr[data-id]');
      if (!tr) return;
      // Ctrl+clic : ajouter / retirer de la sélection ; Maj+clic : toute la plage depuis le dernier clic ; clic simple : modifier
      if (e.ctrlKey || e.metaKey || e.shiftKey) {
        e.preventDefault();
        const ids = items.map((q) => q.id);
        const id = tr.dataset.id;
        if (e.shiftKey && msel.anchor && ids.indexOf(msel.anchor) >= 0) {
          const a = ids.indexOf(msel.anchor), b = ids.indexOf(id);
          for (let i = Math.min(a, b); i <= Math.max(a, b); i++) msel.ids.add(ids[i]);
        } else if (msel.ids.has(id)) msel.ids.delete(id);
        else msel.ids.add(id);
        msel.anchor = id;
        window.getSelection && window.getSelection().removeAllRanges();
        return drawMsel();
      }
      if (msel.ids.size) { msel.ids.clear(); drawMsel(); }
      startEdit(tr.dataset.id);
    });
    q$('#lgMselAll').addEventListener('click', () => { for (const q of items) msel.ids.add(q.id); drawMsel(); });
    q$('#lgMselX').addEventListener('click', () => { msel.ids.clear(); drawMsel(); });
    q$('#lgMselDel').addEventListener('click', () => {
      const ids = Array.from(msel.ids);
      if (!ids.length) return;
      const calls = items.filter((q) => msel.ids.has(q.id)).slice(0, 8).map((q) => q.call).join(', ');
      if (!window.confirm('Supprimer définitivement ' + ids.length + ' QSO du carnet ?\n' + calls + (ids.length > 8 ? '…' : '') + '\n\nSeuls ceux que vous avez le droit de supprimer le seront (les vôtres avec la main ; tous pour un administrateur).')) return;
      api.send({ t: 'log_del_many', ids });
    });
    root.addEventListener('keydown', (e) => { if (e.key === 'Escape' && msel.ids.size && !e.target.closest('input, select, textarea, dialog')) { msel.ids.clear(); drawMsel(); } });
    fromTrx(false);
    rights();
  }
  function closeMenus() {
    if (!root) return;
    root.querySelectorAll('.lg-mlist').forEach((l) => { l.hidden = true; });
    root.querySelectorAll('.lg-menu > .btn').forEach((b) => b.setAttribute('aria-expanded', 'false'));
  }
  function rights() {
    if (!root) return;
    const f = q$('#lgForm');
    const ro = !!me.rxOnly;
    f.querySelector('[data-a="save"]').disabled = ro;
    if (ro) fmsg('Indicatif d’écouteur : consultation du carnet seulement.', 'warn');
    // Synchronisation : administrateurs (tous les indicatifs), membres (leur propre indicatif, avec leurs identifiants)
    const canSync = me.admin || myLogCall() !== '';
    q$('[data-m="sync"]').disabled = !canSync;
    q$('[data-m="sync"]').title = canSync ? (me.admin ? '' : 'Vos QSO sous ' + myLogCall() + ' vers VOS logs en ligne (vos propres identifiants)') : 'Réservé aux administrateurs et aux membres qui émettent sous leur propre indicatif';
    root.querySelectorAll('.lg-mlist [data-a="cfg"], .lg-mlist [data-a="refs"], .lg-mlist [data-a="net"]').forEach((b) => { b.hidden = !me.admin; });
    const sep = root.querySelector('.lg-mlist .lg-msep');
    if (sep) sep.hidden = !me.admin;
    const sel = f.station;
    const keep = sel.value;
    sel.textContent = '';
    for (const c of calls) sel.add(new Option(c, c));
    if (keep && calls.indexOf(keep) >= 0) sel.value = keep;
  }
  function initCols() {
    let saved = {};
    try { saved = JSON.parse(localStorage.getItem('rs.lgcols') || '{}') || {}; } catch (e) { saved = {}; }
    const cols = Array.from(root.querySelectorAll('.lg-table col'));
    const ths = Array.from(root.querySelectorAll('.lg-table thead th'));
    ths.forEach((th, i) => { th.dataset.c = (LG_COLS[i] || [])[0] || ''; });
    const store = () => { try { localStorage.setItem('rs.lgcols', JSON.stringify(saved)); } catch (e) { /* */ } };
    const apply = () => cols.forEach((c, i) => { const [k, w] = LG_COLS[i]; const v = saved[k] || w; c.style.width = v ? v + 'px' : ''; });
    apply();
    ths.forEach((th, i) => {
      const [k, w] = LG_COLS[i] || [];
      if (!k || !w) return;
      // Choix d'une valeur (filtre) à côté du titre
      const fb = document.createElement('b');
      fb.className = 'lg-flt';
      fb.textContent = '▾';
      fb.title = 'Choisir une valeur de cette colonne';
      fb.addEventListener('click', (e) => { e.stopPropagation(); if (fltMenu && fltMenu.col === k) closeFlt(); else openFlt(k, th); });
      th.insertBefore(fb, th.firstChild ? th.firstChild.nextSibling : null);
      const h = document.createElement('i');
      h.className = 'lg-rz';
      h.title = 'Glisser : largeur de la colonne · double-clic : largeur d’origine';
      th.appendChild(h);
      colDrag(th, k);
      h.addEventListener('click', (e) => e.stopPropagation());
      h.addEventListener('dblclick', (e) => { e.stopPropagation(); delete saved[k]; apply(); store(); });
      h.addEventListener('pointerdown', (e) => {
        e.preventDefault();
        e.stopPropagation();
        h.setPointerCapture(e.pointerId);
        const x0 = e.clientX;
        const zf = (window.RSZOOM && window.RSZOOM.z()) || 1; // zoom du dashboard (zoom.js)
        const w0 = th.getBoundingClientRect().width / zf || saved[k] || w;
        const mv = (ev) => { saved[k] = Math.max(24, Math.min(600, Math.round(w0 + (ev.clientX - x0) / zf))); cols[i].style.width = saved[k] + 'px'; };
        const up = () => { h.removeEventListener('pointermove', mv); h.removeEventListener('pointerup', up); h.removeEventListener('pointercancel', up); store(); };
        h.addEventListener('pointermove', mv);
        h.addEventListener('pointerup', up);
        h.addEventListener('pointercancel', up);
      });
    });
  }
  // ------------------------------------------------------------------ ordre des colonnes (choix de chacun, gardé dans ce navigateur)
  // Glisser l'intitulé d'une colonne (bouton gauche enfoncé) vers un autre endroit ; double-clic sur un intitulé : ordre d'origine
  const NAT = LG_COLS.map(([k]) => k);
  let colOrd = NAT.slice();
  try {
    const o = JSON.parse(localStorage.getItem('rs.lgord') || 'null');
    // Ordre gardé d'une version sans les colonnes d'échange de contest : elles sont ajoutées après Env. et Reçu
    if (Array.isArray(o)) for (const [k, after] of [['stx', 'env'], ['srx', 'recu']]) if (o.indexOf(k) < 0 && o.indexOf(after) >= 0) o.splice(o.indexOf(after) + 1, 0, k);
    if (Array.isArray(o) && o.length === NAT.length && NAT.every((k) => o.indexOf(k) >= 0)) colOrd = o;
  } catch (e) { /* */ }
  colOrd = colOrd.filter((k) => k !== 'fill').concat(['fill']); // la colonne de remplissage reste au bout
  const isNat = () => colOrd.every((k, i) => k === NAT[i]);
  // En-tête et largeurs : éléments repérés par data-c ; lignes du carnet (dessinées dans l'ordre d'origine) : réordonnées
  function applyOrder(rowsOnly) {
    if (!root) return;
    if (!rowsOnly) {
      const cg = root.querySelector('.lg-table colgroup'), tr = root.querySelector('.lg-table thead tr');
      if (cg) colOrd.forEach((k) => { const c = cg.querySelector('col[data-c="' + k + '"]'); if (c) cg.appendChild(c); });
      if (tr) colOrd.forEach((k) => { const t = tr.querySelector(':scope > th[data-c="' + k + '"]'); if (t) tr.appendChild(t); });
    }
    if (isNat()) return;
    const idx = colOrd.map((k) => NAT.indexOf(k));
    root.querySelectorAll('#lgBody tr[data-id]').forEach((r) => { const ch = Array.from(r.children); if (ch.length === NAT.length) r.append(...idx.map((i) => ch[i])); });
  }
  function colDrag(th, k) {
    if (k === 'fill') return;
    th.classList.add('lg-movable');
    th.title = (th.title ? th.title + ' — ' : '') + 'glisser l’intitulé pour déplacer la colonne ; double-clic : ordre d’origine des colonnes';
    th.addEventListener('dblclick', (e) => {
      if (e.target.closest('.lg-rz, .lg-flt') || isNat()) return;
      colOrd = NAT.slice(); try { localStorage.removeItem('rs.lgord'); } catch (er) { /* */ }
      applyOrder(); drawList();
    });
    th.addEventListener('pointerdown', (e) => {
      if (e.button !== 0 || e.target.closest('.lg-rz, .lg-flt')) return;
      const x0 = e.clientX;
      let on = false, tgt = null, after = false;
      const clear = () => root.querySelectorAll('.lg-table thead th').forEach((t) => t.classList.remove('lg-drop-l', 'lg-drop-r', 'lg-drag'));
      const mv = (ev) => {
        if (!on && Math.abs(ev.clientX - x0) < 6) return;
        if (!on) { on = true; th.classList.add('lg-drag'); document.body.style.cursor = 'grabbing'; }
        clear(); th.classList.add('lg-drag');
        tgt = null;
        for (const t of root.querySelectorAll('.lg-table thead th')) {
          const r = t.getBoundingClientRect();
          if (ev.clientX >= r.left && ev.clientX < r.right && t.dataset.c && t.dataset.c !== 'fill') { tgt = t; after = ev.clientX > r.left + r.width / 2; }
        }
        if (tgt && tgt !== th) tgt.classList.add(after ? 'lg-drop-r' : 'lg-drop-l');
      };
      const up = () => {
        window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up); window.removeEventListener('pointercancel', up);
        document.body.style.cursor = '';
        clear();
        if (!on || !tgt || tgt === th) return;
        const o = colOrd.filter((x) => x !== k), j = o.indexOf(tgt.dataset.c);
        o.splice(after ? j + 1 : j, 0, k);
        colOrd = o.filter((x) => x !== 'fill').concat(['fill']);
        try { localStorage.setItem('rs.lgord', JSON.stringify(colOrd)); } catch (er) { /* */ }
        applyOrder(); drawList();
        // pas de clic (tri / filtre) juste après un déplacement
        const stop = (ce) => { ce.stopPropagation(); ce.preventDefault(); };
        th.addEventListener('click', stop, { capture: true, once: true }); setTimeout(() => th.removeEventListener('click', stop, { capture: true }), 50);
      };
      window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up); window.addEventListener('pointercancel', up);
    });
  }
  // QRZ.com : nom et prénom, QTH, locator du correspondant (cases vides ; bouton ⇩ QRZ : remplace)
  let qrzT = null;
  let qrzForce = '';
  let qrzAsked = '';
  function qrzAsk(force) {
    const f = root && q$('#lgForm');
    if (!f || !api || viewOnly) return;
    const c = f.call.value.trim().toUpperCase();
    if (!/^(?=.*\d)[A-Z0-9/]{3,15}$/.test(c)) { if (force) fmsg('Tapez d’abord l’indicatif du correspondant.', 'warn'); return; }
    if (!force && (c === qrzAsked || (f.name.value && f.qth.value && f.gridsquare.value))) return;
    qrzAsked = c;
    qrzForce = force ? c : '';
    api.send({ t: 'qrz', call: c });
  }
  const titleCase = (x) => String(x || '').toLowerCase().replace(/(^|[\s'-])(\p{L})/gu, (m, a, b) => a + b.toUpperCase()).trim();
  function fmsg(t, cls) {
    const el = q$('#lgFmsg');
    if (!el) return;
    el.textContent = t || '';
    el.className = 'lg-fmsg' + (cls ? ' ' + cls : '');
  }

  // ------------------------------------------------------------------ pré-remplissage (TRX + correspondant)
  function trxMode(rm) {
    const m = String(rm || '').toUpperCase();
    if (SSBP) {
      // Page TRX SSB : LSB / USB du TRX, sinon d'après la fréquence (LSB sous 10 MHz, sauf 60 m)
      if (/^LSB/.test(m)) return 'LSB';
      if (/^USB/.test(m)) return 'USB';
      const st = api && api.state && api.state();
      const r = st && st.radio;
      const hz = r && (r.vfoSel === 1 && r.freqB ? r.freqB : r.freq);
      return hz && hz < 10e6 && !(hz >= 5.3e6 && hz <= 5.5e6) ? 'LSB' : 'USB';
    }
    if (/^CW/.test(m)) return 'CW';
    if (/^RTTY/.test(m)) return 'RTTY';
    if (m === 'PSK') return 'PSK31';
    if (/DATA|-D$/.test(m)) return window.RSDIGI && window.RSDIGI.logMode ? window.RSDIGI.logMode() : 'FT8';
    if (/^LSB/.test(m)) return 'LSB';
    if (/^USB/.test(m)) return 'USB';
    if (/^AM/.test(m)) return 'AM';
    if (/^FM/.test(m)) return 'FM';
    return '';
  }
  function defaultRst(force) {
    const f = q$('#lgForm');
    const m = f.mode.value;
    const dx = loadDx();
    const want = DIGI.indexOf(m) >= 0 ? [dx.rpt || '-10', ''] : PHONE.indexOf(m) >= 0 ? ['59', '59'] : m === 'SSTV' ? ['595', '595'] : [dx.rst || '599', '599'];
    if (force || !f.rst_sent.value) f.rst_sent.value = want[0];
    if (force || !f.rst_rcvd.value) f.rst_rcvd.value = want[1];
  }
  function fromTrx(withDx) {
    if (!root || editing) return;
    const f = q$('#lgForm');
    const st = api && api.state && api.state();
    const r = st && st.radio;
    // VFO actif du TRX (côté SUB → VFO B)
    const hz = r && (r.vfoSel === 1 && r.freqB ? r.freqB : r.freq);
    if (hz) {
      f.freq.value = (hz / 1e6).toFixed(6).replace(/0{1,3}$/, '');
      const m = trxMode(r.vfoSel === 1 && r.modeB ? r.modeB : r.mode);
      if (m && (withDx || !f.mode.dataset.manual)) f.mode.value = m;
      if (r.power && !f.tx_pwr.value) f.tx_pwr.value = String(Math.round(r.power));
      delete f.freq.dataset.manual;
      qoCheck();
    }
    if (withDx || !f.call.value) {
      const dx = loadDx();
      if (dx.call && (withDx || String(dx.call).toUpperCase() !== lastLogged)) {
        f.call.value = String(dx.call).toUpperCase();
        f.name.value = dx.name || '';
        f.qth.value = dx.qth || '';
        f.gridsquare.value = dx.grid || '';
        qrzAsked = '';
        setTimeout(() => qrzAsk(false), 0);
      }
    }
    if (!f.date.value || withDx) { const n = utcNow(); f.date.value = n.date; f.time.value = n.time; delete f.time.dataset.manual; }
    // Station : l'indicatif sous lequel on émet (« TX call ») s'il est dans la liste
    if (st && st.txCall && [...f.station.options].some((o) => o.value === st.txCall)) f.station.value = st.txCall;
    defaultRst(withDx);
    qoCheck();
  }
  // Fréquence sur la FI du convertisseur QO-100 (ex. 432,540 MHz) : QO-100 coché, fréquence de montée 2400,xxx
  function qoUp(f) {
    const fi = window.RSDIGI && window.RSDIGI.qo100If ? window.RSDIGI.qo100If() : { '2m': 144.5, '70cm': 432.5, '23cm': 1296.5 };
    for (const k of Object.keys(fi)) {
      const base = Number(fi[k]);
      if (base > 0 && f >= base && f <= base + 0.5) return 2400 + (f - base);
    }
    return 0;
  }
  function qoCheck() {
    const f = q$('#lgForm');
    const v = mhz(f.freq.value);
    if (!(v > 0)) return;
    const up = qoUp(v);
    if (up) {
      f.qo100.checked = true;
      fmsg('QO-100 : FI ' + v.toFixed(3) + ' MHz → montée ' + up.toFixed(3) + ' MHz (descente ' + (up + 8089.5).toFixed(3) + ' MHz)', '');
    } else if (v >= 2400 && v <= 2400.5) f.qo100.checked = true;
  }

  // ------------------------------------------------------------------ références IOTA / WWFF / POTA / BOTA / LLOTA
  // Listes téléchargées par le serveur ; on tape le début de la référence ou un morceau du nom, la liste propose
  // (pays du correspondant en premier). Plusieurs références possibles, séparées par une virgule (ex. deux parcs POTA).
  function refsCell(q) {
    const a = REF_KEYS.filter(([k]) => q[k]).map(([k]) => q[k]);
    const b = REF_KEYS.filter(([k]) => q['my_' + k]).map(([k]) => '▲' + q['my_' + k]);
    const t = a.concat(b).join(' · ');
    return '<td class="lg-refc" title="' + esc(REF_KEYS.filter(([k]) => q[k] || q['my_' + k]).map(([k, p]) => p + ' : ' + [q[k], q['my_' + k] ? 'station ' + q['my_' + k] : ''].filter(Boolean).join(', ')).join(' ; ')) + '">' + esc(t) + '</td>';
  }
  const RS = { box: null, input: null, items: [], sel: -1, seq: 0, timer: 0 };
  function showMyRefs(on) {
    const f = q$('#lgForm');
    if (!f) return;
    f.querySelector('.lg-myrefs').hidden = !on;
    const b = f.querySelector('[data-a="myrefs"]');
    b.setAttribute('aria-pressed', String(on));
    b.textContent = on ? '− Ma référence (activation)' : '＋ Ma référence (activation)';
    // Page TRX SSB : jamais ouverte d'office (choix non gardé) ; ouverte à la main : les références gardées reviennent
    if (SSBP) { restoreMyRefs(); return; }
    try { localStorage.setItem('rs.lg.myrefs', on ? '1' : '0'); } catch (e) { /* */ }
  }
  function saveMyRefs() {
    const f = q$('#lgForm');
    if (!f || editing) return;
    try { localStorage.setItem('rs.lg.myrefv', JSON.stringify(Object.fromEntries(REF_KEYS.map(([k]) => [k, f['my_' + k].value.trim()])))); } catch (e) { /* */ }
  }
  function restoreMyRefs() {
    const f = q$('#lgForm');
    if (!f) return;
    let v = {};
    try { v = JSON.parse(localStorage.getItem('rs.lg.myrefv') || '{}') || {}; } catch (e) { v = {}; }
    // Page TRX SSB, « Ma référence » fermée : pas de référence d'activation glissée en douce dans les QSO
    if (SSBP && f.querySelector('.lg-myrefs').hidden) v = {};
    for (const [k] of REF_KEYS) f['my_' + k].value = v[k] || '';
  }
  function initRefs(f) {
    const box = document.createElement('div');
    box.className = 'lg-refbox';
    box.hidden = true;
    root.appendChild(box);
    RS.box = box;
    box.addEventListener('mousedown', (e) => {
      const b = e.target.closest('[data-i]');
      if (!b) return;
      e.preventDefault();
      pickRef(Number(b.dataset.i));
    });
    f.querySelector('[data-a="myrefs"]').addEventListener('click', () => showMyRefs(f.querySelector('.lg-myrefs').hidden));
    let on = false;
    try { on = localStorage.getItem('rs.lg.myrefs') === '1'; } catch (e) { /* */ }
    if (SSBP) on = false; // page TRX SSB : « Ma référence (activation) » fermée par défaut
    showMyRefs(on);
    restoreMyRefs();
    for (const inp of f.querySelectorAll('.lg-ref input')) {
      inp.addEventListener('input', () => { inp.value = inp.value.toUpperCase(); askRefs(inp); if (inp.dataset.my) saveMyRefs(); });
      inp.addEventListener('focus', () => askRefs(inp));
      inp.addEventListener('blur', () => setTimeout(() => { if (RS.input === inp) closeRefs(); }, 150));
      inp.addEventListener('keydown', (e) => {
        if (RS.box.hidden || RS.input !== inp) return;
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); RS.sel = Math.max(0, Math.min(RS.items.length - 1, RS.sel + (e.key === 'ArrowDown' ? 1 : -1))); drawRefs(); }
        else if (e.key === 'Enter' && RS.sel >= 0) { e.preventDefault(); pickRef(RS.sel); }
        else if (e.key === 'Escape') closeRefs();
      });
    }
  }
  // Morceau en cours de frappe (après la dernière virgule)
  const refPart = (v) => { const i = v.lastIndexOf(','); return (i >= 0 ? v.slice(i + 1) : v).trim(); };
  function askRefs(inp) {
    RS.input = inp;
    clearTimeout(RS.timer);
    RS.timer = setTimeout(() => {
      const f = q$('#lgForm');
      const call = inp.dataset.my ? '' : f.call.value.trim();
      const q = refPart(inp.value);
      if (!q && !call) { closeRefs(); return; }
      api.send({ t: 'log_refs_search', id: ++RS.seq, prog: inp.dataset.prog, q, call });
    }, 180);
  }
  function refResults(m) {
    if (!RS.input || m.id !== RS.seq) return;
    RS.items = m.list || [];
    RS.sel = RS.items.length ? 0 : -1;
    RS.note = m.note || (RS.items.length ? '' : 'Aucune référence ' + m.prog + ' ne correspond');
    drawRefs();
  }
  function drawRefs() {
    const inp = RS.input;
    if (!inp || document.activeElement !== inp) return closeRefs();
    const r = inp.getBoundingClientRect();
    const rr = root.getBoundingClientRect();
    const z = (window.RSZOOM && window.RSZOOM.z()) || 1;
    RS.box.style.left = Math.max(0, (r.left - rr.left) / z) + 'px';
    RS.box.style.top = ((r.bottom - rr.top) / z + 2) + 'px';
    RS.box.innerHTML = RS.items.map((x, i) => '<button type="button" class="lg-refi' + (i === RS.sel ? ' cur' : '') + '" data-i="' + i + '"><b>' + esc(x.ref) + '</b> <span>' + esc(x.name) + '</span>' +
      (x.loc ? ' <small>' + esc(x.loc) + '</small>' : '') + '</button>').join('') + (RS.note ? '<p class="lg-refn">' + esc(RS.note) + '</p>' : '');
    RS.box.hidden = !RS.items.length && !RS.note;
    const cur = RS.box.querySelector('.cur');
    if (cur) cur.scrollIntoView({ block: 'nearest' });
  }
  function pickRef(i) {
    const x = RS.items[i];
    const inp = RS.input;
    if (!x || !inp) return;
    const v = inp.value;
    const c = v.lastIndexOf(',');
    inp.value = (c >= 0 ? v.slice(0, c + 1) : '') + x.ref;
    if (inp.dataset.my) saveMyRefs();
    // Locator du correspondant repris de la référence s'il manque
    const f = q$('#lgForm');
    if (!inp.dataset.my && x.grid && /^[A-R]{2}\d{2}/.test(x.grid) && !f.gridsquare.value) f.gridsquare.value = x.grid.slice(0, 6);
    closeRefs();
  }
  function closeRefs() { if (RS.box) RS.box.hidden = true; }
  // Chrome remplit tout seul identifiant + mot de passe avec ceux qu'il a mémorisés (souvent ceux du membre) :
  // cases d'identifiants en lecture seule jusqu'au clic, pour qu'aucun compte ne soit enregistré à la place d'un autre
  function noAutofill(el) {
    if (!el) return;
    el.querySelectorAll('input[type="password"], input[name$=".user"], input[name$=".email"], input[name$=".login"], input[name$="lookupUser"]').forEach((i) => {
      if (i.dataset.noauto) return;
      i.dataset.noauto = '1';
      i.readOnly = true;
      const on = () => { i.readOnly = false; };
      i.addEventListener('focus', on);
      i.addEventListener('pointerdown', on);
    });
  }
  // État des listes (administrateurs) : nombre de références, date du téléchargement, erreur ; « Mettre à jour maintenant »
  let refsDlg = null;
  function openRefsDlg() {
    if (!me.admin) return say('Listes de références : réservé aux administrateurs.', 'warn');
    const d = mkDlg('lg-refsdlg', '<form method="dialog"><h3>Listes de références (IOTA, WWFF, POTA, BOTA, LLOTA, SOTA)</h3>' +
      '<p class="lg-note">Téléchargées par le serveur depuis les sites des programmes, puis mises à jour toutes seules chaque semaine. Le premier téléchargement a lieu quelques minutes après le démarrage du serveur.</p>' +
      '<table class="lg-reft"><tbody><tr><td colspan="4">Lecture…</td></tr></tbody></table>' +
      '<div class="lg-act"><button class="btn" type="button" data-a="go">Mettre à jour maintenant</button><button class="btn" value="x">Fermer</button></div></form>');
    refsDlg = d;
    d.addEventListener('close', () => { if (refsDlg === d) refsDlg = null; });
    d.querySelector('[data-a="go"]').addEventListener('click', () => { api.send({ t: 'log_refs_refresh' }); d.querySelector('tbody').innerHTML = '<tr><td colspan="4">Téléchargement demandé au serveur (quelques minutes)…</td></tr>'; });
    api.send({ t: 'log_refs_status' });
  }
  function drawRefsDlg(st) {
    if (!refsDlg || !st) return;
    refsDlg.querySelector('tbody').innerHTML = '<tr><th>Liste</th><th>Références</th><th>Téléchargée</th><th>État</th></tr>' +
      REF_KEYS.map(([, pr]) => {
        const x = st[pr] || {};
        return '<tr><td><b>' + pr + '</b></td><td>' + (x.count || 0).toLocaleString('fr-BE') + '</td><td>' + (x.at ? new Date(x.at).toLocaleString('fr-BE') : '—') + '</td><td>' +
          (x.busy ? 'téléchargement…' : x.err ? '<span class="lg-bad">' + esc(x.err) + '</span>' : x.count ? 'OK' : 'pas encore téléchargée') + '</td></tr>';
      }).join('');
  }

  // ------------------------------------------------------------------ enregistrement / modification
  function formQso() {
    const f = q$('#lgForm');
    let fr = mhz(f.freq.value);
    if (f.qo100.checked && fr < 2400) { const up = qoUp(fr); if (up) fr = up; }
    const t = f.time.value.replace(/\D/g, '');
    return {
      call: f.call.value.trim().toUpperCase(), qso_date: f.date.value.replace(/\D/g, ''), time_on: (t.length === 3 ? '0' + t : t).padEnd(6, '0'),
      freq: Math.round(fr * 1e6) / 1e6, mode: f.mode.value, rst_sent: f.rst_sent.value.trim(), rst_rcvd: f.rst_rcvd.value.trim(),
      name: f.name.value.trim(), qth: f.qth.value.trim(), gridsquare: f.gridsquare.value.trim(), tx_pwr: f.tx_pwr.value.trim(),
      comment: f.comment.value.trim(), station: f.station.value, qo100: f.qo100.checked,
      ...Object.fromEntries(REF_KEYS.flatMap(([k]) => [[k, f[k].value.trim()], ['my_' + k, f['my_' + k].value.trim()]]))
    };
  }
  function save(force) {
    if (!api || viewOnly) return;
    const qso = formQso();
    if (!qso.call) return fmsg('Indicatif du correspondant ?', 'err');
    if (!(qso.freq > 0)) return fmsg('Fréquence en MHz ? (ex. 14.074)', 'err');
    if (editing) api.send({ t: 'log_edit', id: editing.id, qso, tag: TAG || undefined });
    else api.send({ t: 'log_add', qso, force: !!force, tag: TAG || undefined, spot: !!(window.RSSPOT && RSSPOT.on()) });
    fmsg('Enregistrement…', '');
    // Pas de réponse du serveur (liaison coupée, page du dashboard rechargée…) : on le dit au lieu de rester sur « Enregistrement… »
    clearTimeout(saveWait);
    saveWait = setTimeout(() => {
      const el = q$('#lgFmsg');
      if (el && /^Enregistrement/.test(el.textContent)) fmsg('Pas de réponse du serveur : QSO peut-être non enregistré. Vérifiez la connexion (ou rechargez la page) puis réessayez.', 'err');
    }, 8000);
  }
  let saveWait = 0;
  let viewOnly = false; // fiche ouverte en consultation (pas le droit de modifier ce QSO)
  // Fiche du carnet général : affichée / cachée (DÉTAILS QSO)
  let fHideT = 0;
  function fShow(on, later) {
    clearTimeout(fHideT);
    if (!root || FORM || SSBP) return;
    if (later && !on) { fHideT = setTimeout(() => fShow(false), later); return; }
    root.classList.toggle('lg-fhid', !on);
    const b = q$('#lgDetails');
    if (b) b.setAttribute('aria-pressed', String(!!on));
  }
  function startEdit(id) {
    const q = items.find((x) => x.id === id);
    if (!q) return;
    fShow(true);
    // Tout le monde peut ouvrir la fiche ; modifier / supprimer : administrateur, ou auteur du QSO avec la main
    const ctl = !!(api && api.iControl && api.iControl());
    const can = me.admin || (!me.rxOnly && q.by === me.call && ctl);
    editing = q;
    viewOnly = !can;
    const f = q$('#lgForm');
    f.call.value = q.call;
    f.date.value = q.qso_date.slice(0, 4) + '-' + q.qso_date.slice(4, 6) + '-' + q.qso_date.slice(6, 8);
    f.time.value = fmtTime(q.time_on);
    f.freq.value = q.freq;
    f.mode.value = MODES.indexOf(modeName(q)) >= 0 ? modeName(q) : q.mode === 'SSB' ? 'SSB' : 'DATA';
    for (const k of ['rst_sent', 'rst_rcvd', 'name', 'qth', 'gridsquare', 'tx_pwr', 'comment']) f[k].value = q[k] || '';
    for (const [k] of REF_KEYS) { f[k].value = q[k] || ''; f['my_' + k].value = q['my_' + k] || ''; }
    if (REF_KEYS.some(([k]) => q['my_' + k])) showMyRefs(true);
    if (q.station_callsign && calls.indexOf(q.station_callsign) < 0) { calls = calls.concat([q.station_callsign]); rights(); }
    if (calls.indexOf(q.station_callsign) >= 0) f.station.value = q.station_callsign;
    f.qo100.checked = q.sat_name === 'QO-100';
    qrzAsked = '';
    f.querySelector('[data-a="save"]').textContent = 'Modifier le QSO';
    f.querySelector('[data-a="save"]').hidden = viewOnly;
    f.querySelector('[data-a="del"]').hidden = viewOnly;
    f.querySelector('[data-a="cancel"]').hidden = false;
    f.querySelector('[data-a="cancel"]').textContent = viewOnly ? 'Fermer' : 'Annuler';
    for (const el of f.querySelectorAll('input, select, textarea')) el.disabled = viewOnly;
    for (const el of f.querySelectorAll('button[data-a="now"], button[data-a="trx"], button[data-a="qrz"]')) el.disabled = viewOnly;
    f.classList.add('editing');
    f.classList.toggle('viewonly', viewOnly);
    lastBtns();
    const info = ' — opérateur ' + (q.operator || '?') + ', enregistré par ' + (q.by || '?') + (q.country ? ', ' + q.country : '') + '.';
    if (viewOnly) {
      const why = me.rxOnly ? 'indicatif d’écouteur' : q.by !== me.call ? 'QSO d’un autre opérateur' : 'prenez la main pour le modifier';
      fmsg('Consultation du QSO avec ' + q.call + info + ' Lecture seule (' + why + ').', 'warn');
    } else {
      fmsg('Modification du QSO avec ' + q.call + info + ' Les carnets en ligne déjà servis ne sont pas modifiés : renvoyez-le si nécessaire.', 'warn');
      qrzAsk(false); // nom, QTH ou locator manquants : repris de QRZ.com (à enregistrer avec « Modifier le QSO »)
    }
    drawList();
  }
  // « Modifier le QSO » / « Supprimer le QSO » (fiche seule) : visibles hors modification, actifs après un enregistrement
  function lastBtns() {
    const f = root && q$('#lgForm');
    if (!f) return;
    for (const b of f.querySelectorAll('[data-a="editlast"], [data-a="dellast"]')) {
      b.hidden = !FORM || !!editing;
      b.disabled = !lastSaved;
      if (lastSaved) b.title = (b.dataset.a === 'editlast' ? 'Corriger' : 'Supprimer') + ' le dernier QSO enregistré d’ici : ' + lastSaved.call + ' (' + fmtTime(lastSaved.time_on) + ' UTC)';
    }
  }
  function endEdit() {
    editing = null;
    const f = q$('#lgForm');
    if (viewOnly) {
      viewOnly = false;
      for (const el of f.querySelectorAll('input, select, textarea, button')) el.disabled = false;
      f.querySelector('[data-a="save"]').hidden = false;
      f.classList.remove('viewonly');
    }
    f.querySelector('[data-a="cancel"]').textContent = 'Annuler';
    f.reset();
    restoreMyRefs(); // références d'activation : gardées d'un QSO à l'autre
    delete f.freq.dataset.manual;
    delete f.mode.dataset.manual;
    f.querySelector('[data-a="save"]').textContent = 'Enregistrer le QSO';
    f.querySelector('[data-a="del"]').hidden = true;
    f.querySelector('[data-a="cancel"]').hidden = true;
    f.classList.remove('editing');
    rights();
    fmsg('');
    lastBtns();
    fromTrx(false);
    drawList();
  }

  // ------------------------------------------------------------------ liste
  function reload() {
    if (!api || !root) return;
    stale = false;
    if (FORM) return api.send({ t: 'log_cfg_get', quiet: true }); // fiche seule : juste la liste des TX call
    api.send({ t: 'log_list', q: q$('#lgSearch').value.trim(), limit: TAG === 'big' ? 1000 : 300, f: filt }); // carnet en grand (fenêtre à part) : 1000 lignes
    drawFilt();
    txfDraw();
  }
  // Liste TX call de la barre : indicatifs de la station, ceux du carnet (administrateur), le vôtre
  function txfDraw() {
    const sel = q$('#lgTxf');
    if (!sel) return;
    const l = Array.from(new Set(stCalls.concat(txcalls, calls, [String(me.call || '').toUpperCase(), filt.txc || '']).filter(Boolean)));
    const key = l.join(',');
    if (sel.dataset.k !== key) {
      sel.dataset.k = key;
      sel.textContent = '';
      sel.add(new Option('Tous', ''));
      for (const c of l) sel.add(new Option(c, c));
    }
    sel.value = filt.txc || '';
    sel.classList.toggle('on', !!filt.txc);
  }
  // ------------------------------------------------------------------ filtres par colonne (choix sous chaque titre)
  const FLT_FMT = {
    date: (v) => fmtDate(v), utc: (v) => (v ? v + ' h UTC' : '—'),
    lotw: (v) => v, eqsl: (v) => v, cl: (v) => v, qrz: (v) => v
  };
  const fltLabel = (col, v) => (v === '' ? '(vide)' : FLT_FMT[col] ? FLT_FMT[col](v) : v);
  function drawFilt() {
    if (!root) return;
    root.querySelectorAll('.lg-table thead th').forEach((th) => {
      const k = th.dataset.c;
      const b = th.querySelector('.lg-flt');
      if (!b) return;
      const on = filt[k] != null;
      th.classList.toggle('flt-on', on);
      b.textContent = on ? '●' : '▾';
      b.title = on ? 'Filtre : ' + fltLabel(k, filt[k]) + ' (clic : changer)' : 'Choisir une valeur de cette colonne';
    });
    const c = q$('#lgFclr');
    if (c) c.hidden = !Object.keys(filt).length;
  }
  function closeFlt() { if (fltMenu) { fltMenu.el.remove(); fltMenu = null; } }
  function openFlt(col, th) {
    closeFlt();
    const el = document.createElement('div');
    el.className = 'lg-fmenu';
    el.innerHTML = '<input class="lg-fq" placeholder="Rechercher…" aria-label="Rechercher une valeur"><div class="lg-fl"><p class="lg-fw">Chargement…</p></div>';
    root.appendChild(el);
    const r = th.getBoundingClientRect();
    const rr = root.getBoundingClientRect();
    el.style.left = Math.max(0, Math.min(r.left - rr.left, rr.width - 240)) + 'px';
    el.style.top = (r.bottom - rr.top + 2) + 'px';
    fltMenu = { col, el, values: [] };
    el.addEventListener('click', (e) => e.stopPropagation());
    el.querySelector('.lg-fq').addEventListener('input', () => fillFlt());
    el.querySelector('.lg-fq').focus();
    api.send({ t: 'log_values', col, q: q$('#lgSearch').value.trim(), f: filt });
  }
  function fillFlt() {
    if (!fltMenu) return;
    const { col, el, values } = fltMenu;
    const qq = el.querySelector('.lg-fq').value.trim().toUpperCase();
    const list = el.querySelector('.lg-fl');
    list.textContent = '';
    const add = (label, n, v, cur) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'lg-fi' + (cur ? ' cur' : '');
      b.innerHTML = '<span></span><small></small>';
      b.firstChild.textContent = label;
      b.lastChild.textContent = n == null ? '' : n;
      b.addEventListener('click', () => {
        if (v == null) delete filt[col]; else filt[col] = v;
        closeFlt();
        reload();
      });
      list.appendChild(b);
    };
    add('(tous)', null, null, filt[col] == null);
    for (const [v, n] of values) {
      const lab = fltLabel(col, v);
      if (qq && String(lab).toUpperCase().indexOf(qq) < 0) continue;
      add(lab, n, v, filt[col] === v);
    }
  }
  function upCell(q, s) {
    const u = q.up && q.up[s];
    if (s === 'lotw' && q.lotw_qsl_rcvd === 'Y') return '<td class="c ok" title="Confirmé sur LoTW' + (q.lotw_qslrdate ? ' le ' + fmtDate(q.lotw_qslrdate) : '') + '">★</td>';
    if (!u) return '<td class="c no" title="Pas encore envoyé">·</td>';
    const when = new Date(u.t).toLocaleString('fr-BE');
    return '<td class="c ' + (u.ok ? 'ok' : 'ko') + '" title="' + esc(when + ' — ' + u.msg) + '">' + (u.ok ? '✓' : '✗') + '</td>';
  }
  // Sélection de plusieurs QSO (Ctrl+clic, Maj+clic) pour les supprimer d'un coup
  const msel = { ids: new Set(), anchor: '' };
  function drawMsel() {
    const body = q$('#lgBody');
    if (!body) return;
    const shown = new Set(items.map((q) => q.id));
    for (const id of Array.from(msel.ids)) if (!shown.has(id)) msel.ids.delete(id); // QSO supprimés ou filtrés
    body.querySelectorAll('tr[data-id]').forEach((tr) => tr.classList.toggle('msel', msel.ids.has(tr.dataset.id)));
    const n = msel.ids.size;
    q$('#lgMsel').hidden = !n;
    q$('#lgMselN').textContent = n + ' QSO sélectionné' + (n > 1 ? 's' : '');
  }
  function drawList() {
    const body = q$('#lgBody');
    if (!body) return;
    if (!items.length) {
      body.innerHTML = '<tr><td colspan="24" class="lg-empty">' + (total ? 'Aucun QSO ne correspond à la recherche ou aux filtres.' : 'Carnet vide : enregistrez votre premier QSO ci-dessus.') + '</td></tr>';
    } else {
      body.innerHTML = items.map((q) => '<tr data-id="' + esc(q.id) + '"' + (editing && editing.id === q.id ? ' class="sel"' : '') + ' title="Clic : modifier · Ctrl+clic : sélectionner plusieurs QSO · Maj+clic : une plage">' +
        '<td>' + fmtDate(q.qso_date) + '</td><td>' + fmtTime(q.time_on) + '</td><td class="call">' + esc(q.call) + '</td><td>' + esc(q.band) +
        (q.sat_name ? ' <span class="sat">' + esc(q.sat_name) + '</span>' : '') + '</td><td class="r">' + esc(mhz3(q.freq)) + '</td><td>' + esc(modeName(q)) +
        '</td><td>' + esc(q.rst_sent || '') + '</td><td class="lg-xch">' + esc(q.stx_string || q.stx || '') + '</td><td>' + esc(q.rst_rcvd || '') + '</td><td class="lg-xch">' + esc(q.srx_string || q.srx || '') + '</td><td class="grow">' + esc(q.name || '') + '</td><td class="lg-qth" title="' + esc(q.qth || '') + '">' + esc(q.qth || '') +
        '</td><td class="lg-loc">' + esc(q.gridsquare || '') + '</td><td class="lg-cty" title="' + esc(q.country || '') + '">' + esc(q.country || '') + '</td><td>' + esc(q.dxcc_pfx || '') + '</td><td class="txc">' + esc(q.station_callsign || '') + '</td><td class="op" title="' + esc(q.by && q.by !== q.operator ? 'Enregistré par ' + q.by : '') + '">' + esc(q.operator || q.by || '') + '</td>' + refsCell(q) +
        '<td class="lg-ctst" title="' + esc(q.contest_id ? 'Envoyé : ' + (q.stx_string || q.stx || '—') + ' · reçu : ' + (q.srx_string || q.srx || '—') : '') + '">' + esc(q.contest_id || '') + '</td>' +
        SV.map((s) => upCell(q, s)).join('') + '<td class="lg-fill"></td></tr>').join('');
      applyOrder(true); // ordre des colonnes choisi par l'utilisateur
    }
    drawMsel();
    const c = q$('#lgCount');
    if (c) { c.textContent = total + ' QSO au carnet' + (items.length < total ? ' · ' + items.length + ' affichés' : ''); c.title = engine === 'sqlite' ? 'Carnet enregistré dans la base SQLite du serveur (logbook.db)' : engine === 'json' ? 'Carnet enregistré dans le fichier logbook.json du serveur' : ''; }
  }

  // ------------------------------------------------------------------ fenêtres (dialog)
  // ---------- 🌐 Réseau : mise en réseau des serveurs (administrateurs)
  let netDlg = null;
  function openNetDlg() {
    if (!me.admin) return say('Réseau : réservé aux administrateurs.', 'warn');
    const d = mkDlg('lg-net', '<form method="dialog"><h3>🌐 Réseau — log commun et numéros de série</h3><div class="lg-pp">' +
      '<div class="lg-tabs lg-nettabs" role="tablist"><button type="button" data-nt="cfg" aria-selected="true">RÉGLAGES ET ÉTAT</button><button type="button" data-nt="help" aria-selected="false">HELP</button></div>' +
      '<div class="lg-nethelp" id="lgNetHelp" hidden><p>Chargement de l’aide…</p></div><div class="lg-netcfg">' +
      '<p class="lg-note">Plusieurs serveurs Remote Station (un par TRX, à des endroits différents) partagent <b>un seul log</b> et <b>une seule série de numéros</b> de contest (RTTY, CW, SSB), comme N1MM. Chaque serveur garde une copie complète du log. Les liaisons partent des postes vers le maître (HTTPS, port 443) : rien à ouvrir chez eux, même derrière un CGNAT.</p>' +
      '<label>Mode <select name="mode"><option value="off">Hors réseau (station seule)</option><option value="node">Poste : station distante (son TRX, son serveur), reliée au maître</option><option value="master">Maître (remote.op0p.be) ou maître de secours (secours.op0p.be)</option></select></label>' +
      '<label>Nom de ce serveur dans le réseau <input name="name" maxlength="24" placeholder="ON4LUC-1"></label>' +
      '<label data-n>Partager avec le réseau <select name="share"><option value="club">Seulement les QSO sous les indicatifs du club</option><option value="contest">Seulement les QSO de contest</option><option value="all">Tous les QSO de cette station</option></select><small data-club></small></label>' +
      '<label data-m>Adresse de ce serveur (maître) <input name="self" maxlength="120" placeholder="remote.op0p.be"></label>' +
      '<label>Maîtres, par ordre de priorité (un par ligne ; la même liste sur tous les serveurs) <textarea name="masters" rows="3" placeholder="remote.op0p.be&#10;secours.op0p.be"></textarea></label>' +
      '<label>Clé du réseau (16 caractères au moins, la même partout ; jamais affichée) <input name="key" type="password" autocomplete="new-password" maxlength="200" placeholder="(inchangée)"></label>' +
      '<label data-first>Envoyer aussi les QSO déjà faits depuis le (facultatif) <input name="since" type="date"></label>' +
      '<p class="lg-note">Maître de priorité 1 : actif en permanence (après avoir repris les données du secours à son démarrage). Secours : prend le relais si le maître ne répond plus depuis 30 s, et le lui rend à son retour. Postes : continuent seuls si aucun maître ne répond (numéros de série alors <b>provisoires</b>, signalés en orange).</p>' +
      '<div class="lg-netst" id="lgNetSt">…</div>' +
      '</div></div><div class="md-act"><span class="lg-neterr" id="lgNetErr"></span><button class="btn" value="cancel">Fermer</button><button class="btn btn-primary" type="button" data-a="save">Enregistrer</button></div></form>');
    netDlg = d;
    const f = d.querySelector('form');
    // Onglet HELP : la section « Réseau » du manuel (14.6), lue dans /aide.html
    const tab = (t) => {
      d.querySelectorAll('[data-nt]').forEach((b) => b.setAttribute('aria-selected', String(b.dataset.nt === t)));
      d.querySelector('.lg-netcfg').hidden = t !== 'cfg';
      d.querySelector('[data-a="save"]').hidden = t !== 'cfg';
      const h = d.querySelector('#lgNetHelp');
      h.hidden = t !== 'help';
      if (t === 'help' && !h.dataset.ok) {
        fetch('/aide.html', { cache: 'no-cache' }).then((r) => r.text()).then((html) => {
          const doc = new DOMParser().parseFromString(html, 'text/html');
          const h3 = doc.getElementById('l-net');
          if (!h3) throw new Error('section absente');
          const out = document.createElement('div');
          for (let n = h3; n; n = n.nextElementSibling) { if (n !== h3 && /^H[23]$/.test(n.tagName)) break; out.appendChild(document.importNode(n, true)); }
          out.querySelectorAll('script, iframe, object').forEach((x) => x.remove());
          h.textContent = '';
          h.appendChild(out);
          const a = document.createElement('p');
          a.innerHTML = '<a href="/aide#l-net" target="_blank" rel="noopener">Ouvrir le manuel complet à cette section ↗</a>';
          h.appendChild(a);
          h.dataset.ok = '1';
        }).catch(() => { h.innerHTML = '<p>Aide indisponible : <a href="/aide#l-net" target="_blank" rel="noopener">ouvrir le manuel, section 14.6</a>.</p>'; });
      }
    };
    d.querySelectorAll('[data-nt]').forEach((b) => b.addEventListener('click', () => tab(b.dataset.nt)));
    const upd = () => { d.querySelectorAll('[data-m]').forEach((x) => { x.hidden = f.mode.value !== 'master'; }); d.querySelectorAll('[data-n]').forEach((x) => { x.hidden = f.mode.value !== 'node'; }); };
    f.mode.addEventListener('change', upd);
    d.querySelector('[data-a="save"]').addEventListener('click', () => {
      d.querySelector('#lgNetErr').textContent = '';
      api.send({ t: 'log_net_set', cfg: { mode: f.mode.value, name: f.name.value.trim(), self: f.self.value.trim(), masters: f.masters.value, key: f.key.value, since: f.since.value, share: f.share.value } });
      f.key.value = '';
    });
    d.dataset.filled = '';
    api.send({ t: 'log_net_get' });
    const iv = setInterval(() => { if (!d.isConnected) return clearInterval(iv); api.send({ t: 'log_net_get' }); }, 3000);
    d.addEventListener('close', () => { clearInterval(iv); netDlg = null; });
    upd();
  }
  function netShow(m) {
    const d = netDlg;
    if (!d || !d.isConnected) return;
    const st = m.st || {};
    const f = d.querySelector('form');
    if (!d.dataset.filled) {
      d.dataset.filled = '1';
      f.mode.value = st.mode || 'off';
      f.name.value = st.name || '';
      f.self.value = st.self || '';
      f.masters.value = (st.masters || []).join('\n');
      f.share.value = st.share || 'club';
      d.querySelector('[data-club]').textContent = (st.club || []).length ? 'Indicatifs du club : ' + st.club.join(', ') + '. Les autres QSO de cette station (indicatif personnel du membre…) restent dans son seul carnet.' : '';
      f.key.placeholder = st.hasKey ? '(inchangée : ' + st.keyLen + ' caractères)' : 'à choisir';
      d.querySelectorAll('[data-m]').forEach((x) => { x.hidden = f.mode.value !== 'master'; });
      d.querySelectorAll('[data-n]').forEach((x) => { x.hidden = f.mode.value !== 'node'; });
      d.querySelector('[data-first]').hidden = st.mode !== 'off';
      if (st.mode === 'off') f.mode.addEventListener('change', () => { d.querySelector('[data-first]').hidden = f.mode.value !== 'node'; }); // seulement pour un poste qui rejoint le réseau
    }
    if (m.err) d.querySelector('#lgNetErr').textContent = '✗ ' + m.err;
    else if (m.ok) { d.querySelector('#lgNetErr').textContent = '✓ Enregistré'; f.key.placeholder = st.hasKey ? '(inchangée : ' + st.keyLen + ' caractères)' : 'à choisir'; }
    const ago = (t) => (t ? Math.max(0, Math.round((Date.now() - t) / 1000)) + ' s' : '—');
    const role = st.mode === 'off' ? 'Hors réseau : cette station travaille seule.'
      : st.mode === 'master' ? (st.prio < 0 ? '⚠ Cette adresse n’est pas dans la liste des maîtres.' : (st.prio === 0 ? 'Maître prioritaire' : 'Maître de secours n° ' + st.prio) + ' — ' + (st.active ? '<b class="ok">ACTIF</b> (donne les numéros de série)' : '<b class="wait">en attente</b>' + (st.prio === 0 ? ' (reprise des données du secours, 40 s au plus)' : ' (le maître prioritaire est actif)')))
      : 'Poste — ' + (st.out && st.out.ready ? 'relié à <b>' + esc(st.out.name) + '</b>' + (st.out.active ? ' (actif)' : ' (en attente)') : '<b class="wait">pas de liaison avec un maître</b> (numéros provisoires)');
    const lq = (x) => (x ? esc(x.call) + ' · ' + esc(x.band) + ' ' + esc(x.mode) + ' · ' + esc(String(x.t).slice(6, 8) + '/' + String(x.t).slice(4, 6) + ' ' + String(x.t).slice(8, 10) + ':' + String(x.t).slice(10, 12)) + ' UTC' + (x.by ? ' · ' + esc(x.by) : '') : '—');
    const vn = (v) => String(v || '0').split('.').map(Number).reduce((a, x) => a * 1000 + (x || 0), 0);
    const rows = (st.peers || []).map((p) => '<tr><td><b>' + esc(p.name) + '</b>' + (p.master ? ' (maître)' : '') + (p.v ? '<br><small class="' + (vn(p.v) < vn(st.v) ? 'wait' : vn(p.v) === vn(st.v) ? 'ok' : '') + '">v' + esc(p.v) + '</small>' : '') + '</td><td>' + (p.dir === 'in' ? 'entrante' : 'sortante') + '</td><td>' + ago(p.since) + '</td><td>' + ago(p.heard || p.lastIn) + '</td><td>' + p.inQ + ' / ' + p.outQ + '</td><td>' + p.behind + '</td><td>' + lq(p.lastQso) + '</td></tr>').join('');
    const nSt = (st.peers || []).filter((p) => !p.master).length;
    const old = (st.peers || []).filter((p) => p.v && vn(p.v) < vn(st.v));
    const oldOut = st.out && st.out.v && vn(st.out.v) > vn(st.v);
    d.querySelector('#lgNetSt').innerHTML = '<p><b>État :</b> ' + role + '</p>' +
      (old.length ? '<p class="wait">⚠ Version plus ancienne que ce serveur (' + esc(st.v) + ') : ' + old.map((p) => esc(p.name) + ' (' + esc(p.v) + ')').join(', ') + '. ' + (old.some((p) => p.master && vn(p.v) < vn('0.42.3')) ? 'Mettez le secours à jour une fois à la main (il s’alignera ensuite tout seul, à partir de la 0.42.3) ; ' : old.some((p) => p.master) ? 'Le secours s’aligne tout seul dans la minute ; ' : '') + 'les stations se mettent à jour par 🔔 Mise à jour, hors contest.</p>' : '') +
      (oldOut ? '<p class="wait">⚠ Le maître ' + esc(st.out.name) + ' est en version ' + esc(st.out.v) + ', ce serveur en ' + esc(st.v) + (st.mode === 'master' ? ' : mise à jour automatique en cours ou à venir.' : ' : pensez à mettre ce serveur à jour (🔔 Mise à jour), hors contest.') + '</p>' : '') +
      (st.mode === 'master' ? '<p><b>' + nSt + '</b> station' + (nSt > 1 ? 's' : '') + ' reliée' + (nSt > 1 ? 's' : '') + ' à ce maître.</p>' : '') +
      (rows ? '<table class="lg-nettab"><tr><th>Serveur (version)<br><small>ce serveur : v' + esc(st.v || '?') + '</small></th><th>Liaison</th><th>Depuis</th><th title="Dernier signe de vie (un échange toutes les 3 s ; liaison coupée après 25 s sans nouvelles)">Dernier signe de vie</th><th>QSO reçus / envoyés</th><th>Changements en retard</th><th>Dernier QSO reçu de lui</th></tr>' + rows + '</table>' : (st.mode !== 'off' ? '<p>Aucune liaison ouverte.</p>' : '')) +
      ((st.events || []).length ? '<details><summary>Derniers événements</summary><ul>' + st.events.map((e) => '<li>' + new Date(e.t).toLocaleTimeString('fr-BE') + ' — ' + esc(e.msg) + '</li>').join('') + '</ul></details>' : '');
  }
  // ------------------------------------------------------------------ import d'un log ADIF (Swisslog…), par années
  // Le fichier est lu ici : en-tête retiré, enregistrements comptés par année et par TX call (STATION_CALLSIGN) ; on choisit
  // les années, puis les enregistrements partent par lots de moins de 50 Ko (4 lots en route au plus) ; le serveur
  // ajoute les QSO valides, ignore les doublons et ne renvoie rien aux logs en ligne.
  let imp = null;
  function openImport() {
    if (me.rxOnly) return say('Indicatif d’écouteur : pas d’import.', 'warn');
    const d = mkDlg('lg-impdlg', '<form method="dialog"><h3>📥 Importer .ADI</h3>' +
      '<p class="lg-dhint">Log exporté en ADIF (.adi / .adif) par Swisslog, Log4OM, WSJT-X… Vous pouvez importer <b>tout le fichier ou seulement certaines années</b> (puis les autres plus tard) : les statistiques comptent toujours toutes les années. Les doublons (même indicatif, bande et mode à 30 min près) sont ignorés ; les QSO importés sont notés « déjà envoyés » à LoTW, eQSL, Club Log et QRZ (rien ne repart). ' + (me.admin ? 'Administrateur : tous les indicatifs.' : 'Seulement les QSO faits sous votre indicatif ' + esc(me.call) + '.') + '</p>' +
      '<label class="lg-impf">Fichier <input type="file" name="file" accept=".adi,.adif,.ADI,.ADIF,.txt"></label>' +
      '<div id="lgImpInfo" class="lg-impinfo"></div>' +
      '<div class="lg-imprg" hidden><progress id="lgImpBar" max="1" value="0"></progress> <span id="lgImpTxt"></span></div>' +
      '<div class="lg-dbtns"><button class="btn" type="button" data-go disabled>IMPORTER</button><button class="btn" type="button" data-stop hidden>INTERROMPRE</button><button class="btn" value="close" data-close>FERMER</button></div></form>');
    const f = d.querySelector('form'), info = d.querySelector('#lgImpInfo');
    const st = { recs: [], years: {}, calls: {} };
    f.file.addEventListener('change', () => {
      const file = f.file.files[0];
      if (!file) return;
      if (file.size > 150 * 1024 * 1024) { info.innerHTML = '<p class="warn">Fichier trop gros (' + Math.round(file.size / 1048576) + ' Mo, 150 Mo au plus) : exportez-le en plusieurs fois (par année) depuis votre logiciel.</p>'; return; }
      info.textContent = 'Lecture de ' + file.name + '…';
      const rd = new FileReader();
      rd.onload = () => {
        let t = String(rd.result || '');
        const h = t.search(/<eoh>/i);
        if (h >= 0) t = t.slice(h + 5);
        const parts = t.split(/<eor>/i);
        st.recs = []; st.years = {}; st.calls = {};
        for (const p of parts) {
          if (!/<call:/i.test(p)) continue;
          const y = (/<qso_date:\d+(?::\w)?>(\d{4})/i.exec(p) || [])[1] || '?';
          const mm = /<station_callsign:(\d+)(?::\w)?>/i.exec(p);
          const sc = mm ? p.substr(mm.index + mm[0].length, Number(mm[1])).toUpperCase().trim() : '';
          st.recs.push({ y, t: p.trim() });
          st.years[y] = (st.years[y] || 0) + 1;
          if (sc) st.calls[sc] = (st.calls[sc] || 0) + 1;
        }
        const ys = Object.keys(st.years).sort();
        const cs = Object.keys(st.calls).sort((a, b) => st.calls[b] - st.calls[a]);
        const opts = Array.from(new Set((me.admin ? calls : [String(me.call).toUpperCase()]).concat(me.admin ? cs : []))).filter(Boolean);
        info.innerHTML = '<p><b>' + st.recs.length.toLocaleString('fr-BE') + '</b> QSO dans ' + esc(file.name) + ' (' + (file.size / 1048576).toFixed(1).replace('.', ',') + ' Mo)' +
          (cs.length ? ' · indicatif(s) du fichier : ' + cs.map((c) => '<b>' + esc(c) + '</b> (' + st.calls[c].toLocaleString('fr-BE') + ')').join(', ') : ' · pas de STATION_CALLSIGN dans le fichier') + '</p>' +
          '<fieldset class="lg-impy"><legend>Années à importer <button class="dg-mini" type="button" data-all>tout</button> <button class="dg-mini" type="button" data-none>rien</button></legend>' +
          ys.map((y) => '<label><input type="checkbox" name="y" value="' + esc(y) + '" checked> ' + esc(y) + ' <small>(' + st.years[y].toLocaleString('fr-BE') + ')</small></label>').join('') + '</fieldset>' +
          '<label class="lg-txf">TX call <select name="txc">' + opts.map((c) => '<option' + (c === (cs[0] || (me.admin ? '' : me.call)) ? ' selected' : '') + '>' + esc(c) + '</option>').join('') + '</select></label> ' +
          '<label><input type="checkbox" name="force"' + (cs.length ? '' : ' checked') + '> l’imposer à tous les QSO</label>' +
          '<p class="lg-dhint">Sans la case : chaque QSO garde l’indicatif du fichier (STATION_CALLSIGN) et ce TX call ne sert qu’aux QSO qui n’en ont pas.</p>' +
          '<p id="lgImpSel"></p>';
        const sel = () => { const n = Array.from(f.querySelectorAll('[name="y"]:checked')).reduce((a, x) => a + st.years[x.value], 0); d.querySelector('#lgImpSel').innerHTML = '<b>' + n.toLocaleString('fr-BE') + '</b> QSO choisis.'; d.querySelector('[data-go]').disabled = !n; };
        f.querySelectorAll('[name="y"]').forEach((x) => x.addEventListener('change', sel));
        d.querySelector('[data-all]').addEventListener('click', () => { f.querySelectorAll('[name="y"]').forEach((x) => { x.checked = true; }); sel(); });
        d.querySelector('[data-none]').addEventListener('click', () => { f.querySelectorAll('[name="y"]').forEach((x) => { x.checked = false; }); sel(); });
        sel();
      };
      rd.onerror = () => { info.textContent = 'Lecture du fichier impossible.'; };
      rd.readAsText(file, 'latin1'); // ADIF : texte ASCII (accents éventuels en ISO-8859-1)
    });
    d.querySelector('[data-go]').addEventListener('click', () => {
      const ys = new Set(Array.from(f.querySelectorAll('[name="y"]:checked')).map((x) => x.value));
      const recs = st.recs.filter((r) => ys.has(r.y)).map((r) => r.t);
      if (!recs.length) return;
      // Lots de moins de 50 Ko (taille en octets, le texte peut contenir des accents)
      const enc = new TextEncoder(), chunks = [];
      let cur = '', sz = 0;
      for (const r of recs) {
        const s0 = r + '<eor>\n', b = enc.encode(s0).length;
        if (b > 48000) continue; // enregistrement anormal
        if (sz + b > 48000) { chunks.push(cur); cur = ''; sz = 0; }
        cur += s0; sz += b;
      }
      if (cur) chunks.push(cur);
      imp = { d, chunks, next: 0, inflight: 0, total: recs.length, done: false, started: Date.now() };
      d.dataset.busy = '1';
      d.querySelector('[data-go]').disabled = true;
      d.querySelector('[data-stop]').hidden = false;
      d.querySelector('[data-close]').disabled = true;
      f.file.disabled = true;
      d.querySelector('.lg-imprg').hidden = false;
      d.querySelector('#lgImpBar').max = chunks.length;
      api.send({ t: 'log_import', op: 'start', txc: f.txc ? f.txc.value : '', force: !!(f.force && f.force.checked), size: chunks.reduce((a, c) => a + c.length, 0), records: recs.length });
    });
    d.querySelector('[data-stop]').addEventListener('click', () => { if (imp && !imp.done) { imp.stop = true; api.send({ t: 'log_import', op: 'cancel' }); } });
    d.addEventListener('close', () => { if (imp && imp.d === d && !imp.done) api.send({ t: 'log_import', op: 'cancel' }); imp = null; });
  }
  function impPump() {
    while (imp && !imp.stop && imp.inflight < 4 && imp.next < imp.chunks.length) {
      api.send({ t: 'log_import', op: 'data', part: imp.next, data: imp.chunks[imp.next] });
      imp.next++; imp.inflight++;
    }
    if (imp && !imp.stop && imp.next >= imp.chunks.length && imp.inflight === 0 && !imp.ending) { imp.ending = true; api.send({ t: 'log_import', op: 'end' }); }
  }
  function impMsg(m) {
    if (!imp || !imp.d.isConnected) return;
    const d = imp.d, txt = d.querySelector('#lgImpTxt');
    const fin = (html) => {
      imp.done = true;
      d.dataset.busy = '';
      d.querySelector('[data-stop]').hidden = true;
      d.querySelector('[data-close]').disabled = false;
      d.querySelector('#lgImpInfo').insertAdjacentHTML('beforeend', html);
    };
    if (m.op === 'fail') return fin('<p class="warn">✗ ' + esc(m.msg) + '</p>');
    if (m.op === 'ready') return impPump();
    const s = m.st || {};
    if (m.op === 'ack') {
      imp.inflight--;
      d.querySelector('#lgImpBar').value = imp.next - imp.inflight;
      txt.textContent = (s.n || 0).toLocaleString('fr-BE') + ' / ' + imp.total.toLocaleString('fr-BE') + ' QSO lus · ' + (s.added || 0).toLocaleString('fr-BE') + ' ajoutés · ' + (s.dupes || 0).toLocaleString('fr-BE') + ' doublons';
      return impPump();
    }
    if (m.op === 'done') {
      d.querySelector('#lgImpBar').value = d.querySelector('#lgImpBar').max;
      const why = Object.entries(s.why || {}).map(([k, v]) => k + ' ' + v).join(', ');
      const ys = Object.entries(s.years || {}).sort().map(([y, n]) => y + ' : ' + n.toLocaleString('fr-BE')).join(' · ');
      fin('<p class="ok">' + (m.cancel ? '■ Import interrompu.' : '✓ Import terminé') + ' en ' + Math.round((Date.now() - imp.started) / 1000) + ' s : <b>' + (s.added || 0).toLocaleString('fr-BE') + '</b> QSO ajoutés' +
        (Object.keys(s.calls || {}).length ? ' (' + Object.entries(s.calls).map(([c, n]) => esc(c) + ' ' + n.toLocaleString('fr-BE')).join(', ') + ')' : '') +
        ', <b>' + (s.dupes || 0).toLocaleString('fr-BE') + '</b> doublons ignorés' + (s.bad ? ', <b>' + s.bad + '</b> illisibles (' + esc(why) + ')' : '') + (s.denied ? ', <b>' + s.denied + '</b> refusés (autre indicatif que le vôtre)' : '') + '.</p>' +
        (ys ? '<p class="lg-dhint">Ajoutés par année : ' + ys + '</p>' : ''));
    }
  }
  function mkDlg(cls, html) {
    const d = document.createElement('dialog');
    d.className = 'macro-dlg lg-dlg ' + cls;
    d.innerHTML = html;
    document.body.appendChild(d);
    d.addEventListener('close', () => d.remove());
    d.addEventListener('cancel', (e) => { if (d.dataset.busy === '1') e.preventDefault(); });
    d.showModal();
    return d;
  }
  function tabs(d) {
    d.querySelectorAll('.lg-tabs [data-t]').forEach((b) => b.addEventListener('click', () => showDlgTab(d, b.dataset.t)));
  }
  function showDlgTab(d, t) {
    d.querySelectorAll('.lg-tabs [data-t]').forEach((b) => b.setAttribute('aria-selected', String(b.dataset.t === t)));
    d.querySelectorAll('[data-p]').forEach((p) => { p.hidden = p.dataset.p !== t; });
    const h = d.querySelector('[data-p="' + t + '"][data-help]');
    if (h) loadHelp(h, h.dataset.help);
  }
  // Onglet HELP des fenêtres du carnet : la section du manuel (/aide.html) dont l'identifiant est donné, jusqu'au titre
  // suivant de même niveau (ou plus haut)
  const helpTab = (id) => '<div data-p="help" class="lg-pp lg-nethelp" data-help="' + id + '" hidden><p>Chargement de l’aide…</p></div>';
  function loadHelp(el, id) {
    if (el.dataset.ok) return;
    el.dataset.ok = '1';
    fetch('/aide.html', { cache: 'no-cache' }).then((r) => r.text()).then((html) => {
      const doc = new DOMParser().parseFromString(html, 'text/html');
      const h = doc.getElementById(id);
      if (!h) throw new Error('section absente');
      const lvl = Number(h.tagName.slice(1)) || 3;
      const out = document.createElement('div');
      for (let n = h; n; n = n.nextElementSibling) {
        if (n !== h && /^H[1-6]$/.test(n.tagName) && Number(n.tagName.slice(1)) <= lvl) break;
        out.appendChild(document.importNode(n, true));
      }
      out.querySelectorAll('script, iframe, object').forEach((x) => x.remove());
      el.textContent = '';
      el.appendChild(out);
      const a = document.createElement('p');
      a.innerHTML = '<a href="/aide#' + id + '" target="_blank" rel="noopener">Ouvrir le manuel complet à cette section ↗</a>';
      el.appendChild(a);
    }).catch(() => { el.dataset.ok = ''; el.innerHTML = '<p>Aide indisponible : <a href="/aide#' + id + '" target="_blank" rel="noopener">ouvrir le manuel</a>.</p>'; });
  }
  // Export : administrateurs = tous les TX call du carnet ; membres = leur indicatif et leurs QSO sous les indicatifs du club
  let txcalls = [];
  let engine = ''; // stockage du carnet sur le serveur : sqlite ou json
  let stCalls = [];
  function exportOptions() {
    const mine = String(me.call || '').toUpperCase();
    if (me.admin) {
      const l = Array.from(new Set([mine].concat(stCalls, txcalls).filter(Boolean)));
      return '<option value="">Tous les TX call</option>' + l.map((c) => '<option value="' + esc(c) + '"' + (c === mine ? ' selected' : '') + '>' + esc(c) + '</option>').join('') +
        stCalls.map((c) => '<option value="' + esc(c) + '|mine">' + esc(c) + ' — mes QSO</option>').join('');
    }
    return '<option value="' + esc(mine) + '">' + esc(mine) + ' (mon indicatif)</option>' +
      stCalls.map((c) => '<option value="' + esc(c) + '|mine">' + esc(c) + ' — mes QSO sous cet indicatif</option>').join('');
  }
  const callOptions = (all) => (all ? '<option value="">' + esc(all) + '</option>' : '') + calls.map((c) => '<option>' + esc(c) + '</option>').join('');
  // Indicatif personnel du membre (s'il peut émettre sous son propre indicatif) : le seul qu'il synchronise lui-même
  function myLogCall() {
    const c = String(me.call || '').toUpperCase();
    return c && !me.rxOnly && calls.indexOf(c) >= 0 && stCalls.indexOf(c) < 0 ? c : '';
  }

  // ---------- Synchronisation (Télécharger vers …)
  const STEPS = [['export', 'Exporter les QSOs'], ['sign', 'Signer les QSOs (TQSL)'], ['upload', 'Téléchargement vers LoTW'], ['fetch', 'Obtenir les confirmations LoTW'],
    ['import', 'Importer les confirmations'], ['status', 'Statut d’actualisation']];
  function openSync(s) {
    const own = myLogCall();
    if (!me.admin && !own) return say('Synchronisation : réservée aux administrateurs et aux membres qui émettent sous leur propre indicatif.', 'warn');
    if (sdlg && sdlg.el.open) sdlg.el.close();
    const lotw = s === 'lotw';
    const title = lotw ? 'Opérations LoTW' : 'Télécharger vers ' + NAMES[s];
    const d = mkDlg('lg-sync', '<form method="dialog">' +
      '<h3>' + title + '</h3>' +
      '<div class="lg-tabs" role="tablist"><button type="button" data-t="det" aria-selected="true">Détails</button><button type="button" data-t="proc" aria-selected="false">Traitement</button><button type="button" data-t="help" aria-selected="false">HELP</button></div>' +
      helpTab('help-' + s) +
      '<div data-p="det" class="lg-pp">' +
      (me.admin ? '<label>Indicatif (TX call) <select name="callsign">' + callOptions('Tous les indicatifs') + '</select></label>'
        : '<label>Indicatif (TX call) <select name="callsign"><option>' + esc(own) + '</option></select></label>' +
          '<p class="lg-note">Vos QSO faits sous <b>' + esc(own) + '</b> partent vers <b>vos</b> comptes, avec <b>vos</b> identifiants (gardés sur le serveur, jamais affichés). Les QSO sous ON5VL / OR0L restent gérés par les administrateurs.</p>') +
      // Identifiants du service pour l'indicatif choisi : à vérifier avant chaque synchronisation (un compte par indicatif)
      '<fieldset class="lg-acct"><legend>Identifiants ' + NAMES[s] + ' de <b data-acall>—</b></legend><div class="lg-acf"></div><p class="lg-anote"></p>' +
      '<div class="lg-btns"><button type="button" class="btn" data-a="acct">Enregistrer pour cet indicatif</button></div></fieldset>' +
      '<fieldset><legend>Plage de dates (facultatif)</legend><label>Du <input type="date" name="from"></label><label>Au <input type="date" name="to"></label></fieldset>' +
      '<label class="lg-chk"><input type="checkbox" name="all"> Renvoyer aussi les QSO déjà envoyés</label>' +
      (s === 'clublog' && me.admin ? '<label class="lg-chk warn"><input type="checkbox" name="clear"> Effacer le log ClubLog existant (remplacé par tout le carnet de l’indicatif)</label>' : '') +
      (lotw || s === 'clublog' ? '' : '<label class="lg-w8">Temporisation (secondes) <input type="number" name="delay" min="0" max="120" step="1"><small>Pause entre deux QSO ; 1 s suffit.</small></label>') +
      '<p class="lg-pend">…</p>' +
      // Agent LoTW : TQSL du PC du membre (certificat jamais copié), relié au serveur
      (lotw ? '<fieldset class="lg-agent"><legend>Agent LoTW — TQSL de votre PC</legend><p class="lg-agst">…</p><div class="lg-agl"></div>' +
        '<div class="lg-btns"><button class="btn" type="button" data-a="agpair">Appairer un PC…</button></div><div class="lg-agcode" hidden></div></fieldset>' : '') +
      (lotw ? '<div class="lg-alt"><p><b>Sans Agent LoTW</b> (serveur sans TQSL, comme le VPS) : exportez les QSO non envoyés, signez-les avec TQSL sur votre PC, puis notez-les comme envoyés.</p>' +
        '<div class="lg-btns"><button class="btn" type="button" data-a="exp">Exporter pour TQSL (.adi)</button><button class="btn" type="button" data-a="mark" disabled>Marquer comme envoyés</button></div></div>' : '') +
      '</div>' +
      '<div data-p="proc" class="lg-pp" hidden>' +
      (lotw ? '<ol class="lg-steps">' + STEPS.map(([id, t]) => '<li data-s="' + id + '">' + t + '</li>').join('') + '</ol>' : '') +
      '<div class="lg-prog"><div></div></div><p class="lg-cnt"></p><pre class="lg-log"></pre>' +
      '</div>' +
      '<div class="md-act">' + (lotw ? '<button class="btn" type="button" data-a="confirm" title="Lire seulement les confirmations reçues sur LoTW">Confirmations</button>' : '') +
      '<span></span><button class="btn" type="button" data-a="stop" disabled>Arrêt</button><button class="btn" value="cancel" data-a="close">Fermer</button>' +
      '<button class="btn btn-primary" type="button" data-a="go">' + (lotw ? 'Synchronisation LoTW' : 'Télécharger') + '</button></div></form>');
    sdlg = { service: s, el: d, job: null };
    tabs(d);
    const f = d.querySelector('form');
    // Indicatif proposé : le TX call actuel (ou le premier de la liste), pour voir tout de suite ses identifiants
    const stx = api && api.state && api.state();
    const cur = !me.admin ? own : stx && stx.txCall && calls.indexOf(stx.txCall) >= 0 ? stx.txCall : calls[0];
    if (cur) f.callsign.value = cur;
    const acctAsk = () => {
      const c = f.callsign.value;
      d.querySelector('[data-acall]').textContent = c || '—';
      const box = d.querySelector('.lg-acf');
      d.querySelector('[data-a="acct"]').hidden = !c;
      if (!c) { box.innerHTML = ''; d.querySelector('.lg-anote').textContent = 'Choisissez un indicatif pour voir et régler ses identifiants : chaque indicatif est envoyé avec les siens.'; return; }
      box.innerHTML = '<p class="lg-anote">Chargement…</p>';
      api.send({ t: 'log_acct_get', service: s, call: c });
    };
    f.callsign.addEventListener('change', acctAsk);
    acctAsk();
    d.querySelector('[data-a="acct"]').addEventListener('click', () => {
      const c = f.callsign.value;
      if (!c) return;
      const fields = {};
      d.querySelectorAll('.lg-acf [data-af]').forEach((i) => { fields[i.dataset.af] = i.dataset.clear === '1' && !i.value.trim() ? '__effacer__' : i.value.trim(); });
      const au = d.querySelector('.lg-acf [data-aauto]');
      api.send(Object.assign({ t: 'log_acct_set', service: s, call: c, fields }, au ? { auto: au.checked } : {}));
    });
    const filt = () => ({ callsign: f.callsign.value, from: f.from.value, to: f.to.value, all: f.all.checked || !!(f.clear && f.clear.checked) });
    const askPending = () => api.send(Object.assign({ t: 'log_pending', service: s }, filt()));
    for (const n of ['callsign', 'from', 'to', 'all', 'clear']) if (f[n]) f[n].addEventListener('change', askPending);
    askPending();
    api.send({ t: 'log_cfg_get', quiet: true });
    if (f.clear) f.clear.addEventListener('change', () => {
      if (f.clear.checked && !window.confirm('Club Log : le log existant de l’indicatif sera EFFACÉ puis remplacé par tous les QSO de ce carnet.\nÀ n’utiliser que si ce carnet est complet. Continuer ?')) f.clear.checked = false;
      askPending();
    });
    const go = (action) => {
      sdlg.job = 'wait';
      showDlgTab(d, 'proc');
      d.querySelector('.lg-log').textContent = '';
      d.querySelectorAll('.lg-steps li').forEach((li) => { li.className = ''; });
      d.querySelector('.lg-prog > div').style.width = '0%';
      busy(true);
      const m = Object.assign({ t: 'log_sync', service: s, action }, filt());
      if (f.clear) m.clear = f.clear.checked;
      if (f.delay && f.delay.value !== '') m.delay = Number(f.delay.value);
      api.send(m);
    };
    d.querySelector('[data-a="go"]').addEventListener('click', () => go('send'));
    if (lotw) d.querySelector('[data-a="confirm"]').addEventListener('click', () => go('confirm'));
    d.querySelector('[data-a="stop"]').addEventListener('click', () => { api.send({ t: 'log_sync', service: s, action: 'stop' }); syncLog('Arrêt demandé…'); });
    if (lotw) {
      agents = null;
      api.send({ t: 'log_agents' });
      f.callsign.addEventListener('change', agentsDraw);
      d.querySelector('[data-a="agpair"]').addEventListener('click', () => api.send({ t: 'log_agent_code' }));
      d.querySelector('.lg-agl').addEventListener('click', (e) => {
        const b = e.target.closest('[data-agdel]');
        if (!b || !agents) return;
        const a = agents.find((x) => x.id === b.dataset.agdel);
        if (a && window.confirm('Retirer l’Agent LoTW du PC « ' + a.name + ' » (' + a.owner + ') ?\nCe PC ne pourra plus signer de QSO tant qu’il n’est pas appairé à nouveau.')) api.send({ t: 'log_agent_del', id: a.id });
      });
      d.querySelector('[data-a="exp"]').addEventListener('click', () => api.send(Object.assign({ t: 'log_export', fmt: 'adif', pending: 'lotw' }, filt())));
      d.querySelector('[data-a="mark"]').addEventListener('click', () => {
        if (!lastExport || !lastExport.ids.length) return;
        if (!window.confirm(lastExport.ids.length + ' QSO notés comme envoyés à LoTW (après leur signature avec TQSL) ?')) return;
        api.send({ t: 'log_mark', service: 'lotw', ids: lastExport.ids });
        lastExport = null;
        d.querySelector('[data-a="mark"]').disabled = true;
        askPending();
      });
    }
  }
  // ---------- Agent LoTW
  let agents = null;
  let agentIds = null; // agents connus quand un code d'appairage est affiché
  const hhmm = (t) => { const x = new Date(t); return String(x.getDate()).padStart(2, '0') + '/' + String(x.getMonth() + 1).padStart(2, '0') + ' ' + String(x.getHours()).padStart(2, '0') + ':' + String(x.getMinutes()).padStart(2, '0'); };
  function agentsDraw() {
    if (!sdlg || !sdlg.el.open || sdlg.service !== 'lotw') return;
    const d = sdlg.el;
    const call = d.querySelector('form').callsign.value;
    const list = agents || [];
    const on = list.filter((a) => a.on && (!call || a.calls.indexOf(call) >= 0));
    const st = d.querySelector('.lg-agst');
    if (agents == null) st.textContent = '…';
    else if (on.length) {
      const a = on.find((x) => x.locations.some((l) => l.call === call)) || on[0];
      st.textContent = '✓ ' + (call ? 'QSO de ' + call : 'QSO') + ' signés par l’Agent LoTW du PC « ' + a.name + ' » : SYNCHRONISATION LOTW les signe et les envoie directement, sans export à la main.';
    } else st.textContent = 'Aucun Agent LoTW connecté' + (call ? ' pour ' + call : '') + '. Installez-le sur le PC où TQSL et votre certificat sont installés (bouton « Appairer un PC… »), ou utilisez la procédure manuelle ci-dessous.';
    st.className = 'lg-agst' + (on.length ? ' ok' : '');
    d.querySelector('.lg-agl').innerHTML = list.map((a) => '<div class="lg-ag' + (a.on ? ' on' : '') + '"><span>' + (a.on ? '●' : '○') + ' <b>' + esc(a.name) + '</b>' + (me.admin ? ' (' + esc(a.owner) + ')' : '') +
      (a.on ? ' — connecté depuis ' + hhmm(a.since) + (a.tqsl === false ? ' · <em>TQSL introuvable sur ce PC</em>' : '') + (a.old ? ' · mise à jour de l’agent en cours' : '') : ' — déconnecté' + (a.seen ? ' (vu le ' + hhmm(a.seen) + ')' : ' (jamais connecté)')) +
      (a.locations.length ? '<br><small>Lieux de station TQSL : ' + a.locations.map((l) => esc(l.name) + ' (' + esc(l.call || '?') + ')' + (l.ok ? '' : ' — indicatif non permis')).join(', ') + '</small>' : '') +
      '</span><button type="button" class="btn lg-agx" data-agdel="' + esc(a.id) + '" title="Retirer ce PC">Retirer</button></div>').join('');
  }
  function agentCode(m) {
    if (!sdlg || !sdlg.el.open || sdlg.service !== 'lotw') return;
    const box = sdlg.el.querySelector('.lg-agcode');
    const o = location.origin;
    const v = esc(m.version || '');
    const cmd = (t) => '<code class="lg-cmd" title="Cliquer pour copier">' + esc(t) + '</code>';
    box.innerHTML = '<p>Code d’appairage : <b class="lg-agc">' + esc(m.code) + '</b> — valable 15 minutes, une seule fois (jusqu’à ' + hhmm(m.exp) + ').</p>' +
      '<p><b>Windows</b> : installateur <a href="https://github.com/on6dp/remote-station/raw/main/releases/' + v + '/RemoteStation-Setup-' + v + '.exe" target="_blank" rel="noopener">RemoteStation-Setup-' + v + '.exe</a>, cochez seulement « Agent LoTW (TQSL de ce PC) », puis donnez l’adresse ' + esc(o) + ' et ce code. ' +
      'Déjà installé : menu Démarrer → Remote Station → « Appairer l’Agent LoTW ».</p>' +
      '<p><b>Linux</b> (Debian, Ubuntu, Raspberry Pi) : ' + cmd('curl -fsSL ' + o + '/agent/install-agent-lotw.sh | sudo bash -s -- --serveur ' + o + ' --code ' + m.code) + '</p>' +
      '<p><b>Autre</b> (macOS…, Node.js 22 ou plus) : <a href="' + esc(o) + '/agent/agent-lotw.js" target="_blank" rel="noopener">agent-lotw.js</a> puis ' + cmd('node agent-lotw.js --serveur ' + o + ' --appairer ' + m.code) + ' et ' + cmd('node agent-lotw.js') + '</p>';
    box.hidden = false;
    agentIds = (agents || []).map((a) => a.id);
    box.onclick = (e) => {
      const c = e.target.closest('.lg-cmd');
      if (c && navigator.clipboard) navigator.clipboard.writeText(c.textContent).then(() => say('Commande copiée.', 'info'), () => {});
    };
  }
  function busy(on) {
    if (!sdlg) return;
    const d = sdlg.el;
    d.dataset.busy = on ? '1' : '';
    d.querySelector('[data-a="stop"]').disabled = !on;
    d.querySelector('[data-a="go"]').disabled = on;
    d.querySelector('[data-a="close"]').disabled = on;
    const c = d.querySelector('[data-a="confirm"]');
    if (c) c.disabled = on;
  }
  function syncLog(line) {
    if (!sdlg || !line) return;
    const pre = sdlg.el.querySelector('.lg-log');
    pre.textContent += line + '\n';
    pre.scrollTop = pre.scrollHeight;
  }
  function onJob(m) {
    const j = m.job || {};
    // Envois automatiques : dernière ligne sous la liste
    if (j.auto) {
      const el = q$('#lgJob');
      if (el && m.line && !/QSO à envoyer$/.test(m.line)) { el.textContent = NAMES[j.service] + ' · ' + m.line; el.classList.toggle('err', /^✗|arrêtés/.test(m.line)); }
    }
    if (!sdlg || !sdlg.el.open || sdlg.service !== j.service || j.auto || !sdlg.job) return;
    if (sdlg.job === 'wait') sdlg.job = j.id;
    if (sdlg.job !== j.id) return;
    const d = sdlg.el;
    syncLog(m.line);
    if (m.step) {
      const li = d.querySelector('.lg-steps li[data-s="' + m.step.id + '"]');
      if (li) li.className = m.step.state;
    }
    if (j.total) {
      d.querySelector('.lg-prog > div').style.width = Math.round(100 * j.done / j.total) + '%';
      d.querySelector('.lg-cnt').textContent = j.done + ' / ' + j.total + ' · ' + j.ok + ' envoyé(s) · ' + j.fail + ' en échec';
    }
    if (m.fin) {
      busy(false);
      sdlg.job = null;
      api.send({ t: 'log_pending', service: sdlg.service });
    }
  }

  // ---------- Export ADIF / Cabrillo
  function openExport(fmt) {
    const d = mkDlg('lg-exp', '<form method="dialog"><h3>Exporter le carnet</h3><div class="lg-pp">' +
      '<label>Format <select name="fmt"><option value="adif">ADIF 3 (.adi) — logbooks, LoTW, eQSL, Club Log…</option><option value="cabrillo">Cabrillo 3 (.log) — concours</option></select></label>' +
      '<label>TX call <select name="callsign">' + exportOptions() + '</select></label>' +
      '<fieldset><legend>Plage de dates (facultatif)</legend><label>Du <input type="date" name="from"></label><label>Au <input type="date" name="to"></label></fieldset>' +
      '<label data-cab>Concours (CONTEST) <input name="contest" list="lgContests" placeholder="DX" maxlength="40"></label>' +
      '<datalist id="lgContests">' + CONTESTS.map((c) => '<option value="' + c + '">').join('') + '</datalist>' +
      '<p class="lg-note" data-cab>Cabrillo : un seul indicatif par fichier ; l’échange envoyé / reçu vient des champs « numéro » ou du locator (4 caractères).</p>' +
      '</div><div class="md-act"><span></span><button class="btn" value="cancel">Annuler</button><button class="btn btn-primary" type="button" data-a="go">Exporter</button></div></form>');
    const f = d.querySelector('form');
    f.fmt.value = fmt;
    const upd = () => {
      d.querySelectorAll('[data-cab]').forEach((x) => { x.hidden = f.fmt.value !== 'cabrillo'; });
      if (f.fmt.value === 'cabrillo' && !f.callsign.value && calls[0]) f.callsign.value = calls[0];
    };
    f.fmt.addEventListener('change', upd);
    upd();
    d.querySelector('[data-a="go"]').addEventListener('click', () => {
      const [cs, mine] = String(f.callsign.value).split('|');
      api.send({ t: 'log_export', fmt: f.fmt.value, callsign: cs, mine: mine === 'mine', from: f.from.value, to: f.to.value, contest: f.contest.value.trim() });
      d.close();
    });
  }
  function download(m) {
    const blob = new Blob([m.data], { type: (m.mime || 'text/plain') + ';charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = m.name;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
    say(m.count + ' QSO exportés dans ' + m.name, '');
    if (m.pending === 'lotw') {
      lastExport = { ids: m.ids || [] };
      if (sdlg && sdlg.service === 'lotw' && sdlg.el.open) sdlg.el.querySelector('[data-a="mark"]').disabled = !lastExport.ids.length;
    }
  }

  // ---------- Configuration
  const SECRET_PH = '•••••• enregistré — vide = inchangé';
  function secretField(label, svc, key, cfg, hint) {
    const has = cfg[svc] && cfg[svc]['has_' + key];
    return '<label>' + label + '<span class="lg-pw"><input type="password" name="' + svc + '.' + key + '" autocomplete="new-password" placeholder="' + (has ? SECRET_PH : '') + '">' +
      '<button type="button" class="lg-eye" title="Afficher / masquer" aria-label="Afficher le mot de passe">👁</button>' +
      (has ? '<button type="button" class="lg-clr" data-clr="' + svc + '.' + key + '" title="Effacer la valeur enregistrée">✕</button>' : '') + '</span>' +
      (hint ? '<small>' + hint + '</small>' : '') + '</label>';
  }
  const textField = (label, name, v, hint, extra) => '<label>' + label + '<input name="' + name + '" value="' + esc(v) + '" ' + (extra || '') + '>' + (hint ? '<small>' + hint + '</small>' : '') + '</label>';
  // Onglets de ⚙ Configuration : indicatifs du club seulement (les membres règlent le leur dans la fenêtre du service)
  const CLUBNOTE = '<p class="lg-note">Réglages <b>communs aux indicatifs du club</b> (ON5VL, OR0L) — jamais utilisés pour un indicatif personnel. Un indicatif du club qui a <b>son propre compte</b> (eQSL, QRZ.com, Club Log…) : Synchronisation ▾ → le service → choisir l’indicatif → cadre jaune → ses identifiants et son envoi automatique, qui remplacent ceux d’ici pour lui seul. Un indicatif personnel se règle au même endroit, par son titulaire.</p>';
  const common = (s, c, noDelay) => CLUBNOTE + '<label class="lg-chk"><input type="checkbox" name="' + s + '.auto"' + (c.auto ? ' checked' : '') + '> Télécharger automatiquement les QSO lors de leur enregistrement</label>' +
    (noDelay ? '' : '<label class="lg-w8">Temporisation (secondes) <input type="number" min="0" max="120" name="' + s + '.delay" value="' + esc(c.delay) + '"><small>Pause entre deux QSO lors d’un envoi en lot (1 s suffit).</small></label>');
  function udpRow(u) {
    const fmts = [['wsjtx-adif', 'WSJT-X « Logged ADIF » (type 12)'], ['wsjtx-qso', 'WSJT-X « QSO Logged » (type 5)'], ['n1mm', 'N1MM Logger+ (XML contactinfo)'], ['adif', 'ADIF brut']];
    return '<tr><td><input type="checkbox" data-k="enabled"' + (u.enabled ? ' checked' : '') + ' aria-label="Actif"></td>' +
      '<td><input data-k="label" value="' + esc(u.label || '') + '" placeholder="Swisslog" maxlength="40"></td>' +
      '<td><input data-k="host" value="' + esc(u.host || '') + '" placeholder="127.0.0.1" maxlength="100"></td>' +
      '<td><input data-k="port" type="number" min="1" max="65535" value="' + esc(u.port || '') + '" placeholder="2237"></td>' +
      '<td><select data-k="format">' + fmts.map(([v, t]) => '<option value="' + v + '"' + (u.format === v ? ' selected' : '') + '>' + t + '</option>').join('') + '</select></td>' +
      '<td><button type="button" class="lg-clr" data-a="rm" title="Retirer">✕</button></td></tr>';
  }
  function qrzRow(call, has) {
    return '<tr><td><input data-k="call" value="' + esc(call) + '" placeholder="ON5VL" maxlength="15"></td>' +
      '<td><span class="lg-pw"><input type="password" data-k="key" autocomplete="new-password" placeholder="' + (has ? SECRET_PH : 'XXXX-XXXX-XXXX-XXXX') + '">' +
      '<button type="button" class="lg-eye" title="Afficher / masquer">👁</button></span></td>' +
      '<td><button type="button" class="lg-clr" data-a="rmq" title="Retirer cette clé">✕</button></td></tr>';
  }
  function openCfg() {
    if (!me.admin) return say('Configuration des carnets en ligne : réservée aux administrateurs.', 'warn');
    cdlg = { el: null };
    api.send({ t: 'log_cfg_get' });
  }
  function drawCfg(cfg, saved) {
    if (cdlg && cdlg.el && cdlg.el.open) {
      if (saved) { cdlg.el.close(); say('Réglages des carnets en ligne enregistrés.', ''); }
      return;
    }
    const keys = Object.assign({}, cfg.qrz.has_keys || {});
    for (const c of calls) if (!(c in keys)) keys[c] = false;
    const d = mkDlg('lg-cfg', '<form method="dialog" autocomplete="off"><h3>Configuration de carnets de trafic en ligne</h3>' +
      '<div class="lg-tabs" role="tablist">' + [['clublog', 'CLUBLOG'], ['eqsl', 'eQSL'], ['lotw', 'LoTW'], ['qrz', 'QRZ'], ['udp', 'UDP'], ['help', 'HELP']].map(([k, t], i) =>
        '<button type="button" data-t="' + k + '" aria-selected="' + (i === 0) + '">' + t + '</button>').join('') + '</div>' +
      helpTab('l-config') +
      // Club Log
      '<div data-p="clublog" class="lg-pp">' + common('clublog', cfg.clublog, true) +
      textField('Adresse e-mail', 'clublog.email', cfg.clublog.email, '', 'type="email" maxlength="200"') +
      secretField('Mot de passe', 'clublog', 'password', cfg, 'Un <b>mot de passe d’application</b> (Club Log → Settings → App Passwords) est conseillé.') +
      secretField('Jeton Club Log (cl_…) ou clé API', 'clublog', 'api', cfg, '<b>Conseillé : un jeton</b> (Club Log → Settings → API → Tokens → Create token), qui commence par <b>cl_</b>. Avec un jeton, l’e-mail et le mot de passe ne servent plus, et il ne vaut que pour les indicatifs <b>de ce compte</b> Club Log (jamais prêté aux indicatifs des membres). Ancienne méthode : clé API du logiciel demandée à support@clublog.org, avec e-mail et mot de passe d’application.') +
      '<p class="lg-note">Club Log reçoit les QSO par lots (jeton : 100 QSO par requête), pas de temporisation. Un refus d’accès (erreur 401/403) arrête les envois jusqu’au prochain « OK » de cette fenêtre ; après plusieurs refus, Club Log bloque l’adresse du serveur une heure.</p>' + testRow('clublog') + '</div>' +
      // eQSL
      '<div data-p="eqsl" class="lg-pp" hidden>' + common('eqsl', cfg.eqsl) +
      textField('Indicatif (identifiant eQSL)', 'eqsl.user', cfg.eqsl.user, '', 'maxlength="20" style="text-transform:uppercase"') +
      secretField('Mot de passe', 'eqsl', 'password', cfg) +
      textField('QTH Nickname (facultatif)', 'eqsl.nickname', cfg.eqsl.nickname, 'Si le compte eQSL a plusieurs QTH : le surnom exact du QTH du club.', 'maxlength="60"') +
      testRow('eqsl') + '</div>' +
      // LoTW
      '<div data-p="lotw" class="lg-pp" hidden>' + common('lotw', cfg.lotw, true) +
      (cfg.lotw.tqslHere
        ? textField('Programme TQSL', 'lotw.tqsl', cfg.lotw.tqsl, 'Sur le PC où le <b>certificat LoTW</b> est installé (serveur Windows du club). Le certificat et son mot de passe ne quittent jamais ce PC.', 'maxlength="300"') +
          textField('Dossier TrustedQSL (facultatif)', 'lotw.tqslDir', cfg.lotw.tqslDir, 'Serveur Windows en service : dossier du compte où le certificat est importé, ex. C:\\Users\\Club\\AppData\\Roaming\\TrustedQSL.', 'maxlength="300"')
        : '<p class="lg-note">Ce serveur n’a pas TQSL (VPS) : la signature se fait sur le PC où TQSL et le certificat sont installés, par l’<b>Agent LoTW</b> (Synchronisation LoTW → cadre Agent LoTW), ou par l’export à la main.</p>') +
      textField('Lieu de station TQSL (Station Location)', 'lotw.location', cfg.lotw.location, 'Nom exact du lieu créé dans TQSL (ex. ON5VL Liège). Facultatif avec l’Agent LoTW si le PC n’a qu’un lieu pour l’indicatif.', 'maxlength="100"') +
      (cfg.lotw.tqslHere ? secretField('Mot de passe du certificat (si protégé)', 'lotw', 'password', cfg) : '') +
      textField('Identifiant du site LoTW', 'lotw.login', cfg.lotw.login, 'Pour lire les confirmations (lotwreport.adi).', 'maxlength="40"') +
      secretField('Mot de passe du site LoTW', 'lotw', 'webPassword', cfg) +
      '<p class="lg-note">Confirmations lues jusqu’au : <b>' + esc(cfg.lotw.lastConfirm || 'jamais') + '</b>.</p>' +
      testRow('lotw') + '</div>' +
      // QRZ
      '<div data-p="qrz" class="lg-pp" hidden>' + common('qrz', cfg.qrz) +
      '<p class="lg-note">Une clé API du carnet QRZ par indicatif de station (QRZ.com → Logbook → Settings → API Key ; abonnement XML ou supérieur).</p>' +
      '<table class="lg-grid" data-g="qrz"><thead><tr><th>Indicatif</th><th>Clé API</th><th></th></tr></thead><tbody>' +
      Object.entries(keys).map(([c, h]) => qrzRow(c, h)).join('') + '</tbody></table>' +
      '<div class="lg-btns"><button class="btn" type="button" data-a="addq">+ Ajouter un indicatif</button></div>' + testRow('qrz') +
      '<h4 class="lg-h4">Recherche des correspondants (nom, QTH, locator)</h4>' +
      '<p class="lg-note">Compte QRZ.com utilisé pour remplir tout seul le nom et le QTH du correspondant (ligne Correspondant, carnet). ' +
      'Sans abonnement XML, QRZ ne donne que le prénom, le nom, la ville et le pays ; avec, aussi le locator. Gardé sur le serveur, jamais renvoyé au navigateur.</p>' +
      textField('Identifiant QRZ.com', 'qrz.lookupUser', cfg.qrz.lookupUser, '', 'maxlength="40" autocomplete="off"') +
      secretField('Mot de passe QRZ.com', 'qrz', 'lookupPassword', cfg) +
      testRow('qrzxml') + '</div>' +
      // UDP
      '<div data-p="udp" class="lg-pp" hidden>' +
      '<p class="lg-note">Chaque QSO enregistré est aussi envoyé en UDP aux logbooks du PC (Swisslog, HRD Logbook, Log4OM, N1MM Logger+, DXKeeper…). ' +
      'Les paquets partent du <b>serveur</b> : avec le serveur Windows sur le PC du club, adresse 127.0.0.1 ; depuis le VPS, il faut une adresse joignable depuis internet (redirection de port).</p>' +
      '<table class="lg-grid" data-g="udp"><thead><tr><th>Actif</th><th>Nom</th><th>Adresse</th><th>Port</th><th>Format</th><th></th></tr></thead><tbody>' +
      (cfg.udp || []).map(udpRow).join('') + '</tbody></table>' +
      '<div class="lg-btns"><button class="btn" type="button" data-u="wsjtx">+ WSJT-X (port 2237)</button><button class="btn" type="button" data-u="n1mm">+ N1MM Logger+ (port 12060)</button>' +
      '<button class="btn" type="button" data-u="adif">+ ADIF brut</button></div>' +
      '<p class="lg-note">Ports habituels, à vérifier dans les réglages du logbook. Swisslog, Log4OM et HRD Logbook acceptent le format WSJT-X.</p></div>' +
      '<div class="md-act"><span></span><button class="btn" value="cancel">Annuler</button><button class="btn btn-primary" type="button" data-a="ok">OK</button></div></form>');
    cdlg = { el: d };
    d.addEventListener('close', () => { if (cdlg && cdlg.el === d) cdlg = null; });
    tabs(d);
    const f = d.querySelector('form');
    d.addEventListener('click', (e) => {
      const b = e.target.closest('button');
      if (!b) return;
      if (b.classList.contains('lg-eye')) {
        const i = b.parentElement.querySelector('input');
        i.type = i.type === 'password' ? 'text' : 'password';
      } else if (b.dataset.clr) {
        const i = f.elements[b.dataset.clr];
        i.value = '';
        i.dataset.clear = '1';
        i.placeholder = 'sera effacé à l’enregistrement';
        b.remove();
      } else if (b.dataset.a === 'rm' || b.dataset.a === 'rmq') {
        const tr = b.closest('tr');
        if (b.dataset.a === 'rmq') { const c = tr.querySelector('[data-k="call"]').value.trim().toUpperCase(); if (c) (f._delq = f._delq || []).push(c); }
        tr.remove();
      } else if (b.dataset.a === 'addq') {
        d.querySelector('[data-g="qrz"] tbody').insertAdjacentHTML('beforeend', qrzRow('', false));
      } else if (b.dataset.u) {
        const p = { wsjtx: { label: 'Swisslog', port: 2237, format: 'wsjtx-adif' }, n1mm: { label: 'N1MM', port: 12060, format: 'n1mm' }, adif: { label: '', port: '', format: 'adif' } }[b.dataset.u];
        d.querySelector('[data-g="udp"] tbody').insertAdjacentHTML('beforeend', udpRow(Object.assign({ enabled: true, host: '127.0.0.1' }, p)));
      } else if (b.dataset.test) {
        const out = d.querySelector('[data-tr="' + b.dataset.test + '"]');
        out.textContent = 'Enregistrez d’abord (OK) les réglages modifiés · test en cours…';
        out.className = 'lg-tres';
        api.send(b.dataset.test === 'qrzxml' ? { t: 'qrz_test' } : { t: 'log_test', service: b.dataset.test });
      } else if (b.dataset.a === 'ok') {
        api.send({ t: 'log_cfg_set', cfg: readCfg(f) });
      }
    });
  }
  const testRow = (s) => '<div class="lg-btns"><button class="btn" type="button" data-test="' + s + '">Tester</button><span class="lg-tres" data-tr="' + s + '"></span></div>';
  function readCfg(f) {
    const v = (n) => { const i = f.elements[n]; if (!i) return undefined; if (i.type === 'checkbox') return i.checked; if (i.dataset.clear === '1' && !i.value) return '__effacer__'; return i.value.trim(); };
    const out = {};
    const fields = { clublog: ['auto', 'delay', 'email', 'password', 'api'], eqsl: ['auto', 'delay', 'user', 'password', 'nickname'], qrz: ['auto', 'delay', 'lookupUser', 'lookupPassword'],
      lotw: ['auto', 'delay', 'tqsl', 'tqslDir', 'location', 'password', 'login', 'webPassword'] };
    for (const [s, ks] of Object.entries(fields)) { out[s] = {}; for (const k of ks) { const x = v(s + '.' + k); if (x !== undefined) out[s][k] = x; } }
    if (out.eqsl.user) out.eqsl.user = out.eqsl.user.toUpperCase();
    out.qrz.keys = {};
    for (const c of f._delq || []) out.qrz.keys[c] = '__effacer__';
    f.querySelectorAll('[data-g="qrz"] tbody tr').forEach((tr) => {
      const c = tr.querySelector('[data-k="call"]').value.trim().toUpperCase();
      const k = tr.querySelector('[data-k="key"]').value.trim();
      if (c && k) out.qrz.keys[c] = k;
    });
    out.udp = [];
    f.querySelectorAll('[data-g="udp"] tbody tr').forEach((tr) => {
      const g = (k) => tr.querySelector('[data-k="' + k + '"]');
      out.udp.push({ enabled: g('enabled').checked, label: g('label').value.trim(), host: g('host').value.trim(), port: Number(g('port').value), format: g('format').value });
    });
    return out;
  }

  // ------------------------------------------------------------------ statistiques DXCC (carnet en grand), façon Swisslog
  // Pour un TX call : chaque pays DXCC × bande ; lettres C (CW), P (phonie), D (numérique), en or si confirmé
  // (LoTW ou QSL papier), en vert si seulement contacté. Clic sur une case : le carnet filtré sur ce pays et cette bande.
  const ST = { on: false, data: null, sort: 'pfx', q: '' };
  const ST_GRP = { C: 'CW', P: 'Phonie', D: 'Numérique' };
  function statsSetup() {
    if (!root || q$('#lgStatBtn')) return;
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'btn lg-dbtn lg-statb';
    b.id = 'lgStatBtn';
    b.textContent = '📊 STATISTIQUES';
    b.title = 'Diplômes DXCC, WAZ, ITU, WAE, WAC, WAS, WPX, IOTA et locators : contactés et confirmés, par bande et par mode, pour un TX call (à la manière de Swisslog)';
    b.setAttribute('aria-pressed', 'false');
    const det = q$('#lgDetails');
    if (det) det.after(b); else q$('.lg-bar').prepend(b);
    // Retour au tableau des statistiques après un clic sur une de ses cases (carnet filtré sur ce pays / cette bande)
    const back = document.createElement('button');
    back.type = 'button';
    back.className = 'btn lg-dbtn lg-tostat';
    back.id = 'lgToStats';
    back.textContent = '↩ STATISTIQUES';
    back.title = 'Revenir au tableau des statistiques';
    back.hidden = true;
    b.after(back);
    // Fenêtre du carnet en grand : RETOUR = la fermer et revenir au dashboard
    const ret = document.createElement('button');
    ret.type = 'button';
    ret.className = 'btn lg-dbtn lg-ret';
    ret.textContent = 'RETOUR';
    ret.title = 'Fermer cette fenêtre et revenir au dashboard (le carnet reste dans le dashboard)';
    ret.addEventListener('click', () => { const w = root.ownerDocument.defaultView; try { if (w.opener && !w.opener.closed) w.opener.focus(); } catch (e) { /* */ } w.close(); });
    q$('.lg-bar').appendChild(ret);
    const box = document.createElement('div');
    box.className = 'lg-stw';
    box.id = 'lgStats';
    box.hidden = true;
    box.innerHTML = '<div class="lg-sth"><button type="button" class="btn lg-dbtn lg-stback" id="lgStBack" title="Revenir au carnet (Échap)">↩ CARNET</button>' +
      '<label class="lg-txf lg-staw">Diplôme <select id="lgStAw" aria-label="Diplôme" title="DXCC (pays), WAZ (zones CQ), ITU (zones UIT), WAE (pays d’Europe, entités WAE comprises), WAC (continents), WAS (États US, d’après le champ État du QSO), WPX (préfixes), IOTA (îles, d’après la référence IOTA du QSO), locators (carrés de 4 caractères)">' +
      [['DXCC', 'DXCC (pays)'], ['WAZ', 'WAZ (zones CQ)'], ['ITU', 'ITU (zones UIT)'], ['WAE', 'WAE (Europe)'], ['WAC', 'WAC (continents)'], ['WAS', 'WAS (États US)'], ['WPX', 'WPX (préfixes)'], ['IOTA', 'IOTA (îles)'], ['GRID', 'Locators (carrés)']].map((o) => '<option value="' + o[0] + '">' + o[1] + '</option>').join('') + '</select></label>' +
      '<label class="lg-txf">TX call <select id="lgStTx" aria-label="TX call des statistiques"></select></label>' +
      '<label class="lg-txf">Mode <select id="lgStMode" aria-label="Modes comptés"><option value="">Tous (colonnes par mode)</option><option value="C">CW</option><option value="P">Phonie</option><option value="D">Numérique</option></select></label>' +
      '<label class="lg-txf">Tri <select id="lgStSort" aria-label="Ordre des lignes"><option value="pfx">Référence</option><option value="name">Nom</option><option value="cont">Continent</option><option value="bands">Nombre de bandes</option></select></label>' +
      '<label class="lg-txf">Lignes <select id="lgStShow" aria-label="Lignes affichées"><option value="">Toutes</option><option value="w">Contactées</option><option value="nc">Pas encore confirmées</option><option value="n">Jamais contactées</option></select></label>' +
      '<input class="lg-search lg-stq" id="lgStQ" placeholder="Chercher (nom, référence)" aria-label="Chercher">' +
      '<span class="lg-stsum" id="lgStSum"></span>' +
      '<span class="lg-stleg"><i class="sc">C</i> confirmé (LoTW / QSL) · <i class="sw">W</i> contacté (worked) · <i class="sn">-</i> pas encore · clic sur une case : ces QSO dans le carnet</span></div>' +
      '<div class="lg-stt"><table class="lg-sttab"><thead id="lgStHead"></thead><tbody id="lgStBody"><tr><td class="lg-empty">Chargement…</td></tr></tbody></table></div>' +
      '<div class="lg-sts"><table class="lg-stsum2"><thead id="lgSsHead"></thead><tbody id="lgSsBody"></tbody></table></div>';
    q$('.lg-tw').after(box);
    const ask = (txc) => api && api.send({ t: 'log_stats', txc: txc != null ? txc : q$('#lgStTx').value, mode: q$('#lgStMode').value, award: q$('#lgStAw').value });
    try { const a = localStorage.getItem('rs.lgaward'); if (a && q$('#lgStAw').querySelector('option[value="' + a + '"]')) q$('#lgStAw').value = a; } catch (e) { /* */ }
    ST.ask = () => ask();
    q$('#lgStAw').addEventListener('change', () => { try { localStorage.setItem('rs.lgaward', q$('#lgStAw').value); } catch (e) { /* */ } ask(); });
    const show = (on) => {
      ST.on = on;
      b.setAttribute('aria-pressed', String(on));
      box.hidden = !on;
      root.classList.toggle('lg-ston', on); // barre : recherche et filtres du carnet masqués pendant les statistiques
      if (on && q$('#lgToStats')) q$('#lgToStats').hidden = true;
      q$('.lg-tw').hidden = on;
      q$('.lg-tw').style.display = on ? 'none' : '';
      headDraw();
      // 1re ouverture : TX call du filtre du carnet, sinon celui sous lequel on émet (OR0L…), sinon l'indicatif du club
      const stx = api && api.state && api.state();
      if (on) ask(ST.data ? null : filt.txc || (stx && stx.txCall) || stCalls[0] || '');
    };
    b.addEventListener('click', () => show(!ST.on));
    headDraw();
    setInterval(headDraw, 1000); // TX call en service ou filtre du carnet changés
    q$('#lgStBack').addEventListener('click', () => show(false));
    root.ownerDocument.addEventListener('keydown', (e) => { if (e.key === 'Escape' && ST.on && !root.ownerDocument.querySelector('dialog[open]')) show(false); });
    q$('#lgStTx').addEventListener('change', () => ask());
    q$('#lgStMode').addEventListener('change', () => ask());
    q$('#lgStSort').addEventListener('change', () => { ST.sort = q$('#lgStSort').value; statsDraw(); });
    q$('#lgStShow').addEventListener('change', () => statsDraw());
    q$('#lgStQ').addEventListener('input', () => { ST.q = q$('#lgStQ').value.trim().toUpperCase(); statsDraw(); });
    // Clic sur une case : retour au carnet, filtré sur ce TX call, ce pays (préfixe DXCC) et cette bande
    q$('#lgStBody').addEventListener('click', (e) => {
      const td = e.target.closest('td[data-b]');
      if (!td) return;
      const tr = td.closest('tr');
      filt = {};
      if (ST.data && ST.data.txc) filt.txc = ST.data.txc;
      if (!ST.data || !ST.data.award || ST.data.award === 'DXCC') filt.pfx = tr.dataset.pfx;
      else filt.aw = ST.data.award + ':' + tr.dataset.pfx; // zone, préfixe WPX, île IOTA… (filtre calculé par le serveur)
      if (td.dataset.b && td.dataset.b !== 'SAT') filt.band = td.dataset.b;
      const md = (ST.data && ST.data.mode) || (td.dataset.k && td.dataset.k !== 'AUT' ? td.dataset.k : '');
      if (md && !ST_GRP[md] && md !== 'SSB' && md !== 'AUT' && md !== 'DATA') filt.mode = md;
      show(false);
      back.hidden = false;
      reload();
    });
    back.addEventListener('click', () => { back.hidden = true; show(true); });
    q$('#lgFclr').addEventListener('click', () => { back.hidden = true; });
    // Hauteur : jusqu'en bas de la fenêtre (comme la liste du carnet)
    const fit = () => { const t = q$('.lg-stt'), sm = q$('.lg-sts'); if (!t || box.hidden) return; const h = Math.max(200, Math.floor(window.innerHeight - t.getBoundingClientRect().top - (sm ? sm.offsetHeight + 8 : 0) - 14)) + 'px'; t.style.height = h; t.style.maxHeight = h; };
    window.addEventListener('resize', fit);
    setInterval(fit, 1000);
    ST.fit = fit;
  }
  /** Bandeau de titre du carnet en grand (comme les pages TRX) : TX call, puis LOGBOOK ou LOGBOOK STATISTIQUES */
  function headDraw() {
    if (TAG !== 'big' || !root) return;
    const doc = root.ownerDocument;
    let h = doc.getElementById('lgHead');
    if (!h) {
      h = doc.createElement('header');
      h.id = 'lgHead';
      h.className = 'cwp-head dg-head lg-head';
      h.innerHTML = '<h1><span class="ssb-txc" id="lgHdCall" title="TX call"></span><span id="lgHdName"></span> <small>Remote Station · <span id="lgHdSub"></span></small></h1>';
      doc.body.prepend(h);
      doc.body.classList.add('dg-hd');
    }
    let st = null;
    try { st = api && api.state && api.state(); } catch (e) { st = null; }
    // Statistiques : le TX call choisi dans le tableau (« TOUS » s'il n'y en a pas) ; carnet : celui du filtre, sinon celui en service
    const call = ST.on ? (ST.data ? ST.data.txc || 'TOUS' : '') : filt.txc || (st && st.txCall) || '';
    const c = call ? String(call).toUpperCase() + ' ' : '';
    const name = ST.on ? 'LOGBOOK STATISTIQUES' : 'LOGBOOK';
    const sub = ST.on ? 'diplômes ' + ((ST.data && ST.data.award) || 'DXCC') + ' par bande et par mode' : 'carnet de trafic';
    const hc = doc.getElementById('lgHdCall'), hn = doc.getElementById('lgHdName'), hs = doc.getElementById('lgHdSub');
    if (hc.textContent !== c) hc.textContent = c;
    if (hn.textContent !== name) hn.textContent = name;
    if (hs.textContent !== sub) hs.textContent = sub;
    const t = c + name + ' — Remote Station';
    if (doc.title !== t) doc.title = t;
  }
  function statsDraw() {
    const d = ST.data;
    if (!d || !root) return;
    const tx = q$('#lgStTx');
    const opts = d.txcalls || [];
    if (tx.dataset.k !== opts.join(',')) {
      tx.dataset.k = opts.join(',');
      tx.textContent = '';
      tx.add(new Option('Tous', ''));
      for (const c of opts) tx.add(new Option(c, c));
    }
    tx.value = d.txc || '';
    const ms = q$('#lgStMode');
    const mk = (d.modes || []).join(',');
    if (ms.dataset.k !== mk) {
      ms.dataset.k = mk;
      ms.querySelectorAll('option[data-m]').forEach((o) => o.remove());
      for (const md of d.modes || []) { const o = new Option(md, md); o.dataset.m = '1'; ms.add(o); }
    }
    ms.value = d.mode || '';
    const B = d.bands || [];
    // Tableau à la manière de Swisslog : une ligne par pays, sous chaque bande une colonne par mode (SSB, CW, RTTY, FT8,
    // FT4, FT2, « Autres » s'il y en a) ; case verte C = confirmé, bleue W = contacté (worked), rouge - = pas encore.
    // Mode ou groupe choisi : une colonne par bande. En dessous : le récapitulatif bandes × modes (contactés / confirmés).
    // Colonnes de modes : ceux réellement présents dans le carnet pour ce choix (SSB, CW, RTTY, FT8, FT4, FT2, JTTY, SSTV…)
    const MK = d.mcols && d.mcols.length ? d.mcols : ['SSB', 'CW', 'FT8', 'FT4', 'FT2', 'RTTY', 'DATA'];
    const per = !d.mode;
    const hasAut = false;
    const mks = per ? MK : [''];
    const AW = (d.awards || []).find((a) => a[0] === (d.award || 'DXCC')) || ['DXCC', 'DXCC (pays)', 'Pays DXCC'];
    if (q$('#lgStAw') && d.award) q$('#lgStAw').value = d.award;
    const mkL = (k) => (k === 'AUT' ? 'Autres' : k || (ST_GRP[d.mode] || d.mode));
    const mkT = (k) => (k === 'SSB' ? 'SSB (toute la phonie : SSB, AM, FM…)' : k === 'DATA' ? 'DATA : tous les modes numériques (FT8, FT4, FT2, RTTY, JTTY, PSK, SSTV…)' : mkL(k));
    const st = (x, k) => (!x ? 0 : k ? (x.m && x.m[k]) || 0 : x.c ? 2 : 1); // 0 rien, 1 contacté, 2 confirmé
    const cols = [];
    for (const b of B) for (const k of mks) cols.push([b, k]);
    const allW = d.rows.filter((r) => Object.keys(r.b).length).length, allC = d.rows.filter((r) => Object.values(r.b).some((x) => x.c)).length;
    const full = ['WPX', 'IOTA', 'GRID'].indexOf(AW[0]) < 0; // diplômes à liste fermée : « sur N »
    q$('#lgStSum').innerHTML = '<b>' + esc(d.txc || 'Tous les TX call') + '</b> · ' + esc(AW[0] === 'GRID' ? 'Locators' : AW[0]) + ' · ' + esc(d.mode ? (ST_GRP[d.mode] || d.mode) : 'tous modes') + ' : <b class="w">' + allW + '</b> contactés · <b class="c">' + allC + '</b> confirmés' + (full ? ' sur ' + d.rows.length : '');
    const bl = (b) => (b === 'SAT' ? 'SAT' : /cm$/.test(b) ? b.replace(/cm$/, ' cm') : b.replace(/m$/, ' m'));
    const first = (i) => (i % mks.length === 0 ? 'lg-stb0' : '');
    q$('#lgStHead').innerHTML = '<tr><th rowspan="2" class="lg-stn">' + esc(AW[2]) + '</th>' + B.map((b) => '<th class="lg-stb lg-stb0" colspan="' + mks.length + '">' + esc(bl(b)) + '</th>').join('') + '</tr>' +
      '<tr class="lg-stm">' + cols.map(([, k], i) => '<th class="' + first(i) + (k === 'DATA' ? ' lg-stdata' : '') + '" title="' + esc(mkT(k)) + '"><span>' + esc(mkL(k)) + '</span></th>').join('') + '</tr>';
    let rows = d.rows.slice();
    if (ST.q) rows = rows.filter((r) => r.pfx.toUpperCase().indexOf(ST.q) === 0 || r.name.toUpperCase().indexOf(ST.q) >= 0);
    const show = q$('#lgStShow') ? q$('#lgStShow').value : '';
    if (show === 'w') rows = rows.filter((r) => Object.keys(r.b).length);
    else if (show === 'n') rows = rows.filter((r) => !Object.keys(r.b).length);
    else if (show === 'nc') rows = rows.filter((r) => !Object.values(r.b).some((x) => x.c));
    const nb = (r) => Object.keys(r.b).length;
    const cmp = { pfx: (a, b) => a.pfx.localeCompare(b.pfx), name: (a, b) => a.name.localeCompare(b.name), cont: (a, b) => a.cont.localeCompare(b.cont) || a.pfx.localeCompare(b.pfx),
      bands: (a, b) => nb(b) - nb(a) || a.pfx.localeCompare(b.pfx) }[ST.sort] || ((a, b) => a.pfx.localeCompare(b.pfx));
    rows.sort(cmp);
    const cell = (r, b, k, i) => {
      const v = st(r.b[b], k);
      const what = mkT(k);
      const tip = r.name + ' · ' + bl(b) + ' · ' + what + ' : ' + (v === 2 ? 'confirmé' : v ? 'contacté' : 'pas encore') + (v ? ' — clic : ces QSO dans le carnet' : '');
      return '<td data-b="' + esc(b) + '" data-k="' + k + '" class="' + (v === 2 ? 'sc' : v ? 'sw' : 'sn') + ' ' + first(i) + (k === 'DATA' ? ' lg-stdata' : '') + '" title="' + esc(tip) + '">' + (v === 2 ? 'C' : v ? 'W' : '-') + '</td>';
    };
    q$('#lgStBody').innerHTML = rows.length ? rows.map((r) => '<tr data-pfx="' + esc(r.pfx) + '"><td class="lg-stn" title="' + esc(r.pfx + ' – ' + r.name + (r.cont ? ' (' + r.cont + ')' : '')) + '"><b>' + esc(['WAZ', 'ITU'].indexOf(AW[0]) >= 0 ? String(Number(r.pfx)) : r.pfx) + '</b>' + (r.name && ['WAZ', 'ITU'].indexOf(AW[0]) < 0 ? ' – ' + esc(r.name) : '') + '</td>' +
      cols.map(([b, k], i) => cell(r, b, k, i)).join('') + '</tr>').join('')
      : '<tr><td class="lg-empty" colspan="' + (cols.length + 1) + '">Aucun QSO pour ce choix.</td></tr>';
    // Récapitulatif : pour chaque bande (lignes) et chaque mode (colonnes), pays contactés / confirmés ; Total = tous modes,
    // dernière ligne = toutes bandes (pays distincts)
    const cnt = (bs, k) => {
      let w = 0, c = 0;
      for (const r of d.rows) {
        let v = 0;
        for (const b of bs) { const x = r.b[b]; if (!x) continue; v = Math.max(v, k == null ? (x.c ? 2 : 1) : st(x, k)); }
        if (v) { w++; if (v === 2) c++; }
      }
      return [w, c];
    };
    const sm = mks.filter((k) => k !== 'AUT' || hasAut);
    q$('#lgSsHead').innerHTML = '<tr><th rowspan="2"></th>' + sm.map((k) => '<th colspan="2">' + esc(mkL(k)) + '</th>').join('') + (per ? '<th colspan="2">Total</th>' : '') + '</tr>' +
      '<tr>' + sm.concat(per ? ['T'] : []).map(() => '<th>Contacté</th><th>Confirmé</th>').join('') + '</tr>';
    const line = (lab, bs, cls) => '<tr class="' + (cls || '') + '"><th>' + esc(lab) + '</th>' + sm.map((k) => { const [w, c] = cnt(bs, k); return '<td>' + w + '</td><td>' + c + '</td>'; }).join('') +
      (per ? (() => { const [w, c] = cnt(bs, null); return '<td class="t">' + w + '</td><td class="t">' + c + '</td>'; })() : '') + '</tr>';
    q$('#lgSsBody').innerHTML = B.map((b) => line(b === 'SAT' ? 'SAT' : b, [b])).join('') + line('Total', B, 'tot');
    if (ST.fit) ST.fit();
    headDraw();
  }

  // ------------------------------------------------------------------ messages du serveur
  function onMessage(m) {
    if (m.t === 'log_stats') { ST.data = m; statsDraw(); return; }
    if (m.t === 'log_net') { netShow(m); return; }
    if (m.t === 'log_import') { impMsg(m); return; }
    if (m.t === 'log_changed' && ST.on && api) setTimeout(() => { if (ST.ask) ST.ask(); }, 300); // nouveau QSO : statistiques à jour (même diplôme, TX call, mode)
    if (/^log_(saved|dupe)$/.test(m.t)) clearTimeout(saveWait);
    // Refus du serveur pendant un enregistrement (droits, données invalides) : affiché sous la fiche
    if (m.t === 'notice') {
      const el = root && q$('#lgFmsg');
      if (m.level === 'error' && el && /^Enregistrement/.test(el.textContent)) { clearTimeout(saveWait); fmsg(m.msg, 'err'); }
      return;
    }
    if (m.t === 'log_refs') return refResults(m);
    if (m.t === 'log_refs_status') return drawRefsDlg(m.status);
    if (m.t === 'log_values') {
      if (fltMenu && fltMenu.col === m.col) { fltMenu.values = m.values || []; fillFlt(); }
      return;
    }
    // QSO envoyé par une autre page (tag différent : page TRX SSB / dashboard) : sa réponse ne concerne pas cette fiche
    if ((m.t === 'log_saved' || m.t === 'log_dupe') && (m.tag || '') !== TAG) return;
    if (FORM && m.t === 'log_list') return;
    if (m.t === 'log_list') {
      items = m.items || [];
      total = m.total || 0;
      if (Array.isArray(m.stationCalls)) stCalls = m.stationCalls;
      if (Array.isArray(m.calls)) { calls = m.calls; rights(); }
      if (Array.isArray(m.txcalls)) txcalls = m.txcalls;
      if (m.engine) engine = m.engine;
      if (Array.isArray(m.stationCalls)) stCalls = m.stationCalls;
      if (editing) editing = items.find((x) => x.id === editing.id) || editing;
      txfDraw();
      drawList();
    } else if (m.t === 'log_changed') {
      if (root && !root.hidden) { clearTimeout(listTimer); listTimer = setTimeout(reload, 200); } else stale = true;
    } else if (m.t === 'log_saved') {
      const q = m.qso || {};
      if (m.edited) { lastLogged = q.call; if (lastSaved && q.id === lastSaved.id) lastSaved = q; endEdit(); say('QSO avec ' + q.call + ' modifié.', ''); fShow(false, 2000); return; }
      if (FORM && q.id) { lastSaved = q; lastBtns(); }
      const auto = SV.filter((s) => m.auto && m.auto[s]);
      const okMsg = '✓ QSO avec ' + q.call + ' enregistré (' + q.band + ' ' + modeName(q) + ').' + (auto.length ? ' Envoi automatique : ' + auto.map((s) => NAMES[s]).join(', ') + '.' : '');
      lastLogged = q.call;
      // Enregistré depuis un autre onglet (fiche du QSO RTTY / JTTY / CW, FT8 auto) : message en bas de l'écran
      if (!root || root.hidden || !root.offsetParent) say(okMsg, 'ok');
      if (!root) return;
      // Fiche en cours de modification d'un autre QSO (QSO enregistré ailleurs, ex. fin de QSO FT8) : on n'y touche pas
      if (editing) { say(okMsg, 'ok'); return; }
      fShow(false, 2000); // carnet général : fiche cachée 2 s après l'enregistrement
      const f = q$('#lgForm');
      for (const k of ['call', 'name', 'qth', 'gridsquare', 'comment', 'rst_rcvd']) f[k].value = '';
      qrzAsked = '';
      for (const [k] of REF_KEYS) f[k].value = ''; // références du correspondant ; « ma référence » reste (activation)
      delete f.time.dataset.manual;
      delete f.freq.dataset.manual;
      delete f.mode.dataset.manual;
      defaultRst(true);
      fmsg(okMsg, 'ok');
      f.call.focus();
    } else if (m.t === 'log_dupe') {
      const p = m.prev || {};
      pendingDupe = m.qso;
      // Même QSO déjà enregistré (ex. en fin de QSO) : on complète la fiche existante (nom, QTH, locator…) plutôt qu'un 2e QSO
      const q = m.qso || {};
      const extra = ['name', 'qth', 'gridsquare', 'rst_rcvd', 'comment', 'tx_pwr'].concat(REF_KEYS.flatMap(([k]) => [k, 'my_' + k])).filter((k) => q[k] && !p[k]);
      const LBL = { name: 'nom', qth: 'QTH', gridsquare: 'locator', rst_rcvd: 'RST reçu', comment: 'remarque', tx_pwr: 'puissance' };
      for (const [k, pr] of REF_KEYS) { LBL[k] = pr; LBL['my_' + k] = 'ma réf. ' + pr; }
      if (p.id && extra.length && window.confirm(p.call + ' est déjà dans le carnet (' + p.band + ' ' + modeName(p) + ', ' + fmtDate(p.qso_date) + ' à ' + fmtTime(p.time_on) + ' UTC).\n' +
          'Compléter ce QSO avec : ' + extra.map((k) => LBL[k] + ' « ' + q[k] + ' »').join(', ') + ' ?')) {
        api.send({ t: 'log_merge', id: p.id, qso: q, tag: TAG || undefined });
        pendingDupe = null;
        return;
      }
      if (window.confirm('Doublon possible : ' + p.call + ' déjà dans le carnet sur ' + p.band + ' ' + modeName(p) + ' le ' + fmtDate(p.qso_date) + ' à ' + fmtTime(p.time_on) + ' UTC.\nEnregistrer quand même ?')) {
        api.send({ t: 'log_add', qso: pendingDupe, force: true, tag: TAG || undefined, spot: !!(window.RSSPOT && RSSPOT.on()) });
      } else if (root && !root.hidden && root.offsetParent) fmsg('QSO non enregistré (doublon).', 'warn'); else say('QSO non enregistré (doublon).', 'warn');
      pendingDupe = null;
    } else if (m.t === 'log_export') {
      if (m.tag && m.tag !== TAG) return; // export demandé par la page TRX CW ou TRX SSB : c'est elle qui l'enregistre
      download(m);
    } else if (m.t === 'log_job') {
      onJob(m);
    } else if (m.t === 'log_pending') {
      if (sdlg && sdlg.el.open && sdlg.service === m.service) {
        const p = sdlg.el.querySelector('.lg-pend');
        p.textContent = m.n + ' QSO à envoyer vers ' + NAMES[m.service] + (m.busy ? ' · un envoi est déjà en cours' : '') + (m.stopped ? ' · envois arrêtés après un refus d’accès : vérifiez les identifiants puis enregistrez-les' : '');
        p.classList.toggle('warn', !!m.stopped);
      }
    } else if (m.t === 'log_agents') {
      const before = agentIds;
      agents = m.list || [];
      // Nouveau PC appairé pendant que le code était affiché : le code ne sert plus
      if (before && agents.some((a) => before.indexOf(a.id) < 0) && sdlg && sdlg.el.open && sdlg.service === 'lotw') {
        sdlg.el.querySelector('.lg-agcode').hidden = true;
        agentIds = null;
        say('Agent LoTW appairé.', 'info');
      }
      agentsDraw();
    } else if (m.t === 'log_agent_code') {
      agentCode(m);
    } else if (m.t === 'log_acct') {
      if (!sdlg || !sdlg.el.open || sdlg.service !== m.service) return;
      const f = sdlg.el.querySelector('form');
      if (f.callsign.value !== m.call) return;
      const UI = {
        clublog: [['api', 'Jeton Club Log (cl_…)', 1], ['email', 'E-mail (sans jeton)'], ['password', 'Mot de passe (sans jeton)', 1]],
        eqsl: [['user', 'Indicatif / identifiant eQSL'], ['password', 'Mot de passe', 1], ['nickname', 'QTH nickname (facultatif)']],
        lotw: [['location', 'Lieu de station TQSL (facultatif avec l’Agent LoTW si votre PC n’en a qu’un pour cet indicatif)'], ['password', 'Mot de passe du certificat (TQSL de ce serveur seulement ; avec l’Agent LoTW, il reste sur votre PC)', 1], ['login', 'Identifiant du site LoTW (confirmations)'], ['webPassword', 'Mot de passe du site LoTW', 1]],
        qrz: [['key', 'Clé API du logbook QRZ.com', 1]]
      }[m.service] || [];
      const box = sdlg.el.querySelector('.lg-acf');
      box.innerHTML = UI.map(([k, lab, sec]) => '<label>' + esc(lab) + ' ' + (sec
        // readonly jusqu'au clic : Chrome ne remplit pas tout seul ces cases avec les identifiants qu'il a mémorisés
        // (sinon ceux d'un membre pouvaient se retrouver enregistrés pour ON5VL)
        ? '<span class="lg-pw"><input data-af="' + k + '" type="password" autocomplete="new-password" readonly data-noauto="1" placeholder="' + (m.has && m.has[k] ? SECRET_PH : 'à renseigner') + '">' +
          '<button type="button" class="lg-eye" title="Afficher / masquer" aria-label="Afficher le mot de passe">👁</button>' +
          (m.source === 'compte' && m.has && m.has[k] ? '<button type="button" class="lg-clr" data-aclr="' + k + '" title="Effacer la valeur enregistrée pour cet indicatif">✕</button>' : '') + '</span>'
        : '<input data-af="' + k + '" value="' + esc((m.fields || {})[k] || '') + '" autocomplete="off" readonly data-noauto="1">') + '</label>').join('') +
        // Club Log : où se crée le jeton (les deux autres cases ne servent qu'à l'ancienne méthode)
        (m.service === 'clublog' ? '<p class="lg-note" style="grid-column:1/-1;margin:0">Jeton : clublog.org → Settings → <b>API</b> → Tokens → Create token (commence par <b>cl_</b>). Avec un jeton, e-mail et mot de passe ne servent pas : laissez-les vides (✕).</p>' : '') +
        // Indicatif personnel : envoi automatique de chaque nouveau QSO (le club se règle dans ⚙ Configuration)
        // Indicatif du club (administrateurs) : choix propre à cet indicatif, sinon le réglage commun de ⚙ Configuration
        (m.club && !me.admin ? '<p class="lg-note">Envoi automatique des QSO de ' + esc(m.call) + ' (indicatif du club) : réglé par un administrateur.</p>'
          : '<label class="lg-chk"><input type="checkbox" data-aauto' + (m.auto ? ' checked' : '') + '> Envoyer automatiquement chaque nouveau QSO de ' + esc(m.call) + ' vers ' + esc(NAMES[m.service]) + '</label>' +
            (m.club ? '<p class="lg-note">' + (m.autoOwn ? 'Choix propre à ' + esc(m.call) + '.' : 'Réglage commun aux indicatifs du club (⚙ Configuration) ; « Enregistrer pour cet indicatif » le rend propre à ' + esc(m.call) + '.') + '</p>' : ''));
      box.querySelectorAll('[data-noauto]').forEach((i) => {
        const on = () => i.removeAttribute('readonly');
        i.addEventListener('focus', on);
        i.addEventListener('pointerdown', on);
      });
      box.onclick = (e) => {
        const b = e.target.closest('button');
        if (!b) return;
        const i = b.parentElement.querySelector('input');
        if (b.classList.contains('lg-eye')) i.type = i.type === 'password' ? 'text' : 'password';
        else if (b.dataset.aclr) { i.value = ''; i.dataset.clear = '1'; i.placeholder = 'sera effacé à l’enregistrement'; b.remove(); }
      };
      const missing = UI.filter(([k, , sec]) => k !== 'nickname' && k !== 'login' && k !== 'webPassword' && !(m.service === 'lotw' && (k === 'password' || k === 'location')) && !(sec ? m.has && m.has[k] : (m.fields || {})[k]));
      const note = sdlg.el.querySelector('.lg-anote');
      note.textContent = (m.source === 'compte' ? 'Identifiants propres à ' + m.call + '.' : m.source === 'club' ? 'Identifiants généraux du club (⚙ Configuration), utilisés pour ' + m.call + ' ; vous pouvez lui en donner de propres ici.' : 'Aucun identifiant pour ' + m.call + ' : à renseigner avant la synchronisation.') +
        (missing.length ? ' Manque : ' + missing.map((x) => x[1].toLowerCase()).join(', ') + '.' : '') + (m.saved ? ' ✓ Enregistré.' : '');
      note.classList.toggle('warn', !!missing.length);
    } else if (m.t === 'log_cfg') {
      calls = m.calls || calls;
      if (sdlg && sdlg.el.open && m.cfg) {
        const c = m.cfg[sdlg.service] || {};
        const f = sdlg.el.querySelector('form');
        if (f.delay && f.delay.value === '') f.delay.value = c.delay;
      }
      if (cdlg && !m.quiet) { drawCfg(m.cfg, m.saved); noAutofill(cdlg.el); }
    } else if (m.t === 'log_test') {
      const out = cdlg && cdlg.el && cdlg.el.querySelector('[data-tr="' + m.service + '"]');
      if (out) { out.textContent = (m.ok ? '✓ ' : '✗ ') + m.msg; out.className = 'lg-tres ' + (m.ok ? 'ok' : 'err'); }
    }
  }

  window.RSLOG = {
    init(a) { api = a; TAG = (a && a.tag) || ''; FORM = !!(a && a.formOnly); SSBP = !!(a && a.phone); if (TAG === 'big') statsSetup(); },
    // Fiche du carnet : fréquence et mode suivent tout seuls le VFO actif du TRX (sauf saisie à la main ou modification d'un QSO)
    onState() {
      if (!root || editing) return;
      // TX call de la ligne Correspondant → TX call du carnet (dès qu'il change)
      const s0 = api && api.state && api.state();
      const tc = s0 && s0.txCall ? String(s0.txCall).toUpperCase() : '';
      const f0 = q$('#lgForm');
      // TX call absent de la liste de la fiche (ex. OR0L choisi dans la page FT) : ajouté, pour que la fiche montre et enregistre le bon
      if (f0 && tc && calls.indexOf(tc) < 0) { calls = calls.concat([tc]); rights(); }
      if (f0 && tc && [...f0.station.options].some((o) => o.value === tc)) {
        if (tc !== lastTxCall) { delete f0.station.dataset.manual; lastTxCall = tc; }
        if (!f0.station.dataset.manual && f0.station.value !== tc) f0.station.value = tc;
      }
      if (root.hidden) return;
      const f = q$('#lgForm');
      if (!f || f.freq.dataset.manual || f.contains(document.activeElement) && document.activeElement === f.freq) return;
      const st = api && api.state && api.state();
      const r = st && st.radio;
      const hz = r && (r.vfoSel === 1 && r.freqB ? r.freqB : r.freq);
      if (!hz) return;
      const v = (hz / 1e6).toFixed(6).replace(/0{1,3}$/, '');
      if (f.freq.value !== v) { f.freq.value = v; qoCheck(); }
      const m = trxMode(r.vfoSel === 1 && r.modeB ? r.modeB : r.mode);
      if (m && !f.mode.dataset.manual && f.mode.value !== m) f.mode.value = m;
    },
    onQrz(m) {
      const f = root && q$('#lgForm');
      if (!f || String(f.call.value).trim().toUpperCase() !== String(m.call).toUpperCase()) return;
      const force = qrzForce === String(m.call).toUpperCase();
      qrzForce = '';
      if (!m.ok) {
        if (m.off) { if (force) fmsg('QRZ.com non réglé : Logbooks → Synchronisation → ⚙ Configuration → QRZ.com (identifiant et mot de passe).', 'warn'); return; }
        fmsg('QRZ.com : ' + String(m.msg || 'pas de réponse').replace(/^QRZ\.com : /, ''), 'warn');
        return;
      }
      const v = m.info || {};
      const full = titleCase([v.fname || v.nick, v.name].filter(Boolean).join(' '));
      const set = (k, val) => { if (val && (force || !f[k].value)) f[k].value = val; };
      set('name', full.slice(0, 40));
      set('qth', v.qth);
      set('gridsquare', String(v.grid || '').toUpperCase().slice(0, 6));
      if (!editing || force) fmsg('QRZ.com : ' + m.call + ' — ' + [full, v.qth, v.country].filter(Boolean).join(', ') +
        (v.grid ? ', ' + String(v.grid).toUpperCase() : v.sub ? ' (pas de locator sur sa fiche)' : ' (locator : abonnement XML QRZ.com nécessaire)') + '.', 'ok');
    },
    mount,
    /** Fiche remplie avec le correspondant (ligne Correspondant / QSO FT8) : o = { rst_sent, rst_rcvd, t0 } */
    fill(o) {
      if (!root || editing) return;
      fShow(true);
      fromTrx(true);
      const f = q$('#lgForm');
      if (!f) return;
      if (o && o.rst_sent) f.rst_sent.value = o.rst_sent;
      if (o && o.rst_rcvd != null) f.rst_rcvd.value = o.rst_rcvd;
      if (o && o.t0) { const d = new Date(o.t0); const pad = (n) => String(n).padStart(2, '0'); f.date.value = d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate()); f.time.value = pad(d.getUTCHours()) + ':' + pad(d.getUTCMinutes()); }
    },
    editing: () => !!editing,
    onHello(h) {
      me = { call: h.call, admin: !!h.admin, rxOnly: !!h.rxOnly, digiCall: h.digiCall || '', clubCalls: Array.isArray(h.clubCalls) ? h.clubCalls : [] };
      // Indicatifs de la station (tous, pas seulement le premier) : la fiche des pages TRX (sans liste du carnet) n'a que ceux-ci
      for (const c of me.clubCalls.concat(h.digiCall ? [h.digiCall] : []).map((x) => String(x).toUpperCase()).reverse()) if (c && calls.indexOf(c) < 0) calls = [c].concat(calls);
      rights();
      stale = true;
      if (root && !root.hidden) reload();
    },
    show() {
      if (stale || !items.length) reload();
      if (!editing) {
        const f = q$('#lgForm');
        if (!f.call.value) fromTrx(false);
      }
    },
    onMessage
  };
})();
