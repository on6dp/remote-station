/*
 * Page « TRX SSB » (ssb.html) : contests en phonie. Choix du contest (public/js/contests.js) et de la catégorie
 * (en-tête Cabrillo), échange à annoncer avec le n° de série, log du contest à la manière de N1MM (doublons,
 * compteurs, cadence), mémoires vocales T1 à T8 (VOICE TX), fichier Cabrillo. Les QSO vont dans le carnet général.
 * Même connexion que le dashboard qui l'a ouverte (window.opener.RSHOST), comme le TRX CW.
 */
(function () {
  'use strict';
  const $ = (id) => document.getElementById(id);
  // Page FreeDV (fdv.html) : même page sans les contests ni les mémoires vocales (classe fdv-body), mode FREEDV au carnet
  const FDV = document.body.classList.contains('fdv-body');
  const PTAG = FDV ? 'fdvpage' : 'ssbpage';
  const PMODE = FDV ? 'fdv' : 'ssb';
  const LS = {
    get(k, d) { try { const v = localStorage.getItem('rs.dg.' + k); return v == null ? d : v; } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('rs.dg.' + k, String(v)); } catch (e) {} }
  };

  // Colonnes d'un log réglables à la souris : poignée au bord droit de chaque titre (glisser = largeur ; double-clic =
  // largeurs d'origine) ; largeurs gardées dans ce navigateur, par tableau et par jeu de colonnes
  function colResize(table, key, ST) {
    if (!table) return;
    const head = table.tHead && table.tHead.rows[0];
    if (!head) return;
    const ths = Array.from(head.cells);
    const sig = key + ':' + ths.map((th) => th.textContent.replace(/[^A-Za-z#]/g, '').slice(0, 6)).join('.');
    const apply = (ws) => {
      if (!ws || ws.length !== ths.length) { table.style.tableLayout = ''; table.style.width = ''; ths.forEach((th) => { th.style.width = th.style.minWidth = th.style.maxWidth = ''; }); table.classList.remove('col-fixed'); return; }
      ths.forEach((th, i) => { th.style.width = th.style.minWidth = th.style.maxWidth = ws[i] + 'px'; });
      table.style.tableLayout = 'fixed';
      table.style.width = ws.reduce((a, b) => a + b, 0) + 'px';
      table.classList.add('col-fixed');
    };
    let saved = null;
    try { saved = JSON.parse(ST.get('cols.' + sig, 'null')); } catch (e) { saved = null; }
    apply(saved);
    ths.forEach((th, i) => {
      if (th.querySelector('.col-grip')) return;
      const g = document.createElement('i');
      g.className = 'col-grip';
      g.title = 'Glisser : largeur de la colonne · double-clic : largeurs d’origine';
      th.appendChild(g);
      g.addEventListener('pointerdown', (e) => {
        e.preventDefault(); e.stopPropagation();
        g.setPointerCapture(e.pointerId);
        const zf = (window.RSZOOM && window.RSZOOM.z()) || 1; // page agrandie (zoom.js) : pixels de l'écran → pixels CSS
        const ws = ths.map((x) => Math.round(x.getBoundingClientRect().width / zf));
        const x0 = e.clientX, w0 = ws[i];
        const mv = (ev) => { ws[i] = Math.max(28, Math.round(w0 + (ev.clientX - x0) / zf)); apply(ws); };
        const up = () => { g.removeEventListener('pointermove', mv); g.removeEventListener('pointerup', up); g.removeEventListener('pointercancel', up); ST.set('cols.' + sig, JSON.stringify(ws)); };
        g.addEventListener('pointermove', mv);
        g.addEventListener('pointerup', up);
        g.addEventListener('pointercancel', up);
      });
      g.addEventListener('dblclick', (e) => { e.stopPropagation(); ST.set('cols.' + sig, 'null'); apply(null); });
      g.addEventListener('click', (e) => e.stopPropagation());
    });
  }
  // Logs de la page : colonnes réglables (log du contest, QSO en phonie hors contest)
  setTimeout(() => { colResize(document.querySelector('.ssb-clog'), 'ssbclog', LS); colResize(document.querySelector('.ssb-qlog'), 'ssbqlog', LS); }, 0);
  const C = window.RSCONTESTS || { SSB: [], BANDS: ['ALL'] };
  let hostWin = null;
  let host = null;
  let untap = null;

  const toast = (msg, level, ms) => {
    const el = $('cwpToast');
    el.textContent = msg || '';
    el.className = 'dg-toast ' + (level || '');
    if (msg) { void el.offsetWidth; el.classList.add('blink'); }
    clearTimeout(toast.t);
    if (msg) toast.t = setTimeout(() => { el.textContent = ''; }, Math.max(6000, Number(ms) || 0));
  };
  const api = {
    send: (m) => { try { if (host) host.api.send(m); } catch (e) {} },
    iControl: () => { try { return !!(host && host.api.iControl()); } catch (e) { return false; } },
    state: () => { try { return host ? host.api.state() : null; } catch (e) { return null; } }
  };
  function kit() { try { const d = (hostWin.DG && hostWin.DG()) || hostWin.RSDIGI; return (d && d.cwKit) || null; } catch (e) { return null; } }
  function chain() {
    const out = [];
    let w = window.opener;
    for (let i = 0; i < 4 && w; i++) { try { if (w.closed) break; out.push(w); w = w.opener; } catch (e) { break; } }
    return out;
  }

  // ------------------------------------------------------------------ contest, catégorie, échange
  const S = { id: FDV ? '' : LS.get('ssbc', ''), vm: null, playing: null, pv: [] };
  const def = () => C.SSB.find((c) => c.id === S.id) || null;
  const catKey = () => 'ssbcat_' + S.id;
  function catState() {
    let o = {};
    try { o = JSON.parse(LS.get(catKey(), '{}')) || {}; } catch (e) { o = {}; }
    return o;
  }
  function saveCat(o) { LS.set(catKey(), JSON.stringify(o)); }
  const exchTpl = () => { const d = def(); return LS.get('ssbx_' + S.id, d ? d.exch : '59 <CNTR>'); };
  function exchShown() {
    const k = kit();
    const z = k ? k.zones() : { cqz: '14', itu: '27', name: '' };
    const n = k ? k.serial() : 1;
    return exchTpl().replace(/<CNTR>|<SERNO>/g, String(n).padStart(3, '0')).replace(/<CQZ>/g, String(z.cqz).padStart(2, '0'))
      .replace(/<ITUZ>/g, String(z.itu).padStart(2, '0')).replace(/<MYNAME>/g, String(z.name || 'NOM').toUpperCase()).toUpperCase();
  }
  function fillContests() {
    const sel = $('ssCtst');
    // Ordre alphabétique (sans tenir compte des majuscules ni des accents)
    for (const c of C.SSB.slice().sort((a, b) => (/-OTHER$/.test(a.id) - /-OTHER$/.test(b.id)) || a.name.localeCompare(b.name, 'fr', { sensitivity: 'base' }))) sel.add(new Option(c.name + (c.verif ? '' : ' *'), c.id));
    sel.value = S.id;
    const bs = $('ssBand');
    for (const b of C.BANDS) bs.add(new Option(b === 'ALL' ? 'toutes' : b.toLowerCase(), b));
  }
  // Catégorie Cabrillo : valeurs de la catégorie choisie, puissance / bande / assistance / overlay de la page
  function cabCat() {
    const d = def();
    if (!d) return null;
    const st = catState();
    const c = d.cat.find((x) => x[0] === st.k) || d.cat[0];
    const v = Object.assign({}, c[2]);
    if (!v.POWER && v.OPERATOR !== 'CHECKLOG') v.POWER = st.pw || 'LOW';
    if (d.bands && v.OPERATOR === 'SINGLE-OP') v.BAND = st.band || 'ALL'; else if (v.OPERATOR !== 'CHECKLOG') v.BAND = 'ALL';
    if (d.assisted && v.OPERATOR === 'SINGLE-OP' && !v.ASSISTED) v.ASSISTED = st.ass ? 'ASSISTED' : 'NON-ASSISTED';
    if (!v.MODE) v.MODE = d.mode || 'SSB';
    if (st.ov && (d.overlays || []).indexOf(st.ov) >= 0 && v.OPERATOR === 'SINGLE-OP') v.OVERLAY = st.ov;
    return v;
  }
  function drawContest() {
    const d = def();
    const k = kit();
    document.body.classList.toggle('cwp-inctst', !!d);
    $('cwpCtBody').hidden = !d;
    // Pas de contest : la fiche du carnet pour noter les QSO à la main
    const qb = $('ssQso');
    // Mémoires vocales : aussi sans contest (les textes se changent) — sous le titre de la fiche du carnet ;
    // en contest, à leur place sous la ligne d'entrée (au-dessus du score)
    const vk = document.querySelector('.ssb-vk');
    if (vk) {
      if (d && vk.parentNode !== $('cwpCtBody').querySelector('.cwp-cleft')) $('cwpCtBody').querySelector('.cwp-cleft').insertBefore(vk, $('cwpCtBody').querySelector('.ssb-panels'));
      else if (!d && vk.parentNode !== qb) qb.insertBefore(vk, qb.querySelector('.ssb-lg'));
    }
    if (qb.hidden !== !!d) { qb.hidden = !!d; if (!d && LOG && LOG.mounted) LOG.show(); if (!d) askSsb(); }
    const cs = $('ssCat');
    cs.textContent = '';
    const st = catState();
    if (d) for (const c of d.cat) cs.add(new Option(c[1], c[0]));
    if (d) cs.value = d.cat.some((c) => c[0] === st.k) ? st.k : d.cat[0][0];
    const cur = d ? d.cat.find((c) => c[0] === cs.value) : null;
    const so = cur && cur[2].OPERATOR === 'SINGLE-OP';
    $('ssPwrW').hidden = !d || !cur || !!cur[2].POWER || cur[2].OPERATOR === 'CHECKLOG';
    $('ssPwr').value = st.pw || 'LOW';
    $('ssBandW').hidden = !d || !d.bands || !so;
    $('ssBand').value = st.band || 'ALL';
    $('ssAssW').hidden = !d || !d.assisted || !so || !!(cur && cur[2].ASSISTED);
    $('ssAss').checked = !!st.ass;
    const ov = $('ssOv');
    ov.length = 1;
    if (d) for (const o of d.overlays || []) ov.add(new Option(o, o));
    $('ssOvW').hidden = !d || !(d.overlays || []).length || !so;
    ov.value = st.ov || '';
    // RÈGLEMENT : le règlement officiel du contest choisi ; sans adresse connue, une recherche « <contest> rules <année> »
    const r = $('ssRules');
    r.hidden = !d || /-OTHER$/.test(d.id);
    if (d) {
      r.href = d.url || 'https://www.google.com/search?q=' + encodeURIComponent(d.name.replace(/\s*\(.*\)\s*/g, ' ').trim() + ' contest rules ' + new Date().getUTCFullYear());
      r.title = d.url ? 'Règlement officiel du ' + d.name + ' (nouvel onglet)' : 'Règlement du ' + d.name + ' : recherche sur le web (nouvel onglet)';
    }
    const ex = $('ssExch');
    if (document.activeElement !== ex) ex.value = d ? exchTpl() : '';
    ex.disabled = !d;
    $('ssExchSh').textContent = d ? '→ ' + exchShown() : '';
    fillStx(false);
    $('ssNote').textContent = d ? (d.when ? d.when + ' · ' : '') + (d.note || '') + (d.verif ? '' : ' * Catégories habituelles : à vérifier dans le règlement de l’année.') : ''; // sans contest : pas de note
    if (k) {
      const set = (el, v) => { if (document.activeElement !== el && el.value !== v) el.value = v; };
      set($('ssNr'), String(k.serial()).padStart(3, '0'));
      const z = k.zones();
      set($('ssCqz'), z.cqz);
      set($('ssItu'), z.itu);
      if ($('ssName')) set($('ssName'), z.name);
    }
    logSync(S.id);
  }
  $('ssCtst').addEventListener('change', () => {
    S.id = $('ssCtst').value;
    LS.set('ssbc', S.id);
    { const k = kit(); if (k && k.serialFor && S.id) k.serialFor(S.id); } // numéro de série en main (tenu par le serveur)
    drawContest();
    const d = def();
    if (d) toast(d.name + ' : échange « ' + exchShown() + ' ».', '', 5000);
  });
  $('ssCat').addEventListener('change', () => { const o = catState(); o.k = $('ssCat').value; saveCat(o); drawContest(); });
  $('ssPwr').addEventListener('change', () => { const o = catState(); o.pw = $('ssPwr').value; saveCat(o); });
  $('ssBand').addEventListener('change', () => { const o = catState(); o.band = $('ssBand').value; saveCat(o); });
  $('ssAss').addEventListener('change', () => { const o = catState(); o.ass = $('ssAss').checked; saveCat(o); });
  $('ssOv').addEventListener('change', () => { const o = catState(); o.ov = $('ssOv').value; saveCat(o); });
  $('ssExch').addEventListener('change', () => { if (S.id) LS.set('ssbx_' + S.id, $('ssExch').value.toUpperCase().trim() || (def() || {}).exch || '59 <CNTR>'); drawContest(); });
  $('ssNr').addEventListener('change', () => { const k = kit(); if (k) { k.setSerial($('ssNr').value, S.id); drawContest(); } });
  $('ssNrM').addEventListener('click', () => { const k = kit(); if (k) { k.setSerial(k.serial() - 1, S.id); drawContest(); } });
  $('ssNrP').addEventListener('click', () => { const k = kit(); if (k) { k.setSerial(k.serial() + 1, S.id); drawContest(); } });
  for (const [id, key] of [['ssCqz', 'cqz'], ['ssItu', 'itu'], ['ssName', 'name']]) {
    if (!$(id)) continue;
    $(id).addEventListener('change', () => { const k = kit(); if (k) { k.setZones({ [key]: $(id).value }); drawContest(); } });
  }

  // ------------------------------------------------------------------ mémoires vocales (VOICE TX)
  // 24 mémoires en 4 colonnes de 6 : F1 … F6 | F7 … F12 | Ctrl+F1 … Ctrl+F6 | Ctrl+F7 … Ctrl+F12 (T1 … T24)
  const VM_N = 24;
  const vmKey = (n) => (n <= 12 ? 'F' + n : 'Ctrl+F' + (n - 12));
  // Nom lisible d'une voix de synthèse (Kokoro / Piper : nom donné par le serveur ; espeak-ng : ancienne voix robotique)
  const voiceName = (id) => { const v = (S.pv || []).find((x) => x.id === id); return v ? v.name : /^(piper|kokoro):/.test(id || '') ? String(id).replace(/^(piper|kokoro):/, '') : 'espeak (ancienne voix robotique)'; };
  function drawVk() {
    const box = $('ssVk');
    const meta = S.vm;
    const pl = S.playing ? S.playing.n : 0;
    const sig = JSON.stringify(meta) + '|' + pl + '|' + JSON.stringify(S.tts || {}) + '|' + TT.voice + '|' + (S.pv || []).length;
    if (sig === box.dataset.sig) return;
    box.dataset.sig = sig;
    box.textContent = '';
    for (let n = 1; n <= VM_N; n++) {
      const t = meta && meta.t && meta.t[n - 1];
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'cwp-macro ssb-vm' + (t && t.ms ? ' tx' : ' empty') + (pl === n ? ' play' : '');
      b.innerHTML = '<small></small><span></span>';
      b.querySelector('small').textContent = vmKey(n) + ' · T' + n + (t && t.ms ? ' · ' + (t.ms / 1000).toFixed(1).replace('.', ',') + ' s' : '');
      b.querySelector('span').textContent = (t && t.name) || (t && t.ms ? 'T' + n : 'vide');
      const tt = S.tts && S.tts[n];
      // Mémoire faite avec une autre voix que celle choisie dans « Config. Macros » (ancienne génération, autre langue,
      // voix espeak robotique) : marquée en orange, pour la refaire (cocher T1 à T8 puis GÉNÉRER)
      const other = !!(tt && tt.voice !== TT.voice);
      if (tt) { b.classList.add('tts'); b.classList.toggle('other', other); b.querySelector('small').textContent += ' · ' + (/^(piper:)?fr|^kokoro:f/i.test(tt.voice || '') ? 'FR' : 'EN') + (other ? ' ⚠' : ''); }
      b.title = t && t.ms ? 'Émet la mémoire vocale T' + n + ' (' + vmKey(n) + ')' + (tt ? ' (message de synthèse ' + (/^(piper:)?fr|^kokoro:f/i.test(tt.voice || '') ? 'en français' : 'en anglais') + ', voix ' + voiceName(tt.voice) + ', ' + tt.call + ')' +
        (other ? '\n⚠ Pas la voix choisie (' + voiceName(TT.voice) + ') : 🗣 Config. Macros → cochez T' + n + ' → GÉNÉRER pour la refaire.' : '') : '') : 'Mémoire T' + n + ' vide : l’enregistrer avec « 🎙 Ma voix » (votre micro) ou « 🗣 Config. Macros » (voix de synthèse)';
      b.addEventListener('click', () => playVm(n));
      box.appendChild(b);
    }
  }
  // Messages standard en anglais ou en français (fabriqués sur le serveur par espeak-ng, TX call épelé)
  const TTS_DEFS = {
    en: [
      { name: 'CQ TEST', text: 'CQ contest, CQ contest, this is {CALL}, {CALL}, contest.' },
      { name: 'CQ', text: 'CQ, CQ, CQ, this is {CALL}, {CALL}, {CALL}, calling CQ and standing by.' },
      { name: 'TU QRZ', text: 'Thank you, {CALL}, QRZ?' },
      { name: 'MY CALL', text: '{CALL}' },
      { name: 'AGN', text: 'Again please?' },
      { name: 'NR AGN', text: 'Your number again please?' },
      { name: 'QRL?', text: 'Is this frequency in use? This is {CALL}.' },
      { name: '73', text: 'Thank you for the QSO, 73, {CALL} clear.' }
    ],
    // Coupe du REF et QSO en français
    fr: [
      { name: 'CQ COUPE', text: 'CQ Coupe du REF, CQ Coupe du REF, ici {CALL}, {CALL}, contest.' },
      { name: 'APPEL', text: 'Appel général, CQ, CQ, ici {CALL}, {CALL}, {CALL}, à l’écoute.' },
      { name: 'MERCI QRZ', text: 'Merci, {CALL}, QRZ ?' },
      { name: 'INDICATIF', text: '{CALL}' },
      { name: 'REPETEZ', text: 'Pouvez-vous répéter, s’il vous plaît ?' },
      { name: 'NUMERO?', text: 'Votre numéro, s’il vous plaît ?' },
      { name: 'QRL?', text: 'La fréquence est-elle occupée ? Ici {CALL}.' },
      { name: '73', text: 'Merci pour le QSO, 73, {CALL}.' }
    ]
  };
  const TTS_VOICES = {
    en: [['Voix féminines', [['en-us+f2', 'Femme 1 · US'], ['en-us+f3', 'Femme 2 · US'], ['en-us+f4', 'Femme 3 · US'], ['en-us+f5', 'Femme 4 · US'], ['en-us+Annie', 'Annie · US'],
      ['en-us+linda', 'Linda · US'], ['en-us+belinda', 'Belinda · US'], ['en-us+steph', 'Steph · US'], ['en-us+victoria', 'Victoria · US'], ['en-gb+f2', 'Femme 1 · GB'],
      ['en-gb+f3', 'Femme 2 · GB'], ['en-gb+linda', 'Linda · GB'], ['en-gb+victoria', 'Victoria · GB']]],
    ['Voix masculines', [['en-us', 'Homme · US'], ['en-us+m3', 'Homme grave · US'], ['en-gb', 'Homme · GB'], ['en-gb+m3', 'Homme grave · GB']]]],
    fr: [['Voix féminines', [['fr+f2', 'Femme 1'], ['fr+f3', 'Femme 2'], ['fr+f4', 'Femme 3'], ['fr+Annie', 'Annie'], ['fr+linda', 'Linda'], ['fr+victoria', 'Victoria']]],
      ['Voix masculines', [['fr', 'Homme'], ['fr+m3', 'Homme grave']]]]
  };
  // T1 … T8 : messages proposés ; T9 … T24 : vides (à écrire), non cochés
  const defItems = (lang) => TTS_DEFS[lang].map((x) => Object.assign({ on: true }, x)).concat(Array.from({ length: VM_N - 8 }, () => ({ on: false, name: '', text: '' })));
  function ttsLoad() {
    let o = null;
    try { o = JSON.parse(LS.get('ssbtts', 'null')); } catch (e) { o = null; }
    o = o && typeof o === 'object' ? o : {};
    // Ancien format (anglais seul) : repris comme jeu anglais
    if (Array.isArray(o.items) && o.items.length >= 8 && !o.sets) { o.sets = { en: o.items }; o.voices = { en: o.voice || 'en-us+f2' }; }
    delete o.items; delete o.voice;
    o.sets = o.sets || {};
    o.voices = o.voices || {};
    for (const l of ['en', 'fr']) {
      if (!Array.isArray(o.sets[l]) || o.sets[l].length < 8) o.sets[l] = defItems(l);
      // Anciennes listes de 8 : complétées jusqu'à T24 (messages déjà écrits gardés)
      else if (o.sets[l].length < VM_N) o.sets[l] = o.sets[l].concat(defItems(l).slice(o.sets[l].length));
      else if (o.sets[l].length > VM_N) o.sets[l] = o.sets[l].slice(0, VM_N);
      if (!o.voices[l]) o.voices[l] = l === 'fr' ? 'fr+f2' : 'en-us+f2';
    }
    o.lang = o.lang === 'fr' ? 'fr' : 'en';
    o.speed = Number(o.speed) || 175;
    return o;
  }
  const TT = ttsLoad();
  // Messages et voix de la langue choisie
  Object.defineProperty(TT, 'items', { get() { return TT.sets[TT.lang]; }, set(v) { TT.sets[TT.lang] = v; }, enumerable: false });
  Object.defineProperty(TT, 'voice', { get() { return TT.voices[TT.lang]; }, set(v) { TT.voices[TT.lang] = v; }, enumerable: false });
  function ttsVoices() {
    const sel = $('ssTtsV');
    sel.textContent = '';
    // Voix naturelles (Piper, installées sur le serveur par deploy/install-voix.sh) : en premier, choisies d'office une fois
    // Voix naturelles : Kokoro (les plus réalistes, deploy/install-kokoro.sh) puis Piper (deploy/install-voix.sh)
    const nat = (S.pv || []).filter((v) => v.lang === TT.lang);
    const ko = nat.filter((v) => v.kind === 'kokoro'), pi = nat.filter((v) => v.kind !== 'kokoro');
    for (const [label, list] of [['Voix Kokoro (les plus réalistes)', ko], ['Voix Piper', pi]]) {
      if (!list.length) continue;
      const og = document.createElement('optgroup');
      og.label = label;
      for (const v of list) og.appendChild(new Option(v.name, v.id));
      sel.appendChild(og);
    }
    if (!nat.length) { const o = new Option('Voix naturelles à installer sur le serveur (install-kokoro.sh / install-voix.sh)', ''); o.disabled = true; sel.appendChild(o); }
    TT.natAuto = TT.natAuto || {};
    if (nat.length && !TT.natAuto[TT.lang] && !/^(piper|kokoro):/.test(TT.voice || '')) { TT.voice = nat[0].id; TT.natAuto[TT.lang] = 1; ttsSave(); }
    // Kokoro installé : choisi une fois d'office (le plus réaliste), à la place d'une voix Piper
    if (ko.length && !TT.natAuto['k' + TT.lang] && !/^kokoro:/.test(TT.voice || '')) { TT.voice = ko[0].id; TT.natAuto['k' + TT.lang] = 1; ttsSave(); }
    // Seulement les voix naturelles : les voix espeak-ng (robotiques, hachées) ne sont plus proposées
    if (nat.length && !/^(piper|kokoro):/.test(TT.voice || '')) { TT.voice = nat[0].id; ttsSave(); }
    sel.disabled = !nat.length;
    sel.title = nat.length ? 'Voix naturelle (Piper) des messages vocaux' : 'Voix naturelles pas encore installées sur le serveur : sudo bash /opt/remote-station/deploy/install-voix.sh';
    sel.value = TT.voice;
    if (sel.value !== TT.voice && sel.options.length) { const f = Array.from(sel.options).find((o) => !o.disabled); if (f) { sel.value = f.value; TT.voice = f.value; } }
  }
  const ttsSave = () => LS.set('ssbtts', JSON.stringify(TT));
  const PHON = { A: 'Alfa', B: 'Bravo', C: 'Charlie', D: 'Delta', E: 'Echo', F: 'Foxtrot', G: 'Golf', H: 'Hotel', I: 'India', J: 'Juliett', K: 'Kilo', L: 'Lima', M: 'Mike',
    N: 'November', O: 'Oscar', P: 'Papa', Q: 'Quebec', R: 'Romeo', S: 'Sierra', T: 'Tango', U: 'Uniform', V: 'Victor', W: 'Whiskey', X: 'X-ray', Y: 'Yankee', Z: 'Zulu' };
  const DIGW = ['Zero', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine'];
  const txNow = () => { const st = api.state(); return String((st && st.txCall) || '').toUpperCase(); };
  function ttsDraw() {
    const L = $('ssTtsL');
    L.textContent = '';
    TT.items.forEach((it, i) => {
      const row = document.createElement('div');
      row.className = 'ssb-ttsi';
      row.innerHTML = '<label title="' + vmKey(i + 1) + '"><input type="checkbox"> T' + (i + 1) + '</label><input class="nm" maxlength="16" spellcheck="false"><input class="tx" maxlength="200" spellcheck="false"><small class="vv"></small>';
      // Voix avec laquelle la mémoire est faite en ce moment (orange : pas la voix choisie ci-dessus)
      const tt = S.tts && S.tts[i + 1];
      const vv = row.querySelector('.vv');
      vv.textContent = tt ? voiceName(tt.voice) : (S.vm && S.vm.t && S.vm.t[i] && S.vm.t[i].ms ? 'au micro' : 'vide');
      vv.classList.toggle('other', !!(tt && tt.voice !== TT.voice));
      vv.title = tt ? 'Faite avec la voix ' + voiceName(tt.voice) + (tt.voice !== TT.voice ? ' : pas la voix choisie, cochez-la et GÉNÉRER pour la refaire' : '') : '';
      const [cb, nm, tx] = row.querySelectorAll('input');
      cb.checked = it.on !== false;
      nm.value = it.name;
      tx.value = it.text;
      cb.addEventListener('change', () => { it.on = cb.checked; ttsSave(); });
      nm.addEventListener('input', () => { it.name = nm.value.toUpperCase(); ttsSave(); });
      tx.addEventListener('input', () => { it.text = tx.value; ttsSave(); });
      L.appendChild(row);
    });
    $('ssTtsLang').value = TT.lang;
    TT.pron = TT.pron || {};
    $('ssTtsP').value = TT.pron[TT.lang] || '';
    ttsVoices();
    $('ssTtsS').value = TT.speed;
    $('ssTtsSo').textContent = TT.speed + ' mots/min';
    if (TT.gap == null) TT.gap = 70;
    $('ssTtsG').value = TT.gap;
    $('ssTtsGo2').textContent = TT.gap + ' ms';
    ttsCall();
  }
  function ttsCall() {
    const c = txNow();
    const dg = TT.lang === 'fr' ? ['Zéro', 'Un', 'Deux', 'Trois', 'Quatre', 'Cinq', 'Six', 'Sept', 'Huit', 'Neuf'] : DIGW;
    $('ssTtsEx').textContent = c ? c + ' → ' + c.split('').map((x) => (/\d/.test(x) ? dg[+x] : PHON[x] || x)).join(' ') : 'TX call inconnu';
    $('ssTtsGo').textContent = 'GÉNÉRER' + (c ? ' POUR ' + c : '');
  }
  $('ssTtsX').addEventListener('click', () => { $('ssTts').hidden = true; });
  $('ssTtsBtn').addEventListener('click', () => { const p = $('ssTts'); p.hidden = !p.hidden; if (!p.hidden) { $('ssRec').hidden = true; ttsDraw(); } });
  $('ssTtsV').addEventListener('change', () => { TT.voice = $('ssTtsV').value; ttsSave(); ttsDraw(); drawVk(); });
  $('ssTtsS').addEventListener('input', () => { TT.speed = Number($('ssTtsS').value); $('ssTtsSo').textContent = TT.speed + ' mots/min'; ttsSave(); });
  $('ssTtsG').addEventListener('input', () => { TT.gap = Number($('ssTtsG').value); $('ssTtsGo2').textContent = TT.gap + ' ms'; ttsSave(); });
  $('ssTtsP').addEventListener('input', () => { TT.pron = TT.pron || {}; TT.pron[TT.lang] = $('ssTtsP').value; ttsSave(); });
  // « mot=dit comme », une ligne par mot
  function pronObj() {
    const o = {};
    for (const line of String((TT.pron && TT.pron[TT.lang]) || '').split(/\n/)) {
      const m = /^\s*([^=]{1,40}?)\s*=\s*(.{1,60}?)\s*$/.exec(line);
      if (m) o[m[1]] = m[2];
    }
    return o;
  }
  // Messages proposés : T1 … T8 seulement (T9 … T24 gardés tels quels)
  $('ssTtsDef').addEventListener('click', () => { TT.items = defItems(TT.lang).slice(0, 8).concat(TT.items.slice(8)); ttsSave(); ttsDraw(); });
  if ($('ssTtsAll')) $('ssTtsAll').addEventListener('click', () => { for (const it of TT.items) it.on = true; ttsSave(); ttsDraw(); });
  $('ssTtsLang').addEventListener('change', () => { TT.lang = $('ssTtsLang').value === 'fr' ? 'fr' : 'en'; ttsSave(); ttsDraw(); });
  $('ssTtsGo').addEventListener('click', () => {
    if (!host) return toast('Page d’origine fermée.', 'warn');
    if (!/^(piper|kokoro):/.test(TT.voice || '')) return toast('Voix naturelles pas encore installées sur le serveur : sudo bash /opt/remote-station/deploy/install-kokoro.sh (ou install-voix.sh), puis Ctrl+F5.', 'warn', 9000);
    const items = TT.items.map((it, i) => ({ n: i + 1, name: it.name, text: it.text, voice: TT.voice, speed: TT.speed, gap: TT.gap == null ? 70 : TT.gap, pron: pronObj(), on: it.on })).filter((x) => x.on !== false && x.text.trim());
    if (!items.length) return toast('Cochez au moins une mémoire.', 'warn');
    const busy = items.filter((x) => vmFilled(x.n) && !(S.tts && S.tts[x.n])).map((x) => 'T' + x.n);
    if (busy.length && !window.confirm('Remplacer ' + busy.join(', ') + ' (enregistrées au micro) par les messages en anglais ?')) return;
    api.send({ t: 'vm_tts', items: items.map(({ on, ...x }) => x) });
    $('ssTts').hidden = true; // réglages gardés : le cadre se referme
    toast('Fabrication des messages pour ' + txNow() + '…', '', 4000);
  });
  setInterval(() => { if (!$('ssTts').hidden) ttsCall(); }, 1000);
  // ▶ Écouter : la voix choisie sur le message T1 (ou le premier coché), joué dans ce PC
  $('ssTtsTry').addEventListener('click', () => {
    if (!host) return toast('Page d’origine fermée.', 'warn');
    if (!/^(piper|kokoro):/.test(TT.voice || '')) return toast('Voix naturelles pas encore installées sur le serveur : sudo bash /opt/remote-station/deploy/install-kokoro.sh (ou install-voix.sh), puis Ctrl+F5.', 'warn', 9000);
    const it = TT.items.find((x) => x.on !== false && x.text.trim()) || TT.items[0];
    api.send({ t: 'vm_tts_try', text: it.text, voice: TT.voice, speed: TT.speed, gap: TT.gap == null ? 70 : TT.gap, pron: pronObj() });
    toast('Voix « ' + $('ssTtsV').selectedOptions[0].textContent + ' » : préparation…', '', 2500);
  });
  let ttsCtx = null;
  function ttsPlay(b64) {
    try {
      const raw = atob(b64);
      const pcm = new Float32Array(raw.length);
      for (let i = 0; i < raw.length; i++) pcm[i] = ULAW_DEC[raw.charCodeAt(i)];
      ttsCtx = ttsCtx || new AudioContext();
      if (ttsCtx.state === 'suspended') ttsCtx.resume();
      const buf = ttsCtx.createBuffer(1, pcm.length, 12000);
      buf.copyToChannel(pcm, 0);
      const src = ttsCtx.createBufferSource();
      src.buffer = buf;
      src.connect(ttsCtx.destination);
      // Départ 0,25 s plus tard : la sortie son (casque Bluetooth, carte USB) a le temps de se réveiller, le début n'est pas coupé
      src.start(ttsCtx.currentTime + 0.25);
    } catch (e) { toast('Lecture impossible dans ce navigateur.', 'warn'); }
  }
  const ULAW_DEC = (() => {
    const t = new Float32Array(256);
    for (let i = 0; i < 256; i++) { const u = ~i & 0xff; const e = (u >> 4) & 7; let s2 = (((u & 0x0f) << 3) + 0x84) << e; s2 -= 0x84; t[i] = ((u & 0x80) ? -s2 : s2) / 32768; }
    return t;
  })();
  function vmFilled(n) { const t = S.vm && S.vm.t && S.vm.t[n - 1]; return !!(t && t.ms); }

  // ------------------------------------------------------------------ 🎙 Ma voix : T1 … T8 enregistrées au micro de ce PC (tous les TRX)
  const REC = { n: 0, t0: 0, timer: null, dl: null, ctx: null, src: null, playN: 0 };
  const REC_MAX = 30; // secondes
  function recMsg(t, warn) { const e = $('ssRecM'); e.textContent = t || ''; e.classList.toggle('warn', !!warn); }
  function recDraw() {
    if ($('ssRec').hidden) return;
    const L = $('ssRecL');
    for (let n = 1; n <= VM_N; n++) {
      let row = L.querySelector('[data-n="' + n + '"]');
      if (!row) {
        row = document.createElement('div');
        row.className = 'ssb-reci'; row.dataset.n = n;
        row.innerHTML = '<b title="' + vmKey(n) + '">T' + n + '</b><input class="nm" maxlength="16" spellcheck="false" placeholder="nom (CQ, QRZ…)"><span class="st"></span>' +
          '<button type="button" class="rec">● REC</button><button type="button" class="pl" title="Réécouter dans ce PC (rien n’est émis)">▶</button><button type="button" class="dl" title="Effacer cette mémoire">✕</button>';
        const nm = row.querySelector('.nm');
        nm.addEventListener('change', () => api.send({ t: 'vm_name', n, name: nm.value.toUpperCase() }));
        nm.addEventListener('keydown', (e) => { if (e.key === 'Enter') nm.blur(); e.stopPropagation(); });
        row.querySelector('.rec').addEventListener('click', () => (REC.n === n ? recStop() : recStart(n)));
        row.querySelector('.pl').addEventListener('click', () => recListen(n));
        row.querySelector('.dl').addEventListener('click', () => {
          if (!vmFilled(n)) return;
          if (!window.confirm('Effacer la mémoire T' + n + ' ?')) return;
          api.send({ t: 'vm_del', n });
        });
        L.appendChild(row);
      }
      const t = S.vm && S.vm.t && S.vm.t[n - 1];
      const tt = S.tts && S.tts[n];
      const nm = row.querySelector('.nm');
      if (document.activeElement !== nm) nm.value = (t && t.name) || '';
      const st = row.querySelector('.st');
      if (REC.n === n) {
        const s = Math.min(REC_MAX, (VX && VX.recLen ? VX.recLen() : 0) / 12000);
        st.textContent = '● ' + s.toFixed(1).replace('.', ',') + ' / ' + REC_MAX + ' s';
        st.className = 'st on';
      } else {
        st.textContent = t && t.ms ? (t.ms / 1000).toFixed(1).replace('.', ',') + ' s · ' + (tt ? 'synthèse ' + (/^(piper:)?fr|^kokoro:f/i.test(tt.voice || '') ? 'FR' : 'EN') : 'votre voix') : 'vide';
        st.className = 'st' + (t && t.ms ? (tt ? ' tts' : ' mine') : '');
      }
      const rb = row.querySelector('.rec');
      rb.textContent = REC.n === n ? '■ STOP' : '● REC';
      rb.classList.toggle('on', REC.n === n);
      rb.disabled = !!REC.n && REC.n !== n;
      row.querySelector('.pl').disabled = !vmFilled(n) || !!REC.n;
      row.querySelector('.pl').classList.toggle('on', REC.playN === n);
      row.querySelector('.dl').disabled = !vmFilled(n) || !!REC.n;
    }
  }
  function recStart(n) {
    if (!host) return toast('Page d’origine fermée : rouvrez le TRX SSB depuis le dashboard.', 'warn');
    if (!VX || !VX.recStart) return toast('Micro indisponible dans cette page.', 'warn');
    if (!VX.micOn()) { recMsg('Mettez d’abord votre micro en service (cadre micro ci-dessus), puis ● REC.', true); return toast('REC : mettez d’abord votre micro en service.', 'warn', 5000); }
    const st = api.state();
    if ((st && st.tx) || P.held) return toast('REC : pas pendant une émission.', 'warn', 3000);
    recListenStop();
    if (!VX.recStart(12000 * REC_MAX)) return toast('REC : micro pas prêt.', 'warn');
    REC.n = n; REC.t0 = Date.now();
    recMsg('Enregistrement de T' + n + ' : parlez, puis ■ STOP (' + REC_MAX + ' s au plus).');
    clearInterval(REC.timer);
    REC.timer = setInterval(() => { if (!REC.n) return clearInterval(REC.timer); if (VX.recLen() >= 12000 * REC_MAX) recStop(); else recDraw(); }, 100);
    recDraw();
  }
  function recStop() {
    const n = REC.n;
    REC.n = 0; clearInterval(REC.timer);
    const pcm = VX && VX.recStop ? VX.recStop() : null;
    if (!n || !pcm) { recDraw(); return; }
    if (pcm.length < 6000) { recMsg('Trop court : 0,5 s au moins.', true); recDraw(); return; }
    // Petit fondu au début et à la fin (pas de clic), puis envoi au serveur en µ-law 12 kHz, morceaux de 36 ko
    const f = Math.min(240, pcm.length >> 2);
    for (let i = 0; i < f; i++) { pcm[i] *= i / f; pcm[pcm.length - 1 - i] *= i / f; }
    const u = window.ULAW.encodeFrame(pcm, 12000, 0x05).subarray(1), CH = 36000, total = Math.ceil(u.length / CH);
    for (let i = 0; i < total; i++) {
      let s2 = '';
      const part = u.subarray(i * CH, (i + 1) * CH);
      for (let j = 0; j < part.length; j += 8192) s2 += String.fromCharCode.apply(null, part.subarray(j, j + 8192));
      api.send({ t: 'vm_put', n, i, total, d: btoa(s2) });
    }
    recMsg('T' + n + ' envoyée au serveur (' + (pcm.length / 12000).toFixed(1).replace('.', ',') + ' s).');
    recDraw();
  }
  function recListen(n) {
    if (REC.playN === n) return recListenStop();
    if (!vmFilled(n)) return;
    REC.dl = { n, parts: [] };
    api.send({ t: 'vm_get', n, tag: 'ssb' });
  }
  function recListenStop() { if (REC.src) { try { REC.src.stop(); } catch (e) { /* */ } } REC.src = null; REC.playN = 0; recDraw(); }
  function recOnData(m) {
    if (!REC.dl || REC.dl.n !== m.n) return;
    REC.dl.parts[m.i] = m.d;
    if (REC.dl.parts.filter((x) => x != null).length < m.total) return;
    const raw = atob(REC.dl.parts.join(''));
    REC.dl = null;
    if (!raw.length) return toast('T' + m.n + ' : mémoire vide.', 'warn');
    const pcm = new Float32Array(raw.length);
    for (let i = 0; i < raw.length; i++) pcm[i] = ULAW_DEC[raw.charCodeAt(i)];
    try {
      recListenStop();
      REC.ctx = REC.ctx || new AudioContext();
      if (REC.ctx.state === 'suspended') REC.ctx.resume();
      const b = REC.ctx.createBuffer(1, pcm.length, 12000);
      b.copyToChannel(pcm, 0);
      const src = REC.src = REC.ctx.createBufferSource();
      src.buffer = b; src.connect(REC.ctx.destination);
      src.onended = () => { if (REC.src === src) { REC.src = null; REC.playN = 0; recDraw(); } };
      src.start(REC.ctx.currentTime + 0.15);
      REC.playN = m.n;
      recDraw();
    } catch (e) { toast('Lecture impossible dans ce navigateur.', 'warn'); }
  }
  $('ssRecBtn').addEventListener('click', () => {
    const p = $('ssRec');
    p.hidden = !p.hidden;
    if (!p.hidden) { $('ssTts').hidden = true; const on = !!(VX && VX.micOn()); recMsg(on ? '' : 'Micro hors service : mettez-le en service pour enregistrer.', !on); recDraw(); }
  });
  $('ssRecX').addEventListener('click', () => { if (REC.n) recStop(); recListenStop(); $('ssRec').hidden = true; });
  function playVm(n) {
    if (!host) return toast('Dashboard non raccroché.', 'warn');
    if (!vmFilled(n)) return toast('Mémoire T' + n + ' vide : enregistrez-la avec « 🎙 Ma voix » ou « 🗣 Config. Macros ».', 'warn');
    api.send({ t: 'vm_play', n });
  }

  // ------------------------------------------------------------------ log du contest (comme le TRX CW)
  const CL = { id: '', items: [], esm: LS.get('ssesm', 'run') === 'sp' ? 'sp' : 'run' };
  const E = { call: $('cwpECall'), rs: $('cwpERs'), stx: $('cwpEStx'), rr: $('cwpERr'), srx: $('cwpESrx') };
  const BANDS = [[1.8, 2, '160m'], [3.5, 4, '80m'], [5.3, 5.5, '60m'], [7, 7.3, '40m'], [10.1, 10.15, '30m'], [14, 14.35, '20m'], [18.068, 18.168, '17m'],
    [21, 21.45, '15m'], [24.89, 24.99, '12m'], [28, 29.7, '10m'], [50, 54, '6m'], [144, 146, '2m'], [430, 440, '70cm']];
  const bandOf = (mhz) => { const b = BANDS.find((x) => mhz >= x[0] && mhz <= x[1]); return b ? b[2] : ''; };
  const ymd = (d) => d.getUTCFullYear() + String(d.getUTCMonth() + 1).padStart(2, '0') + String(d.getUTCDate()).padStart(2, '0');
  const stripRs = (x) => String(x || '').toUpperCase().replace(/^5[1-9]\s+/, '').trim();
  // Case « Envoyé » : toujours l'échange à annoncer (zone, puissance… ou le n° de série de ce QSO), sauf si vous l'avez changé
  function fillStx(force) {
    if (!def()) return;
    if (force) delete E.stx.dataset.manual;
    if (E.stx.dataset.manual || document.activeElement === E.stx) return;
    const v = stripRs(exchShown());
    if (E.stx.value !== v) E.stx.value = v;
  }
  E.stx.addEventListener('input', () => { E.stx.value = E.stx.value.toUpperCase(); E.stx.dataset.manual = '1'; });
  function trxMhz() { const st = api.state(); const r = (st && st.radio) || {}; return (Number(r.vfoSel === 1 ? r.freqB : r.freq) || 0) / 1e6; }
  function fromDate() {
    let v = LS.get('ssbfrom_' + CL.id, '');
    if (!/^\d{8}$/.test(v)) v = ymd(new Date(Date.now() - 3 * 86400000));
    return v;
  }
  function askList() { if (CL.id) api.send({ t: 'ctst_list', contest: CL.id, from: fromDate() }); }
  function logSync(id) {
    if (id === CL.id) return;
    CL.id = id;
    CL.items = [];
    const f = fromDate();
    $('cwpFrom').value = f.slice(0, 4) + '-' + f.slice(4, 6) + '-' + f.slice(6, 8);
    drawLog();
    askList();
  }
  function checkDupe() {
    const call = E.call.value.trim().toUpperCase();
    const el = $('cwpDupe');
    if (!call || call.length < 3) { el.textContent = ''; el.className = 'cwp-dupe'; return false; }
    const band = bandOf(trxMhz());
    const d = CL.items.filter((q) => q.call === call && q.band === band);
    const other = CL.items.filter((q) => q.call === call && q.band !== band).map((q) => q.band);
    // Seulement les doublons : « DUPE » clignotant (rien d'affiché = QSO valable)
    el.textContent = d.length ? 'DUPE' : '';
    el.title = d.length ? call + ' déjà contacté sur ' + band + ' à ' + d[d.length - 1].t.slice(0, 2) + ':' + d[d.length - 1].t.slice(2, 4) + ' UTC' + (other.length ? ' (aussi sur ' + Array.from(new Set(other)).join(', ') + ')' : '') : '';
    el.className = 'cwp-dupe' + (d.length ? ' dup' : '');
    return d.length > 0;
  }
  function drawLog() {
    const tb = $('cwpCLog');
    tb.textContent = '';
    // Points de chaque QSO selon le règlement du contest (doublon = 0), dans l'ordre chronologique
    const d0 = def(), R0 = (d0 && RULES[d0.id]) || GENERIC, k0 = kit();
    const my0 = { itu: k0 ? Number(k0.zones().itu) : 27, cqz: k0 ? Number(k0.zones().cqz) : 14 };
    const pts = new Map(), seen0 = new Set();
    for (const q of CL.items.slice().sort((a, b) => (tOf(a) < tOf(b) ? -1 : tOf(a) > tOf(b) ? 1 : 0))) {
      const k = q.call + '|' + q.band;
      if (seen0.has(k)) { pts.set(q, 'dup'); continue; }
      seen0.add(k);
      let p = null;
      try { p = q.dx || q.ct ? R0.pts(q, my0) || 0 : null; } catch (e) { p = null; }
      pts.set(q, p);
    }
    const cname = d0 ? d0.name : '';
    for (const q of CL.items.slice(-1500).reverse()) {
      const tr = document.createElement('tr');
      const p = pts.get(q);
      if (p === 'dup') tr.className = 'dup';
      const cells = [q.t.slice(0, 2) + ':' + q.t.slice(2, 4), q.band, q.call, q.rs || '', q.stx, q.rr || '', q.srx, q.cn || q.dx || '', p === 'dup' ? '0 (doublon)' : p == null ? '…' : String(p), cname];
      cells.forEach((v, i) => { const td = document.createElement('td'); td.textContent = v == null ? '' : v; if (i === 8) td.className = 'r'; tr.appendChild(td); });
      // Clic sur l'indicatif : détails du QSO sous la ligne, pour le corriger
      if (q.id) { const tc = tr.children[2]; tc.classList.add('ssb-qed'); tc.title = 'Clic : détails du QSO (corriger une erreur, supprimer)'; tc.addEventListener('click', (e) => { e.stopPropagation(); qsoOpen(q.id, tr); }); }
      tb.appendChild(tr);
    }
    const per = {};
    const seen = new Set();
    let dup = 0;
    for (const q of CL.items) { const k = q.call + '|' + q.band; if (seen.has(k)) dup++; else { seen.add(k); per[q.band] = (per[q.band] || 0) + 1; } }
    const now = Date.now();
    const t = (q) => Date.UTC(+q.d.slice(0, 4), +q.d.slice(4, 6) - 1, +q.d.slice(6, 8), +q.t.slice(0, 2), +q.t.slice(2, 4), +(q.t.slice(4, 6) || 0));
    const r10 = CL.items.filter((q) => now - t(q) < 600000).length;
    const r60 = CL.items.filter((q) => now - t(q) < 3600000).length;
    $('cwpCStats').innerHTML = '<b>' + CL.items.length + '</b> QSO' + (dup ? ' · <span class="dup">' + dup + ' doublon(s)</span>' : '') +
      ' · ' + (Object.keys(per).map((b) => b + ' ' + per[b]).join(' · ') || '—') + ' · cadence <b>' + (r10 * 6) + '</b>/h (10 min), <b>' + r60 + '</b>/h';
    drawScore();
    drawProb();
  }

  // ------------------------------------------------------------------ détails d'un QSO du log du contest (correction)
  // Clic sur un indicatif du log : le QSO complet est demandé au serveur, puis affiché sous sa ligne (par-dessus les QSO
  // suivants) ; Enregistrer = le QSO corrigé remplace l'ancien dans le carnet général ; Supprimer ; Fermer (ou Échap)
  const QE = { id: '', tr: null, el: null };
  function qsoClose() {
    if (QE.el) QE.el.remove();
    QE.el = null; QE.id = '';
    if (QE.tr) QE.tr.classList.remove('ssb-qsel');
    QE.tr = null;
    if (CL.pend) { CL.pend = false; drawLog(); }
  }
  function qsoOpen(id, tr) {
    if (QE.id === id && QE.el) return qsoClose();
    qsoClose();
    QE.id = id; QE.tr = tr; tr.classList.add('ssb-qsel');
    api.send({ t: 'log_get', id, tag: 'ssbedit' });
  }
  function qsoShow(m) {
    const q = m.qso || {};
    if (!QE.tr || q.id !== QE.id) return;
    const wrap = QE.tr.closest('.cwp-clogw');
    if (!wrap) return;
    const esc = (v) => String(v == null ? '' : v).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
    const d = String(q.qso_date || ''), t = String(q.time_on || '');
    const el = document.createElement('div');
    el.className = 'ssb-qdet';
    const ro = m.can ? '' : ' disabled';
    el.innerHTML = '<div class="ssb-qdh"><b>QSO avec ' + esc(q.call) + '</b> <small>' + esc(q.band || '') + ' · ' + esc(q.submode || q.mode || '') + ' · TX call ' + esc(q.station_callsign || '') + ' · opérateur ' + esc(q.operator || '') + (q.dxcc_pfx ? ' · DXCC ' + esc(q.dxcc_pfx) : '') + '</small></div>' +
      '<div class="ssb-qdg">' +
      '<label>Indicatif <input name="call" maxlength="15" value="' + esc(q.call) + '"' + ro + '></label>' +
      '<label>Date UTC <input name="date" type="date" value="' + (d.length === 8 ? d.slice(0, 4) + '-' + d.slice(4, 6) + '-' + d.slice(6, 8) : '') + '"' + ro + '></label>' +
      '<label>Heure UTC <input name="time" maxlength="8" value="' + (t.length >= 4 ? t.slice(0, 2) + ':' + t.slice(2, 4) + (t.length >= 6 ? ':' + t.slice(4, 6) : '') : '') + '"' + ro + '></label>' +
      '<label>Fréquence MHz <input name="freq" inputmode="decimal" value="' + esc(q.freq) + '"' + ro + '></label>' +
      '<label>Mode <select name="mode"' + ro + '>' + ['USB', 'LSB', 'SSB', 'AM', 'FM'].map((x) => '<option' + (x === (q.submode || q.mode) ? ' selected' : '') + '>' + x + '</option>').join('') + '</select></label>' +
      '<label>RS envoyé <input name="rs" maxlength="8" value="' + esc(q.rst_sent) + '"' + ro + '></label>' +
      '<label>TX # <input name="stx" maxlength="30" value="' + esc(q.stx_string || q.stx || '') + '"' + ro + '></label>' +
      '<label>RS reçu <input name="rr" maxlength="8" value="' + esc(q.rst_rcvd) + '"' + ro + '></label>' +
      '<label>RX # <input name="srx" maxlength="30" value="' + esc(q.srx_string || q.srx || '') + '"' + ro + '></label>' +
      '<label>Nom <input name="name" maxlength="40" value="' + esc(q.name) + '"' + ro + '></label>' +
      '<label>Contest <input name="ct" maxlength="40" value="' + esc(q.contest_id) + '"' + ro + '></label>' +
      '<label class="ssb-qdw">Remarque <input name="comment" maxlength="200" value="' + esc(q.comment) + '"' + ro + '></label>' +
      '</div><div class="ssb-qda">' + (m.can ? '<button type="button" class="btn ssb-qdsave">ENREGISTRER</button><button type="button" class="btn ssb-qddel">SUPPRIMER</button>' : '<span class="ssb-qdro">' + esc(m.why || 'Modification non permise') + '</span>') +
      '<span class="ssb-qdmsg"></span><button type="button" class="btn ssb-qdclose">FERMER</button></div>';
    QE.el = el;
    wrap.appendChild(el);
    el.style.top = (QE.tr.offsetTop + QE.tr.offsetHeight) + 'px';
    el.addEventListener('click', (e) => e.stopPropagation());
    const f = (n) => el.querySelector('[name="' + n + '"]');
    el.querySelector('.ssb-qdclose').addEventListener('click', qsoClose);
    if (!m.can) return;
    el.querySelector('.ssb-qdsave').addEventListener('click', () => {
      const tt = String(f('time').value).replace(/\D/g, '');
      const fr = Number(String(f('freq').value).replace(',', '.'));
      const qso = { call: f('call').value.trim().toUpperCase(), qso_date: f('date').value.replace(/\D/g, ''), time_on: (tt.length === 3 ? '0' + tt : tt).padEnd(6, '0').slice(0, 6),
        time_off: q.time_off, qso_date_off: q.qso_date_off, freq: fr, mode: f('mode').value, rst_sent: f('rs').value.trim(), rst_rcvd: f('rr').value.trim(),
        name: f('name').value.trim(), qth: q.qth, gridsquare: q.gridsquare, comment: f('comment').value.trim(), tx_pwr: q.tx_pwr,
        contest_id: f('ct').value.trim().toUpperCase(), stx_string: f('stx').value.trim().toUpperCase(), srx_string: f('srx').value.trim().toUpperCase(),
        station: q.station_callsign, qo100: q.sat_name === 'QO-100' };
      if (/^\d{1,5}$/.test(qso.stx_string)) qso.stx = qso.stx_string;
      if (/^\d{1,5}$/.test(qso.srx_string)) qso.srx = qso.srx_string;
      for (const k of ['iota', 'wwff_ref', 'pota_ref', 'sota_ref', 'my_iota', 'my_wwff_ref', 'my_pota_ref', 'my_sota_ref']) if (q[k]) qso[k] = q[k];
      if (!(fr > 0)) { el.querySelector('.ssb-qdmsg').textContent = 'Fréquence en MHz ?'; return; }
      api.send({ t: 'log_edit', id: q.id, qso, tag: PTAG });
      el.querySelector('.ssb-qdmsg').textContent = 'Enregistrement…';
    });
    el.querySelector('.ssb-qddel').addEventListener('click', () => {
      if (!window.confirm('Supprimer du carnet le QSO avec ' + q.call + ' (' + (q.band || '') + ', ' + (t.slice(0, 2) + ':' + t.slice(2, 4)) + ' UTC) ?')) return;
      api.send({ t: 'log_del', id: q.id });
      qsoClose();
    });
  }
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && QE.el) qsoClose(); });

  // ------------------------------------------------------------------ score estimé (règlement de chaque contest)
  // Chaque QSO du log du contest porte le pays DXCC et le continent du correspondant (dx, ct) et de la station (mp, mc).
  const LOWB = { '160m': 1, '80m': 1, '40m': 1 };
  const BAND_ORDER = ['160m', '80m', '40m', '20m', '15m', '10m', '60m', '30m', '17m', '12m', '6m', '2m', '70cm'];
  // Pays de l'Union européenne (UBA DX : 2 points pour une station belge)
  const EU_UNION = new Set(['DL', 'F', 'I', 'IS', 'EA', 'EA6', 'EA8', 'EA9', 'CT', 'CT3', 'CU', 'PA', 'LX', 'OE', 'OK', 'OM', 'SP', 'HA', 'YO', 'LZ', 'SV', 'SV5', 'SV9',
    '5B', '9H', 'OH', 'OH0', 'SM', 'OZ', 'EI', 'ES', 'YL', 'LY', 'S5', '9A', 'TK', 'ON']);
  const num = (x) => { const m = /(\d+)/.exec(String(x || '')); return m ? Number(m[1]) : NaN; };
  const section = (x) => { const m = /([A-Z]{2,4})\s*$/.exec(String(x || '').toUpperCase()); return m && m[1] !== 'XXX' ? m[1] : ''; };
  // Préfixe WPX : « ON6DP » → ON6, « W1AW/3 » → W3, « PA/ON6DP » → PA0, sans chiffre : + 0
  function wpxPfx(call) {
    let c = String(call || '').toUpperCase().replace(/\/(P|M|MM|AM|QRP|A|B)$/, '');
    const parts = c.split('/');
    if (parts.length > 1) {
      const a = parts[0], b = parts[1];
      if (/^\d$/.test(b)) { const m = /^([A-Z0-9]*?[A-Z])\d*[A-Z]*$/.exec(a.replace(/\d+[A-Z]*$/, '')); return (m ? m[1] : a.replace(/\d.*$/, '')) + b; }
      c = a.length <= b.length ? a : b;
      if (!/\d/.test(c)) return c.slice(0, 2) + '0';
      return c; // indicatif de préfixe (« VP2E/W1XX », « N8BJQ/KH9 ») : il devient le préfixe
    }
    if (!/\d/.test(c)) return c.slice(0, 2) + '0'; // sans chiffre : 2 premières lettres + 0
    const m = /^(.*\d)[A-Z]+$/.exec(c);
    return m ? m[1] : c;
  }
  // Règles : points d'un QSO et multiplicateurs (par bande ou sur tout le contest)
  const RULES = {
    'CQ-WW-SSB': { note: '0 / 1 / 3 points (même pays / même continent / autre continent) × (zones CQ + pays DXCC) par bande',
      pts: (q) => (q.dx && q.dx === q.mp ? 0 : q.ct === q.mc ? 1 : 3), mul: (q) => { const z = num(q.srx); return [z >= 1 && z <= 40 ? 'Z' + z : '', q.dx ? 'C' + q.dx : '']; } },
    'CQ-WPX-SSB': { note: 'même pays 1 point ; même continent 1 (2 sur 40-160 m) ; autre continent 3 (6 sur 40-160 m) × préfixes WPX (une fois)', all: true,
      pts: (q) => (q.dx && q.dx === q.mp ? 1 : q.ct === q.mc ? (LOWB[q.band] ? 2 : 1) : (LOWB[q.band] ? 6 : 3)), mul: (q) => ['P' + wpxPfx(q.call)] },
    'ARRL-DX-SSB': { note: '3 points par QSO avec W / VE × États et provinces par bande',
      pts: (q) => (q.dx === 'K' || q.dx === 'VE' ? 3 : 0), mul: (q) => { const x = String(q.srx || '').toUpperCase().replace(/[^A-Z]/g, ''); return (q.dx === 'K' || q.dx === 'VE') && x ? ['S' + x] : []; } },
    'IARU-HF': { note: 'même zone ITU 1 point, même continent 3, autre continent 5, sièges IARU 1 × (zones ITU + sièges) par bande',
      pts: (q, my) => { if (/^[A-Z]/.test(String(q.srx || '').trim())) return 1; const z = num(q.srx); return z === my.itu ? 1 : q.ct === q.mc ? 3 : 5; },
      mul: (q) => { const x = String(q.srx || '').toUpperCase().trim(); return [/^[A-Z]/.test(x) ? 'H' + x.replace(/[^A-Z0-9]/g, '') : Number.isFinite(num(x)) ? 'Z' + num(x) : '']; } },
    'DARC-WAEDC-SSB': { note: 'station européenne : 1 point par QSO hors Europe (QTC non comptés) × pays par bande (×4 sur 80 m, ×3 sur 40 m, ×2 au-dessus)',
      pts: (q) => (q.ct && q.ct !== 'EU' ? 1 : 0), mul: (q) => (q.ct && q.ct !== 'EU' ? ['C' + q.dx] : []), w: (b) => ({ '80m': 4, '40m': 3, '160m': 4 }[b] || 2) },
    'UBA-DX-SSB': { note: 'station belge : ON 1 point, Union européenne 2, autres 3 × (pays DXCC + sections UBA) par bande',
      pts: (q) => (q.dx === 'ON' ? 1 : EU_UNION.has(q.dx) ? 2 : 3), mul: (q) => [q.dx ? 'C' + q.dx : '', q.dx === 'ON' && section(q.srx) ? 'S' + section(q.srx) : ''] },
    'ON-CONTEST-SSB': { note: '3 points par QSO (au plus 10 avec votre section par bande) × (sections UBA + pays DXCC hors ON) par bande',
      pts: () => 3, mul: (q) => [section(q.srx) ? 'S' + section(q.srx) : '', q.dx && q.dx !== 'ON' ? 'C' + q.dx : ''] },
    'EU-HF': { note: '1 point par QSO avec l’Europe × années de première licence différentes par bande',
      pts: (q) => (q.ct === 'EU' ? 1 : 0), mul: (q) => { const y = num(q.srx); return q.ct === 'EU' && Number.isFinite(y) ? ['Y' + String(y % 100).padStart(2, '0')] : []; } }
  };
  const GENERIC = { generic: true, note: 'règle générique (1 point par QSO × pays DXCC par bande) : indication seulement, voir le règlement',
    pts: () => 1, mul: (q) => [q.dx ? 'C' + q.dx : ''] };
  const tOf = (q) => q.d + (q.t || '').slice(0, 4);
  function scoreOf(list, R, my) {
    const seen = new Set();
    const bands = {};
    const glob = new Set();
    let Q = 0, P = 0;
    for (const q of list) {
      const k = q.call + '|' + q.band;
      if (seen.has(k)) continue;
      seen.add(k);
      const b = bands[q.band] || (bands[q.band] = { q: 0, p: 0, m: new Set() });
      const p = R.pts(q, my) || 0;
      b.q++; b.p += p; Q++; P += p;
      for (const x of R.mul(q, my) || []) if (x) { if (R.all) { if (!glob.has(x)) { glob.add(x); b.m.add(x); } } else b.m.add(x); }
    }
    let M = 0;
    for (const bn in bands) M += R.all ? 0 : bands[bn].m.size * (R.w ? R.w(bn) : 1);
    if (R.all) M = glob.size;
    return { bands, Q, P, M, S: P * M };
  }
  const fmtN = (n) => Number(n || 0).toLocaleString('fr-BE');
  function drawScore() {
    const d = def();
    if (!d) return;
    const R = RULES[d.id] || GENERIC;
    const k = kit();
    const my = { itu: k ? Number(k.zones().itu) : 27, cqz: k ? Number(k.zones().cqz) : 14 };
    const list = CL.items.slice().sort((a, b) => (tOf(a) < tOf(b) ? -1 : tOf(a) > tOf(b) ? 1 : 0));
    const sc = scoreOf(list, R, my);
    $('ssScNote').textContent = R.generic ? '(estimation)' : '';
    $('ssScNote').title = R.note;
    const tb = $('ssScB');
    tb.textContent = '';
    for (const bn of BAND_ORDER) {
      const b = sc.bands[bn];
      if (!b) continue;
      const tr = document.createElement('tr');
      for (const v of [bn, fmtN(b.q), fmtN(b.p), R.all ? '+' + b.m.size : fmtN(b.m.size * (R.w ? R.w(bn) : 1))]) { const td = document.createElement('td'); td.textContent = v; tr.appendChild(td); }
      tb.appendChild(tr);
    }
    if (!tb.children.length) tb.innerHTML = '<tr><td colspan="4">Aucun QSO</td></tr>';
    $('ssScQ').textContent = fmtN(sc.Q);
    $('ssScP').textContent = fmtN(sc.P);
    $('ssScM').textContent = fmtN(sc.M);
    $('ssScT').textContent = fmtN(sc.S);
    $('ssScT').parentElement.title = R.note;
    // Évolution heure par heure (UTC) : QSO de l'heure, cumul et score à la fin de l'heure
    const hours = [];
    for (const q of list) { const h = q.d + (q.t || '').slice(0, 2); if (!hours.length || hours[hours.length - 1] !== h) hours.push(h); }
    const ev = $('ssEvo');
    ev.textContent = '';
    let cum = 0;
    const rows = [];
    for (const h of Array.from(new Set(hours))) {
      const inH = list.filter((q) => q.d + (q.t || '').slice(0, 2) === h).length;
      cum += inH;
      const upTo = list.filter((q) => q.d + (q.t || '').slice(0, 2) <= h);
      rows.push([h.slice(6, 8) + '/' + h.slice(4, 6) + ' ' + h.slice(8, 10) + ' h', fmtN(inH), fmtN(cum), fmtN(scoreOf(upTo, R, my).S)]);
    }
    for (const r of rows.slice(-24).reverse()) {
      const tr = document.createElement('tr');
      for (const v of r) { const td = document.createElement('td'); td.textContent = v; tr.appendChild(td); }
      ev.appendChild(tr);
    }
    if (!rows.length) ev.innerHTML = '<tr><td colspan="4">—</td></tr>';
  }

  // ------------------------------------------------------------------ indicatifs probables (Super Check Partial + spots)
  const PR = { q: '', list: [], n: 0, asked: '' };
  // Plages SSB des bandes (kHz) : spots du DX cluster à afficher
  const SSB_SEG = { '160m': [1840, 2000], '80m': [3600, 3800], '40m': [7060, 7200], '20m': [14100, 14350], '17m': [18111, 18168], '15m': [21151, 21450],
    '12m': [24931, 24990], '10m': [28300, 29000], '6m': [50100, 50500] };
  function askScp() {
    const q = E.call.value.trim().toUpperCase();
    if (q.length < 2) { PR.q = ''; PR.list = []; PR.asked = ''; return drawProb(); }
    if (q === PR.asked) return;
    PR.asked = q;
    clearTimeout(askScp.t);
    askScp.t = setTimeout(() => api.send({ t: 'scp', q, n: 40 }), 120);
  }
  function pickCall(call, spot) {
    E.call.value = call;
    const k = kit();
    if (k) k.setCall(call);
    drawState.kc = call;
    checkDupe();
    askScp();
    // Spot cliqué : le TRX va sur sa fréquence (en LSB / USB) si vous avez la main
    if (spot && api.iControl()) {
      try { host.api.setFreq(Math.round(spot.f * 1000)); setTimeout(() => { try { if (hostWin.RSDIGI) hostWin.RSDIGI.modeFor(PMODE); } catch (e) {} }, 500); } catch (e) {}
    }
    drawProb();
    if (CL.esm === 'sp' && vmFilled(4)) toast('Entrée : votre indicatif (T4).', '', 2500);
    E.srx.focus();
  }
  function chip(call, cls, sub, title, onClick) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'ssb-pc ' + cls;
    b.textContent = call;
    if (sub) { const s = document.createElement('small'); s.textContent = sub; b.appendChild(s); }
    b.title = title || '';
    b.addEventListener('click', onClick);
    return b;
  }
  function drawProb() {
    const box = $('ssPr');
    if (!box || !def()) return;
    const band = bandOf(trxMhz());
    const worked = new Set(CL.items.filter((q) => q.band === band).map((q) => q.call));
    const any = new Set(CL.items.map((q) => q.call));
    box.textContent = '';
    const typed = E.call.value.trim().toUpperCase();
    if (typed.length >= 2) {
      $('ssPrH').textContent = 'Indicatifs probables · « ' + typed + ' »';
      // Déjà dans le log du contest d'abord, puis la liste Super Check Partial
      const mine = Array.from(any).filter((c) => c.indexOf(typed) >= 0);
      const scp = PR.q === typed ? PR.list : [];
      const all = Array.from(new Set(mine.concat(scp))).slice(0, 40);
      for (const c of all) {
        const dup = worked.has(c);
        box.appendChild(chip(c, dup ? 'dup' : any.has(c) ? '' : 'new', dup ? band : any.has(c) ? 'autre bande' : '', dup ? 'Déjà contacté sur ' + band : 'Cliquer : dans la case Indicatif', () => pickCall(c)));
      }
      $('ssPrNote').textContent = all.length ? 'Vert : pas encore contacté · barré : doublon sur ' + (band || 'cette bande') + '.' : (PR.n ? 'Aucun indicatif connu ne contient « ' + typed + ' ».' : 'Liste Super Check Partial pas encore téléchargée par le serveur.');
      return;
    }
    // Rien de tapé : stations spotées en SSB sur la bande du TRX (DX cluster), les plus récentes d'abord
    const seg = SSB_SEG[band];
    $('ssPrH').textContent = 'Stations spotées ' + (band ? 'sur ' + band : '') + ' (SSB)';
    const k = kit();
    let spots = [];
    try { spots = k && k.spots ? k.spots() : []; } catch (e) { spots = []; }
    spots = spots.filter((s) => seg && s.f >= seg[0] && s.f <= seg[1] && !s.skim && !/\b(CW|FT[48]|RTTY|PSK|WPM|DIGI|JT65|SSTV)\b/i.test(s.cmt))
      .sort((a, b) => b.at - a.at);
    const seen = new Set();
    for (const s of spots) {
      if (seen.has(s.call)) continue;
      seen.add(s.call);
      const dup = worked.has(s.call);
      box.appendChild(chip(s.call, dup ? 'dup' : 'new', (s.f / 1000).toFixed(3).replace('.', ','), (dup ? 'Déjà contacté sur ' + band + ' · ' : 'Cliquer : indicatif + TRX sur ') + s.f.toFixed(1) + ' kHz' + (s.cmt ? ' · ' + s.cmt : ''), () => pickCall(s.call, s)));
      if (seen.size >= 60) break;
    }
    $('ssPrNote').textContent = seen.size ? 'Vert : à contacter · barré : déjà dans le log sur ' + band + '. Tapez le début d’un indicatif : liste Super Check Partial.' : 'Aucun spot SSB sur cette bande pour l’instant. Tapez le début d’un indicatif : liste Super Check Partial (indicatifs actifs en contest).';
  }
  setInterval(() => { if (def() && E.call.value.trim().length < 2) drawProb(); }, 5000);
  function wipe() {
    for (const k of ['call', 'stx', 'srx']) E[k].value = '';
    fillStx(true);
    askScp();
    const k = kit();
    if (k) k.setCall('');
    drawState.kc = '';
    checkDupe();
    E.call.focus();
  }
  function logEntry() {
    const k = kit();
    if (!k || !CL.id) return false;
    const call = E.call.value.trim().toUpperCase();
    if (!/^(?=.*[0-9])[A-Z0-9/]{3,15}$/.test(call)) { toast('Indicatif du correspondant ?', 'warn'); E.call.focus(); return false; }
    if (!E.srx.value.trim()) { toast('Échange reçu ?', 'warn'); E.srx.focus(); return false; }
    const mhz = trxMhz();
    if (!(mhz > 0)) { toast('Fréquence du TRX inconnue : QSO non enregistré.', 'warn'); return false; }
    if (!E.stx.value.trim()) E.stx.value = stripRs(exchShown());
    const d = new Date(k.utcNow());
    const hms = String(d.getUTCHours()).padStart(2, '0') + String(d.getUTCMinutes()).padStart(2, '0') + String(d.getUTCSeconds()).padStart(2, '0');
    const stx = stripRs(E.stx.value);
    const srx = stripRs(E.srx.value);
    const st = api.state();
    const r = (st && st.radio) || {};
    const md = String((r.vfoSel === 1 ? r.modeB : r.mode) || '');
    const qso = { call, qso_date: ymd(d), time_on: hms, time_off: hms, freq: Math.round(mhz * 1e6) / 1e6,
      mode: /^LSB/.test(md) ? 'LSB' : /^USB/.test(md) ? 'USB' : mhz < 10 ? 'LSB' : 'USB',
      rst_sent: E.rs.value.trim() || '59', rst_rcvd: E.rr.value.trim() || '59', contest_id: CL.id, stx_string: stx, srx_string: srx, station: k.myCall() };
    if (/^\d{1,5}$/.test(stx)) qso.stx = stx;
    if (/^\d{1,5}$/.test(srx)) qso.srx = srx;
    api.send({ t: 'log_add', qso, force: true, tag: PTAG, spot: !!(window.RSSPOT && RSSPOT.on()) });
    CL.items.push({ call, band: bandOf(mhz), d: qso.qso_date, t: hms, stx, srx, rs: qso.rst_sent, rr: qso.rst_rcvd });
    if (/<CNTR>|<SERNO>/.test(exchTpl())) k.afterLog(call, S.id); // n° de série suivant (seulement s'il fait partie de l'échange ; tenu par le serveur)
    drawLog();
    for (const x of ['call', 'stx', 'srx']) E[x].value = '';
    delete E.stx.dataset.manual;
    k.setCall('');
    drawState.kc = '';
    checkDupe();
    drawContest();
    return true;
  }
  // Entrée (ESM de N1MM, en phonie) : RUN : vide → T1 (CQ) ; indicatif → échange reçu à taper (vous annoncez le vôtre
  // au micro) ; échange reçu → QSO enregistré + T3 (TU). S&P : indicatif → T4 (votre indicatif) ; échange reçu → QSO enregistré.
  function esmEnter() {
    const call = E.call.value.trim();
    const srx = E.srx.value.trim();
    if (CL.esm === 'run') {
      if (!call) return playVm(1);
      if (!srx) { E.stx.value = stripRs(exchShown()); E.srx.focus(); return; }
      if (logEntry()) { if (vmFilled(3)) playVm(3); E.call.focus(); }
      return;
    }
    if (!call) return toast('Tapez l’indicatif de la station qui appelle CQ.', 'warn');
    if (!srx) { if (vmFilled(4)) playVm(4); E.stx.value = stripRs(exchShown()); E.srx.focus(); return; }
    if (logEntry()) E.call.focus();
  }
  function esmShow() { $('cwpRun').classList.toggle('on', CL.esm === 'run'); $('cwpSp').classList.toggle('on', CL.esm === 'sp'); }
  const esmSet = (v) => { CL.esm = v; LS.set('ssesm', v); esmShow(); E.call.focus(); };
  $('cwpRun').addEventListener('click', () => esmSet('run'));
  $('cwpSp').addEventListener('click', () => esmSet('sp'));
  esmShow();
  for (const key of Object.keys(E)) {
    E[key].addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); esmEnter(); }
      else if (e.key === ' ' && key === 'call') { e.preventDefault(); E.srx.focus(); }
      else if (e.key === ' ' && key === 'srx' && !E.srx.value.trim()) { e.preventDefault(); E.call.focus(); }
    });
  }
  E.call.addEventListener('input', () => {
    E.call.value = E.call.value.toUpperCase().replace(/[^A-Z0-9/?]/g, '');
    askScp();
    drawProb();
    const k = kit();
    if (k) k.setCall(E.call.value);
    drawState.kc = E.call.value.trim().toUpperCase(); // tapé ici : pas à recopier depuis le dashboard
    checkDupe();
  });
  E.srx.addEventListener('input', () => { E.srx.value = E.srx.value.toUpperCase(); });
  E.rs.value = E.rr.value = '59';
  $('cwpELog').addEventListener('click', () => { if (logEntry()) E.call.focus(); });
  $('cwpEWipe').addEventListener('click', wipe);
  document.addEventListener('keydown', (e) => {
    if ((e.key === 'w' || e.key === 'W') && e.altKey) { e.preventDefault(); wipe(); return; }
    // F1 … F12 : T1 … T12 ; Ctrl+F1 … Ctrl+F12 : T13 … T24 (Ctrl+F4 est gardé par Windows : il ferme la fenêtre)
    const f = /^F(\d{1,2})$/.exec(e.key);
    const fn = f ? Number(f[1]) : 0;
    if (fn >= 1 && fn <= 12 && !e.altKey && !e.metaKey && !e.shiftKey) { e.preventDefault(); playVm(fn + (e.ctrlKey ? 12 : 0)); return; }
    if (e.key === 'Escape') api.send({ t: 'vm_stop' });
  });
  $('cwpFrom').addEventListener('change', () => {
    const v = $('cwpFrom').value.replace(/\D/g, '');
    if (/^\d{8}$/.test(v)) LS.set('ssbfrom_' + CL.id, v);
    askList();
  });
  $('cwpCab').addEventListener('click', () => {
    const k = kit();
    const d = def();
    if (!k || !d) return;
    const f = fromDate();
    api.send({ t: 'log_export', fmt: 'cabrillo', callsign: k.myCall(), mine: true, contest: d.id, contestOnly: true, cat: cabCat(), location: d.location || '',
      from: f.slice(0, 4) + '-' + f.slice(4, 6) + '-' + f.slice(6, 8), tag: PTAG });
  });
  // ADIF (.adi) : QSO du contest (même choix que le Cabrillo) ; sans contest : QSO en phonie hors contest
  $('ssAdi').addEventListener('click', () => {
    const k = kit();
    const d = def();
    if (!k || !d) return;
    const f = fromDate();
    api.send({ t: 'log_export', fmt: 'adif', callsign: k.myCall(), mine: true, contest: d.id, contestOnly: true,
      from: f.slice(0, 4) + '-' + f.slice(4, 6) + '-' + f.slice(6, 8), tag: PTAG });
  });
  // LOG SSB : titre = log agrandi au centre de la page ; EXPORTER ▾ = vos QSO en phonie hors contest en un clic,
  // ou une fenêtre de filtres (TX call, opérateur — tous les opérateurs pour un administrateur —, dates, contests)
  {
    const box = $('ssQBox');
    const zoom = (on) => { box.classList.toggle('rt-logbig', on); $('ssLogZoom').textContent = on ? 'LOG SSB ⤡' : 'LOG SSB ⤢'; };
    $('ssLogZoom').addEventListener('click', () => zoom(!box.classList.contains('rt-logbig')));
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && box.classList.contains('rt-logbig')) zoom(false); });
    const xm = $('ssLogXm');
    $('ssLogX').addEventListener('click', (e) => { e.stopPropagation(); xm.hidden = !xm.hidden; });
    document.addEventListener('click', () => { xm.hidden = true; });
    const esc = (v) => String(v == null ? '' : v).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
    const exp = (kind) => {
      const k = kit();
      if (!k) return;
      if (kind === 'mine') return api.send({ t: 'log_export', fmt: 'adif', callsign: k.myCall(), mine: true, phoneOnly: !FDV, fdvOnly: FDV || undefined, tag: PTAG });
      let me = {};
      try { me = (host && host.me && host.me()) || {}; } catch (e) { /* */ }
      const adm = !!me.admin, my = String(me.call || '').toUpperCase();
      const calls = Array.from(new Set([k.myCall()].concat(Array.from(document.querySelectorAll('#cwpTxCall option')).map((o) => o.value), my ? [my] : []).map((c) => String(c || '').toUpperCase()).filter(Boolean)));
      const ops = Array.from(new Set(Array.from(document.querySelectorAll('#ssQLog tr')).map((tr) => (tr.lastChild && tr.lastChild.textContent) || '').filter((x) => /^[A-Z0-9/]{3,15}$/.test(x) && x !== my)));
      const old = $('ssExpDlg');
      if (old) old.remove();
      const dlg = document.createElement('dialog');
      dlg.id = 'ssExpDlg';
      dlg.className = 'macro-dlg qso-log rt-expdlg';
      dlg.innerHTML = '<form method="dialog"><h3>Exporter des QSO en phonie en ADIF (.adi)</h3><div class="ql-g">' +
        '<label>TX call <select name="cs">' + (adm ? '<option value="">Tous les TX call</option>' : '') + calls.map((c) => '<option' + (c === String(k.myCall()).toUpperCase() ? ' selected' : '') + '>' + esc(c) + '</option>').join('') + '</select></label>' +
        '<label>Opérateur <select name="op"><option value="mine">Mes QSO (' + esc(my) + ')</option>' + (adm ? '<option value="">Tous les opérateurs</option>' + ops.map((o) => '<option value="' + esc(o) + '">' + esc(o) + '</option>').join('') : '') + '</select></label>' +
        '<label>QSO <select name="ct"><option value="">Phonie hors contest</option><option value="*">Toute la phonie (contests compris)</option></select></label><span></span>' +
        '<label>Du <input type="date" name="from"></label><label>Au <input type="date" name="to"></label></div>' +
        '<p class="md-prev">' + (adm ? 'Administrateur : tous les TX call et tous les opérateurs possibles.' : 'Vos QSO seulement : sous votre indicatif, ou faits par vous sous un indicatif de la station.') + ' Le log d’un contest (Cabrillo / ADIF) s’exporte dans le cadre du contest.</p>' +
        '<div class="md-act"><span></span><button class="btn" value="cancel">Annuler</button><button class="btn btn-primary" type="button" data-a="go">Exporter</button></div></form>';
      document.body.appendChild(dlg);
      const f = dlg.querySelector('form');
      dlg.querySelector('[data-a="go"]').addEventListener('click', () => {
        const op = f.op.value;
        api.send({ t: 'log_export', fmt: 'adif', callsign: f.cs.value, mine: op === 'mine', operator: op && op !== 'mine' ? op : undefined, phoneOnly: !FDV, fdvOnly: FDV || undefined,
          allContests: f.ct.value === '*' || undefined, from: f.from.value || undefined, to: f.to.value || undefined, tag: PTAG });
        dlg.close();
      });
      dlg.addEventListener('close', () => dlg.remove());
      try { dlg.showModal(); } catch (e) { dlg.setAttribute('open', ''); }
    };
    xm.querySelectorAll('[data-x]').forEach((b) => b.addEventListener('click', () => { xm.hidden = true; exp(b.dataset.x); }));
  }
  function saveFile(m) {
    const blob = new Blob([m.data], { type: (m.mime || 'text/plain') + ';charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = m.name;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
    toast(m.count + ' QSO dans ' + m.name + (/\.adi$/.test(m.name) ? ' (ADIF).' : ' (Cabrillo).'), '', 5000);
  }

  // ------------------------------------------------------------------ phonie : micro, égaliseurs (SSB CONFIGURATION) et PTT
  // Même module que la face avant (voice.js), ici dans cette page : la voix part par la connexion de la page d'origine.
  const VX = window.RSVOICE || null;
  const P = { held: false, hb: null, voiceOn: false };
  function voiceInit() {
    if (!VX || !host) return;
    VX.init({ compact: true, auto: true, send: api.send, say: (msg, lvl, ms) => toast(msg, lvl === 'warn' || lvl === 'error' ? 'warn' : '', ms),
      iControl: api.iControl, state: api.state, me: () => { try { return host.me ? host.me() : null; } catch (e) { return null; } },
      rig: () => { try { return host.api.rig(); } catch (e) { return {}; } },
      setSink: (id) => { try { if (host.setSink) host.setSink(id); } catch (e) {} },
      txSet: (id, v) => { try { return host.txSet ? host.txSet(id, v) : 'Indisponible'; } catch (e) { return 'Indisponible'; } },
      sendBin: (buf) => { try { if (host.sendBin) host.sendBin(buf); } catch (e) {} } });
    try { VX.onHello(host.me ? host.me() : {}); } catch (e) {}
    // ÉCOUTER LE TRX : à droite de MONITORING (l'écoute est jouée par le dashboard ou la face avant qui a ouvert cette page)
    if ($('vxMonBtn') && !$('ssListen')) {
      const b = document.createElement('button');
      b.type = 'button'; b.id = 'ssListen'; b.className = 'btn ss-listen'; b.setAttribute('aria-pressed', 'false');
      b.addEventListener('click', () => {
        const L = host && host.listen;
        if (!L) return toast('Écoute indisponible : la page qui a ouvert celle-ci est fermée ou trop ancienne (rechargez-la).', 'warn');
        if (L.on()) L.stop(); else if (!L.start()) toast('Le navigateur bloque le son : cliquez une fois dans le dashboard, puis réessayez.', 'warn', 6000);
        drawListenBtn();
      });
      // Bouton et son volume dans un même bloc : toujours côte à côte, quelle que soit la mise en page de la ligne
      const wrap = document.createElement('span');
      wrap.className = 'ss-listenw'; wrap.id = 'ssListenW';
      wrap.appendChild(b);
      $('vxMonBtn').after(wrap);
      // Volume de l'écoute du TRX (celui du dashboard) — le « Volume » à côté de MONITORING est celui de votre voix
      const vl = document.createElement('label');
      vl.className = 'ss-lvol'; vl.id = 'ssLVolW';
      vl.title = 'Volume de l’écoute du TRX (le même que dans le dashboard)';
      vl.innerHTML = 'Volume TRX <input type="range" id="ssLVol" min="0" max="150" step="1"> <output id="ssLVolV"></output>';
      vl.querySelector('input').addEventListener('input', (ev) => {
        try { const r = host.listen.vol(Number(ev.target.value)); if (r) $('ssLVolV').textContent = r.v + ' %'; } catch (e) {}
      });
      wrap.appendChild(vl);
      drawListenBtn();
    }
    // Réglages micro du TRX (GAIN MICRO, PROC, MIC EQ, NIVEAU PROC, VOX) sur la ligne SSB CONFIGURATION, à droite de TRX EQ ;
    // « Profil de … » tout à droite : tous les réglages sur une seule ligne
    { const t = $('vxTrxBtn'), m = $('ssMic'), pr = $('vxProf');
      if (t && m && m.previousElementSibling !== t) { t.after(m); m.classList.add('vx-mic'); }
      if (pr && m && m.nextElementSibling !== pr) m.after(pr); }
  }
  function pttReason() {
    const st = api.state();
    const me = host && host.me ? host.me() : null;
    if (!host) return 'Page d’origine fermée';
    if (!st || !st.station) return 'Station hors ligne';
    if (!st.radio || !st.radio.connected) return 'TRX non connecté';
    if (!api.iControl()) return 'Prenez la main pour émettre';
    if (st.radio.vox) return 'VOX actif au club : coupez-le d’abord';
    if (!st.txOk) return st.radio.txVfo === 1 ? 'VFO B (SPLIT) hors des bandes autorisées' : 'Hors des bandes autorisées';
    if (me && st.radio.power != null && st.radio.power > me.maxWatts) return 'Puissance au-delà de votre limite (' + me.maxWatts + ' W)';
    if (st.swrLock) return st.swrLock.text || 'ROS trop élevé ici';
    return null;
  }
  function pttDown() {
    if (P.held) return;
    const why = pttReason();
    if (why) return toast(why, 'warn');
    P.held = true;
    P.voiceOn = !!(VX && VX.txStart());
    if (FDV && !P.voiceOn) { P.held = false; return toast('FreeDV a besoin de votre voix : activez « MICRO » (SSB CONFIGURATION) pour parler depuis ce PC.', 'warn', 6000); }
    if (host) host.extTalk = P.voiceOn;
    api.send({ t: 'ptt', on: true, voice: P.voiceOn, fdv: FDV || undefined });
    P.hb = setInterval(() => api.send({ t: 'ptt', on: true, voice: P.voiceOn, fdv: FDV || undefined }), 400);
    $('ptt').classList.add('held');
    if (!P.voiceOn) toast(FDV ? 'PTT sans votre micro : FreeDV a besoin de votre voix. Activez « MICRO » (SSB CONFIGURATION) pour parler depuis ce PC.' : 'PTT sans votre micro : activez « MICRO » (SSB CONFIGURATION) pour parler depuis ce PC.', 'warn', 5000);
  }
  function pttUp() {
    if (!P.held) return;
    P.held = false;
    clearInterval(P.hb);
    if (VX) VX.txEnd();
    try { if (host) host.extTalk = false; } catch (e) {}
    api.send({ t: 'ptt', on: false });
    $('ptt').classList.remove('held');
  }
  {
    const b = $('ptt');
    b.addEventListener('pointerdown', (ev) => { ev.preventDefault(); try { b.setPointerCapture(ev.pointerId); } catch (e) {} pttDown(); });
    b.addEventListener('pointerup', pttUp);
    b.addEventListener('pointercancel', pttUp);
    b.addEventListener('lostpointercapture', pttUp);
    // Barre d'espace = PTT, hors des cases de saisie (où elle passe au champ suivant)
    const typing = (e) => e.target && /INPUT|TEXTAREA|SELECT/.test(e.target.tagName);
    document.addEventListener('keydown', (e) => { if (e.key === ' ' && !typing(e)) { e.preventDefault(); if (!e.repeat) pttDown(); } });
    document.addEventListener('keyup', (e) => { if (e.key === ' ' && P.held) { e.preventDefault(); pttUp(); } });
    window.addEventListener('blur', pttUp); // sécurité : fenêtre quittée pendant l'émission
  }

  // ------------------------------------------------------------------ fiche de QSO du carnet (sans contest)
  const LOG = window.RSLOG || null;
  function logInit() {
    if (!LOG || !host) return;
    LOG.init({ send: api.send, state: api.state, iControl: api.iControl, tag: PTAG, formOnly: true, phone: true, freedv: FDV,
      say: (msg, lvl, ms) => toast(msg, lvl === 'warn' || lvl === 'error' ? 'warn' : '', ms) });
    if (!LOG.mounted) { LOG.mount($('ssLog')); LOG.mounted = true; }
    try { const me = host.me ? host.me() : null; if (me) LOG.onHello(me); } catch (e) {}
    if (!$('ssQso').hidden) LOG.show();
  }

  // QSO en phonie hors contest (ceux du carnet général) : liste sous la fiche
  function askSsb() { if (host && !def()) api.send({ t: FDV ? 'fdv_list' : 'ssb_list', n: 300 }); }
  function drawSsb(items) {
    const tb = $('ssQLog');
    tb.textContent = '';
    const fd = (d) => d.slice(6, 8) + '/' + d.slice(4, 6) + '/' + d.slice(0, 4);
    for (const q of items) {
      const tr = document.createElement('tr');
      for (const v of [fd(q.d), q.t.slice(0, 2) + ':' + q.t.slice(2, 4), q.call, q.band, Number(q.freq) > 0 ? (Math.round(Number(q.freq) * 1000) / 1000).toFixed(3) : '', q.mode, q.rs, q.rr, q.name, q.qth, q.country, q.st, q.op]) {
        const td = document.createElement('td');
        td.textContent = v == null ? '' : String(v);
        tr.appendChild(td);
      }
      tb.appendChild(tr);
    }
    if (!items.length) tb.innerHTML = '<tr><td colspan="13">' + (FDV ? 'Aucun QSO en FreeDV dans le carnet.' : 'Aucun QSO en phonie hors contest dans le carnet.') + '</td></tr>';
    const today = ymd(new Date());
    $('ssQStats').textContent = (FDV ? '· ' : '· hors contest · ') + items.length + ' QSO' + (items.length ? ' · aujourd’hui ' + items.filter((q) => q.d === today).length : '');
  }

  // ------------------------------------------------------------------ FreeDV (page fdv.html)
  // Le serveur décode la BF du TRX (RADE, 700D, 700E et 1600 en même temps, lib/bin/fdvd) et code votre voix au PTT dans le mode
  // choisi. La page s'annonce toutes les 10 s ({t:'fdv'}) : sans elle, le serveur arrête le décodeur.
  const FD = { tx: LS.get('fdvtx', 'RADE'), hear: LS.get('fdvhear', 'dec'), ok: true, st: null, heard: [], c: [] };
  const FDV_MODES = [['RADE', 'Le mode actuel de FreeDV (le plus utilisé, 14 236 kHz…) : voix naturelle, robuste, réseau neuronal (Radio Autoencoder)'],
    ['700D', 'Le plus utilisé des anciens modes : robuste sur un signal faible, voix un peu « codée »'],
    ['700E', 'Comme 700D, mieux adapté au fading rapide (propagation difficile, DX)'], ['1600', 'Le mode historique : meilleure voix, mais demande un signal plus fort']];
  // Fréquences d'activité FreeDV (USB, toutes bandes)
  const FDV_QRG = [[3625, '80 m'], [7177, '40 m'], [14236, '20 m'], [18118, '17 m'], [21313, '15 m'], [24933, '12 m'], [28330, '10 m']];
  function fdvAnnounce() { if (FDV && host) api.send({ t: 'fdv', on: true, tx: FD.tx, hear: FD.hear }); }
  function fdvInit() {
    if (!FDV || fdvInit.done) return;
    fdvInit.done = true;
    const seg = $('fdvTxSeg');
    for (const [m, tip] of FDV_MODES) {
      const b = document.createElement('button');
      b.type = 'button'; b.dataset.m = m; b.textContent = m; b.title = tip;
      b.addEventListener('click', () => { FD.tx = m; LS.set('fdvtx', m); fdvAnnounce(); fdvDraw(); });
      seg.appendChild(b);
    }
    $('fdvHear').querySelectorAll('button').forEach((b) => b.addEventListener('click', () => { FD.hear = b.dataset.h; LS.set('fdvhear', FD.hear); fdvAnnounce(); fdvDraw(); }));
    const q = $('fdvQrg');
    for (const [k, band] of FDV_QRG) {
      const b = document.createElement('button');
      b.type = 'button'; b.textContent = (k / 1000).toFixed(3).replace('.', ','); b.title = band + ' : ' + k.toLocaleString('fr-BE') + ' kHz USB (avec la main)';
      b.addEventListener('click', () => {
        if (!api.iControl()) return toast('Prenez la main pour changer de fréquence.', 'warn');
        try { host.api.setFreq(k * 1000); setTimeout(() => { try { if (hostWin.RSDIGI) hostWin.RSDIGI.modeFor('fdv'); } catch (e) {} }, 500); } catch (e) {}
      });
      q.appendChild(b);
    }
    $('fdvHeard').addEventListener('click', (e) => {
      const tr = e.target.closest('tr[data-call]');
      if (!tr) return;
      const c = tr.dataset.call;
      const k = kit();
      if (k && k.setCall) k.setCall(c); // le dashboard suit aussi (correspondant)
      // Fiche du QSO : heure, fréquence du TRX, indicatif (recherche QRZ comme si on l'avait tapé)
      const inp = document.querySelector('#ssLog input[name="call"]');
      if (!inp) return toast('Indicatif : ' + c, '', 3000);
      try { if (LOG && LOG.fill && !LOG.editing()) LOG.fill({ t0: Date.now() }); } catch (x) { /* fiche occupée */ }
      inp.value = c;
      inp.dispatchEvent(new Event('input', { bubbles: true }));
      inp.dispatchEvent(new Event('change', { bubbles: true }));
    });
    setInterval(fdvAnnounce, 10000);
    window.addEventListener('pagehide', () => { try { api.send({ t: 'fdv', on: false }); } catch (e) {} });
    fdvDraw();
  }
  function fdvMsg(m) {
    if (m.t === 'fdv_hello') { FD.ok = !!m.ok; FD.heard = m.heard || []; if (m.st) FD.st = m.st; fdvDraw(); fdvHeard(); }
    else if (m.t === 'fdv_st') { FD.st = m.st; FD.c = m.c || []; fdvDraw(); fdvScope(); }
    else if (m.t === 'fdv_heard') { FD.heard = m.items || []; fdvHeard(); if (m.last) { FD.last = { call: m.last, at: Date.now() }; fdvDraw(); toast('FreeDV : ' + m.last + ' entendu.', '', 3000); } }
  }
  function fdvDraw() {
    if (!FDV) return;
    $('fdvTxSeg').querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.m === FD.tx));
    $('fdvHear').querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.h === FD.hear));
    const st = FD.st || { m: [], act: '' };
    $('fdvLamps').innerHTML = FDV_MODES.map(([n]) => { const x = (st.m || []).find((y) => y.n === n); return '<i class="' + (st.act === n ? 'act' : x && x.s ? 'sy' : '') + '">' + n + '</i>'; }).join('');
    const on = !!st.act;
    $('fdvAct').textContent = on ? st.act : '—';
    $('fdvSnr').textContent = on && st.snr != null ? Math.round(st.snr) + ' dB' : '—';
    $('fdvFo').textContent = on && st.fo != null ? (st.fo > 0 ? '+' : '') + Math.round(st.fo) + ' Hz' : '—';
    $('fdvBox').classList.toggle('sync', on);
    // Indicatif du correspondant : le dernier reçu (canal texte), pendant 2 minutes
    $('fdvCall').textContent = FD.last && Date.now() - FD.last.at < 120000 ? FD.last.call : '—';
    $('fdvTxNote').textContent = 'votre indicatif (TX call) part dans le canal texte de FreeDV';
    $('fdvNote').textContent = !FD.ok ? 'FreeDV indisponible sur ce serveur (programme lib/bin/fdvd absent ou système non pris en charge).'
      : FD.hear === 'dec' ? 'Écoute : « ÉCOUTER LE TRX » doit être allumé ; silence tant qu’aucun signal FreeDV n’est calé. TRX en USB, filtre d’au moins 2,7 kHz, compresseur (PROC) coupé.'
        : 'Écoute du signal brut : on entend le modem FreeDV, pas la voix. Repassez sur « Voix décodée » pour la voix.';
  }
  function fdvScope() {
    const cv = $('fdvSc');
    const g = cv.getContext('2d');
    const W = cv.width, H = cv.height;
    g.fillStyle = '#0b1422'; g.fillRect(0, 0, W, H);
    g.strokeStyle = '#1e3350'; g.beginPath(); g.moveTo(W / 2, 4); g.lineTo(W / 2, H - 4); g.moveTo(4, H / 2); g.lineTo(W - 4, H / 2); g.stroke();
    const c = FD.c || [];
    if (FD.st && FD.st.act === 'RADE') { g.fillStyle = '#c084fc'; g.font = '800 12px system-ui, sans-serif'; g.textAlign = 'center'; g.fillText('RADE', W / 2, H / 2 - 4); g.fillStyle = '#94a3b8'; g.font = '600 10px system-ui, sans-serif'; g.fillText('pas de constellation', W / 2, H / 2 + 12); return; }
    let mx = 0;
    for (let i = 0; i < c.length; i++) mx = Math.max(mx, Math.abs(c[i]));
    if (!mx) return;
    const k = (W / 2 - 8) / mx;
    g.fillStyle = FD.st && FD.st.act ? '#5ee0f5' : '#64748b';
    for (let i = 0; i + 1 < c.length; i += 2) g.fillRect(W / 2 + c[i] * k - 1, H / 2 - c[i + 1] * k - 1, 2.4, 2.4);
  }
  function fdvHeard() {
    const tb = $('fdvHeard');
    if (!tb) return;
    const p2 = (n) => String(n).padStart(2, '0');
    tb.innerHTML = FD.heard.length ? FD.heard.slice(0, 30).map((h) => { const d = new Date(h.at); return '<tr data-call="' + h.call + '" title="Cliquer : ' + h.call + ' dans la fiche du QSO"><td>' + p2(d.getUTCHours()) + ':' + p2(d.getUTCMinutes()) + '</td><td><b>' + h.call + '</b></td><td>' + (h.mode || '') + '</td><td>' + (h.snr == null ? '' : Math.round(h.snr)) + '</td><td>' + (h.hz ? (h.hz / 1000).toFixed(1) : '') + '</td></tr>'; }).join('')
      : '<tr><td colspan="5">Personne pour l’instant.</td></tr>';
  }

  // ------------------------------------------------------------------ messages du serveur, état
  function onMsg(m) {
    if (!m || typeof m !== 'object') return;
    if (m.t === 'vm') {
      S.vm = m.meta || null; S.tts = m.tts || {}; S.playing = m.playing || null;
      const pv = Array.isArray(m.ttsVoices) ? m.ttsVoices : [];
      if (JSON.stringify(pv) !== JSON.stringify(S.pv || [])) { S.pv = pv; if (!$('ssTts').hidden) ttsVoices(); }
      drawVk();
      recDraw();
    }
    else if (m.t === 'vm_data' && m.tag === 'ssb') recOnData(m);
    else if ((m.t === 'mic_profile' || m.t === 'trxeq' || m.t === 'trxeq_values' || m.t === 'profile') && VX) VX.onMessage(m);
    else if (m.t === 'hello') { if (VX) VX.onHello(m); if (LOG && LOG.mounted) LOG.onHello(m); }
    else if (m.t === 'state') { if (VX) VX.onState(); if (LOG && LOG.mounted) LOG.onState(); if (P.held && !api.iControl()) pttUp(); drawMic(); }
    else if (m.t === 'qrz_info' && LOG && LOG.mounted && LOG.onQrz) LOG.onQrz(m);
    else if (m.t === 'notice' && m.msg) toast(m.msg, m.level === 'error' ? 'warn' : '', 6000);
    else if (m.t === 'prop') drawProp(m);
    else if (m.t === 'ssb_list' && !FDV) drawSsb(m.items || []);
    else if (m.t === 'fdv_list' && FDV) drawSsb(m.items || []);
    else if (FDV && /^fdv_/.test(m.t)) fdvMsg(m);
    else if (m.t === 'tts_audio' && m.d) ttsPlay(m.d);
    else if (m.t === 'scp') { PR.q = m.q; PR.list = m.list || []; PR.n = m.n || 0; drawProb(); }
    else if (m.t === 'ctst_list' && m.contest === CL.id) { CL.items = m.items || []; if (QE.el) CL.pend = true; else drawLog(); checkDupe(); } // détails ouverts : log redessiné à leur fermeture
    else if (m.t === 'log_one' && m.tag === 'ssbedit') qsoShow(m);
    else if (m.t === 'log_saved' && m.edited && m.tag === PTAG) { toast('QSO avec ' + ((m.qso && m.qso.call) || '') + ' corrigé dans le carnet.', '', 4000); qsoClose(); clearTimeout(onMsg.lt); onMsg.lt = setTimeout(askList, 300); }
    else if ((m.t === 'log_saved' || m.t === 'log_changed') && CL.id) { clearTimeout(onMsg.lt); onMsg.lt = setTimeout(askList, 400); }
    else if ((m.t === 'log_saved' || m.t === 'log_changed') && !def()) { clearTimeout(onMsg.st); onMsg.st = setTimeout(askSsb, 400); }
    else if (m.t === 'log_export' && m.tag === PTAG) saveFile(m);
    // Fiche du carnet (sans contest) : réponses à ses QSO, liste des TX call, références
    if (LOG && LOG.mounted && /^(log_saved|log_dupe|log_cfg|log_refs)$/.test(m.t)) LOG.onMessage(m);
  }
  const fmtF = (hz) => { if (!hz) return '—'; const s = String(Math.round(hz)).padStart(7, '0'); return s.slice(0, -6) + '.' + s.slice(-6, -3) + '.' + s.slice(-3); };
  function drawState() {
    const st = api.state();
    const r = (st && st.radio) || {};
    const B = r.vfoSel === 1;
    $('cwpFreq').textContent = fmtF(B ? r.freqB : r.freq);
    const md = (B ? r.modeB : r.mode) || '—';
    $('cwpMode').textContent = md;
    $('cwpMode').classList.toggle('bad', !!st && !(FDV ? /^USB/ : /^(USB|LSB)/).test(md));
    const me = api.iControl();
    // Main : 👥, votre indicatif et le bouton de la main (ctlchip.js, comme le dashboard) ; ici, seulement « dashboard non raccroché »
    $('cwpCtl').textContent = !host ? 'dashboard non raccroché' : '';
    $('cwpCtl').className = '';
    $('cwpTake').hidden = true;
    drawFollow();
    drawListenBtn();
    const tx = !!(st && st.ptt && st.ptt.active) || !!r.tx;
    $('cwpTx').textContent = tx ? 'TX' : 'RX';
    // Grand PTT en rouge dès que le TRX émet (PTT de cette page, mémoire vocale, PTT d'une autre page)
    $('ptt').classList.toggle('on-air', tx);
    $('ptt').textContent = 'PTT'; // rouge en émission : pas besoin de le dire
    $('cwpTx').classList.toggle('on', tx);
    $('cwpTxSt').textContent = 'Émission : ' + (st && st.ptt && st.ptt.active ? (st.ptt.voice ? 'phonie / mémoire vocale de ' : 'PTT de ') + (st.ptt.by || '?') : 'aucune');
    $('cwpLink').textContent = 'Liaison : ' + (host ? 'par la page d’origine' : 'aucune');
    // Indicatif du titre : le TX call choisi dans la fiche (sans contest), sinon celui d'émission de la station
    const fsel = !$('ssQso').hidden ? document.querySelector('#ssLog select[name="station"]') : null;
    const tcall = (fsel && fsel.dataset.manual && fsel.value) || (st && st.txCall) || '';
    $('ssTxc').textContent = tcall ? String(tcall).toUpperCase() + ' - ' : ''; // « ON5VL - SSB » (« ON5VL - FreeDV »)
    const k = kit();
    if (k) {
      // Indicatif choisi ailleurs (spot cliqué dans une BAND MAP…) : dans la case Indicatif
      const kc = String(k.call() || '').toUpperCase();
      if (kc !== drawState.kc) {
        const was = drawState.kc;
        drawState.kc = kc;
        if (was !== undefined && kc && E.call.value.trim().toUpperCase() !== kc) { E.call.value = kc; E.srx.value = ''; checkDupe(); }
      }
      const n = String(k.serial()).padStart(3, '0');
      if (document.activeElement !== $('ssNr') && $('ssNr').value !== n) { $('ssNr').value = n; $('ssExchSh').textContent = def() ? '→ ' + exchShown() : ''; fillStx(false); }
    }
  }
  $('cwpTake').addEventListener('click', () => api.send({ t: 'take' }));
  // RETOUR (en haut à droite, comme les autres pages) : ferme cette page, la page d'origine repasse devant
  $('cwpBack').addEventListener('click', () => { try { if (window.opener && !window.opener.closed) window.opener.focus(); } catch (e) { /* page d'origine fermée */ } window.close(); });
  if (window.RSCTL) window.RSCTL.mount($('cwpChip'), { state: api.state, iControl: api.iControl, send: api.send, me: () => (host && host.me ? host.me() : null) });
  // « Suivre l'opérateur » (formation à distance) : le même que celui du dashboard, de la page TRX DIGI et de la face avant
  const DGS = () => { const out = []; try { const a = hostWin && hostWin.RSDIGI; if (a) out.push(a); const b = hostWin && hostWin.DG && hostWin.DG(); if (b && out.indexOf(b) < 0) out.push(b); } catch (e) {} return out; };
  const following = () => DGS().some((d) => { try { return !!(d.following && d.following()); } catch (e) { return false; } });
  const TABNAME = { ftx: 'FT8 / FT4 / FT2', rtty: 'RTTY', wspr: 'WSPR', jt65: 'JT65', jtty: 'JTTY', cw: 'CW', sstv: 'SSTV', sync: 'Synchro' };
  $('ssFollow').addEventListener('click', () => {
    const on = !following();
    const ds = DGS();
    if (!ds.length) return toast('Suivi indisponible : le dashboard qui a ouvert cette page est fermé.', 'warn');
    for (const d of ds) { try { if (d.setFollowAll) d.setFollowAll(on); else if (d.followSync) d.followSync(on); } catch (e) {} }
    toast(on ? 'Suivi de l’opérateur : vos pages montrent le même mode et les mêmes repères que celui qui a la main.' : 'Suivi de l’opérateur arrêté.', '', 5000);
    drawFollow();
  });
  function drawListenBtn() {
    const b = $('ssListen');
    if (!b) return;
    let on = false, ok = false;
    try { ok = !!(host && host.listen); on = ok && host.listen.on(); } catch (e) { ok = false; }
    b.hidden = !ok;
    // À droite de MONITORING ; micro pas ouvert (ligne du micro cachée) : à droite du bouton MICRO
    // Ordre : MONITORING · Volume (votre voix) · ÉCOUTER LE TRX · Volume TRX
    const body = $('vxBody'), mic = $('vxOn'), monv = $('vxMonVol') && $('vxMonVol').closest('label');
    const where = body && body.hidden ? mic : monv || $('vxMonBtn');
    const wrapE = $('ssListenW') || b;
    if (where && wrapE.previousElementSibling !== where) where.after(wrapE);
    b.setAttribute('aria-pressed', String(on));
    const vw = $('ssLVolW');
    if (vw) {
      let r = null;
      try { r = ok && host.listen.vol ? host.listen.vol() : null; } catch (e) { r = null; }
      vw.hidden = !r;
      const inp = $('ssLVol');
      if (r && document.activeElement !== inp) { inp.max = String(r.max); inp.value = String(r.v); $('ssLVolV').textContent = r.v + ' %'; }
    }
    const t = on ? '🔇 ARRÊTER L’ÉCOUTE' : '🔊 ÉCOUTER LE TRX';
    if (b.textContent !== t) b.textContent = t;
    b.title = on ? 'Vous entendez le TRX (BF reçue) : clic pour arrêter' : 'Entendre la BF du TRX dans votre casque ou vos haut-parleurs (sortie choisie dans « Sortie »)';
  }
  function drawFollow() {
    const b = $('ssFollow'), st = api.state(), mine = api.iControl();
    const on = following();
    b.hidden = !host;
    b.setAttribute('aria-pressed', String(on));
    b.disabled = mine;
    b.title = mine ? 'Vous avez la main : les autres membres peuvent suivre votre écran (👁 Suivre l’opérateur chez eux).'
      : 'Suivre l’opérateur (formation à distance) : vos pages (dashboard, TRX DIGI, face avant) montrent le même mode et les mêmes repères que celui qui a la main.';
    // Suivi en marche : le mode affiché par l'opérateur, à côté de « Main : … »
    const v = st && st.view;
    if (on && !mine && st && st.controller && v && v.tab && TABNAME[v.tab]) $('cwpCtl').textContent = st.controller + ' · sur ' + (v.tab === 'ftx' && v.mode ? v.mode : TABNAME[v.tab]);
  }

  // Les deux VFO (SPLIT) : même main et mêmes commandes que le dashboard
  // DUAL RX et écoute au casque en stéréo (VFO A / MAIN à gauche, VFO B / SUB à droite) : écoute jouée par le dashboard
  if (window.RSVFOBOX) window.RSVFOBOX.mount($('cwpVfo'), { api, toast, dual: true,
    rig: () => { try { return host ? host.api.rig() : {}; } catch (e) { return {}; } },
    listen: () => { try { return host ? host.listen : null; } catch (e) { return null; } },
    // Écrans des deux VFO : ceux du dashboard (page générale), recopiés
    mirror: () => { try { return hostWin && !hostWin.closed && hostWin.document.getElementById('vfoA') ? hostWin.document : null; } catch (e) { return null; } } });

  // Carte de bande à gauche : spots SSB de la bande du TRX ; clic = indicatif + TRX sur la fréquence du spot (avec la main)
  // TRX à deux vrais récepteurs (état « dualRx » : IC-7760, FTDX101, FTDX5000…) : carte du VFO-A à gauche, du VFO-B à droite
  const twoRx = (r) => r && r.dualRx != null && r.freqB != null;
  if (window.RSBMAP) window.RSBMAP.mount($('xBmB'), { api, kit, mode: 'SSB', side: () => 'B',
    label: (r) => 'VFO-B' + (r.dualRx === 0 && r.vfoSel !== 1 ? ' (SUB coupé)' : ''),
    worked: (call, band) => (CL.id && CL.items.some((q) => q.call === call && q.band === band) ? 'dup' : ''),
    onPick: (call, s) => {
      const k = kit();
      if (k) k.setCall(call);
      if (api.iControl() && host && host.api.setFreq) { try { host.api.setFreq(Math.round(s.f * 1000), 'B'); } catch (e) {} }
      else if (!api.iControl()) toast('Indicatif repris ; prenez la main pour mettre le VFO-B sur sa fréquence.', 'warn', 4000);
    } });
  setInterval(() => { const st = api.state(), e = $('xBmB'); const on = twoRx(st && st.radio); if (e.hidden === on) e.hidden = !on; }, 1000);
  if (window.RSBMAP) window.RSBMAP.mount($('xBm'), { api, kit, mode: 'SSB',
    side: (r) => (twoRx(r) ? 'A' : null), label: (r) => (twoRx(r) ? 'VFO-A' : ''),
    worked: (call, band) => (CL.id && CL.items.some((q) => q.call === call && q.band === band) ? 'dup' : ''),
    onPick: (call, s) => {
      const k = kit();
      if (k) k.setCall(call);
      if (api.iControl() && host && host.api.setFreq) {
        // Deux récepteurs : cette carte est celle du VFO-A
        try { const st = api.state(); host.api.setFreq(Math.round(s.f * 1000), twoRx(st && st.radio) ? 'A' : undefined); setTimeout(() => { try { if (hostWin.RSDIGI) hostWin.RSDIGI.modeFor(PMODE); } catch (e) {} }, 500); } catch (e) {}
      } else if (!api.iControl()) toast('Indicatif repris ; prenez la main pour aller sur sa fréquence.', 'warn', 4000);
    } });
  // TX CALL : indicatif d'émission (et des QSO enregistrés), comme dans la page TRX DIGI ; avec la main
  function drawTxCall() {
    const sel = $('cwpTxCall');
    const k = kit();
    const st = api.state();
    const opts = k && k.txCalls ? k.txCalls() : [];
    const cur = String((st && st.txCall) || opts[0] || '').toUpperCase();
    const all = opts.indexOf(cur) < 0 && cur ? opts.concat(cur) : opts;
    if (sel.dataset.opts !== all.join(',')) {
      sel.dataset.opts = all.join(',');
      sel.textContent = '';
      for (const c of all) sel.add(new Option(k && k.isClubCall && k.isClubCall(c) ? c + ' (station)' : c, c));
    }
    if (document.activeElement !== sel && sel.value !== cur) sel.value = cur;
    const me = api.iControl();
    sel.disabled = !me || all.length < 2;
    sel.parentElement.title = me ? 'TX CALL : indicatif sous lequel on émet et sous lequel les QSO vont dans le carnet (exports ADIF / Cabrillo)' : 'TX CALL : prenez la main pour le changer';
  }
  $('cwpTxCall').addEventListener('change', () => {
    const k = kit();
    const v = $('cwpTxCall').value;
    if (!k || !k.setTxCall || !k.setTxCall(v)) { toast('Prenez d’abord la main pour choisir le TX call.', 'warn'); drawTxCall(); return; }
    // La fiche du carnet (sans contest) prend le même indicatif
    const fs = document.querySelector('#ssLog select[name="station"]');
    if (fs) { delete fs.dataset.manual; if ([...fs.options].some((o) => o.value === v)) fs.value = v; }
    toast('TX call : ' + v + ' (émission et QSO enregistrés).', '', 4000);
  });
  setInterval(drawTxCall, 500);
  // ------------------------------------------------------------------ micro du TRX (gain micro, PROC / COMP, MIC EQ, niveau, VOX)
  // Envoyés par le dashboard (mêmes protections : main, émission bloquée…) ; VOX : seulement coupé à distance
  const MIC = { key: '', refs: {}, drag: {} };
  function drawMic() {
    const box = $('ssMic'), body = $('ssMicB');
    let list = [];
    try { list = host && host.txCtls ? host.txCtls() : []; } catch (e) { list = []; }
    list = list.filter((c) => c.id !== 'micEq'); // MIC EQ : dans la fenêtre TRX EQ (bouton TRX EQ vert = en service)
    // PROC : plus de bouton ; NIVEAU PROC à 0 = PROC coupé, au-dessus de 0 = PROC en service (mis tout seul)
    const procC = list.find((c) => c.id === 'proc'), lvlC = list.find((c) => c.id === 'procLvl');
    const procByLvl = !!(procC && lvlC);
    if (procByLvl) list = list.filter((c) => c.id !== 'proc');
    box.hidden = !list.length;
    if (!list.length) return;
    const key = list.map((c) => c.id + c.type + c.max).join('|');
    if (key !== MIC.key) {
      MIC.key = key; MIC.refs = {}; body.textContent = '';
      for (const c of list) {
        if (c.type === 'level') {
          const cell = document.createElement('div'); cell.className = 'ctl';
          const hd = document.createElement('div'); hd.className = 'ctl-head';
          const l = document.createElement('span'); l.className = 'ctl-label'; l.textContent = c.label;
          const out = document.createElement('output'); out.className = 'ctl-val';
          hd.append(l, out);
          const inp = document.createElement('input'); inp.type = 'range'; inp.min = c.min; inp.max = c.max; inp.step = c.step || 1; inp.setAttribute('aria-label', c.label);
          inp.addEventListener('pointerdown', () => { MIC.drag[c.id] = true; });
          inp.addEventListener('pointerup', () => { setTimeout(() => { MIC.drag[c.id] = false; }, 1200); });
          inp.addEventListener('input', () => {
            const v = Number(inp.value);
            if (c.id === 'procLvl' && MIC.procByLvl) {
              const on = !!((host.txCtls().find((x) => x.id === 'proc') || {}).value);
              let why = '';
              if (v <= 0) { if (on) why = host.txSet('proc', 0); }
              else {
                why = host.txSet('procLvl', v);
                if (!why && !on) why = host.txSet('proc', 1);
              }
              if (why) toast(why, 'warn');
              return;
            }
            const why = host.txSet(c.id, v); if (why) toast(why, 'warn');
          });
          cell.append(hd, inp); body.appendChild(cell);
          MIC.refs[c.id] = { inp, out };
        } else {
          const b = document.createElement('button'); b.type = 'button'; b.className = 'btn'; b.dataset.id = c.id; b.textContent = c.label; b.setAttribute('aria-pressed', 'false');
          b.addEventListener('click', () => { const cur = (host.txCtls().find((x) => x.id === c.id) || {}).value; const why = host.txSet(c.id, cur ? 0 : 1); if (why) toast(why, 'warn'); });
          body.appendChild(b);
          MIC.refs[c.id] = { btn: b };
        }
      }
    }
    MIC.procByLvl = procByLvl;
    const ctl = api.iControl();
    for (const c of list) {
      const r = MIC.refs[c.id];
      if (!r) continue;
      if (r.inp) {
        const pOff = procByLvl && c.id === 'procLvl' && !procC.value;
        if (!MIC.drag[c.id] && c.value != null) r.inp.value = pOff ? 0 : c.value;
        r.out.textContent = pOff ? 'OFF' : c.text;
        if (c.id === 'procLvl' && procByLvl) r.inp.title = 'NIVEAU PROC : à 0 = PROC coupé ; au-dessus de 0, PROC en service (SSB ou AM sur le VFO d’émission)';
        r.inp.disabled = !ctl;
        const lo = Number(r.inp.min) || 0, hi = Number(r.inp.max) || 100;
        r.inp.style.setProperty('--p', ((Number(r.inp.value) - lo) / (hi - lo || 1) * 100).toFixed(1) + '%');
      } else {
        r.btn.setAttribute('aria-pressed', String(!!c.value));
        r.btn.disabled = !ctl || (c.offOnly && !c.value);
        r.btn.title = c.offOnly ? (c.value ? 'Couper ' + c.label : c.label + ' ne peut pas être activé à distance') : '';
      }
    }
  }
  function link() {
    const w = chain().find((x) => { try { return !!x.RSHOST; } catch (e) { return false; } }) || null;
    const h = w ? w.RSHOST : null;
    if (h && h !== host) {
      if (untap) try { untap(); } catch (e) {}
      hostWin = w;
      host = h;
      untap = h.tap ? h.tap(onMsg) : null;
      $('cwpOrphan').hidden = true;
      voiceInit();
      logInit();
      drawMic();
      askSsb();
      if (FDV) { fdvInit(); fdvAnnounce(); }
      api.send({ t: 'vm_list' });
      api.send({ t: 'prop_get' });
      drawContest();
    } else if (!h) { host = null; hostWin = null; $('cwpOrphan').hidden = false; }
  }
  // ------------------------------------------------------------------ propagation (à droite des QSO hors contest)
  // SFI, taches, A, K, rayons X, vent solaire, Bz, champ géomagnétique, bruit ; conditions HF jour / nuit (colonne de
  // l'heure actuelle à la station en surbrillance, d'après la hauteur du soleil au locator de la station) ; VHF
  const PROP = { m: null };
  const esc = (t) => String(t == null ? '' : t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  function gridLL(g) {
    g = String(g || '').toUpperCase();
    if (!/^[A-R]{2}[0-9]{2}/.test(g)) return [50.63, 5.57]; // Liège
    let lon = (g.charCodeAt(0) - 65) * 20 - 180 + Number(g[2]) * 2 + 1, lat = (g.charCodeAt(1) - 65) * 10 - 90 + Number(g[3]) + 0.5;
    if (/^[A-X]{2}$/.test(g.slice(4, 6))) { lon += (g.charCodeAt(4) - 65) / 12 - 1 + 1 / 24; lat += (g.charCodeAt(5) - 65) / 24 - 0.5 + 1 / 48; }
    return [lat, lon];
  }
  function sunUp(lat, lon) {
    const d = new Date(), r = Math.PI / 180;
    const n = (d - Date.UTC(d.getUTCFullYear(), 0, 1)) / 864e5;
    const decl = -23.44 * Math.cos(2 * Math.PI * (n + 10) / 365);
    const ha = ((d.getUTCHours() + d.getUTCMinutes() / 60) * 15 + lon - 180) * r;
    const el = Math.asin(Math.sin(lat * r) * Math.sin(decl * r) + Math.cos(lat * r) * Math.cos(decl * r) * Math.cos(ha)) / r;
    return el > -6; // jour (crépuscule civil compris)
  }
  function drawProp(m) {
    if (m) PROP.m = m;
    m = PROP.m;
    if (!m) return;
    const d = m.data;
    if (!d) { $('ssPropG').innerHTML = '<p class="cwp-note">Données de propagation indisponibles' + (m.err ? ' (' + esc(m.err) + ')' : '') + '.</p>'; return; }
    const cls = (v, ok, mid) => (v == null ? '' : v <= ok ? 'pg' : v <= mid ? 'py' : 'pr');
    const box = (lbl, v, c, tip) => '<div class="ssb-pv ' + (c || '') + '" title="' + esc(tip) + '"><span>' + lbl + '</span><b>' + esc(v == null || v === '' ? '—' : v) + '</b></div>';
    const sfiC = d.sfi == null ? '' : d.sfi >= 150 ? 'pg' : d.sfi >= 100 ? 'py' : 'pr';
    const xC = /^[X]/i.test(d.xray) ? 'pr' : /^M/i.test(d.xray) ? 'py' : d.xray ? 'pg' : '';
    const bzC = d.bz == null ? '' : d.bz >= -2 ? 'pg' : d.bz >= -8 ? 'py' : 'pr';
    const gmC = /quiet|calme/i.test(d.geomag) ? 'pg' : /unsettled|active/i.test(d.geomag) ? 'py' : d.geomag ? 'pr' : '';
    $('ssPropG').innerHTML =
      box('SFI', d.sfi, sfiC, 'Flux solaire à 10,7 cm : plus il est haut, mieux les bandes hautes (20 m à 10 m) passent') +
      box('Taches', d.ssn, sfiC, 'Nombre de taches solaires') +
      box('Indice A', d.a, cls(d.a, 7, 20), 'Activité géomagnétique sur 24 h : bas = bandes calmes') +
      box('Indice K', d.k, cls(d.k, 2, 4), 'Activité géomagnétique des 3 dernières heures (0 à 9) : 0–2 calme, 3–4 agité, 5 et plus : orage') +
      box('Rayons X', d.xray, xC, 'Rayons X du soleil (A, B, C : calme ; M, X : éruption, coupures possibles côté jour)') +
      box('Vent sol.', d.wind == null ? null : Math.round(d.wind) + ' km/s', cls(d.wind, 450, 600), 'Vitesse du vent solaire') +
      box('Bz', d.bz == null ? null : d.bz + ' nT', bzC, 'Composante Nord-Sud du champ magnétique interplanétaire : négative et forte = risque d’orage') +
      box('Champ géo.', d.geomag, gmC, 'État du champ géomagnétique') +
      box('Bruit', d.noise, '', 'Bruit de fond estimé (S-mètre)') +
      (d.muf && !/norpt|no ?report/i.test(d.muf) ? box('MUF', d.muf + ' MHz', '', 'Fréquence maximale utilisable') : '');
    const [la, lo] = gridLL((host && host.me && host.me() && host.me().stationGrid) || '');
    const day = sunUp(la, lo);
    const bc = (v) => (/good|bon/i.test(v) ? 'pg' : /fair|moyen/i.test(v) ? 'py' : /poor|mauvais/i.test(v) ? 'pr' : '');
    const fr = (v) => ({ Good: 'Bonnes', Fair: 'Moyennes', Poor: 'Mauvaises' }[v] || v || '—');
    $('ssPropB').innerHTML = (d.bands || []).map((b) => '<tr><td>' + esc(b.name.replace(/m-/g, ' – ').replace(/m$/, ' m')) + '</td><td class="' + bc(b.day) + (day ? ' now' : '') + '">' + esc(fr(b.day)) +
      '</td><td class="' + bc(b.night) + (day ? '' : ' now') + '">' + esc(fr(b.night)) + '</td></tr>').join('');
    document.querySelector('.ssb-pband thead th:nth-child(2)').className = day ? 'now' : '';
    document.querySelector('.ssb-pband thead th:nth-child(3)').className = day ? '' : 'now';
    const vh = (d.vhf || []).filter((v) => /europe|northern/i.test(v.loc));
    const vfr = (v) => (/closed/i.test(v) ? 'fermée' : /open|high|mid|mhz/i.test(v) ? '<b class="pg">' + esc(v) + '</b>' : esc(v));
    $('ssPropV').innerHTML = vh.length ? 'VHF : ' + vh.map((v) => esc(v.name === 'vhf-aurora' ? 'aurore' : v.loc === 'europe_6m' ? 'Es 6 m' : v.loc === 'europe_4m' ? 'Es 4 m' : v.loc === 'europe' ? 'Es 2 m' : v.name) + ' ' + vfr(v.v)).join(' · ') : '';
    $('ssPropT').textContent = d.updated ? 'mis à jour ' + d.updated.replace(/\s+/g, ' ').replace(/ GMT$/, ' UTC') : '';
  }
  setInterval(() => { if (PROP.m) drawProp(); }, 60000); // jour / nuit

  window.addEventListener('pagehide', () => { pttUp(); if (untap) try { untap(); } catch (e) {} });
  fillContests();
  link();
  drawVk();
  drawContest();
  setInterval(link, 1000);
  setInterval(drawState, 250);
  // Numéro de série tenu par le serveur : demandé à l'ouverture, puis l'affichage suit ses réponses
  let serAsked = '';
  setInterval(() => {
    const k = kit();
    if (!k || !S.id) return;
    if (k.serialFor && serAsked !== S.id) { serAsked = S.id; k.serialFor(S.id); }
    const e = $('ssNr'), v = String(k.serial()).padStart(3, '0');
    if (e && document.activeElement !== e && e.value !== v) { e.value = v; $('ssExchSh').textContent = '→ ' + exchShown(); }
  }, 1000);
  setInterval(() => { if (host) api.send({ t: 'vm_list' }); }, 30000);
})();
