<!-- Fichier produit par native/manual2md.js à partir de public/aide.html : modifier la page HTML, puis relancer le script. -->

# Remote Station UBA-LGE — manuel d’utilisation

*Version en ligne : bouton **HELP** du dashboard ou https://remote.op0p.be/aide — [English version](USER-MANUAL.md)*

- [1. Avant de commencer](#intro)
- [2. Petit lexique](#lexique)
- [3. Se connecter](#connexion)
- [4. Premiers pas guidés](#premiers)
   - [4.1 Écouter une bande](#p-ecoute)
   - [4.2 Un QSO en phonie (BLU) avec votre micro](#p-phonie)
   - [4.3 Un QSO en FT8](#p-ft8)
   - [4.4 Noter le QSO dans le carnet](#p-log)
- [5. L'écran en un coup d'œil](#ecran)
- [6. Prendre et passer la main](#main)
- [7. Piloter le TRX](#trx)
   - [7.1 Les écrans VFO](#vfo)
   - [7.2 Ligne Step et bandes](#step)
   - [7.3 Colonne de gauche](#gauche)
   - [7.4 Colonne de droite](#droite)
   - [7.5 Trafic en SPLIT](#split)
- [8. Écouter](#ecoute)
- [9. Émettre et sécurités](#emission)
   - [9.1 Phonie et contests : le TRX SSB](#ssbcontest)
- [10. Opérateurs et discussion](#operateurs)
- [11. Disposition et fenêtres séparées](#disposition)
   - [11.1 Face avant du FTDX101](#face)
- [12. Modes numériques](#numeriques)
   - [12.1 FT8 · FT4 · FT2](#ft8)
   - [12.2 JT65](#jt65)
   - [12.3 RTTY](#rtty)
   - [12.4 WSPR](#wspr)
   - [12.5 JTTY](#jtty)
   - [12.6 CW](#cw)
   - [12.7 SSTV](#sstv)
   - [12.8 Synchro](#synchro)
   - [12.9 QO-100](#qo100)
- [13. Correspondant, macros et balises](#messages)
- [14. Logbooks (carnet de trafic)](#logs)
   - [14.1 Enregistrer un QSO](#l-fiche)
   - [14.2 La liste des QSO](#l-liste)
   - [14.3 Exporter](#l-export)
   - [14.4 Synchronisation (LoTW, eQSL, Club Log, QRZ)](#l-sync)
   - [14.5 Configuration](#l-config)
- [15. Raccourcis clavier](#clavier)
- [16. Problèmes fréquents](#problemes)
- [17. Pour les administrateurs](#admin)
- [18. Le PC du club (page Station)](#club)

> [!NOTE]
> Le dashboard fonctionne dans **Google Chrome** ou **Microsoft Edge**, sur PC, Mac, tablette ou téléphone. Il est prévu pour un écran de **1920 × 1080** ou plus ; sur un écran plus petit, les cadres se placent les uns sous les autres. Après une mise à jour du serveur, appuyez sur `Ctrl` + `F5` pour recharger la page.

<a id="intro"></a>
## 1. Avant de commencer

La **Remote Station** permet aux membres de la section UBA-LGE d'utiliser le **transceiver (TRX) du club** depuis chez eux, avec un simple navigateur. Le TRX (un Yaesu FTX-1 avec son ampli SPA-1, ou selon le cas un FTDX10, un FTDX101D / MP ou un IC-7300) est au club, relié à un PC. Ce PC est relié par internet au serveur **remote.op0p.be**, et c'est ce serveur que vous ouvrez dans votre navigateur.

1. Vous cliquez sur un bouton du dashboard (par exemple « 20M »).
2. Le serveur transmet l'ordre au PC du club.
3. Le PC du club envoie la commande au TRX par son câble USB (la « liaison CAT »).
4. Le TRX change de bande, et tous les membres connectés voient la nouvelle fréquence.

Le son du récepteur fait le chemin inverse : il arrive dans votre navigateur, et les modes numériques (FT8, RTTY, CW…) sont décodés sur le serveur.

> [!TIP]
> **Les règles d'or**
> - **Une seule personne pilote** le TRX à la fois : celle qui « a la main ». Les autres regardent et écoutent.
> - **Tout ce que vous réglez agit sur le vrai TRX du club**, pour tout le monde. Si vous n'êtes pas sûr d'un réglage, laissez-le tel quel.
> - Après un changement de bande, faites toujours un `TUNE` avant d'émettre (accord de l'antenne).
> - Respectez votre licence : bandes et puissance autorisées. Le serveur le vérifie de toute façon.
> - En partant, **libérez la main** et coupez le SPLIT si vous l'avez mis.

<a id="lexique"></a>
## 2. Petit lexique

Les mots qui reviennent souvent dans ce manuel et sur l'écran.

| Mot | Signification |
|---|---|
| TRX | Transceiver : l'émetteur-récepteur du club. |
| Avoir la main | Être l'opérateur qui pilote le TRX en ce moment. Sans la main, on peut regarder et écouter, mais pas régler ni émettre. |
| VFO | Le « bouton de fréquence » du TRX. Il y en a deux, **A** et **B** (sur le FTX-1 : **MAIN** et **SUB**), chacun avec sa fréquence et son mode. |
| MAIN / SUB | Les deux récepteurs du FTX-1. MAIN correspond au VFO A, SUB au VFO B. Le « côté actif » est celui qu'on écoute et qu'on règle. |
| PTT | Push To Talk : le bouton qui met le TRX en émission tant qu'on le maintient. |
| CAT | La liaison par câble USB entre le PC du club et le TRX, qui sert à le commander. |
| BF | Basse fréquence : le son qui sort du récepteur (ce que vous entendez, et ce que le décodeur analyse). |
| Mode | La façon de transmettre : **LSB / USB** (BLU, la phonie en HF), **CW** (morse), **AM**, **FM**, **DATA-U** (modes numériques par la carte son du TRX), **RTTY**… |
| BLU | Bande latérale unique (SSB en anglais) : la phonie en HF. LSB en dessous de 10 MHz, USB au-dessus. |
| Bande | Une plage de fréquences : 80 m, 40 m, 20 m… (plus le chiffre est petit, plus la fréquence est haute). |
| SWR / ROS | Rapport d'ondes stationnaires : indique si l'antenne est bien accordée. 1,0 est parfait, jusqu'à 1,5 c'est très bien, au-delà de 2,5 l'émission est coupée. |
| TUNE / tuner | Le tuner (boîte d'accord) adapte l'antenne à la fréquence. TUNE lance cet accord : le TRX émet une porteuse quelques secondes. |
| ALC | Indicateur qui montre si l'émetteur est « poussé » trop fort. En modes numériques, l'ALC doit rester très faible. |
| S-mètre | Indique la force du signal reçu, de S1 (très faible) à S9, puis S9+10, +20… dB (très fort). |
| Filtre / BW | Largeur de la « fenêtre » d'écoute. Plus étroite = moins de bruit et de stations voisines, mais il faut être bien calé. |
| SPLIT | Écouter sur une fréquence et émettre sur une autre (pour les expéditions DX). |
| RIT / XIT | Petit décalage de la fréquence de réception (RIT) ou d'émission (XIT), sans toucher au VFO. |
| Cascade (waterfall) | L'image qui défile dans les onglets numériques : chaque trait coloré est un signal ; plus il est clair ou rouge, plus il est fort. |
| QSO | Un contact radio entre deux stations. |
| Correspondant | La station avec qui vous faites le QSO (DX en abrégé). |
| Report / RST | Le compte rendu de réception qu'on se donne : **59** ou **599** en phonie / CW / RTTY, un nombre de **dB** (−15, +03…) en FT8. |
| Locator | Position en carré Maidenhead (ex. JO20 pour la région liégeoise). |
| TX call | L'indicatif sous lequel partent les émissions numériques et sous lequel le QSO est noté : celui du club (ON5VL, OR0L) ou le vôtre. |
| UTC | L'heure universelle utilisée en radio (heure belge − 1 h en hiver, − 2 h en été). |
| ADIF | Format de fichier standard pour échanger des QSO entre logiciels de carnet (.adi). |
| LoTW, eQSL, Club Log, QRZ | Sites où l'on envoie ses QSO pour obtenir des confirmations (QSL électroniques) et des diplômes. |
| DXCC | La liste officielle des « pays » radioamateurs (entités). Le préfixe (ON, F, DL…) indique le pays d'un indicatif. |

<a id="connexion"></a>
## 3. Se connecter

1. Ouvrez [https://remote.op0p.be](https://remote.op0p.be) dans Chrome ou Edge.
2. Entrez **votre indicatif** et **votre mot de passe** (donnés par un administrateur du club), puis cliquez `Se connecter`.
3. Le navigateur reste connecté **7 jours** : en rechargeant la page, vous revenez directement au dashboard.
4. `Déconnexion` (en haut à droite) ferme la session et oublie le navigateur : à faire sur un PC qui n'est pas le vôtre.

- Les indicatifs d'**écouteurs** (ONL…) peuvent tout voir et tout écouter, mais pas émettre ni régler la puissance.
- Après **15 minutes sans aucune action**, vous êtes déconnecté. Un avertissement apparaît une minute avant, avec un bouton `Rester connecté`. Cela n'arrive jamais pendant une émission.
- Le bouton `HELP` en haut à droite ouvre ce manuel dans un nouvel onglet.

<a id="premiers"></a>
## 4. Premiers pas guidés

Quatre « recettes » pour démarrer. Le détail de chaque bouton se trouve plus loin (sections 7 à 14).

<a id="p-ecoute"></a>
### 4.1 Écouter une bande

1. À droite, cadre **RX audio** : cliquez `🔊 Écouter le TRX`. Réglez le curseur **Volume** juste en dessous (il n'agit que chez vous).
2. Pour changer de bande ou de fréquence, il faut **avoir la main** : cliquez `Prendre la main` en haut (si personne ne l'a).
3. Cliquez une bande, par exemple `40M`, dans la ligne des bandes sous les VFO.
4. Choisissez le mode dans le cadre **Mode** à gauche : `LSB` pour la phonie sur 40 m, `USB` sur 20 m et au-dessus.
5. Tournez la fréquence : placez la souris sur les chiffres du **VFO A** et utilisez la **molette**. Chaque chiffre se règle séparément ; le chiffre sous la souris monte ou descend.
6. Une station trop forte ? Baissez le **RF GAIN** (cadre RF front end) ou allumez l'`ATT`. Beaucoup de bruit ? Essayez `DNR` (réducteur de bruit).

<a id="p-phonie"></a>
### 4.2 Un QSO en phonie (BLU) avec votre micro

Votre micro (celui de votre PC, un micro-casque, un micro USB…) part vers le TRX pendant l'appui sur PTT : c'est la **phonie à distance**. Elle marche en **LSB / USB** (et en AM / FM sur le FTX-1 et l'IC-7300). Un micro-casque donne le meilleur résultat (pas d'effet Larsen, voix proche).

1. Prenez la main, choisissez la bande et le mode LSB ou USB. Ensuite, à chaque changement de bande, le dashboard remet tout seul **LSB sous 10 MHz** et **USB au-dessus** (USB sur 60 m) ; les modes DATA, CW, AM et FM ne sont pas touchés.
2. Ouvrez la page **TRX SSB** (onglet `SSB` du dashboard, ou bouton bleu `🎙 Phonie : page TRX SSB` du cadre **TX**, ou bouton SSB de la face avant) ; ligne **SSB configuration** : cliquez `Configuration micro` (MICRO). La première fois, Chrome demande l'accès au micro : **Autoriser**. Choisissez votre micro dans la liste s'il y en a plusieurs.
3. Le dashboard **reconnaît le type de micro** d'après son nom (micro-casque, micro USB de studio, webcam, Bluetooth, micro du PC…) et propose un réglage d'égaliseur adapté. Parlez : la barre de niveau doit rester dans le **vert**, jamais dans le rouge (**SAT**).
4. `Equalizer micro` : coupe-bas, trois bandes réglables (fréquence, niveau, largeur), coupe-haut, gain du micro, réduction de bruit. Écoutez-vous **au casque** avec `🎧 M’écouter` (curseur **Volume** juste dessous), puis `Enregistrer pour ce micro` : ces réglages reviennent tout seuls chaque fois que vous utilisez ce micro, sur n'importe quel PC.
5. Cadre **Accord** : `TUNE`, puis vérifiez le **SWR** et la **puissance**.
6. Écoutez que la fréquence est libre, puis maintenez `PTT` (ou la barre `Espace`) et **parlez quand le voyant TX passe au rouge** (environ une demi-seconde au premier appui, aussitôt aux suivants). Relâchez pour écouter : pendant que vous parlez, l'écoute du TRX est coupée chez vous.

> [!NOTE]
> Au club, la page Station met le menu « source de modulation » du TRX sur USB juste avant votre émission, puis le remet comme avant 20 s après votre dernière émission ou dès que vous rendez la main : le micro du club refonctionne. Le niveau de votre voix à l'entrée du TRX se règle sur la page Station (« Niveau phonie à distance ») : l'ALC doit à peine bouger.

**Égaliseur du TRX** (FTX-1, FTDX10, FTDX101) : bouton `Equalizer TRX` du même cadre. Ce sont les menus PRMTRC EQ1 à EQ3 du TRX (PROC coupé, puis PROC en service). Prenez la main, `Lire le TRX`, réglez, `Essayer sur le TRX`, puis `Enregistrer mon profil` : votre profil est mis au TRX chaque fois que vous prenez la main, et le réglage du club est remis quand vous la rendez. Les administrateurs peuvent enregistrer le réglage du club.

<a id="p-ft8"></a>
### 4.3 Un QSO en FT8

Le FT8 est le mode le plus simple à distance : tout se fait à la souris et le dashboard gère la séquence comme WSJT-X.

1. Prenez la main. Dans la ligne **QSO** (en bas), choisissez le **TX call** : l'indicatif du club (ON5VL) ou le vôtre.
2. Onglet `FT8 · FT4 · FT2` au centre, bouton `FT8`, puis choisissez une bande dans la liste des fréquences (ex. « 14.074 · 20m »). Le TRX y va tout seul, en DATA-U.
3. Faites un `TUNE` (cadre Accord), puis réglez une puissance raisonnable (20 à 40 W suffisent en FT8).
4. Attendez une ou deux périodes de 15 s : les stations entendues s'affichent dans **Activité de bande**. Les appels **CQ** sont en vert.
5. **Pour répondre à un CQ** : cliquez sur l'**indicatif** de la station (souligné en pointillé) ou double-cliquez sur sa ligne. Le TRX émet votre appel dès le début de la période suivante.
6. Laissez faire : la **séquence avance toute seule** (report, R-report, RR73, 73). La barre sous les listes est rouge pendant l'émission, verte en réception.
7. Dès que le correspondant envoie RR73, la fiche **« Enregistrer le QSO »** s'ouvre déjà remplie : vérifiez et enregistrez.
8. Pour appeler vous-même : cliquez `Tx6` (CQ). Cochez **Répondre au 1er** pour que la première station qui répond soit prise automatiquement.
9. Pour tout arrêter : `■ Arrêter` (ou la barre `Espace`).

<a id="p-log"></a>
### 4.4 Noter le QSO dans le carnet

1. Après un QSO numérique, la fiche s'ouvre toute seule (FT8) ou avec le bouton `Log QSO` (RTTY, JTTY, CW ; aussi sur la ligne des onglets, à droite de Logbooks).
2. Pour un QSO en phonie : onglet `LOGS`, tapez l'indicatif (l'heure UTC se met toute seule), cliquez `⇩ TRX` pour reprendre fréquence et mode, complétez les reports.
3. `Enregistrer le QSO` (ou `Entrée`). Le QSO apparaît dans la liste. Sous l'indicatif du club, il est aussi envoyé aux carnets en ligne si les administrateurs l'ont prévu.
4. Pour récupérer vos QSO dans votre propre logiciel : **Exporter ▾ → Mes QSO (.adi)**.

<a id="ecran"></a>
## 5. L'écran en un coup d'œil

### Bandeau du haut

| Élément | Ce que c'est | Ce qu'il fait |
|---|---|---|
| `● Serveur` | Voyant de liaison entre votre navigateur et le serveur. | Vert = connecté. Rouge ou gris : vérifiez votre internet, la page se reconnecte toute seule. |
| `● Station` | Voyant de la page Station du PC du club. | Vert = le PC du club est en ligne. Pour les administrateurs, un clic ouvre le menu du TRX (section 17). |
| `● FTX-1 FTDX10 FTDX101D / MP IC-7300` | Les TRX du club ; celui en service est en surbrillance. | Vert = le TRX répond par le CAT ; rouge = le TRX émet. |
| Titre au centre | Indicatif et nom de la station. | — |
| `👥 n` | Nombre de membres connectés. | Ouvre le volet **Opérateurs** : qui est là, qui a la main, discussion (section 10). Un point rouge signale un nouveau message. |
| Votre indicatif | Le compte avec lequel vous êtes connecté. | — |
| `Prendre la main` / `Libérer la main` | Grand bouton de pilotage, coloré selon l'état : **vert** qui pulse doucement = la main est libre ; **orange** = vous avez la main ; **ambre** (administrateur) = « Reprendre la main » à celui qui l'a ; **gris** = un autre membre a la main. | Vous devenez l'opérateur, ou vous rendez la main (section 6). |
| `<-> DX Cluster ▾` | Liaison du TRX avec un cluster DX du club (barre du haut, entre « Prendre la main » et la taille). | Clic : choix de **dx.op0p.be** (Ultimate Cluster) ou **cluster.op0p.be** (CC-Cluster OP0P), ouvert dans sa propre fenêtre (à poser sur le 2ᵉ écran) ; s'il est déjà ouvert, sa fenêtre revient devant. <-> vert = un cluster de ce navigateur est relié et vous avez la main (« ● relié » dans le menu) ; **orange** = cluster ouvert mais vous n'avez pas la main (« ● ouvert, prenez la main ») : prenez la main pour le relier ; rouge = aucun cluster ouvert. Sens unique : la liaison s'ouvre seulement depuis le dashboard (membre connecté) ; depuis la page du cluster, rien n'ouvre ni ne pilote le dashboard sans lui. |
| Clic sur un spot de dx.op0p.be / cluster.op0p.be | Le TRX se cale sur la station. | Ouvrez le cluster dans une autre fenêtre (2ᵉ écran) **du même navigateur** que le dashboard. Un clic sur un spot : FT8 / FT4 / FT2, JT65, JTTY, WSPR → l'onglet du mode s'ouvre, le VFO A va sur la fréquence d'appel et la réception sur le signal ; RTTY → onglet RTTY, décodeur de l'émission sur le signal ; CW → onglet CW, VFO sur la station (CW-L sous 10 MHz, CW-U au-dessus) ; phonie (SSB, AM, FM) → VFO choisi (A ou B) et mode (LSB sous 10 MHz, USB au-dessus). L'indicatif passe dans Correspondant. Il faut avoir la main ; refusé pendant une émission. Le site du cluster doit être autorisé (`qsyOrigins` dans config.json) et servi en https. Un badge **Remote Station <-> DX Cluster** (visible seulement pour les membres déjà connectés au dashboard dans ce navigateur), en haut de la colonne Alert / Show Only / Hide sur dx.op0p.be, en bas à droite ailleurs (ou dans un élément `id="rs-qsy-badge"` de la page) : <-> vert = dashboard ouvert avec la main, **orange** = dashboard ouvert sans la main, rouge = pas de dashboard ; après un clic, il indique « TRX calé sur le spot » ou ce qui manque. |
| `Auto 100 %` | Taille du dashboard. | **Auto** (conseillé) : le dashboard est dessiné pour un écran 1920 × 1080 ; sur un écran plus grand, il est agrandi dans la même proportion pour remplir l'écran, sans rien déplacer (2560 × 1440 : environ 130 % ; 4K 3840 × 2160 : 200 %). C'est la **hauteur** qui décide : un écran très large mais de 1080 de haut (2560 × 1080) reste à 100 %, la largeur en plus élargit la cascade et les fenêtres. Le haut du menu indique l'écran du PC et la taille choisie par Auto. Si Windows agrandit déjà l'affichage (Paramètres › Affichage › Échelle, souvent 125 % ou 150 % sur un écran 2560 × 1440 ou 4K), Auto en tient compte et n'ajoute que le complément : 125 % × 105 % ≈ 131 %, la même taille qu'un écran 2560 × 1440 à 100 % avec Auto à 133 %. Le menu permet aussi de choisir la taille soi-même, de **50 % à 200 %** : en dessous de 100 %, tout est plus petit et on en voit plus (utile sur un portable) ; les tailles plus grandes que l'écran (en gris) restent permises, mais la mise en page se serre et certaines colonnes défilent. Réglage gardé dans ce navigateur. Sur un écran plus petit que 1920, la mise en page s'adapte déjà toute seule ; `Ctrl` + `−` de Chrome peut aider. |
| `HELP` | Le manuel. | Ouvre cette page (français ou anglais selon votre navigateur). |
| `Déconnexion` | Fin de session. | Ferme la session et oublie ce navigateur. |

### Les zones de l'écran

1. **Colonne de gauche** : Antenne, RF front end (réception), Mode, Filtres, Station meters (mesures).
2. **Centre, en haut** : les deux écrans VFO (A / MAIN et B / SUB), la ligne **Step** (pas d'accord, choix du VFO, SPLIT…) et la ligne des **bandes**.
3. **Centre, en bas** : la ligne des onglets (sans titre au-dessus) : Modes (journal de la station), FT8 · FT4 · FT2, SSB, RTTY, WSPR, JT65, JTTY, CW, SSTV (un clic sur un mode ouvre sa page : **TRX SSB**, **TRX CW**, ou **TRX DIGI** sur ce mode ; avec la main, le TRX passe dans le mode), puis Logbooks (le dashboard s'ouvre sur le **carnet de trafic**, qui reste affiché pendant que les modes sont dans leurs pages), le bouton `Log QSO` et Synchro, puis `👁 Suivre l'opérateur`. À droite, la **carte de bande** (spots du DX cluster), dans tous les onglets de modes sauf SSTV.
4. **Colonne de droite** : RX audio (écoute), DSP (antiparasites), Accord (tuner), TX (PTT et puissance).
5. Sous les onglets : la ligne **QSO** (la station contactée, ses reports et le TX call), dans les onglets des modes et Synchro ; elle est masquée dans les onglets **Modes** et **Logbooks**, où la fiche du carnet donne déjà l'indicatif, les reports et le TX call (choisi là, avec la main, il change aussi l'indicatif d'émission).

- **Replier un cadre** : cliquez sur son titre (par exemple « DSP ») ; un deuxième clic le rouvre. Votre choix est retenu.
- **Fenêtre séparée** : le bouton `⧉` d'un cadre l'ouvre dans sa propre fenêtre (section 11).
- Sous la ligne des bandes, une ligne de messages affiche les confirmations et les refus (« Prenez la main… », « PTT refusé : … »).

<a id="main"></a>
## 6. Prendre et passer la main

- Une seule personne **a la main** (pilote le TRX) ; tout le monde voit et entend la même chose.
- `Prendre la main` (bandeau du haut) : possible si personne ne l'a. Le bouton devient `Libérer la main`.
- Si quelqu'un l'a déjà : ouvrez le volet `👥` et cliquez `Demander la main à …`. L'opérateur reçoit la demande (son volet s'ouvre) et peut cliquer `Passer la main à …`. Vous pouvez aussi lui écrire un message dans la discussion.
- **Équité** : si l'opérateur a la main depuis **45 min** et qu'un autre membre l'a demandée (demande valable 15 min), il est prévenu ; la main passe au demandeur **2 min** plus tard, jamais au milieu d'une émission (à la fin de celle-ci). Sans demande en attente, on peut garder la main aussi longtemps qu'on est actif (libérée après 15 min sans aucune action).
- **📊 STATS** (administrateurs, en haut à droite) : page des statistiques d'utilisation — temps avec la main et temps connecté par indicatif, émission, sessions, jours, QSO, bandes et modes, graphique par jour, carte jours de la semaine × heures (heure belge), journal des sessions (qui, quand, combien de temps, bandes, modes, TRX), export CSV pour Excel ; période et indicatif au choix. Relevé minute par minute dans `logs/usage-AAAA-MM.jsonl` ; avant cette version, durées estimées d'après le journal des prises de main.
- **Un compte, un opérateur** : votre compte peut être ouvert dans plusieurs onglets ou sur plusieurs appareils **du même réseau** (même adresse internet). Une connexion depuis une **autre adresse** ferme les sessions ouvertes ailleurs (elles devront retaper le mot de passe) et les administrateurs sont prévenus : ne prêtez pas votre compte.
- **Décompte** : à côté de `Libérer la main`, `⏱ 14:58` donne le temps restant avant que la main soit libérée (et la session fermée) sans aucune action ; chaque réglage ou émission le remet à 15 min ; orange sous 2 min, « ⏱ en émission » pendant une émission. Quand un membre attend la main (équité), il devient un badge rouge `⏱ main → ON4XXX dans 1:45`.
- **En partant**, cliquez `Libérer la main`. Sans action pendant **15 minutes**, la main est libérée automatiquement.
- Le bouton du bandeau affiche `Main occupée` quand quelqu'un d'autre l'a, et `Prendre la main ici` si vous l'avez déjà dans un autre onglet ou un autre navigateur. Un administrateur voit `Reprendre la main` : il peut la reprendre en cas de besoin, après confirmation.
- Sans la main, les commandes sont grisées et un message rappelle « Prenez la main ».
- **Suivre l'opérateur** (pour une formation à distance) : bouton `👁 Suivre` juste après les onglets des modes numériques. Allumé (vert), votre écran affiche le même onglet que celui qui a la main (RTTY, FT8, CW…) et en change avec lui. Cliquer vous-même sur un autre onglet arrête le suivi ; un clic sur `👁 Suivre` le relance. Ce bouton n'apparaît pas chez celui qui a la main. Il s'enclenche **tout seul** quand vous arrivez alors qu'un autre membre a la main, et chaque fois qu'un autre membre prend la main ensuite.

<a id="trx"></a>
## 7. Piloter le TRX

Toutes les commandes de cette section demandent d'**avoir la main**, sauf l'écoute et le volume. Elles agissent sur le vrai TRX du club et tout le monde voit le résultat. Certaines n'existent que sur un TRX : elles sont grisées ou absentes sur les autres. Quand un bouton est allumé (en couleur), la fonction est en service ; un clic l'éteint.

<a id="vfo"></a>
### 7.1 Les écrans VFO

En haut au centre, deux écrans : **VFO A (MAIN)** à gauche et **VFO B (SUB)** à droite. Ils ressemblent à l'afficheur du TRX.

| Élément | Ce qu'il montre | Ce qu'un clic (ou la molette) fait |
|---|---|---|
| `RX` | Vert : ce VFO est celui qu'on écoute. | Clic : ce VFO devient celui de réception (comme la touche MAIN / SUB du TRX ; pas sur l'IC-7300). |
| `TX` | Rouge foncé : l'émission partirait sur ce VFO. Rouge vif avec halo : émission en cours. | Clic sur le TX de l'autre VFO : SPLIT (on écoute sur un VFO et on émet sur l'autre, section 7.5). Clic sur le TX du VFO écouté : SPLIT coupé. |
| `BW 2.4K` | Largeur du filtre de réception de ce VFO. | **Molette** dessus : vers l'avant = plus large, vers soi = plus étroit, cran par cran parmi les largeurs que le TRX propose dans ce mode (sur les Yaesu : 300 Hz à 4 kHz en BLU, 50 Hz à 4 kHz en CW, RTTY et DATA). « FIX » en AM / FM (largeur fixe), « NAR » quand NARROW est enclenché (la molette est alors refusée, avec un message). IC-7300 : la molette passe de FIL1 à FIL2 et FIL3. Sur le VFO B (FTX-1, FTDX101) : largeur du côté SUB. |
| « Émission sur A / B » | Rappel orange du VFO sur lequel partirait l'émission. | — |
| MAIN / SUB · 20M | Côté du TRX et bande de ce VFO. | — |
| S-mètre (S1 … +60) | Force du signal reçu. Grisé sur le VFO qu'on n'écoute pas. | — (en émission, regardez Station meters). |
| Chiffres de la fréquence | La fréquence en MHz. Rouge pendant l'émission ; grisée si ce VFO ne sert ni à recevoir ni à émettre. | **Molette** sur un chiffre (vers l'avant = monter) ou **glisser** vers le haut / le bas (un pas tous les 14 pixels ; au doigt sur une tablette) : ce chiffre monte ou descend, des MHz jusqu'au dernier chiffre, le hertz ; les retenues se font toutes seules (7,099 → 7,100). **Simple clic sur un chiffre**, sans bouger : ce chiffre devient le **pas** de la ligne Step, des flèches ◀ ▶ et des touches `↑` `↓` (il est souligné). **Clic** ailleurs sur l'écran : ce VFO devient celui que règlent les flèches, le clavier et les bandes (sa lettre est soulignée). La fréquence reste toujours dans la couverture du TRX. |
| Mode (USB, DATA-U…) | Le mode de ce VFO. | Il se change dans le cadre **Mode** à gauche. |
| `RIT` | Décalage de la réception seulement. | Clic : marche / arrêt. **Molette** sur la valeur affichée (+0.00 kHz) : ± 10 Hz, ± 100 Hz avec `Maj`. Utile si le correspondant dérive un peu. |
| `XIT` | Décalage de l'émission seulement. | Clic : marche / arrêt. Molette sur la valeur : comme RIT. Utile pour un petit split de quelques kHz. |
| `CLEAR` | — | Remet le décalage RIT / XIT à zéro. |
| `ATT` | Atténuateur d'entrée. | Clic : marche / arrêt. Pour une station locale très forte ou une bande saturée (le bruit baisse aussi). Grisé en 2 m / 70 cm. Sur le FTDX10 : OFF, 6, 12 ou 18 dB. |
| `IPO` / `AMP1` / `AMP2` | Préamplificateur (HF et 6 m). IPO = sans préampli. | Chaque clic passe au suivant. AMP1 / AMP2 aident sur les bandes hautes calmes (15, 10, 6 m) ; sur 80 / 40 m, IPO suffit en général. |
| `AMP` | Préampli en 2 m / 70 cm. | Clic : marche / arrêt. |
| `NB` | Noise blanker : antiparasite pour les bruits d'impulsions (moteurs, clôtures électriques). | Clic : marche / arrêt (le niveau se règle dans le cadre DSP). |
| `DNR` | Réducteur de bruit numérique (souffle). | Clic : marche / arrêt ; niveau dans le cadre DSP. |
| `NOTCH` | Filtre manuel qui creuse une fréquence (un sifflement). | Clic : marche / arrêt ; sa fréquence se règle dans le cadre DSP. |
| `DNF` | Notch automatique : supprime tout seul les porteuses qui sifflent. | Clic : marche / arrêt. À éviter en CW et en modes numériques (il peut supprimer le signal utile). |
| `NAR` | Filtre étroit (NARROW). Enclenché, le TRX impose sa largeur étroite : le curseur BW du cadre Filtres est grisé et affiche « NARROW ✕ ». | Clic : marche / arrêt. Un clic sur « NARROW ✕ » du cadre Filtres le coupe aussi et rend le curseur BW. |
| `AGC AUTO` | Rappel du réglage d'AGC. | Il se change dans RF front end (pas de clic sur ce badge). |
| `RFG 80` | Rappel : le RF GAIN est baissé (ici à 80 %). Absent quand il est au maximum. | Se remonte avec le curseur RF GAIN du cadre RF front end. |
| `LOCK` | La face avant du TRX au club est verrouillée. | Se coupe avec `LOCK` de la ligne Step. |

> [!TIP]
> **Les badges cliquables (ATT, IPO / AMP, NB, DNR, NOTCH, DNF, NAR)**
> - **Gris** = fonction coupée ; **en couleur** = en service (vert pour ATT et préampli, orange pour NB, DNR, NOTCH, DNF, bleu pour NAR). Au survol, le badge s'éclaircit et se cerne de pointillés, sans changer de couleur : on voit son état sous la souris.
> - **Un seul clic** suffit : le nouvel état s'affiche aussitôt, puis la relecture du TRX le confirme dans la seconde. Si le badge revient à l'état d'avant, le TRX a refusé (fonction sans effet dans ce mode, par exemple) : le message sous les bandes le dit.
> - Il faut avoir la main ; refusé pendant une émission. Au survol, une bulle rappelle le nom du réglage et ce que fait le clic.
> - NB et DNR : le clic allume au dernier niveau utilisé (ou au milieu) et éteint ; le niveau exact se règle dans le cadre DSP. IPO / AMP1 / AMP2 et ATT à plusieurs crans (FTDX10, FTDX101 : 6 / 12 / 18 dB) : chaque clic passe au cran suivant.

> [!TIP]
> **FTX-1 : les deux côtés MAIN et SUB**
> - L'écran du VFO B règle NB, DNR, NOTCH, DNF et NAR du côté SUB.
> - ATT et préampli sont propres à chaque côté, mais le TRX ne les donne que pour le côté actif : un clic sur ceux de l'autre VFO fait passer le TRX de ce côté 2 à 3 s, sans émettre, puis revenir. Tant qu'ils n'ont jamais été lus, ils affichent « ? ».
> - Les cadres RF front end, Filtres et DSP règlent le **côté actif** : leur titre indique « A · MAIN » ou « B · SUB ».
> - **FTDX101D / MP** (vrai double récepteur) : l'écran du VFO B règle directement le côté SUB (ATT, IPO / AMP, NB, DNR, NOTCH, DNF, NAR, BW), sans changer de côté ni d'état du TRX.

<a id="step"></a>
### 7.2 Ligne Step et ligne des bandes

Sous les écrans VFO.

| Commande | Ce qu'elle fait | Quand s'en servir |
|---|---|---|
| `1 Hz` … `100 kHz` (Step) | Choisit le pas des flèches ◀ ▶ et des flèches `↑` `↓` du clavier ; le chiffre correspondant de l'écran VFO est souligné. Un simple clic sur un chiffre d'un écran VFO choisit aussi le pas. Réglage gardé dans votre navigateur. | 100 Hz à 1 kHz pour chercher en BLU ; 10 Hz pour un réglage fin, 1 Hz pour le plus fin (RTTY, modes numériques, battement nul en CW) ; 10 à 100 kHz pour traverser une bande. |
| `A` / `B` (VFO) | Choisit le VFO que règlent les flèches et les bandes. Sur le FTX-1, fait aussi passer le TRX sur ce côté (comme MAIN / SUB). | Pour travailler sur le VFO B. |
| `◀` `▶` | Descend / monte la fréquence d'un pas. | Recherche pas à pas. |
| `MAIN` / `SUB` | Côté actif du TRX (réception et émission ensemble), comme la touche de la face avant, sans émission. Prend 1 à 2 secondes. **FTX-1 : seulement en double réception (DUAL RX, un VFO en 144 / 430 MHz).** En réception simple, le dashboard refuse : le TRX est passé en émission (constaté au club les 24 et 25/10). Pour écouter la fréquence du VFO B en HF : `A ⇄ B`. Un administrateur peut l'autoriser pour des essais (`ftx1SubSingle`). | FTX-1 : écouter et émettre sur le VFO B. |
| `SPLIT` | Émettre sur l'autre VFO que celui qu'on écoute. | Expéditions DX (section 7.5). |
| `TXW` | **Maintenir** le bouton (ou la touche `W`) : on écoute la fréquence d'émission ; relâcher = retour sur le DX. Les VFO sont remis en place tout seuls (aussi après 15 s ou si la liaison se coupe). Le PTT est refusé tant que TXW est enfoncé. | En SPLIT, pour écouter le pile-up et trouver un trou. |
| `DUAL RX` | FTX-1 : double réception (MAIN et SUB entendus ensemble) ou réception simple. Le FTX-1 refuse la double réception avec les deux VFO en HF / 50 MHz, même sur la même bande (essayé au club : 20 m + 15 m, puis 7,074 + 7,090 MHz) ; il faut qu'un des VFO soit en 144 / 430 MHz. Le bouton est alors grisé (explication au survol). Pour suivre deux stations d'une même bande HF : les deux décodeurs de l'onglet RTTY. | Surveiller deux fréquences. En modes numériques, coupez-le pour ne décoder que le côté actif. |
| `A → B` / `B → A` | Recopie la fréquence et le mode d'un VFO sur l'autre. | Préparer un SPLIT. |
| `A ⇄ B` | Échange les deux VFO. | Passer rapidement d'une fréquence à l'autre. |
| `LOCK` | Verrouille les boutons de la **face avant du TRX au club**. Le dashboard reste utilisable. | Pour qu'une personne au club ne dérègle rien pendant votre trafic. |
| **Bands** : `160M` … `70CM` | Change de bande, sur le VFO choisi (A / B) : le FTX-1 et le FTDX101 reprennent la dernière fréquence et le dernier mode utilisés sur cette bande (comme leur touche BAND) ; le FTDX10 et l'IC-7300 vont sur la fréquence habituelle de la bande (ex. 7,100 MHz en LSB, 14,200 MHz en USB). Seules les bandes du TRX branché sont proposées : `4M` (70 MHz) avec le FTDX10, le FTDX101 et l'IC-7300, `2M` et `70CM` seulement avec le FTX-1. La bande en cours est en surbrillance. Le petit `⧉` dans le coin en haut à droite du cadre l'ouvre dans une fenêtre séparée. | Changer de bande. Un rappel « **TUNE obligatoire** » clignote ensuite à droite jusqu'au prochain TUNE. |
| `Mode auto` | Vert = en service. Quand le VFO entre dans une autre portion de la bande (touche de bande, molette, flèches), le TRX prend le **mode du plan de bande IARU Région 1** : CW dans la portion CW, DATA-U dans la portion des modes numériques et sur les fréquences FT8 / FT4 / WSPR / JT65 / JTTY et SSTV (ex. 7,074, 14,230), phonie en **LSB sous 10 MHz** et **USB au-dessus** (USB sur 60 m), FM en haut du 10 m, en 2 m et en 70 cm. Exemple sur 20 m : 14,000–14,070 CW, 14,070–14,099 DATA-U, 14,101–14,350 USB, sauf 14,227–14,236 (SSTV) en DATA-U. **Votre choix l'emporte** : un mode choisi à la main reste tant que vous restez dans la même portion (USB sur 14,004 par exemple) ; un onglet numérique ou un spot du cluster impose aussi le sien. Balises et segments mixtes : rien ne change. Un clic coupe ou remet ce réglage (gardé dans votre navigateur). | Laisser en service : on arrive toujours dans le bon mode. |

La ligne grise sous les bandes rappelle les gestes utiles ; la ligne de messages juste en dessous affiche les confirmations et les refus.

**Zoom de la fenêtre des modes numériques** : Ctrl + / Ctrl − / Ctrl 0 (ou Ctrl + molette) agrandissent ou réduisent cette fenêtre seule, sans toucher à la face avant ni au dashboard (réglage gardé pour la fenêtre).

<a id="gauche"></a>
### 7.3 Colonne de gauche

**Antenne**

| Commande | Ce qu'elle fait |
|---|---|
| `ANT 1` / `ANT 2` | Choisit la prise d'antenne de l'ampli SPA-1 (FTX-1), ou ANT 1 / ANT 2 / ANT 3 sur le FTDX101. Refusé pendant une émission. Le FTDX10 et l'IC-7300 ne permettent pas ce choix à distance (boutons grisés). Après un changement d'antenne, refaites un TUNE. |

**RF front end** (l'entrée du récepteur)

| Commande | Ce qu'elle fait | Conseil |
|---|---|---|
| **RF GAIN** | Sensibilité du récepteur (0 à 100 %). | Laissez au maximum en général ; baissez-le si une bande est très bruyante ou si une station proche sature. |
| **AGC** `OFF` `FAST` `MID` `SLOW` `AUTO` | Commande automatique de gain : vitesse à laquelle le récepteur baisse le volume après un signal fort. | AUTO convient presque toujours. FAST en CW, SLOW en BLU. OFF à éviter (son très fort et distordu). |
| Préampli, ATT | Comme les badges de l'écran VFO (section 7.1). | — |

**Mode**

| Bouton | Utilisation |
|---|---|
| `LSB` / `USB` | Phonie BLU : LSB sous 10 MHz (160, 80, 40 m), USB au-dessus (20 m…). |
| `CW-L` / `CW-U` | Morse. Les deux s'emploient ; le dashboard choisit tout seul **CW-L sous 10 MHz** et **CW-U au-dessus** quand il change lui-même le mode (spot du DX cluster, carte de bande, liste de fréquences de l'onglet CW), comme LSB / USB en phonie. |
| `RTTY-L` / `RTTY-U` | RTTY décodé par le TRX lui-même. Pour le RTTY du dashboard, utilisez DATA-U. |
| `DATA-L` / `DATA-U` | Modes numériques par la carte son du TRX : **DATA-U** pour FT8, FT4, FT2, RTTY, JTTY, WSPR, JT65, SSTV du dashboard. |
| `PSK` | PSK31 décodé par le TRX. |
| `AM` / `AM-N`, `FM` / `FM-N`, `DATA-FM` | Modulation d'amplitude, de fréquence (N = étroit), numérique en FM (relais, packet…). |
| IC-7300 : `CW` / `CW-R`, `RTTY` / `RTTY-R`, `USB-D` / `LSB-D`, `AM-D`, `FM-D` | Noms Icom : CW = CW-U, CW-R = CW-L (inversé) ; **USB-D** remplace DATA-U pour les modes numériques du dashboard. |

Sous les boutons, « Mode appliqué à **VFO A** » indique quel VFO change de mode (celui choisi avec A / B).

**Filtres**

| Commande | Ce qu'elle fait | Conseil |
|---|---|---|
| **BW** (WIDTH) | Largeur du filtre de réception. FTDX101 : jusqu'à 4,0 kHz, et tout en bas de l'échelle **« défaut »** (badge « BW DEF ») : le TRX reprend sa largeur par défaut et son indicateur WIDTH s'éteint. | BLU : 2,4 à 2,7 kHz ; CW : 300 à 500 Hz ; FT8 : 3 kHz (toute la bande audio). |
| **ROOFING** (FTDX101D / MP) | Filtre de toit (R.FIL du TRX) : 12k, 3k, 1.2k, 600, 300 Hz. 1.2k et 300 seulement si le filtre optionnel est monté. Comme BW, il règle le VFO indiqué dans le titre du cadre (A · MAIN ou B · SUB). | 12k ou 3k en BLU et en numérique ; 600 ou 300 en CW pour résister à une station forte toute proche. |
| **IF SHIFT** | Fait glisser la bande passante vers le haut ou le bas sans changer de fréquence. | Écarter une station gênante d'un côté. Remettez à 0 ensuite. |
| `CONTOUR` | Correcteur de tonalité qui atténue une partie du son. | Rendre une voix plus lisible. |
| `APF` | Filtre audio de pointe, en CW seulement. | Faire ressortir un signal CW faible. |
| `NARROW` | Filtre étroit : il s'allume et se coupe avec le badge `NAR` de l'écran VFO. Enclenché, le TRX impose sa largeur étroite : le curseur BW est grisé et affiche `NARROW ✕` (explication au survol) ; un clic sur `NARROW ✕` coupe NARROW et rend le curseur BW. | Bande encombrée. Si BW est grisé sur un VFO et pas sur l'autre, c'est que NARROW est enclenché de ce côté. |
| IC-7300 : **FILTRE**, **PBT** | FIL1 / FIL2 / FIL3 (large, moyen, étroit) et Twin PBT (rétrécir par les deux bords). | — |

**Station meters** (mesures, surtout utiles en émission)

| Mesure | Signification | Valeur normale |
|---|---|---|
| RX / TX | État du TRX ; à droite, durée de l'émission en cours. | — |
| **Po** | Puissance émise (watts). | Celle réglée dans le cadre TX. |
| **SWR** | Accord de l'antenne. | Sous 1,5 ; au-delà de 2,5, l'émission est coupée. |
| **ALC** | L'émetteur est-il poussé trop fort ? | Modes numériques : le plus bas possible (idéalement 0). Phonie : un peu d'ALC sur les pointes. |
| **Id** / **Vd** | Courant et tension de l'étage final. | Pour les responsables (surveillance). |
| **COMP** | Compression du processeur de modulation (phonie). | Quelques dB quand PROC est en service. |
| **S** | S-mètre du côté actif. | — |

<a id="droite"></a>
### 7.4 Colonne de droite

**RX audio**

| Commande | Ce qu'elle fait | Pour qui |
|---|---|---|
| `🔊 Écouter le TRX` | Fait entendre le son du récepteur dans votre navigateur. Un deuxième clic coupe. | Vous seul (pas besoin de la main). |
| **Volume** | Volume de votre écoute (0 à 150 %). | Vous seul. |
| **AF LEVEL** | Volume du haut-parleur du TRX au club. | Tout le monde (avec la main). N'influence pas votre écoute ni les décodeurs. |
| **SQUELCH** | Silencieux : coupe le son tant qu'aucun signal ne dépasse le seuil. | Tout le monde. Utile en FM ; laissez-le à 0 en HF et en numérique, sinon les décodeurs n'entendent plus rien. |
| « ⚠ Plus de son du TRX sur le PC du club » | Alerte orange : depuis 45 s, la page Station ne reçoit plus de son du TRX alors qu'il est connecté (carte son USB du TRX figée). | Tout le monde la voit. ON6DP et ON4LUC ont le bouton `Relancer la carte son` (section 18). Elle disparaît dès que le son revient. |

**DSP** (traitement du signal)

| Commande | Ce qu'elle fait |
|---|---|
| **NB** | Niveau de l'antiparasite (OFF, puis 1 à 10). Commencez bas et montez jusqu'à ce que les claquements disparaissent. |
| **DNR** | Niveau du réducteur de bruit (OFF, puis 1 à 10 ; jusqu'à 15 sur le FTDX10). Trop haut, la voix devient « métallique ». |
| `NOTCH` + **Fréq. NOTCH** | Allume le notch manuel et règle sa fréquence (10 à 3200 Hz) : tournez jusqu'à ce que le sifflement disparaisse. |
| `DNF` | Notch automatique. |

**Accord (tuner)**

| Commande | Ce qu'elle fait |
|---|---|
| `TUNER` | Met en service ou hors service la boîte d'accord (celle du SPA-1 pour le FTX-1). Elle est remise en service toute seule à la connexion du TRX et à chaque changement de bande HF / 6 m. |
| `TUNE` | Lance l'accord : le TRX émet une porteuse quelques secondes, le tuner cherche le meilleur réglage. **Obligatoire après un changement de bande** ; vérifiez ensuite le SWR. TUNE compte comme une émission : il faut avoir la main et l'émission autorisée. |

**TX**

| Commande | Ce qu'elle fait |
|---|---|
| Voyant `RX` / `TX` | État réel du TRX (vert en réception, rouge en émission). |
| `PTT` | **Maintenir** pour émettre (ou la barre `Espace`) ; relâcher = retour en réception. Le petit texte en dessous dit pourquoi le PTT est indisponible (« Prenez la main pour émettre »…). |
| **Puissance** `−` `+` | Baisse ou monte la puissance du TRX, d'un pas par clic : 5 W (0,5 W sur le FTX-1 sans l'ampli SPA-1). Plages : FTX-1 0,5 à 10 W seul, 5 à 100 W avec le SPA-1 ; FTDX10, FTDX101D et IC-7300 5 à 100 W ; FTDX101MP 5 à 200 W. Votre limite de licence est affichée en dessous (ON2 : 100 W, ON3 : 25 W) ; au-delà, la puissance est ramenée automatiquement. **Licence ON3** : émission seulement sur 80, 40, 30, 20, 15, 10 m, 2 m et 70 cm (refusée sur 160, 60, 17, 12, 6 et 4 m, avec la raison affichée) ; la réception reste libre partout. |
| **Gain micro** | Niveau du **micro du club** en phonie (menu MIC GAIN du TRX). La phonie à distance a son propre niveau (page Station, « Niveau phonie à distance »). Grisé quelques secondes à l'ouverture, le temps que le TRX donne sa valeur. |
| `PROC` + **Niveau PROC** | Processeur de modulation (compresseur) : la voix « porte » mieux dans le bruit. Niveau modéré, sinon la modulation est désagréable. Sur l'IC-7300 : COMP. |
| `MIC EQ` (FTDX10, FTDX101) | Met en service ou coupe l'égaliseur paramétrique du TRX (réglé avec `Equalizer TRX`). |
| `VOX` | Émission déclenchée par la voix : peut seulement être **coupé** à distance, jamais activé. |
| **SSB CONFIGURATION** | Phonie à distance (section 4.2) : `Configuration micro` (votre micro vers le TRX ; point vert = actif ; nouveau clic = coupé), `Equalizer TRX` (menus PRMTRC du TRX, votre profil), choix du micro et type reconnu, barre de niveau (restez dans le vert, jamais **SAT**), `Equalizer micro` (égaliseur de votre micro dans le navigateur), ligne d'état, `🎧 M'écouter` (au casque) et son **Volume** (0 à 300 %, sans effet sur ce qui part vers le TRX). |

<a id="split"></a>
### 7.5 Trafic en SPLIT (émission et réception sur deux fréquences)

Le SPLIT sert surtout pour une **expédition DX** qui écoute ailleurs que sur sa fréquence (« UP 5 », « listening 14 200 to 14 210 »). On **écoute le DX sur le VFO A** et on **émet sur le VFO B**.

1. Réglez le **VFO A** sur la fréquence du DX, dans le bon mode. Vérifiez que `RX` est vert sur le VFO A.
2. Cliquez `A → B` : le VFO B prend la même fréquence et le même mode.
3. Réglez la **fréquence d'émission sur le VFO B** avec la molette sur ses chiffres, par exemple +5 kHz pour « UP 5 ». Sur le FTX-1, la molette sur le VFO B ne change pas le côté écouté : vous restez sur A.
4. Cliquez `SPLIT` (ou `TX` sur l'écran du VFO B). Le voyant **TX** et le cadre lumineux passent sur le VFO B ; le rappel indique « Émission sur B ».
5. Écoutez le DX sur A ; **maintenez TXW** (ou `W`) pour écouter le pile-up sur votre fréquence d'émission. Pour l'appeler, **PTT** : l'émission part sur le VFO B (chiffres en rouge). En relâchant, retour en réception sur A.
6. Pour finir : cliquez de nouveau `SPLIT` (ou `TX` du VFO A). Le voyant TX revient sur A.

> [!TIP]
> **Bon à savoir**
> - Règle des TRX : sans SPLIT on émet sur le VFO où l'on écoute ; avec SPLIT, sur l'autre.
> - **FTX-1** : le SPLIT est géré par le dashboard, par échange des VFO. Au PTT, la page Station échange A et B sur le TRX (A ⇄ B), émet du côté actif sur la fréquence et dans le mode du VFO d'émission, puis, une fois la réception confirmée, remet les VFO en place. Sur l'écran du TRX, les fréquences s'échangent pendant l'émission : c'est normal ; le dashboard, lui, montre les VFO à leur place. Un appui très court (moins d'un quart de seconde) n'émet pas. Un SPLIT mis sur la face avant est suivi par le dashboard.
> - La fréquence **réellement émise** (VFO B, XIT compris) est contrôlée : hors des bandes autorisées, le PTT est refusé.
> - Petit écart (quelques kHz) : `XIT` sur le VFO A suffit, sans SPLIT.
> - En **FT8 / FT4 / FT2**, inutile de mettre SPLIT : l'émission se place dans la bande audio avec le repère TX de la cascade (clic droit).
> - Coupez le SPLIT en fin de pile-up : sinon, le prochain opérateur émettrait sur le VFO B sans le savoir.

<a id="ecoute"></a>
## 8. Écouter

- Cadre **RX audio** → `🔊 Écouter le TRX`, puis réglez votre **Volume**. Tout le monde peut écouter, même sans la main.
- Le son arrive avec un petit retard (une fraction de seconde) : c'est normal sur internet.
- Si rien ne s'entend : vérifiez le volume de votre PC, puis le voyant Station. La page Station du club doit avoir l'audio activé (section 18). Le message sous le bouton indique ce qui manque.
- **AF LEVEL** et **SQUELCH** agissent sur le TRX lui-même, pour tout le monde.
- Plus de son, cascade muette avec seulement un ronflement tout à gauche, et l'alerte orange « Plus de son du TRX » : la carte son USB du TRX s'est figée. Un responsable la relance à distance (bouton `Relancer la carte son`), sinon il faut éteindre et rallumer le TRX au club (section 18).

<a id="emission"></a>
## 9. Émettre et sécurités

1. **Avoir la main** et un compte autorisé à émettre (les écouteurs ONL ne peuvent pas).
2. Être dans une **bande autorisée** pour votre licence.
3. Après un changement de bande : `TUNE`, puis vérifier le **SWR**. Un rappel clignote à droite de la touche 70CM jusqu'au TUNE (en 2 m et 70 cm, pas de tuner : seulement « vérifiez le SWR »). Le tuner du SPA-1 ne travaille qu'en HF et 6 m, et l'ampli doit être allumé.
4. Régler la **puissance** (cadre TX).
5. Émettre : `PTT` maintenu (ou `Espace`), ou les boutons d'émission des modes numériques.

> [!WARNING]
> **Sécurités automatiques** (impossible de les contourner depuis le dashboard) :
> - Émission seulement dans les bandes autorisées, vérifiée sur la fréquence réellement émise (SPLIT et XIT compris).
> - Durée maximale d'une émission : **120 s**, puis coupure ; relâchez le PTT avant de réémettre.
> - Coupure immédiate si vous perdez la liaison, si le PC du club perd internet ou si la page Station se ferme.
> - **ROS** supérieur à 2,5:1, ou **HI-SWR** signalé par le TRX : émission coupée et PTT refusé sur cette fréquence (± 25 kHz) jusqu'à un TUNE réussi.
> - **TUNE sans accord** : si le FTX-1 signale HI-SWR à la fin d'un TUNE, l'émission est **bloquée sur toute la bande** (sauf TUNE) pour protéger l'ampli. Un message rouge s'affiche à droite des bandes. Le blocage tombe dès qu'un TUNE réussit ; sinon, essayez l'autre antenne ou prévenez un responsable.
> - Au club, le TRX repasse en réception s'il émet sans modulation pendant 2 min (**20 s en modes numériques** : DATA, RTTY, PSK — carte son figée pendant une série FT8…) ou 5 min sans interruption.
> - Puissance ramenée à la limite de votre licence ; indicatifs d'écouteurs : aucune émission.

L'émission n'est possible que si les administrateurs l'ont autorisée sur le serveur.

<a id="ssbcontest"></a>
### 9.1 Phonie et contests : le TRX SSB

Onglet `SSB` de la ligne des onglets du dashboard, ou bouton `SSB` de la ligne **MODES** de la face avant : une page à part (adresse **/ssb**), raccrochée à la page qui l'a ouverte (même connexion, même main), comme le TRX CW ; avec la main, le TRX passe en LSB (sous 10 MHz) ou en USB s'il n'était pas en phonie BLU. En haut : fréquence et mode du TRX (orange hors LSB / USB), qui a la main (`PRENDRE LA MAIN`), grand voyant **RX / TX**. Juste dessous, la **phonie** comme sous la face avant : le grand bouton `PTT` (maintenir, ou la barre d'espace quand le curseur n'est pas dans une case) et la ligne **SSB CONFIGURATION** (`MICRO`, `EQUALIZER MICRO`, niveau du micro, `EQUALIZER TRX`, `Profil de …`, **Entrée** et **Sortie** son, `M'ÉCOUTER` et son volume). Activez `MICRO` dans cette page pour parler depuis elle ; la voix part par la connexion de la page d'origine, mêmes sécurités que le PTT de la face avant. Le titre commence par le **TX call** (indicatif sous lequel on émet, par exemple « ON5VL TRX SSB »), comme dans le TRX CW.

**Sans contest** (« — pas de contest — ») : cadre **LOG DU QSO**, la fiche du carnet de trafic comme dans l'onglet Logbooks (indicatif, date et heure UTC, ⟳ Maintenant, fréquence et mode repris du TRX, ⇩ TRX, RST, TX call, QO-100, nom, QTH, locator, puissance, remarque, références IOTA / WWFF / POTA / BOTA / LLOTA, ＋ Ma référence) et `ENREGISTRER LE QSO` : le QSO va dans le carnet général. Les doublons sont demandés dans cette page seulement ; la fiche du dashboard n'est pas touchée. Sous la fiche, jusqu'en bas de la page : les **derniers QSO en phonie hors contest** (SSB, LSB, USB) du carnet général, le plus récent en haut (date, heure, indicatif, bande, fréquence, reports, nom, QTH, pays, TX call, opérateur). En contest, la page ne montre que les QSO du contest choisi (log à droite) ; ils sont aussi dans le carnet général, avec le nom du contest dans la colonne **Contest**.

- **Contest** : liste des contests en phonie avec, pour chacun, l'**échange** à donner par une station belge et les **catégories** d'inscription ; à côté de la liste, la date habituelle, une note et le lien `Règlement ↗`. Les contests marqués ***** ont des catégories « habituelles » : vérifiez le règlement de l'année.
   - CQ WW DX SSB : **59 + zone CQ (14)** ; catégories mono-op HP / LP / QRP, multi-single HP / LP, multi-two, multi-multi, multi-distribué, checklog ; overlays Classic, Rookie, Youth.
   - CQ WPX SSB : **59 + n° de série** ; mono-op HP / LP / QRP (36 h sur 48), multi-one HP / LP, multi-two, multi-multi, multi-distribué ; overlays Tribander-wires, Rookie, Classic, Youth.
   - ARRL DX SSB : **59 + puissance** (100, 400, KW…) ; on ne contacte que les W / VE ; mono-op HP / LP / QRP, multi-single, multi-two, multi-multi.
   - IARU HF : **59 + zone ITU (27)** (les sièges IARU donnent leur sigle) ; mono-op phonie, mono-op mixte, multi-single, multi-two.
   - WAE DX SSB (DARC) : **59 + n° de série** ; mono-op LP / HP, multi ; les QTC ne sont pas gérés par la page.
   - UBA DX SSB : **59 + n° de série + section UBA** (LGE pour le club ; XXX pour un non-membre) ; CH / CL (24 h), BH / BL (12 h), AH / AL (6 h), D multi-op, E QRP, BASE (ON3).
   - ON Contest SSB : **59 + n° de série + section** (LGE) ; catégories A et A2.
   - EU HF Championship : **59 + année de la première licence** (« 00 » à remplacer) ; SSB HP / LP, mixte HP / LP, illimité, QRP.
   - Les autres (RDXC, SP DX, HA DX, OK/OM, YO DX, El Rey de España, Helvetia, PACC, WAG, Coupe du REF, ARI, Ukrainian DX, CQ-M, ARRL 10 m : 59 + n° de série ; CQ 160 m, JIDX : 59 + zone CQ ; LZ DX : 59 + zone ITU ; All Asian : 59 + âge) et « Autre contest ».
- **Catégorie** : celle de l'inscription ; selon le contest s'y ajoutent **Puissance** (quand la catégorie ne la fixe pas), **Bande** (mono-bande), **Assisté** (spots du DX cluster utilisés) et **Overlay**. Elle est écrite dans l'en-tête du fichier Cabrillo (CATEGORY-OPERATOR, -POWER, -BAND, -ASSISTED, -MODE, -TRANSMITTER, -OVERLAY, -TIME). Gardée par contest dans ce navigateur.
- **Échange** : modifiable (`<CNTR>` n° de série, `<CQZ>` zone CQ, `<ITUZ>` zone ITU, `<MYNAME>` prénom) ; en vert, ce qu'il faut annoncer au micro. **N°** : numéro de série, **+1 automatique à chaque QSO enregistré** (seulement si l'échange contient `<CNTR>`), `−1` / `+1` pour corriger ; même numéro que le TRX CW et le contest RTTY.
- **Log du contest** (à la manière de N1MM) : ligne **Indicatif · RS · Envoyé · RS · Reçu** (**Envoyé** est rempli tout seul avec ce qu'il faut annoncer : la zone, la puissance… ou le **n° de série de ce QSO**, qui passe au suivant dès que le QSO est enregistré ; vous pouvez le changer à la main), `LOG ↵`, `EFFACER` (`Alt`+`W`), `Espace` = champ suivant ; **DOUBLON** (même indicatif sur la même bande) en rouge, « nouveau » en vert ; à droite, les QSO, les compteurs par bande, la cadence (QSO / h), **Depuis** (date de début) et `CABRILLO` (fichier du contest avec la catégorie choisie). Les QSO vont dans le **carnet général** (contest, échange envoyé et reçu, LSB / USB selon le TRX). Un spot cliqué dans une carte de bande met l'indicatif dans la case **Indicatif**.
- **Score** (sous les mémoires vocales) : par bande, les QSO, les points et les multiplicateurs, puis le **score estimé** d'après le règlement du contest (CQ WW, CQ WPX, ARRL DX, IARU HF, WAE, UBA DX, ON Contest, EU HF ; survol du score : la règle appliquée ; autres contests : règle générique, « estimation »). Doublons non comptés ; QTC du WAE et bonus de l'UBA DX non comptés. **Évolution** : heure par heure (UTC), les QSO de l'heure, le cumul et le score à la fin de l'heure.
- **Indicatifs probables** : en tapant le début d'un indicatif (2 caractères ou plus), les indicatifs connus qui le contiennent : ceux du log du contest, puis la liste **Super Check Partial** (MASTER.SCP, indicatifs actifs en contest, téléchargée chaque semaine par le serveur), en vert s'ils ne sont pas encore dans le log, barrés si déjà contactés sur la bande ; un clic le met dans la case Indicatif. Case vide : les **stations spotées en SSB** sur la bande du TRX (DX cluster), les plus récentes d'abord ; un clic met l'indicatif et, si vous avez la main, le TRX sur sa fréquence.
- Le **log du contest** (à droite) descend jusqu'en bas de la page ; chaque QSO est aussi dans le carnet général, colonne **Contest**.
- **Touche Entrée** (ESM) : **RUN** (vous appelez CQ) : case vide → mémoire vocale **T1** (CQ) ; indicatif tapé → curseur dans **Reçu** (annoncez l'échange au micro) ; échange reçu tapé → QSO enregistré, puis **T3** (TU / QRZ) si elle est enregistrée. **S&P** (vous répondez) : indicatif → **T4** (votre indicatif) ; échange reçu → QSO enregistré.
- **Mémoires vocales** `F1` … `F8` = vos mémoires **T1 … T8** (VOICE TX : enregistrées avec votre micro, MENU → VOICE → REC sur la face avant), durée sous le nom ; la touche devient rouge pendant l'émission, `Échap` l'arrête. Le reste se dit au micro avec le `PTT` de la page qui a ouvert le TRX SSB. Mêmes sécurités qu'en phonie.

<a id="operateurs"></a>
## 10. Opérateurs et discussion

- Le volet **Opérateurs** s'ouvre et se ferme avec le bouton `👥` du bandeau. Un point rouge sur `👥` signale un nouveau message. À l'arrivée d'un message d'un autre membre, `👥` **clignote** (jusqu'à l'ouverture du volet), l'indicatif de l'auteur clignote dans la liste pendant 20 s, le message s'affiche en bas de l'écran et un **bip-bip** retentit ; `🔔` à côté de « Envoyer » coupe ou remet le bip (🔕 = coupé), réglage gardé dans ce navigateur.
- ON6DP, ON4LUC et ON5VL (le compte de la station elle-même) ne sont **jamais déconnectés** pour inactivité (seulement par « Déconnexion ») ; la main leur est quand même libérée après 15 min sans action. Réglage `idleExempt` du serveur.
- Il montre les membres connectés et qui a la main.
- **Discussion** : tapez un message dans « Message aux connectés… » puis `Envoyer` (ou `Entrée`). Tous les connectés le voient. Les messages ne sont pas gardés après un redémarrage du serveur.
- Les boutons `Demander la main à …` et `Passer la main à …` y apparaissent quand c'est utile (section 6).
- L'onglet **Modes** (au centre, premier onglet) est le journal de la station : connexions, prises et passages de main, émissions (fréquence, mode, puissance, durée), accords, coupures de sécurité, station en ligne, TRX connecté…

<a id="disposition"></a>
## 11. Disposition et fenêtres séparées

- Bouton `⧉` en haut à droite d'un cadre : le cadre s'ouvre dans **sa propre fenêtre**, à placer où vous voulez (sur un 2e écran…). Dans cette fenêtre, `⧉ Ramener` le remet dans le dashboard.
- Le bouton `⧉` à droite des onglets ouvre **tous les modes numériques** dans une fenêtre séparée. `⧉ Ramener dans le dashboard` (ou `Ramener ici` dans le dashboard) les remet en place.
- La barre `Espace` (PTT) fonctionne aussi depuis une fenêtre séparée.
- La disposition est retenue : au chargement suivant, les fenêtres se rouvrent à leur place si Chrome **autorise les fenêtres pop-up** pour remote.op0p.be (icône à droite de la barre d'adresse → Toujours autoriser).
- **Replier un cadre** : clic sur son titre (ou `Entrée` quand le titre a le focus) ; un deuxième clic le rouvre. Retenu dans ce navigateur.
- **Tout le dashboard dans sa propre fenêtre** : bouton `⧉ Fenêtre` du bandeau. Le dashboard se rouvre dans une fenêtre à lui, sans barre d'adresse ni onglets, que vous placez et dimensionnez où vous voulez ; sa place et sa taille sont retenues pour la fois suivante. L'onglet d'origine affiche « Dashboard ouvert dans sa fenêtre » (bouton pour l'y ramener ou la remettre devant). Chrome doit **autoriser les fenêtres pop-up** pour remote.op0p.be.
- **L'installer comme une application** (Chrome, Edge) : bouton `⤓ Installer` du bandeau (ou l'icône d'installation à droite de la barre d'adresse). Remote Station reçoit alors son **icône sur le bureau** et dans le menu Démarrer, et s'ouvre toujours dans sa propre fenêtre. Le bouton disparaît une fois l'application installée ; pour la désinstaller : menu ⋮ de sa fenêtre → Désinstaller.
- **Taille de tout le dashboard** : menu `Auto 100 %` du bandeau (section 5), de 50 à 200 %.
- **Poignées à glisser** (double-clic : taille d'origine, retenue dans ce navigateur) : sous la cascade (hauteur de la cascade et des listes), entre les deux listes FT8 et entre les deux décodeurs RTTY (largeurs), sur le bord gauche de la carte de bande (sa largeur), au bord droit des titres de colonnes du carnet (largeur des colonnes).
- **Carte de bande** : sur un écran de 1920 × 1080 et plus, elle forme une colonne à part, **tout à droite**, sur toute la hauteur (la colonne RX audio / DSP / Accord / TX se place juste à sa gauche). Elle n'apparaît que sur les onglets qui ont des spots (FT8 · FT4 · FT2, JT65, RTTY, WSPR, JTTY, CW). Sur un écran plus petit, elle reste au bord droit de la fenêtre centrale.

<a id="face"></a>
### 11.1 Face avant du FTDX101 (page séparée)

Adresse : **https://remote.op0p.be/ftdx101**. La face avant du FTDX101MP, où **chaque touche et chaque bouton fait la même chose que sur le TRX**, avec en dessous les **modes numériques** (FT8, RTTY, WSPR, JT65, JTTY, CW, SSTV, Synchro) comme dans le dashboard. Le dashboard reste la page principale (carnet, phonie à distance…). Même connexion (pas de mot de passe à retaper si vous êtes déjà connecté dans ce navigateur), même bouton `Prendre la main`, mêmes sécurités. Elle ne sert que lorsque le FTDX101 est le TRX en service ; sinon la page l'indique.

**FTDX10** : même principe à l'adresse **https://remote.op0p.be/ftdx10** (modes numériques : **/ftdx10/digi.html**). Le FTDX10 n'a **qu'un seul récepteur** : l'écran montre un S-mètre, le VFO-A en grand et le VFO-B en petit (grisé), les cases ATT / IPO / R.FIL / AGC, le filtre (WIDTH, NAR, R.FIL 12k / 3k / 500 Hz, IF SHIFT, NOTCH, CONTOUR) et le scope de la BF ; pas de MAIN / SUB, de DISP, de MONO ni de double réception. Touches : **BAND** = tableau des bandes sur l'écran ; **A/B** = échange des VFO (appui long : A → B) ; **STEP/MCH** = accord rapide (voyant STEP) ; **FINE** = 1 Hz par cran (la touche FINE du TRX suit) ; **CONT/APF** = CONTOUR, ou APF en CW ; **VOX/MOX** : clic = VOX, appui long = MOX ; bouton **FUNC** = la fonction de la case à droite du VFO-B (choisie dans le menu FUNC : clic sur le bouton ou sur la case). Rangée du bas : CENTER, 3DSS, MULTI, EXPAND, SPAN, SPEED (vitesse de la cascade). Voyants du haut : TX, VFO-A et VFO-B (vert = réception, rouge = émission), FINE, STEP.

**FTX-1** (tête Field avec l'ampli Optima) : **https://remote.op0p.be/ftx1** (modes numériques : **/ftx1/digi.html**). Même écran que la face avant du FTDX101 (deux récepteurs : galvanomètres, filtres, fréquences, cases, scope, DISP, MONO…), mais comme sur le TRX le **SUB est à gauche** et le **MAIN à droite** ; cases ANT, ATT, IPO, NAR, AGC ; fréquences avec les 3 derniers chiffres (Hz) plus petits, filtres comme sur le TRX (trait blanc, intérieur gris, spectre dans la bande passante) ; rangée du bas D-MODE (CENTER : fréquence au milieu ; CURSOR : fenêtre fixe où se déplacent ▼ vert (écoute) et ▼ rouge (émission) ; FIX : fenêtre au début de la bande, « R ▶ / T ▶ » au bord quand on est en dehors — le spectre est celui du son reçu, placé à sa fréquence), 3DSS, MULTI, **SCOPE** (MAIN ou SUB dessous : scope du VFO sélectionné ; réglages du scope dans l'écran FUNC), **SPAN** (5 kHz à 1 MHz, lu sur le TRX et envoyé au TRX ; le scope du TRX ne passe pas par le CAT : en **CENTER**, dès que le SPAN dépasse le son reçu, la cascade de la page montre ce son, **3 kHz, sur toute sa largeur** avec sa propre échelle en fréquences, et l'indique en haut à droite « son reçu : 3 kHz (SPAN … sur le TRX) ») ; en **CURSOR / FIX**, la vraie fenêtre du SPAN, en entier : le ▼ vert de l'écoute peut être n'importe où et suit la souris quand on glisse avec le **bouton gauche** (le son reçu se déplace avec lui) ; le **bouton droit** (clic ou glisser) place la ligne rouge, la fréquence d'émission sur l'autre VFO, et met le SPLIT en service s'il ne l'est pas ; en SPLIT, comme sur le TRX : en CURSOR / FIX la page reprend la vraie fenêtre du SPAN, fixe, avec ▼ rouge à la fréquence d'émission et ▼ vert de l'écoute qui se déplace sur toute la largeur avec le grand bouton (le son reçu, 3 kHz, se déplace avec lui) ; en CENTER, seul le trait rouge, celui de l'émission, se déplace (l'écoute reste au même endroit) ; **clic sur le spectre ou la cascade** (ou **glisser**, bouton enfoncé, en CURSOR / FIX : la fréquence suit la souris) : le VFO de ce scope va sur la fréquence cliquée (au survol : la fréquence sous la souris), comme en touchant l'écran du TRX (main prise), **SPEED** (tableau SLOW1, SLOW2, FAST1, FAST2, FAST3, STOP ; nouvel appui sur SPEED : fermé). Touches : **MAG BAND** (appui bref : bande suivante 1.8 → 3.5 → 7 → 10 → 14 … ; appui d'1 s : tableau des bandes du TRX, 1.8 à 430, pour aller directement à une bande ; AIR et 70/GEN pas à distance), **N/W MODE** (appui bref : NARROW ⇄ WIDE, filtre étroit ou large du récepteur actif ; appui d'1 s : tableau des modes pour choisir le mode), **SPLIT** (« SPLIT » noir sur blanc dans la barre d'état, à droite de FAST / FINE, qui clignote 2 fois à la mise en service — pas sur le TRX, pour attirer l'attention ; SPLIT virtuel du FTX-1, comme dans le dashboard : rien n'est envoyé au TRX avant l'émission ; **appui de plus d'1 s** : comme sur le TRX, l'autre VFO prend la même fréquence et le SPLIT se met en service — on émet là (▼ rouge sur le scope, il ne bouge plus) et le grand bouton déplace l'écoute (▼ vert, fréquence en orange) pour aller sur la station), **CLAR** (1er appui CLAR RX, 2e CLAR TX, 3e CLAR RXTX, 4e arrêt ; les bandes de part et d'autre du grand bouton passent au rouge et le **grand bouton règle le décalage** (10 Hz par cran, 1 Hz en FINE), la fréquence affichée suit le décalage en CLAR RX ; appui long : décalage à zéro), **DISP** (comme sur le TRX : écran normal → un VFO (le sélectionné) avec le scope → MAIN et SUB l'un sur l'autre sans scope, avec leurs cases ATT / IPO / DNF / AGC (clic : changer ; ATT et IPO du SUB : le CAT du FTX-1 ne les lit et ne les règle que sur le côté en service — « — » tant que le SUB n'a pas été le côté en service, valeurs gardées ensuite ; à changer sur la face avant du TRX) → filtres agrandis (à la place de l'écran éteint du TRX) → retour), **BACK** (ferme le tableau ouvert), **FINE/FAST** (appui bref : FINE, accord fin, « FINE » en noir sur blanc dans la barre d'état ; appui d'1 s : FAST, « FAST » en bleu ; le TRX suit, FN), **LOCK** (administrateurs seulement) ; voyants **BUSY/TX SUB / MAIN** (rouge sur le VFO qui émet). Boutons : grand bouton = fréquence du récepteur actif, **SUB DIAL** = fréquence du VFO B (SUB) ; **clic** : VFO actif MAIN ⇄ SUB, comme sur le TRX (en double réception seulement, par sécurité), **FUNC** : **appui de 2 s** = écran FUNC du TRX (3 pages SSB / CW / FM-C4FM, comme sur le TRX : D-LEVEL, ATT, IPO, DNF, AGC, MIC EQ, PROC LEVEL, TUNER, NB, DNR, ANT, TXW, RF POWER, MIC GAIN, AMC LEVEL, VOX GAIN / DELAY, MONI LEVEL, KEYER, BK-IN, CW SPEED / PITCH, BK-DELAY, ZIN, CW SPOT, RPT SHIFT, SQL TYPE, TONE FREQ…) ; dans l'écran, **tourner FUNC** déplace le cadre orange, **pousser FUNC** règle la case (tourner FUNC change la valeur, pousser à nouveau : fini ; FWD / BACK : page suivante / précédente), clic sur une case puis − / + ou molette ; **appui de 2 s** : sortie. Page 3 (FM/C4FM) : **SQL TYPE** se règle dans tous les modes (OFF, ENC, TSQ, DCS, PR FREQ, REV TONE) ; **TONE FREQ** (67.0 à 254.1 Hz) et **DCS** (023 à 754) en FM, valeur affichée en gris dans les autres modes ; **DTMF** = écran DTMF CODE du TRX : clavier à gauche, mémoires 1 à 10 à droite (▲ ▼), relues sur le TRX ; choisir une mémoire puis taper le code (16 caractères au plus) : il part au TRX quand la frappe est finie (main prise ; une mémoire ne s'efface pas par le CAT ; rien n'est émis depuis cet écran). APRS S.LIST / M.LIST (tous modes), APRS BEACON / BCN-TX (FM seulement, grisés sinon), DG-ID TX / RX (00 à 99), HOME (dernière fréquence FM), REV et T-CALL : pas de commande CAT, au TRX seulement. Les menus **RADIO / CW / OPERATION / DISPLAY / EXTENSION / APRS SETTING** (case du bas de la page 3) et **APRS BEACON** (case APRS BEACON, en FM) sont **réservés aux administrateurs ON6DP et ON4LUC** (les autres membres ont le message « réservé aux administrateurs » ; le serveur le vérifie aussi). Ils s'ouvrent comme sur le TRX : titre, sous-menus à gauche (RADIO : MODE SSB, AM, FM, DATA, RTTY, DIGITAL, WIRES-X ; CW : MODE CW, KEYER ; OPERATION : GENERAL, BAND-SCAN, RX-DSP, TX AUDIO, TX GENERAL, KEY/DIAL, OPTION ; DISPLAY : DISPLAY, UNIT, SCOPE, VFO IND COLOR ; EXTENSION : DATE&TIME, MY POSITION, SD CARD, SOFT VERSION, CALIBRATION, RESET ; APRS SETTING : GENERAL, MSG TEMPLATE, MY SYMBOL, DIGI PATH ; APRS BEACON : BEACON SET., AUTO BEACON, SmartBeac., BEACON TEXT ; APRS FILTER : LIST SETTING, STATION LIST, POPUP, RINGER, MSG FIL.), 5 réglages à droite avec leur valeur relue sur le TRX (« lecture sur le TRX… » dans le titre pendant la lecture), ▲ ▼, molette ou bouton FUNC pour défiler, BACK pour revenir à l'écran FUNC. **Clic sur un réglage** (cadre jaune) : toutes ses valeurs possibles s'affichent dessous (la valeur actuelle en surbrillance), puis − / +, molette ou FUNC : la valeur part au TRX et elle est relue. Tant que l'écran est ouvert, le sous-menu est **relu toutes les 8 s** : un réglage changé au TRX lui-même apparaît sur la page. Les valeurs suivent l'écran du TRX (puissances de la tête Field en dixièmes de watt : 6.0W sur batterie, 10.0W en HF ; RPT SFT FREQ 144 / 430 MHz par pas de 50 kHz ; symboles APRS « /> (Car) »…). **DATE&TIME** : jour, mois, année, heure et minute lus sur le TRX ; bouton **« Mettre à l'heure de votre PC »** (main prise). Les cases **PRMTRC EQ** de TX AUDIO portent l'étiquette EQUALIZER TRX : elles se règlent par les profils, avec le bouton **« Ouvrir EQUALIZER TRX »**. **Restent bloqués, même pour les administrateurs** (ils casseraient la station à distance) : liaison CAT-1 et CAT-3, MOD SOURCE, USB MOD GAIN, RPTT SELECT, PC KEYING, CW MEMORY 5, égaliseur d'émission (par les profils), AUTO POWER OFF. Les textes (MY CALL, CALLSIGN APRS, messages, statuts, groupes…) sont relus mais se changent au TRX ; WIRES-X, DAY / MONTH… non : pas de commande CAT (« au TRX »). SD CARD, SOFT VERSION, CALIBRATION, RESET : au club seulement. Attention : BEACON TYPE en AUTO ou SMART fait émettre le TRX tout seul. MOX et MESSAGE / PLAY / RECORD ne sont pas à distance (VOX : seulement coupé). Écran fermé, tourner FUNC règle la dernière case choisie, dont le nom est en haut à droite de l'écran (ex. RF POWER), avec le cadre « RF POWER 83W » sur le scope comme sur le TRX, **toucher un S-mètre** : tableau **METER** comme sur le TRX (PO, COMP, ALC, VDD, ID, SWR ; TEMP pas à distance) — la 2e échelle sous l'S-mètre et l'aiguille en émission suivent ce choix, **SUB DSP AF/RF/SQL** et **MAIN DSP AF/RF/SQL** (centre : AF, bague : RF ; **appui d'1 s** (ou clic sur le cadre de son filtre) : écran DSP de ce récepteur — grand filtre, onglets SHIFT, WIDTH, NOTCH, CONTOUR / APF en CW ; tourner le bouton ou la molette règle, pousser le bouton : onglet suivant, appui d'1 s : fermé). En CW-L / CW-U, le BK-IN est mis en service tout seul à chaque passage en CW. QMB, V/M, M▸V, PMG : pas à distance ; **S-DX** (Super DX : renfort des signaux faibles en réception, « S-DX » à côté de FAST / FINE quand il est en service) : le FTX-1 n'a pas de commande CAT pour lui, il ne se règle qu'au club. Cartes de bande dans le même ordre que l'écran : **VFO-B (SUB) à gauche**, **VFO-A (MAIN) à droite**. Bouton **🎧 Stéréo MAIN | SUB** : comme sur le FTDX101, double réception, MAIN dans l'oreille gauche et SUB dans l'oreille droite (le FTX-1 sort ses deux récepteurs en stéréo sur l'USB ; double réception seulement si l'un des VFO est au-delà de 118 MHz, pas avec deux fréquences HF) ; dans la page /ftx1/digi.html, le 2e décodeur RTTY lit alors le SUB avec sa cascade. L'émission FT8 auto part toujours du VFO principal du FTX-1.

**IC-7300** : **https://remote.op0p.be/ic7300** (modes numériques : **/ic7300/digi.html**). Un seul récepteur ; l'écran est celui de l'IC-7300 : en haut TUNE et l'indicateur **TX** (rouge sur fond noir en réception dans une bande amateur, blanc sur fond rouge en émission, barré hors des bandes amateur), le mode dans son badge bleu (clic = tableau des modes), le petit dessin du filtre (il suit FIL1/2/3 et le TWIN PBT), la case FIL (clic = FIL suivant), l'heure et la case du bouton MULTI (« RIT ΔTX » quand ils sont en service), le badge orange **SPLIT**, **RFG** en orange sous le mode quand le gain HF (RF/SQL) n'est pas au maximum ; dessous les voyants (P.AMP, ATT, IP+, NB, NR, AN / MN, COMP, VOX, BK-IN, AGC), le bargraph **S/Po** (clic : S/SWR, S/ALC, S/COMP, S/Vd, S/Id — mesure montrée en émission), « VFO A » et la grande fréquence (clic = taper une fréquence) ; à sa droite le décalage RIT / ΔTX, ou en SPLIT la fréquence de l'autre VFO (en émission, le VFO d'émission passe en grand) ; pas de rangée de touches sous le scope. **TWIN PBT** (bouton du haut à gauche : centre = PBT intérieur, bague = PBT extérieur, clic = CLR, les deux au milieu ; quand on le tourne ou le pousse, ici ou sur le TRX, le cadre **BW / SFT** du TRX s'affiche 2 s sur le scope : bande passante, décalage et dessin du filtre avec ses bords en Hz ; largeur du filtre relue sur le TRX). **P.AMP/ATT** : clic = OFF → AMP1 → AMP2, appui long = ATT. **MENU** = écran MENU de l'IC-7300 (2 pages : SCOPE, AUDIO, VOICE — KEYER en CW, DECODE en RTTY —, METER, SWR, MEMORY, SCAN, MPAD, RECORD, SET ; PRESET, SET ; boutons ① ② et ↩), **FUNCTION** = écran FUNCTION de l'IC-7300 : P.AMP/ATT, AGC, NOTCH, NB, NR, IP+, VOX (en CW : BKIN), COMP, TBW (WIDE / MID / NAR), MONI, l'état sous chaque touche, cadre bleu clair quand elle est en service ; un clic change le réglage sur le TRX (VOX : seulement coupé à distance), **MULTI** poussé = menu MULTI du mode (RF POWER, MIC GAIN, COMP, MONITOR ; en CW : KEY SPEED, CW PITCH) réglé en tournant le bouton, le mode se change en cliquant sur le mode à l'écran, les touches du MENU ont leurs icônes, sous la fréquence, l'écran montre par défaut une bande de scope et les **mesures** comme le METER du TRX (ALC, COMP, SWR, Id, Vd, TEMP — la température n'est pas relue par le CAT ; MENU → SCOPE : le scope, MENU → METER : les mesures), **Scope du TRX** : le spectre et la cascade de l'écran sont ceux de l'IC-7300 lui-même (CI-V 27 00, environ 10 images par seconde, relayés par la page Station seulement quand une page IC-7300 est ouverte) : 0 au milieu, échelle qui suit le SPAN (±2,5k → −2.0 … +2.0, ±250k → −200 … +200), bornes en FIX ; **un clic sur le spectre ou la cascade met le VFO sur la fréquence cliquée** (pas de 100 Hz, 10 Hz en CW ; il faut avoir la main) ; il faut sur le TRX SET → Connectors → CI-V : « CI-V USB Port » = Unlink from [REMOTE] et « CI-V USB Baud Rate » = 115200 (sinon, la cascade reste celle du son reçu). MENU → **SCOPE** = SPECTRUM SCOPE (touches SPAN HOLD CENT/FIX EXPD/SET, puis REF SPEED MARKER EXPD/SET ; SPAN ±2,5k … ±500k, HOLD, CENT/FIX (en FIX : EDGE 1 à 4 — bords envoyés par le TRX, grille « …k/10dB » selon leur largeur, « > » quand la fréquence en sort — et R vert ; appui long : SCROLL-C / SCROLL-F en jaune), REF (cadre REF Level, réglé de −20 à +20 dB au grand bouton ou à la molette, DEF = 0 dB, nouveau clic sur REF : fin), SPEED (SLOW / MID / FAST) et MARKER (repère T) règlent le scope du TRX ; EXPD/SET agrandit le scope ; appui long sur EXPD/SET : **SCOPE SET** (4 réglages par page comme sur le TRX : Scope during Tx, Max Hold, CENTER Type Display, Marker Position, VBW, Averaging, Waveform Type, couleurs en lecture seule, Waterfall Display / Speed / Size / Peak Color Level / Marker Auto-hide, **Fixed Edges** : les 3 bords de la tranche de la fréquence en cours, clic = saisie « bas-haut » en kHz) ; avec la grande fréquence de M.SCOPE, le scope se met sous le grand S/Po, comme sur le TRX), MENU → **VOICE** (en phonie) = VOICE TX : l'IC-7300 garde ses mémoires vocales sur une carte SD ; à distance, **T1 … T8 sont vos propres mémoires**, enregistrées avec votre micro et gardées sur le serveur (vous les retrouvez sur tout PC). **REC/SET → REC** = VOICE TX RECORD : choisissez T1 … T8, **● REC** (micro en service : bouton MICRO sous la face avant ; 30 s au plus) puis **■ STOP**, **▶** pour l'écouter dans la page (rien n'est émis), **NAME** (16 caractères, affiché sous la touche), **CLEAR**. **REC/SET → SET** = VOICE TX SET : Auto Monitor (vous entendez la mémoire pendant qu'elle part) et Repeat Time (1 à 15 s). Clic sur T1 … T8 : la mémoire part en phonie (le serveur l'émet au rythme réel, avec les mêmes contrôles que le PTT : main, bandes, puissance, VOX, ROS) ; **appui d'1 s** : répétée toutes les Repeat Time secondes, 2 minutes au plus ; un clic sur une touche T (ou le PTT) l'arrête. **TX LEVEL** : niveau d'émission des mémoires (50 % = niveau enregistré ; grand bouton ou molette, DEF = 50 %). En SPLIT, pendant l'émission, la fréquence d'émission est affichée en rouge (ajout de la page, pas sur le TRX), MENU → **SWR** = SWR GRAPH comme sur le TRX (fréquence au kHz au milieu, ROS relevé pendant vos émissions — TUNE, porteuse, phonie — en barres par fréquence, rouge au-dessus de 1.5 ; STEP 10k / 50k / 100k / 500k, BAR 3 à 13 barres, RECALL : graphe centré sur la fréquence du dernier ROS relevé, sans bouger le VFO (touche en surbrillance ; nouveau clic : le graphe suit de nouveau le VFO) ; la mesure automatique ▷■ n'émet pas à distance), MENU → **MEMORY** = canaux mémoire du TRX relus par le CAT (clic : fréquence et mode dans le VFO), MENU → **SCAN** = balayage PROGRAM (P1 – P2) ou ΔF (± ΔF SPAN), FINE (réception seulement ; nouveau clic sur PROG ou ΔF : arrêt), **SET** = SCAN SET relu sur le TRX : SCAN Speed (Slow / Fast) et SCAN Resume (OFF / ON), un clic change la valeur, touche **MPAD** = note la fréquence dans le MEMO PAD de la page, MENU → **MPAD** = MEMO PAD (▲ ▼, DEL, DEL ALL, **EXPAND** : 10 lignes sur tout l'écran, sans le scope ; nouveau clic : normal), MENU → **RECORD** et **PRESET** : pas de commande CAT, MENU → **SET** = réglages du TRX relus par le CI-V (1A 05), 5 par page : **Tone Control/TBW**, **Function**, **Display** et **Time Set** modifiables (la partie émission de Tone Control — SSB TX Bass / Treble, TBW WIDE / MID / NAR, AM et FM TX Bass / Treble — se garde aussi comme **profil de chaque opérateur** : bouton **Equalizer TRX** de la ligne SSB CONFIGURATION, « Lire le TRX », « Essayer », « Enregistrer « Profil de … » » ; mis au TRX quand vous prenez la main, réglage du club remis quand vous la rendez) (clic : valeur suivante, ou − à gauche / + à droite ; Date et Time : réglés sur l'horloge de ce PC), **Connectors** en lecture seule (liaison avec le club), **SD Card** pas à distance, **Others** : Information seulement (pas Touch Screen, Reset, Emergency) ; langue, REF Adjust, Calibration Marker et Inhibit Timer en lecture seule, MENU → **AUDIO** = AUDIO SCOPE sous la bande du scope, comme sur le TRX : FFT 0 – 4.0kHz avec sa cascade bleue, oscilloscope à droite ; touches **ATT** de la FFT (OFF, 10, 20, 30 dB ; appui long : OFF), **HOLD**, **LEVEL** de l'oscilloscope (0, −10, −20, −30 dB), **TIME** (1, 3, 10, 30, 100, 300 ms/Div ; au départ 100 ms/Div) — ATT, LEVEL et TIME n'ont pas de commande CAT : ils se règlent avec les touches de la page, indépendamment du TRX, et sont retenus dans ce navigateur ; niveaux calés sur le TRX (bruit de la bande passante vers le milieu de la FFT, bruit qui remplit l'oscilloscope à −20 dB), **EXPD/SET** (AUDIO SCOPE agrandi, sans la bande du scope ; appui long : **AUDIO SCOPE SET** relu sur le TRX — FFT Scope Waveform Type Fill / Line et Waterfall Display modifiables, couleurs de la FFT et de l'oscilloscope en lecture seule ; ces réglages du TRX sont appliqués au dessin de la page) ; EXIT : retour), MENU → **KEYER** (en CW) = mémoires **M1 … M8** du manipulateur du TRX, relues sur le TRX, un clic émet la mémoire (« * » = numéro de concours, compté après l'envoi ; touche −1 pour revenir en arrière ; les mémoires se modifient sur le TRX), **M.SCOPE** = grand écran des mesures sans scope (grande fréquence, grand S/Po, ALC, COMP, SWR, Id, Vd, TEMP), un 2e appui revient à l'écran par défaut ; un réglage qui change (P.AMP, ATT, AGC, NB, NR, NOTCH, FILTER, COMP…) s'affiche un instant dans un cadre au milieu de l'écran, comme sur le TRX, **QUICK** = QUICK MENU (BAND, SPLIT, A=B, A/B, TUNER, TUNE, LOCK), **EXIT** = ferme le tableau ouvert, **▼ ▲** = bande précédente / suivante, **A/B** = passe sur l'autre VFO comme sur le TRX, « VFO A » / « VFO B » affiché au-dessus de la fréquence (le CI-V ne dit pas quel VFO est en service : la page le suit quand on appuie sur A/B depuis le dash ou sur le TRX) ; appui long : A = B, **CLEAR** = RIT / ΔTX à zéro, **TRANSMIT** = émission maintenue. **XFC** : en SPLIT, tant que vous le tenez, les deux VFO sont inversés (écoute de votre fréquence d'émission), remis comme avant au relâchement ; hors SPLIT, rien. **AUTO TUNE** (CW) : accorde le TRX sur le signal CW le plus fort à ± 400 Hz de votre tonalité (pitch), trouvé dans la BF reçue (il faut écouter le TRX) ; RIT en service : c'est le RIT qui est corrigé ; « AUTOTUNE » s'affiche un instant au-dessus de la fréquence ; signal trop faible : un bip.

| Sur la face avant | Ce que ça fait |
|---|---|
| Touches **1.8 … 70/GEN** | Changent de bande sur le récepteur actif (MAIN ou SUB). Voyant blanc sous la touche : bande du MAIN ; bleu au-dessus : bande du SUB. |
| **MAIN** / **SUB**, **MAIN/SUB** | Choisissent le récepteur sur lequel agissent le grand bouton, les touches de bande et de mode. La touche du récepteur choisi est éclairée comme sur le TRX : MAIN en blanc (texte noir), SUB en bleu. |
| **RX** / **TX**, **MAIN⇆SUB** | RX du SUB : double réception en marche / arrêt. TX MAIN / TX SUB : VFO d'émission (voyant rouge ; en SPLIT, sa fréquence s'affiche en rouge). SPLIT en marche : l'émission passe sur le VFO non sélectionné (MAIN sélectionné → TX SUB ; SUB sélectionné → TX MAIN) ; SPLIT arrêté : elle revient sur le VFO sélectionné. MAIN⇆SUB : échange des fréquences ; **appui d'au moins 1 s** : copie MAIN → SUB. |
| **MODE**, **SSB**, **CW**, **BK-IN** | MODE : mode suivant ; **appui d'au moins 1 s** : le tableau de tous les modes (LSB, USB, CW-L, CW-U, AM, AM-N, FM, FM-N, DATA-L, DATA-U, DATA-FM, D-FM-N, RTTY-L, RTTY-U, PSK), clic sur le mode voulu. SSB : LSB ⇄ USB ; CW : CW-U ⇄ CW-L (en passant en CW depuis un autre mode, BK-IN est mis en service d'office) ; BK-IN : break-in CW, à couper ou remettre à tout moment sans changer de mode. |
| **SPLIT**, **CLAR RX** / **TX**, **CLAR**, **LOCK**, **FAST**, **FINE TUNING** | SPLIT ; clarifier RIT / XIT ; grande touche CLAR : RIT (« CLAR RX ±…Hz » en rouge au-dessus de la fréquence ; la **bague extérieure du grand bouton** règle alors le décalage, 10 Hz par cran), et **appui long** : décalage à zéro ; LOCK ; grand bouton : 100 Hz par cran, FAST : 1 kHz, FINE : 1 Hz. |
| **NB**, **DNR**, **DNF**, **NOTCH**, **CONT**, **APF** | Rangée du haut : récepteur SUB ; rangée du bas : MAIN. Voyant orange quand la fonction est en service. **NB** et **DNR** : clic bref = en / hors service ; **appui d'au moins 1 s** = cadre « NB LEVEL » / « DNR LEVEL » sur l'écran, comme le TRX, réglable avec le bouton **MULTI** (comme sur le TRX), la molette de la souris sur le cadre, ou − / +. |
| Boutons rotatifs | **Molette** sur le bouton, ou **cliquer-glisser** vers le haut / le bas ; boutons doubles : le **bouton cranté** du milieu (cercle orange au survol) pour le bouton intérieur, l'**anneau à points** autour pour la bague (au survol : centre éclairé en orange, anneau en bleu, avec le nom du réglage). AF ◎ RF/SQL (SUB en haut, MAIN en bas), SHIFT ◎ WIDTH (WIDTH : toutes les largeurs du TRX, une par cran de molette (300 à 4000 Hz en SSB) ; SHIFT −1200 à +1200 Hz ; petit voyant orange au-dessus de SHIFT ou de WIDTH quand il n'est plus à sa position par défaut (WIDTH par défaut : 3000 Hz, comme le TRX) ; **appui d'au moins 1 s sur le centre** : SHIFT à 0 et WIDTH par défaut, voyants éteints, et le filtre de l'écran suit la largeur ; pendant le réglage, un cadre « SHIFT … Hz » / « WIDTH … Hz » s'affiche sur le scope comme sur le TRX, de même pour NOTCH, CONTOUR et APF ; ce cadre se règle aussi avec ses boutons − / + ou la molette, et reste affiché tant que la souris est dessus), NOTCH, MIC/SPEED ◎ PROC (**clic sans tourner** : KEYER en CW, PROC en SSB — voyant allumé ; nouveau clic : arrêt). Grand bouton : molette ou glisser en tournant ; flèches ↑ ↓ du clavier ; sa **bague extérieure** (bleue au survol) accorde l'**autre récepteur** que celui qui est sélectionné (SUB sélectionné → VFO-A, MAIN sélectionné → VFO-B), sauf CLAR en service (décalage) ou grande touche VC TUNE (présélecteur). |
| **MULTI** | Décalage du clarifier quand CLAR est actif ; sinon il règle la fonction affichée dans la dernière case de l'écran (« MULTI RF POWER » au départ), choisie dans FUNC. |
| **FUNC** | Ouvre le menu des fonctions dans l'écran, comme sur le TRX, mais à la souris : clic sur une case pour la choisir (cadre rouge ; COLOR, STEP DIAL, R.FIL, MIC EQ changent directement), puis clic sur **−** (à gauche dans la case) ou **+** (à droite), **molette sur la case** ou bouton **MULTI**. RF POWER, MONI LEVEL, DNR LEVEL, NB LEVEL, VOX GAIN, VOX DELAY, ANTI VOX, R.FIL, MIC EQ, STEP DIAL, et en FM RPT (SIMP / + / −), ENC/DEC (CTCSS / DCS), TONE FREQ (du VFO sélectionné) : valeurs lues sur le TRX ; SPEED, PEAK, MARKER, COLOR, LEVEL règlent la cascade de la page et, main prise, le scope du TRX (MAIN ou SUB, côté sélectionné ; les réglages faits au club sont repris par la page) ; SPAN aussi (1 kHz à 1 MHz sur le TRX, la page montrant le son reçu, 5 kHz au plus). Cases **RADIO / CW / OPERATION / DISPLAY SETTING** : les **menus du TRX**, comme sur son écran — sous-menus à gauche (MODE SSB, KEYER…), réglages à droite avec leur valeur lue sur le TRX ; clic sur un réglage puis **−** / **+**, molette ou bouton **MULTI** (main prise) : la valeur part au TRX et est relue. **BACK** en bas : retour à l'écran FUNC. **STEP DIAL** : le bouton MULTI fait monter / descendre la fréquence par pas de canal (CH STEP du TRX, 2,5 kHz par défaut). Réglages en gris : lecture seule (liaison CAT, phonie et CW à distance, puissance maximale, étalonnage, égaliseur réglé par EQUALIZER TRX). EXTENSION SETTING (date, carte SD, remise à zéro…) : au club seulement. Cases grises : pas disponibles à distance (mémoires, SCAN, DECODE, REC/PLAY). Comme sur le TRX, des cases se grisent selon le mode du VFO sélectionné : RPT, ENC/DEC et TONE FREQ hors FM ; MIC EQ en CW, DATA, RTTY et PSK ; DECODE en FM. |
| **MOX**, **PTT**, **MONI** | Sous la face avant : le bouton **PTT** (large et bas), la ligne **MODES** (FT8/FT4/FT2, SSB, RTTY, WSPR, JT65, JTTY, CW, SSTV : clic sur SSB → le **TRX SSB** ; sur CW → le **TRX CW** ; sur un autre mode → le **TRX DIGI**, page des modes numériques /ftdx101/digi.html, s'ouvre sur ce mode, ou y passe si elle est déjà ouverte) puis la ligne **SSB CONFIGURATION · MICRO · EQUALIZER MICRO · niveau du micro · EQUALIZER TRX** ; micro actif, la ligne suivante donne l'**Entrée** son (votre micro) et la **Sortie** son (casque ou haut-parleurs : écoute du TRX et M'écouter), M'écouter et son volume (le type du micro reconnu est dans la fenêtre Equalizer micro). Le bouton **Profil de …** (indicatif de celui qui a la main, s'il a un profil enregistré) montre ce qui est gardé pour lui : réglages de micro et égaliseur du TRX (« Profil de ON6DP », mis au TRX à chaque prise de main), puis la ligne d'état. Le bouton **PTT** (maintenir, ou la barre d'espace) et le cadre **SSB CONFIGURATION** (votre micro, égaliseurs), comme dans le dashboard. **MOX** : émission maintenue (clic : émission, clic suivant : réception). **MONI** : entendre sa propre modulation (« M'écouter », au casque ; micro activé d'abord). |
| Modes numériques de la face avant | Ligne **MODES** : un clic sur un mode numérique ouvre le **TRX DIGI** (page des modes numériques, /ftdx101/digi.html) sur ce mode (SSB : TRX SSB ; CW : TRX CW) ; le bouton du mode affiché y est en **bleu clair**. Cette page utilise la connexion de la face avant. En haut : **LOGBOOKS** (le carnet de trafic s'ouvre dans **sa propre fenêtre** : saisie, liste, SYNCHRONISATION LoTW / eQSL / Club Log / QRZ, EXPORTER en ADIF ou Cabrillo ; tous les QSO vont dans le même carnet de la station), **SYNCHRO** (heure du PC, en FT8 / FT4 / FT2, WSPR, JT65 seulement) et **Suivre l'opérateur** (le même que le bouton SUIVRE de la face avant). Dans la barre de chaque mode : **TX call** en jaune fluo (indicatif sous lequel on émet : ON5VL / OR0L de la station, ou le vôtre ; choisi par celui qui a la main, le même pour tous les modes). Les annonces s'affichent en jaune fluo et clignotent 1 s. Le pays DXCC, la distance et l'azimut d'une station s'affichent en passant la souris sur son indicatif. |
| FT8 / FT4 / FT2 sur MAIN et SUB | TRX en double réception (DUAL RX) : les deux récepteurs sont décodés en même temps. Deux cascades côte à côte (VFO-A · MAIN à gauche, VFO-B · SUB à droite) avec la fréquence de chaque VFO en grand — **sur fond rouge avec « TX »** pour celui qui émet — et son mode (vert en DATA-U / USB, orange sinon) ; quatre colonnes : **VFO-A · Activité de bande**, **VFO-A · Fréquence RX**, puis les mêmes pour le **VFO-B**, séparées par un trait gris, chacune avec son ascenseur. Chaque cascade a ses repères RX (clic gauche) et TX (clic droit ; drapeau TX en **bleu** sur le VFO qui n'émet pas), son **zoom à la molette** (vers soi : plage plus étroite autour de la souris, jusqu'à 300 Hz ; vers l'avant : jusqu'à 0–3000 Hz), ses réglages (gain, zéro, plat, couleurs, vitesse) et une poignée pour la hauteur des cascades. **Émission sur le bon VFO** : un double-clic (ou un clic sur l'indicatif) dans une colonne VFO-B répond sur le SUB, dans une colonne VFO-A sur le MAIN ; les boutons **TX VFO-A / VFO-B** de la barre du haut le montrent et le changent (le TRX passe TX sur MAIN / SUB), et suivent le VFO d'émission choisi sur le TRX ou la face avant. **Deux cartes de bande** : celle du VFO-A à gauche, celle du VFO-B à droite (chacune avec ses filtres, son ascenseur et ses fréquences en blanc gras ; clic sur un spot de la carte B = réception du VFO-B sur ce signal). Le SUB n'a que les passes rapides du décodeur (pas la passe profonde). SUB coupé, ou dashboard générique : un seul récepteur, comme avant. |
| JT65, WSPR, JTTY sur MAIN et SUB | Même disposition qu'en FT8 en double réception : deux cascades côte à côte (VFO-A · MAIN, VFO-B · SUB, chacune avec sa fréquence, son mode et ses réglages), les décodages du VFO-A à gauche et ceux du VFO-B à droite (JT65 : activité de bande et fréquence RX de chaque VFO ; WSPR : stations entendues par chaque récepteur, avec les fréquences du VFO-B ; JTTY : activité et fréquence RX de chaque VFO ; double-clic sur un message du VFO-B : émission sur le VFO-B), et deux cartes de bande (VFO-A à gauche, VFO-B à droite). L'émission part sur le VFO d'émission du TRX. |
| CW sur MAIN et SUB | FTDX101 en double réception : deux récepteurs CW séparés. Deux cascades côte à côte (VFO-A · MAIN, VFO-B · SUB) et deux zones de réception, chacune avec son filtre, son silencieux, son niveau, sa tonalité et la vitesse lue. Dans chaque cascade : clic = se caler sur le signal le plus proche, bouton gauche maintenu = glisser le repère, clic droit = repère exactement là. Double-clic sur un indicatif reçu : il devient le correspondant et l'émission passe sur le VFO où il a été entendu. Le changement de filtre d'un décodeur règle aussi la largeur (BW) de son récepteur (avec la main, en CW). |
| CW : zoom et filtre du TRX | Molette sur une cascade CW (MAIN ou SUB) : zoom autour de la souris (vers soi = plus étroit, jusqu'à 200 Hz de large). Les deux barres bleu clair montrent le filtre du TRX (WIDTH, ou NAR) de ce VFO, centré sur la tonalité CW (pitch) et suivant l'IF SHIFT ; elles suivent les réglages faits sur le TRX. Avec la main : glisser une barre ou Ctrl + molette sur la cascade règle la largeur (BW) du TRX. |
| RX MAIN / RX SUB (face avant FTDX101) | Comme les touches RX du TRX : RX MAIN coupe ou remet le récepteur MAIN (par exemple pour n'écouter que le SUB), RX SUB met en marche ou arrête la double réception. Voyant vert = récepteur en service. |
| RTTY sur MAIN et SUB | Deux décodeurs, un par récepteur, avec chacun sa cascade (au même niveau, mêmes réglages qu'en FT) et sa carte de bande (VFO-A à gauche, VFO-B à droite). En haut de chaque décodeur : la fréquence du **VFO en grand, comme sur l'écran du TRX** (sur fond rouge « TX » pour le décodeur qui émet) et, en petit, celle du **signal** suivi (VFO + centre du décodeur, comme FLDIGI). À l'ouverture, les repères des deux décodeurs sont sur **1500 Hz**. La **règle des fréquences** au-dessus de chaque cascade **accorde le VFO** (le TRX suit) : molette (10 Hz par cran, 50 Hz en tournant vite) ou glisser, sur toute la bande ; pendant l'accord les repères restent en place, on les recale ensuite **dans la cascade** (clic ou glisser ; molette dans la cascade : zoom), comme FLDIGI et MixW. Poignée sous les fenêtres de décodage : leur hauteur, pour garder les macros en vue. Silencieux par défaut 9 dB (signaux faibles, environ −6 dB dans 3 kHz ; plus haut = moins de caractères au hasard sur le bruit). |
| Macros RTTY et contests | 12 macros (F1 à F12), personnelles (gardées sur le serveur sous votre indicatif) : clic droit ou ✎ pour les modifier. **F11 « TX »** émet le texte tapé dans la zone d'écriture, **F12 « RX »** repasse en réception. Dans l'éditeur, les **balises** (champs standardisés de FLDIGI) sont rangées par groupe — Émission, Station, Correspondant, Trafic, Heure et date, Contest — avec leur explication au survol et un aperçu du texte. **Contests** : sous les macros, choix du contest (liste de N1MM Logger+ : CQ WW, CQ WPX, ARRL Roundup, BARTG, SARTG, WAEDC, SP DX, Volta, Russian, Ukrainian… ou « autre »), **échange envoyé** modifiable (<EXCH> : 599 + zone CQ, numéro de série, locator, heure…), prénom, zones CQ / ITU, **numéro de série** : il passe tout seul au suivant avec la macro TU (une seule fois par correspondant ; renvoyer l'échange redonne le même numéro), boutons −1 / +1 et ↺ 001. Une 2e rangée de 12 **macros contest** (CQ, Échange, TU, Réponse, AGN?, NR?…) répond aux touches F1 à F12 quand un contest est choisi. La fiche du QSO reprend l'échange envoyé, l'échange reçu et le contest (export Cabrillo). |
| **TUNE**, **VOX**, **PROC** | TUNE : coupleur d'antenne en service / hors service ; **appui d'au moins 1 s** : accord (après confirmation, avec les sécurités habituelles). VOX (ne peut être que coupé à distance) ; processeur de modulation. |
| Prise **PHONES**, `🎧 Stéréo MAIN \| SUB` | PHONES (ou `Écouter le TRX`) : écouter le TRX. **Stéréo** : met la double réception en marche (les deux récepteurs), puis le MAIN dans l'oreille gauche et le SUB dans l'oreille droite (pratique en SPLIT avec un casque) ; coupé : les deux mélangés. |
| Écran | Galvanomètres (S-mètre MAIN et SUB ; en émission PO et SWR) avec le filtre de chaque récepteur (en CW : sous le filtre, l'indicateur d'accord « − … + » comme sur le TRX : repère rouge au milieu = le pitch, petit trait gris = le signal le plus fort reçu à ± 200 Hz ; trait au milieu (blanc) = bien accordé, il reste au milieu en émission ; NOTCH en service : creux dans la bande passante à sa fréquence, qui se déplace quand on tourne le bouton NOTCH (10 Hz par cran), comme sur le TRX ; trait rouge pointillé si le notch est sur un flanc ou hors de la bande passante ; et trait rouge « N » sur le spectre avec MARKER ; CONT en service : petit « V » bleu peu profond dans le haut du filtre, à la fréquence du CONTOUR, qui suit le bouton CONT (le creux profond est celui du NOTCH), avec le cadre « CONT … Hz » comme sur le TRX), fréquences (clic : la taper), ANT / ATT / IPO / R.FIL / AGC (clic : valeur suivante), et à la place du scope du TRX (qui ne passe pas par la liaison CAT) le **spectre et la cascade de la BF** reçue (FAST : commute aussi la touche FAST du FTDX101 du côté sélectionné, MAIN ou SUB ; voyant lu sur le TRX), MAIN \| SUB côte à côte en double réception ; chaque partie va de 0 au haut de la bande passante de son filtre (sans dépasser le SPAN), pour remplir toute sa largeur ; dans les petits filtres près des S-mètres, le spectre est à l'échelle du filtre. Rangée du bas : SPAN (largeur 2 à 6 kHz), MONO (comme le TRX : un seul VFO à l'écran, celui qui est sélectionné — galvanomètre à gauche, filtre en grand à droite, fréquence, cases sur toute la largeur, un seul scope ; MONO écrit en bleu ; nouveau clic : MAIN et SUB), EXPAND (comme le TRX : galvanomètres réduits à leur partie haute, filtres aplatis, fréquences remontées et scope agrandi ; EXPAND écrit en bleu ; nouveau clic : affichage normal), MULTI (menu FUNC), HOLD (cascade figée). En haut à droite : **👥** et le nombre de membres connectés ; clic : leurs indicatifs (adresse IP de connexion pour les administrateurs), qui a la main, et les **messages** entre membres (bip 🔔 et pastille rouge à l'arrivée d'un message), comme dans le dashboard ; à côté de Prendre / Libérer la main, votre indicatif (et celui qui a la main si c'est un autre). **👁 Suivre** (Suivre l'opérateur, pour une formation à distance ; sous la face avant, à droite de Profil de …, grisé chez celui qui a la main) : votre face avant montre le même écran que celui qui a la main (DISP, MONO, EXPAND, MULTI, 3DSS, menu FUNC) ; il s'enclenche tout seul quand un autre membre a la main ; une de ces touches l'arrête, un clic sur 👁 Suivre le relance. Dans la page 📟 Numériques, le bouton du même nom fait suivre l'onglet des modes numériques. Juste après : **<-> DX Cluster**, comme dans le dashboard : ouvre dx.op0p.be ou cluster.op0p.be dans sa fenêtre, reliée au TRX (clic sur un spot : le VFO sélectionné y va, main prise ; <-> vert = relié avec la main, orange = ouvert sans la main) ; case « Ouvrir ce cluster automatiquement à chaque connexion » (il s'ouvre au premier clic dans la page, le navigateur exigeant un clic). Les spots du cluster du serveur arrivent d'office dans les cartes de bande. |
| **SYNC**, **KEYER** | SYNC (voyant allumé) : le SUB prend la fréquence du MAIN et le grand bouton accorde ensuite les deux récepteurs ensemble ; nouveau clic : arrêt. KEYER : manipulateur électronique en CW. |
| Écran : la cascade | Spectre plus fin (analyse sur 2048 points) : chaque colonne garde le pic le plus fort, une porteuse ou un signal CW reste net même avec SPAN large. |
| **Carte de bande** | Sur les onglets FT8, RTTY, WSPR, JT65, JTTY, CW : colonne tout à droite, sur toute la hauteur de la fenêtre. Bouton `⧉` de son en-tête : la carte part dans **sa propre fenêtre** (à mettre sur un autre écran, taille libre) ; `⧉ Ramener` ou fermer la fenêtre : elle revient à droite. La fenêtre est rouverte au prochain chargement de la page si Chrome autorise les fenêtres pop-up pour le site. |
| **Cartes de bande** VFO A / VFO B | À gauche du TRX, la bande du **VFO A** (MAIN) ; à droite, celle du **VFO B** (SUB) : spots du cluster autour de la fréquence du VFO (trait du VFO ; rouge si c'est le VFO d'émission), indicatifs en blanc (gardés 30 min), mode du spot en bleu. **Largeur** : poignée sur leur bord côté TRX (les deux cartes ensemble ; double-clic : largeur d'origine, retenue dans ce navigateur). **− / +** (ou **Maj + molette**) : plage affichée (5 à 200 kHz, ou **toute la bande** du VFO, au départ : tous les spots de la bande). Quand les indicatifs ne tiennent pas dans la hauteur, un **ascenseur** apparaît à droite : la **molette** fait alors défiler la liste ; la carte garde le VFO en vue, sauf pendant 15 s après un défilement à la main. **En SPLIT**, les deux cartes passent toutes seules à **±10 kHz** autour de leur VFO (− / + et molette restent possibles) ; hors SPLIT, chacune reprend sa plage. **Clic sur un indicatif** : ce VFO va sur sa fréquence (main prise). Sous le nom de la bande : **TOUS · FT8/4/2 · SSB · CW · RTTY** pour n'afficher que les spots de ce mode (mode écrit dans le spot, sinon skimmer = CW, fréquences d'appel FT8 / FT4, puis plan de bande IARU) ; nouveau clic sur le mode choisi : tous ; chaque carte garde son choix. |
| **Modes numériques** dans leur propre page | Bouton `📟 Numériques` en haut : FT8 / FT4, RTTY, WSPR, CW, SSTV… s'ouvrent dans leur propre fenêtre (à mettre sur un autre écran), avec leur carte de bande, sur la même connexion que la face avant. `✕ Fermer` dans cette fenêtre la ferme. |
| Bague **CONT/APF** (autour du bouton NOTCH) | Fréquence du **CONTOUR** (10 à 3200 Hz, 10 Hz par cran ; touche CONT pour le mettre en service) ; en CW avec l'**APF** en service : fréquence de l'APF (−250 à +250 Hz). Le centre du bouton règle le NOTCH. **Appui d'au moins 1 s sur le centre** : NOTCH 1500 Hz, CONTOUR 1000 Hz (et APF 0 Hz en CW), NOTCH, CONT et APF arrêtés. |
| Voyants au-dessus des touches | SYNC, SPLIT, CLAR RX, CLAR TX, FAST, LOCK : le petit voyant au-dessus de la touche s'allume en orange quand la fonction est en service. |
| **PROC**, **KEYER** (voyants) | PROC ne s'enclenche qu'en SSB ou AM sur le VFO d'émission (le MAIN, ou le SUB en SPLIT) : en DATA, FM ou CW, la page l'explique au lieu d'envoyer la commande que le TRX refuserait. Voyant **orange** au-dessus du bouton MIC/SPEED : allumé tant que le processeur (SSB) ou le manipulateur (CW) est en marche ; nouveau clic sur la touche ou sur le bouton : arrêt, le voyant s'éteint. |
| **DISP** | Comme sur le TRX, un clic après l'autre : cascade du MAIN → SUB au-dessus, MAIN en dessous → MAIN \| SUB côte à côte → filtres agrandis (largeur et décalage de chaque récepteur, avec le spectre de sa BF ; rangée du bas réduite à MULTI, HOLD) → retour. Pour voir le SUB : `🎧 Stéréo MAIN \| SUB`. |
| **MULTI** (case de l'écran, en bas) | Comme sur le TRX : scope du VFO sélectionné en haut, et en bas **OSCILLOSCOPE** (forme d'onde de la BF, 10 ms par division) et **AF-FFT** (spectre de la BF 0–4 kHz avec sa cascade) ; MAIN ou SUB selon la touche MAIN / SUB. Nouveau clic : retour à l'affichage normal. (Le bouton MULTI, lui, règle la fonction choisie dans FUNC.) |
| **VC TUNE** | **Petite touche** VC TUNE : présélecteur du récepteur actif (MAIN ou SUB) en marche / arrêt, avec son voyant orange (éteint à l'arrêt). **Grande touche** VC TUNE (autour du grand bouton), indépendante : comme sur le TRX (même voyant sur le TRX), la **bague extérieure** du grand bouton accorde alors le présélecteur (un pas par cran ; voyant orange à gauche de la touche) ; nouveau clic : la bague revient à la fréquence. Comme sur le TRX, une barre rouge « − … + » au-dessus du filtre montre la position du présélecteur (repère rouge), qui suit les réglages. Si le TRX répond que le VC TUNE n'est pas installé, la page le dit. |
| **S.MENU** | Le **SCOPE MENU**, comme sur le TRX, posé sur le haut de la cascade (qui reste visible) : **SPEED** (vitesse de la cascade), **PEAK** (crêtes du spectre gardées : OFF, LV1 longtemps … LV3 brièvement), **MARKER** (bande passante du filtre et repère central sur le spectre), **COLOR** (couleurs), **LEVEL** (clic à gauche −, à droite +, ou molette). Clic : valeur suivante. Il se ferme seul 3 s après la dernière action (reste ouvert tant que la souris est dessus). |
| Sans effet à distance | ON/OFF, ZIN/SPOT, QMB, C.S, mémoires : un message l'explique. |

<a id="numeriques"></a>
## 12. Modes numériques

Les onglets du centre : **Modes**, **FT8 · FT4 · FT2**, **RTTY**, **WSPR**, **JT65**, **JTTY**, **CW**, **SSTV**, puis **Logbooks**, le bouton `Log QSO` et **Synchro**. Avec la main, un clic sur l'onglet d'un mode numérique (FT8 · FT4 · FT2, RTTY, WSPR, JT65, JTTY, SSTV) met le TRX en **DATA-U** (USB-D sur l'IC-7300) sur le VFO écouté, même sous 10 MHz ; l'onglet **CW** le met en CW (CW-L sous 10 MHz, CW-U au-dessus ; CW-R / CW sur l'IC-7300), sauf s'il y est déjà. À droite des onglets FT8 · FT4 · FT2, RTTY, WSPR, JT65, JTTY et CW, la **carte de bande** montre les spots du DX cluster (voir 12.3, « Carte de bande »). Vous n'avez **aucun logiciel à installer** (pas de WSJT-X, FLDIGI…) : tout se fait dans la page.

- Le **décodage se fait sur le serveur**, à l'heure du serveur (synchronisée) : l'heure de votre PC et de celui du club n'a pas d'importance.
- Le son du TRX n'est envoyé que si quelqu'un écoute ou regarde un onglet de mode numérique : les décodages commencent quelques secondes après l'ouverture de l'onglet.
- **Liste des fréquences** (en haut de chaque onglet) : choisir une ligne envoie le TRX sur cette fréquence, en **DATA-U** (en CW pour l'onglet CW). Il faut avoir la main. Le bouton `↺` à côté ramène le TRX sur la fréquence choisie si quelqu'un a tourné le VFO entre-temps.
- **Cascade** : chaque onglet montre le spectre de 0 à 3000 Hz qui défile. Un signal est un trait coloré ; sa position horizontale est sa fréquence audio.
- **Ligne d'état** (à droite de la barre de l'onglet) : signale les problèmes (station hors ligne, BF non activée, TRX pas en DATA-U…) ou l'état du décodeur.
- **Émission** en FT8 · FT4 · FT2, RTTY, JTTY, CW et SSTV, sous le **TX call** choisi dans la ligne Correspondant (ON5VL ou votre indicatif). Il faut avoir la main et l'émission autorisée. WSPR et JT65 sont pour l'instant en **réception** seulement *(bientôt)*.

**Réglages de la cascade** (au-dessus de l'échelle, communs à tous les onglets et gardés dans votre navigateur)

| Réglage | Ce qu'il fait |
|---|---|
| **Gain** | Contraste : plus à droite, les signaux faibles ressortent davantage. |
| **Zéro** | Niveau du fond : plus à droite, le fond est plus clair. |
| **Plat** | Rend le bruit de fond égal sur toute la largeur (corrige la pente du filtre du TRX). Laisser coché. |
| **Couleurs** | JTDX (par défaut : bruit bleu, signaux jaunes, forts en rouge), bleu, arc-en-ciel, gris. |
| **Vitesse** | Défilement rapide, normal ou lent (lent = signaux plus ramassés et plus d'historique), comme « Spd » de JTDX. |
| `↺` | Remet les réglages d'origine. |
| Poignée sous la cascade | À glisser vers le haut ou le bas : hauteur de la cascade et des listes (double-clic : taille d'origine). |

<a id="ft8"></a>
### 12.1 FT8 · FT4 · FT2

FT8 est un mode numérique fait pour les signaux très faibles : chaque station émet un court message pendant 15 secondes (une **période**), puis écoute pendant la période suivante. Un QSO complet prend environ une minute et demie. **FT4** est deux fois plus rapide (7,5 s), **FT2** encore plus (3,75 s).

**La barre du haut de l'onglet**

| Commande | Ce qu'elle fait |
|---|---|
| `FT8` / `FT4` / `FT2` | Choisit le mode ; le TRX va sur la fréquence d'appel de ce mode dans sa bande. FT2 est le mode rapide de Decodium (IU8LMC), incompatible avec le « FT2 » de WSJT-X Improved. |
| Liste des fréquences | Fréquences d'appel par bande (ex. 14.074 · 20m), et QO-100 (section 12.9). |
| `↺` | Ramène le TRX sur la fréquence choisie (VFO A, DATA-U). |
| RX … Hz / TX … Hz | Fréquences audio de réception (vert) et d'émission (rouge) dans la bande de 3 kHz. |
| `TX ← RX` | Émettre sur la même fréquence audio que la réception. |
| `RX ← TX` | Recevoir sur la fréquence audio d'émission. |
| **Période** auto / 1re / 2e | Dans quelle période émettre. « auto » : à l'opposé du correspondant choisi (c'est presque toujours ce qu'il faut) ; « 1re » = 00 et 30 s, « 2e » = 15 et 45 s en FT8. |
| ☐ **Répondre au 1er** | Quand vous lancez CQ (Tx6), la première station qui répond devient le correspondant et le QSO se déroule tout seul (« Call 1st » de WSJT-X). |
| `■ Arrêter` | Coupe l'émission automatique tout de suite (« Halt Tx »). La barre `Espace` fait de même. |
| Horloge | Heure UTC du serveur. |

**La cascade** : **clic gauche** = fréquence de réception (drapeau vert « RX 1500 » et trait vert), **clic droit** = fréquence d'émission (drapeau rouge et trait rouge). Bouton **maintenu** (gauche pour la réception, droit pour l'émission) : le trait suit la souris en continu, comme en RTTY et en CW (FT8 · FT4 · FT2, WSPR, JT65, JTTY) ; ceux qui suivent l'opérateur le voient bouger. Choisissez pour l'émission un endroit libre de la cascade. Un trait blanc marque le début de chaque période, avec l'heure UTC et la bande.

**Les deux listes de messages**

- **Activité de bande** (à gauche) : tous les messages décodés. Les **CQ** sont en vert, les messages adressés à votre TX call (ON5VL, OR0L ou le vôtre) en rouge, vos propres émissions en jaune. `Effacer` vide la liste.
- **Fréquence RX** (à droite) : seulement les messages proches de votre fréquence de réception, c'est-à-dire votre QSO en cours.
- Un trait sépare chaque période ; les messages sont classés dans l'ordre chronologique.
- **Largeur des deux listes** : glisser le trait vertical entre elles (double-clic : moitié-moitié).

| Colonne | Signification |
|---|---|
| UTC | Début de la période où le message a été reçu. |
| dB | Rapport signal/bruit (comme WSJT-X) : −24 = très faible, +10 = fort. C'est le report qu'on envoie. |
| DT | Décalage en temps du signal (secondes). Proche de 0 quand tout est bien calé. |
| Fréq | Fréquence audio du signal (Hz). |
| Message | Le texte décodé, par ex. « CQ F4ABC JN18 ». Une marque **a1**…**a7** à la fin indique un décodage obtenu grâce à l'aide a priori (voir plus bas). |
| Pays | Pays DXCC de la station qui émet. |
| km / Az | Distance et direction (azimut en degrés) depuis le club. « ≈ » : approximatif (pas de locator dans le message, centre du pays). |

- **Stations déjà contactées** : les messages d'une station déjà au carnet **sous le TX call actuel**, sur la même bande et dans le même mode, sont en vert barré (« worked before »). Avec un autre TX call, seuls les QSO faits sous cet indicatif comptent.

**Les messages Tx1 à Tx7** (sous les listes, comme dans WSJT-X)

| Message | Exemple | Quand |
|---|---|---|
| `Tx1` | F4ABC ON5VL JO20 | Répondre à un CQ (votre indicatif et locator). |
| `Tx2` | F4ABC ON5VL −12 | Donner le report au correspondant. |
| `Tx3` | F4ABC ON5VL R−12 | Accuser réception de son report et donner le vôtre. |
| `Tx4` | F4ABC ON5VL RR73 | Tout est reçu, au revoir. |
| `Tx5` | F4ABC ON5VL 73 | Dernier message. |
| `Tx6` | CQ ON5VL JO20 | Lancer appel. |
| `Tx7` | texte libre | Message libre de 13 caractères au plus. Clic droit ou `✎` pour le modifier. |

- **Un clic sur un message Tx** le fait partir à **chaque période** (une sur deux) jusqu'à la réponse, comme « Enable Tx » de WSJT-X. Il faut avoir la main, le VFO d'émission en **DATA-U** et une puissance dans votre limite.
- **Répondre à une station** : clic sur son **indicatif** (souligné en pointillé) ou **double-clic** sur son message. Elle devient le correspondant (indicatif, locator, report) et, avec la main, le bon message part dès la période suivante, à l'opposé de la sienne. Un clic ailleurs sur la ligne ne fait que régler la réception.
- **La séquence avance toute seule** d'après la réponse : son locator → Tx2 ; son report → Tx3 ; R+report → Tx4 (RR73) ; RRR ou RR73 → Tx5 (73). Après RR73 ou 73 : fin du QSO, émission coupée, retour sur Tx6, et la fiche **Enregistrer le QSO** s'ouvre déjà remplie.
- **Quand part la réponse** : en FT8, une émission doit commencer au début d'une période (au plus 2,3 s de retard, sinon elle n'est plus décodée ; FT4 : 0,8 s). Les décodages arrivent vers 12,7 s : un clic avant la fin de la période du correspondant (ou dans les 2 premières secondes de la suivante) fait partir la réponse aussitôt. L'émission s'arrête toujours à la fin de la période. Un message en bas de l'écran dit quand votre réponse part.
- **Barre de période** (sous les listes) : verte en réception, rouge en émission ; elle se remplit au cours de la période.
- **Arrêts automatiques** : `■ Arrêter` ou `Espace` ; le correspondant répond à quelqu'un d'autre ; le même message depuis 6 minutes sans réponse ; main perdue.
- En **SPLIT**, le message part sur l'autre VFO, comme le PTT.

> [!TIP]
> **Le décodeur**
> - C'est le moteur de **WSJT-X 3**, avec le décodeur multi-passes de **JTDX**. En FT8, trois passes par période : une anticipée vers 12 s (pour pouvoir répondre tout de suite), une normale à la fin du signal, puis une profonde qui ajoute les stations les plus faibles quelques secondes plus tard.
> - **Aide a priori (AP)** : pendant un QSO, le décodeur sait qui est le correspondant et quel message est attendu ; il le retrouve alors jusqu'à 2 à 3 dB plus bas. Ces décodages portent la marque a1 … a7.
> - Sensibilité : FT8 vers −22 dB (−24 dB avec l'aide a priori), FT4 vers −17,5 dB. Une base de ~100 000 indicatifs (celle de JTDX) écarte les faux décodages très faibles.

<a id="jt65"></a>
### 12.2 JT65

Même fenêtre que FT8, mais avec des périodes d'une minute ; le TRX va sur la fréquence JT65 de sa bande. Les décodages arrivent vers la 52e seconde. Réception seulement.

<a id="rtty"></a>
### 12.3 RTTY

Le RTTY est le « télétype » : on tape du texte qui défile chez le correspondant. Très utilisé en concours. L'onglet a **deux décodeurs indépendants** : **A** (VFO-A, à gauche) et **B** (VFO-B, à droite), chacun avec son texte reçu et ses réglages. Le FTX-1, le FTDX10 et l'IC-7300 n'envoient qu'un seul son au PC (le FTDX101 en réception simple ; en double réception, il envoie ses deux récepteurs en stéréo : une cascade par décodeur, A = MAIN, B = SUB) : il y a donc **une seule cascade**, sur toute la largeur, avec les repères des deux décodeurs. On suit ainsi deux stations de la même bande en même temps (concours, DX et son pile-up). Un TRX qui envoie ses deux récepteurs séparément (FTDX101D / MP) aura une cascade par décodeur, côte à côte.

Au-dessus de la cascade, la ligne d'aide (« clic gauche : décodeur A… ») s'affiche **3 secondes** à l'arrivée sur l'onglet puis s'efface, pour laisser plus de place aux fenêtres de réception ; elle reste au survol de la cascade. La ligne d'état n'apparaît qu'en cas de problème (pas de BF, TRX pas en DATA-U…).

| Commande | Ce qu'elle fait |
|---|---|
| Liste des fréquences + `↺` | Fréquences RTTY par bande ; le TRX y va en DATA-U. |
| **Bande** 3 kHz / 4 kHz | Largeur audio affichée. Le TRX n'envoie que le son après son filtre : pour 4 kHz, ouvrez aussi son filtre (BW 4.0K), sinon le bord droit reste noir. Impossible d'aller au-delà avec ces TRX (le scope de leur écran ne passe pas par l'USB). |
| **Zoom** ×1 à ×8, ou **molette** sur la cascade | Comme MixW : la cascade montre une plage plus étroite et plus détaillée (×4 : 750 Hz en bande 3 kHz). **Molette vers soi** : plus étroit, autour de la souris ; **molette vers l'avant** : plus large, jusqu'à la bande entière (×1). La liste fait de même, centrée sur le décodeur marqué TX ; la fenêtre suit ce décodeur quand il s'approche d'un bord. |
| `SPLIT` | Réception sur le VFO A, émission sur le VFO B (même commande que SPLIT de la ligne Step). Allumé en rouge : « SPLIT · TX sur B ». |
| Échelle de la cascade | En **kHz**, fréquence réelle (porteuse du VFO + audio) ; le petit triangle blanc marque le milieu de la bande audio. En **DATA-U** (mode à utiliser en RTTY), les fréquences basses sont à gauche ; en LSB, l'échelle est inversée et l'émission RTTY aussi : passez en DATA-U. |
| Repères sur la cascade | Décodeur **A** : jaune (Mark) et bleu (Space). Décodeur **B** : mauve (Mark) et vert (Space). Couleurs foncées, cadres épais : visibles même sur un écran très lumineux. La lettre **A** ou **B** est écrite en grand, sur une pastille de sa couleur, au-dessus des repères. |
| Bouton gauche / bouton droit | **Clic gauche** sur un signal : y caler le décodeur **A** ; **clic droit** : le décodeur **B**. En **gardant le bouton enfoncé** et en glissant, les deux barres du décodeur (Mark et Space) suivent la souris **en continu** : gauche pour A, droit pour B ; le décodage suit pendant le déplacement. Relâcher : le décodeur reste là. |
| `Maj` + glisser / `Maj` + molette sur la cascade | `Maj` + **glisser** la cascade à gauche ou à droite (ou glisser avec le bouton du milieu, la molette enfoncée) accorde le VFO (on « attrape » la bande, les signaux suivent la souris) ; `Maj` + **molette** : VFO ± 10 Hz par cran. Les deux décodeurs restent calés sur leurs signaux. Il faut avoir la main. |
| Fréquence (ex. 7 074,9 kHz) | À côté de VFO-A / VFO-B : fréquence du signal suivi par ce décodeur (porteuse du VFO écouté + centre Mark / Space, − en LSB), utile pour le carnet ou un spot. En réception simple (toujours le cas avec deux VFO en HF sur le FTX-1), les deux décodeurs lisent le même récepteur : leurs fréquences sont calculées sur le VFO écouté, indiqué entre parenthèses, par ex. « 7 079,1 kHz (VFO A) ». |
| **Shift** (170, 200, 425, 850 Hz) / **Vitesse** (45,45 … 100 Bd) | Radioamateurs : 170 Hz et 45,45 bauds. |
| `Inversé` | Échange Mark et Space si le texte reçu n'a aucun sens (signal « à l'envers »). |
| **Silencieux** | Plus haut = moins de caractères au hasard sur le bruit ; trop haut, les signaux faibles ne sont plus décodés. |
| Indicateur M / S | Les deux barres doivent battre en alternance quand le décodeur est bien calé. |
| Centre … Hz | Fréquence audio où le décodeur est calé. |
| `⌖ Centrer` | Déplace le VFO pour que le signal suivi par ce décodeur tombe au milieu de la bande audio (triangle blanc) : sa fréquence ne change pas. L'autre décodeur reste calé sur son signal s'il est encore dans la bande. |
| `TX` / clic dans la fenêtre | Choisit le décodeur dont les réglages servent à l'émission (fréquence audio, shift, vitesse) : **un clic n'importe où dans la fenêtre VFO-A ou VFO-B** suffit, ou le bouton `TX` de son en-tête. Le bouton devient `▶ TX ici` (rouge), l'en-tête rosit et un cadre rouge entoure le décodeur ; l'autre fenêtre affiche `RX ici` en vert, avec un cadre vert (réception seule). Un clic sur `RX ici` inverse les rôles. Le zoom se centre sur lui. **Un clic sur `▶ TX ici` émet le texte personnalisé** tapé dans le cadre du bas (comme `Émettre`) ; pendant l'émission il devient `■ Arrêter`. Les macros `F1`…`F12` partent aussi sur cette fenêtre. |
| `Effacer` | Vide le texte reçu de ce décodeur. La fenêtre a un ascenseur et suit toujours le décodage le plus récent (l'historique le plus ancien est retiré au fur et à mesure) ; si vous remontez pour relire (molette ou ascenseur), elle reprend le suivi 10 s plus tard. |
| Trait vertical entre les deux textes | À glisser : largeur des deux décodeurs (double-clic : moitié-moitié). |

1. **Recevoir** : clic gauche sur un signal pour le décodeur A, clic droit pour le décodeur B (bouton maintenu : les barres suivent la souris en continu, pour les poser exactement sur les traces). Les deux repères doivent tomber sur les deux traces du signal. Le texte s'affiche sous la cascade, A à gauche, B à droite.
2. **Double-clic sur un indicatif** reçu : il devient le correspondant.
3. **Choisir le décodeur de l'émission** : un clic dans sa fenêtre (VFO-A ou VFO-B), ou le bouton `TX` de son en-tête ; votre réponse part sur la fréquence de la station qu'il suit. Double-cliquer sur un indicatif dans la fenêtre B fait donc les deux : B devient le décodeur de l'émission et l'indicatif passe dans Correspondant.
4. **Émettre** : texte dans la zone du bas, puis `Émettre` (ou `Ctrl`+`Entrée`). Le texte part avec les réglages du décodeur marqué TX (et sur le VFO B si SPLIT est allumé), puis le TRX repasse en réception. Il s'affiche en gris dans la réception de ce décodeur, puis chaque lettre passe en rouge au moment où elle part. Pendant l'émission, le bouton devient `■ Arrêter`. 600 caractères au plus ; fréquence audio d'émission entre 300 et 2800 Hz.
5. **Macros** `F1` à `F12` (touches du clavier ou clic) : émission tout de suite ; **Maj+clic** ajoute la macro au texte sans émettre (section 13). `Échap` arrête l'émission en cours.
6. `Effacer` (sous Émettre) vide le texte à émettre ; `Log QSO` ouvre la fiche du carnet, avec la fréquence du décodeur marqué TX.

1. **Prendre la main**, onglet **RTTY**, TRX en **DATA-U** (bouton `↺` de la liste des fréquences).
2. **Chercher une station** : clic sur un indicatif vert de la **carte de bande**. Le TRX se cale dessus, le décodeur de l'émission la décode et son indicatif passe dans Correspondant. Ou bien : clic gauche sur une trace de la cascade (décodeur A), clic droit (décodeur B).
3. **Choisir la fenêtre d'émission** : un clic dans la fenêtre VFO-A ou VFO-B (« ▶ TX ici »). Un double-clic sur un indicatif reçu le met dans Correspondant et choisit en même temps sa fenêtre.
4. **Répondre** : touche `F2` (ou la macro de réponse), puis échange avec la macro du report. Pour un texte personnalisé : le taper dans le cadre du bas, puis `▶ TX ici` (ou `Ctrl`+`Entrée`). `Échap` arrête l'émission en cours.
5. **Noter le QSO** : macro qui contient `<LOG>` (fiche ouverte toute seule) ou bouton `Log QSO`.
6. **Appeler soi-même** (CQ) : choisir la fenêtre d'émission, puis `F1`. Avec deux décodeurs, on peut lancer CQ sur A tout en surveillant une autre station sur B.
7. **Station hors de la cascade mais pas spottée** : clic sur la carte de bande à la bonne fréquence (le TRX y va), ou molette / glisser sur la **règle des fréquences** au-dessus de la cascade (aussi Maj + glisser, `Maj` + molette dans la cascade).

À droite des onglets FT8 · FT4 · FT2, RTTY, WSPR, JT65, JTTY et CW (pas en SSTV : une seule fréquence), une **colonne verticale** montre la bande comme une règle (sur un grand écran, elle monte jusqu'en haut, à côté des écrans VFO A et B, rétrécis de la même largeur) : fréquences basses **en haut**, hautes en bas (par défaut 7030–7120 kHz en 40 m, 14080–14150 kHz en 20 m, 3570–3600 kHz en 80 m…). Les **spots** du DX cluster du club (OP0P, avec les stations repérées par le Reverse Beacon Network) s'y affichent à leur fréquence. On voit d'un coup d'œil toute la portion RTTY de la bande, alors que la cascade ne montre que 3 ou 4 kHz.

| Élément | Ce qu'il montre ou fait |
|---|---|
| Point vert / rouge, **20 m** | Liaison avec le cluster (vert = connecté), bande du VFO écouté. |
| `Filtres ▾` (jaune) / `Tous` | Sous le numéro de la bande (en grand). **Filtres** ouvre la liste des modes de l'onglet (RTTY : RTTY, PSK, OLIVIA ; FT8 · FT4 · FT2 : FT8, FT4, FT2 ; JT65 : JT65, JT9, Q65…) et « Spots sans mode indiqué » : cochez ceux à afficher. Choix gardé par onglet ; `Par défaut` revient au mode de l'onglet + spots sans mode. **Tous** (vert quand il est enclenché) : tous les spots de la plage, quel que soit leur mode. |
| Deux cases kHz | Plage affichée, gardée pour chaque bande, à part pour le RTTY, le CW et les autres modes numériques. Tapez-y vos limites (ex. 7030 et 7120). Par défaut en 40 m : RTTY 7030–7120, CW 7000–7040, FT8 et autres 7038–7080 kHz. |
| Indicatif en vert | Station qui appelle (CQ, spot d'un skimmer RBN). |
| Indicatif barré | Déjà contacté en RTTY sur cette bande (sous le TX call choisi). |
| Indicatif pâle | Spot ancien (gardé 30 minutes). Au survol : commentaire, qui l'a spotté, il y a combien de minutes. |
| Zone bleue | La partie de la bande visible dans la cascade en ce moment. |
| Trait jaune / mauve | RTTY : décodeur A / B ; « TX » à côté de celui de l'émission, « RX » à côté de l'autre. FT8, JT65, JTTY : trait vert = fréquence de réception, rouge = émission. CW : trait jaune = fréquence du VFO. « ▲ VFO » ou « ▼ VFO » : le VFO est hors de la plage. |
| **Clic sur un spot** | Le TRX se cale sur la station : si elle est déjà dans la cascade, seul le décodeur de l'émission s'y place ; sinon le VFO bouge pour la mettre au milieu de la cascade, avec le décodeur dessus. L'indicatif passe dans Correspondant. Il reste à appuyer sur la macro de réponse (`F2`…). Il faut avoir la main. |
| Clic ailleurs sur la carte | Même chose sur cette fréquence, sans indicatif (balayer la bande). |
| Clic dans les autres onglets | **CW** : le VFO va sur la station (elle sort à la tonalité du TRX, là où le décodeur CW est calé). **FT8 · FT4 · FT2, JT65, JTTY, WSPR** : la fréquence de réception se place sur le signal ; s'il est hors de la bande audio, le VFO bouge pour le mettre à 1500 Hz. |
| Poignée sur le bord gauche | Glisser à gauche ou à droite : largeur de la carte de bande (gardée dans ce navigateur) ; double-clic : largeur d'origine. |
| **Molette** / glisser / double-clic | Molette : zoom autour de la souris ; glisser vers le haut ou le bas : déplacer la plage ; double-clic : plage d'origine de la bande. |

Réglages du cluster (administrateur, `config.json`, puis redémarrer le service) : `clusterHost` (op0p.be par défaut ; vide = pas de cluster), `clusterPort` (8000), `clusterCall` (indicatif de connexion avec un SSID ; vide = digiCall suivi de -7, donc ON5VL-7) et `clusterCmds` (commandes envoyées après la connexion : `set/skimmer` pour les spots RBN).

<a id="wspr"></a>
### 12.4 WSPR

Le WSPR sert à étudier la propagation : des balises de faible puissance émettent leur indicatif, leur locator et leur puissance toutes les 2 minutes. Choisissez la bande dans la liste ; une dizaine de secondes après chaque minute paire, la liste se complète : heure, dB, DT, fréquence, dérive, indicatif, locator, puissance et distance depuis la station. Réception seulement.

- Les balises WSPR occupent seulement **200 Hz** de la bande audio, de **1400 à 1600 Hz** (rappel en haut de l'onglet) : la fréquence de la liste (ex. 14,0956 MHz) est celle du VFO en USB / DATA-U.
- Le bouton `↺` ramène le VFO A sur la fréquence WSPR choisie ; `Effacer` vide la liste ; le nombre de stations entendues s'affiche dans le titre.
- L'horloge indique l'heure UTC du serveur : chaque période de 2 minutes commence aux minutes paires.

<a id="jtty"></a>
### 12.5 JTTY

- Mode de WSJT-X 3.3 pour le clavier à clavier et les concours : pas de périodes, chaque message apparaît **trame après trame** (1,9 s) ; `▌` = message en cours de réception.
- Comme en FT8 : clic gauche = réception, clic droit = émission, double-clic = correspondant. Deux listes : Activité JTTY et Fréquence RX.
- Macros `F1` à `F8` : un clic émet tout de suite, **Maj+clic** les ajoute au message.
- `Émettre` (ou `Entrée`) : le message part tout de suite sur la fréquence TX, puis retour en réception. 80 caractères par message (au-delà : deux messages à la suite) ; TRX en **DATA-U**.

<a id="cw"></a>
### 12.6 CW

| Commande | Ce qu'elle fait |
|---|---|
| Liste des fréquences + `↺` | Fréquences CW par bande ; le TRX passe en CW. |
| **Filtre** 50 … 400 Hz | Largeur du filtre du décodeur : 100 Hz par défaut, 50 Hz en cas de QRM, 200 à 400 Hz pour chercher. **Avec la main et le TRX en CW**, le choix règle aussi la largeur **BW du TRX** au plus près (pour tout le monde, comme le cadre Filtres ; NARROW est coupé s'il était enclenché ; IC-7300 : FIL3 jusqu'à 250 Hz, FIL2 au-delà) : la BF entendue se rétrécit aussi. Le TRX centre son filtre sur sa propre tonalité CW (pitch) : la station doit être calée sur cette tonalité (clic sur la carte de bande, ou VFO), sinon elle disparaît de la cascade avec un filtre étroit. Sans la main, seul le décodeur change. |
| **Silencieux** | Niveau du signal (dB) au-dessous duquel rien n'est affiché : plus haut = moins de lettres au hasard sur le bruit, mais les signaux très faibles disparaissent. 5 par défaut ; 3 ou 4 pour un signal très faible. Le décodeur continue de suivre le signal même silencieux fermé. |
| **Vitesse** (cadre Émission, à droite du titre) | Vitesse d'**émission** du manipulateur du TRX, 5 à 60 mots/min (48 sur l'IC-7300) ; une valeur plus haute est ramenée au maximum du TRX. Sans effet sur la réception : la vitesse reçue est mesurée toute seule. |
| Voyant et barre de niveau | Suivent la manipulation : le voyant clignote au rythme du morse quand le décodeur est bien calé. |
| Tonalité / Vitesse | Fréquence audio suivie et vitesse mesurée (mots/minute). |

- **Cliquez sur un signal** dans la cascade : le décodeur se cale sur le signal le plus proche et apprend sa vitesse. Clic droit : calage exact là où vous cliquez. **Bouton gauche maintenu** en glissant : le repère jaune du décodeur suit la souris **en continu** (le décodage suit pendant le déplacement) et reste exactement où vous relâchez, comme les barres du RTTY.
- Double-clic sur un indicatif reçu = correspondant ; `Log QSO` ouvre la fiche du carnet.
- **Le décodeur** (depuis la 0.23.1) travaille comme l'oreille : il se recale tout seul sur la tonalité exacte du signal (jusqu'à ± 60 Hz du repère avec le filtre de 100 Hz), filtre au plus étroit que permet la vitesse (environ 1 / point), et fait tourner trois décodeurs en parallèle (rapide, moyen, lent) en gardant celui dont les points et les traits ont les durées les plus cohérentes. Il copie correctement des signaux bien plus faibles qu'avant ; il lui faut quelques lettres pour trouver la vitesse d'une nouvelle station.
- **Émission CW**, par le **manipulateur du TRX** (pas de son envoyé : le TRX fabrique le morse lui-même, comme avec ses mémoires) :
   - **Vitesse** (5 à 60 mots/min, 48 sur l'IC-7300) : vitesse du manipulateur, envoyée au TRX à chaque émission.
   - **Macros** `F1` à `F12` (touche ou clic) : **liseré rouge = émission immédiate** (CQ, Appel, Report, R TU, 73, QRZ?, AGN?), comme en RTTY ; **Maj+clic** l'ajoute au texte sans émettre. `<CALL>` sans correspondant : rien ne part.
   - **Texte** : tapé dans la zone (en majuscules), puis `Émettre` ou `Ctrl`+`Entrée` ; la zone se vide quand l'émission part. Caractères envoyés : lettres, chiffres, `/ ? . , = + -` et espaces ; `<AR>` devient + et `<BT>` devient = ; le reste est ignoré. 300 caractères au plus, et pas plus long que la durée maximale d'émission.
   - Pendant l'émission, un gros bouton rouge `■ ARRÊTER (Échap)` clignote dans le titre du cadre Émission, au-dessus des macros (macro lancée par erreur…) ; le bouton `Émettre` devient aussi `■ Arrêter` et la ligne du bas indique « ● En émission CW (indicatif, vitesse, durée) ». Un clic ou `Échap` coupe tout de suite.
   - Conditions : avoir la main, l'émission autorisée, une bande et une puissance permises, le TRX en **CW** (CW-L / CW-U, CW / CW-R sur l'IC-7300) et **sans SPLIT** (le manipulateur émet sur le VFO écouté).
   - **FTX-1 : manipulation par DTR** (conseillée) : si le « Port de manipulation CW (DTR) » est choisi sur la page Station (section 18), la page manipule elle-même le TRX par ce port ; sinon elle passe par la mémoire du manipulateur, décrite ci-dessous.
   - Ce que fait la page Station : vitesse du manipulateur, **break-in** en service (le TRX émet tout seul pendant le morse et revient en réception), texte écrit dans une mémoire du manipulateur puis joué, par morceaux de 50 caractères (30 sur l'IC-7300). **Attention** : la mémoire 5 du FTX-1 (menu CW MEMORY 5, mise en TEXT par le dashboard) et la mémoire 1 du FTDX10 / FTDX101 sont remplacées par le texte émis. Chaque étape (mémoire écrite, lecture acceptée, émission) s'affiche sous les bandes ; un seul clic suffit : l'émission est reconnue à l'état TX du TRX ou à la puissance émise (Po) ; si rien n'est vu après 1,6 s, la page relance une fois la lecture (break-in remis) puis la laisse jouer. Sous les bandes s'affiche le délai réel (« en émission 1,2 s après la demande »). Une macro cliquée pendant un message le remplace aussitôt (inutile d'attendre la fin). Le texte émis s'inscrit dans la réception CW comme en RTTY : **rouge** pour les lettres déjà parties, **gris** pour celles qui restent (barrées si l'émission est arrêtée avant la fin). **Préparation d'avance** : la macro survolée par la souris, le texte en cours de frappe et, au repos, la 1re macro (F1, CQ) sont déjà écrits dans la mémoire du TRX (sans émettre) ; le clic ne lance plus que la lecture, l'émission part alors aussi vite que le TRX le permet. Menu PC KEYING du TRX sur **OFF** : sur DTR ou RTS, le FTX-1 refuse la lecture des mémoires (KY05 refusé). Sur le FTX-1, la méthode par la mémoire est lente (le TRX ne joue pas une mémoire qu'on vient d'écrire, et ne signale pas toujours l'émission) : la **manipulation DTR** (page Station) est conseillée, l'émission part alors en moins d'une demi-seconde. Commutation rapide : vitesse, break-in et texte déjà en mémoire ne sont pas renvoyés au message suivant, une macro répétée part donc aussitôt (tout est renvoyé après un arrêt, une erreur ou 20 minutes). Un réglage déjà en place que le FTX-1 refuse (« ? ») est seulement noté au journal. À l'arrêt, la lecture est interrompue (FTX-1 : KY00, le break-in reste comme il est ; FTDX10 / FTDX101 : break-in coupé).
   - Sécurités : celles de toute émission (bandes, puissance, ROS), arrêt si la main est perdue, si la liaison ou la station tombe, et durée maximale.
- **Clé CW depuis chez vous** (palettes ou pioche, depuis la 0.37.174) : la ligne `Clé → TRX` sous le cadre Émission. Le keyer tourne dans **votre navigateur** avec l'écoute locale (sidetone) : vous entendez votre manipulation sans retard ; les points et traits partent horodatés vers le serveur et la page Station les rejoue au même rythme sur la ligne DTR du 2e port USB du TRX. Le TRX émet avec **environ 0,2 à 0,3 s de décalage** (Internet) : pas de QSK, le break-in du TRX revient en réception après chaque pause.
   - **TRX CW** (bouton bleu `🎛 TRX CW` au bout de la ligne de la clé) : une page entière dans l'esprit du W1VE Keyer Suite, raccrochée au dashboard (même connexion, même main) : grand affichage de la vitesse et curseurs (vitesse, poids, tonalité, volume), type de clé et branchement, grandes palettes à l'écran, grand bouton `CLÉ → TRX`, macros F1 à F12 (clic droit ou ✎ : modifier), correspondant, texte à émettre (Entrée), `■ ARRÊTER`, réception CW, grand voyant **RX / TX**, et en bas l'état de la liaison (aller-retour en ms). La vitesse y vaut pour la clé et pour les macros. Tant que cette page est ouverte, la clé de l'onglet CW du dashboard est en veille (une seule clé à la fois). Les refus (« mettez d'abord le TRX en CW »…) s'y affichent aussi.
   - **Contest CW** (ligne **CONTEST** du TRX CW) : liste des contests CW (CQ WW, CQ WPX, ARRL DX, IARU HF, WAE, UBA DX, ON Contest, EU HF, OK/OM, RDXC, SP DX, HA DX, YO DX, LZ DX, El Rey de España, Helvetia, PACC, WAG, All Asian, JIDX, CWops CWT, autre) avec l'**échange** d'une station belge, modifiable (`<CNTR>` = n° de série, `<CQZ>` zone CQ 14, `<ITUZ>` zone ITU 27, `<MYNAME>` prénom ; « 00 » à compléter : âge, année de licence ; UBA DX et ON Contest : section, LGE pour le club) ; à droite, en vert, ce qui sera émis. **N°** : numéro de série, **+1 automatique** avec la macro **TU** (`<INCR>`), une seule fois par correspondant (renvoyer TU au même ne saute pas de numéro) ; `−1` / `+1` pour corriger. Un contest choisi fait apparaître 12 **macros contest** (jaunes) : CQ TEST, Échange, TU, Mon ind., Son ind., Réponse, AGN?, NR?, ?, QRZ?, R, Log (fiche du QSO avec l'échange envoyé et le contest) ; les touches `F1`…`F12` passent alors aux macros contest, les macros habituelles restent au clic. Même numéro de série que le contest RTTY.
   - **Log du contest** (à la manière de N1MM, sous la ligne CONTEST) : ligne de saisie **Indicatif · RST · Envoyé · RST · Reçu**, `LOG ↵` et `EFFACER` (`Alt`+`W`). `Espace` passe de l'indicatif à l'échange reçu. **Entrée** fait tout (ESM de N1MM) : en `RUN` (vous appelez CQ) : ligne vide → CQ (F1), indicatif tapé → indicatif + échange (F2), échange reçu tapé → QSO enregistré + TU (F3) ; en `S&P` (vous répondez) : indicatif tapé → votre indicatif (F4), échange reçu tapé → TU + échange (F6) et QSO enregistré. Dès l'indicatif tapé : **DOUBLON** (rouge, même bande dans ce contest), « déjà sur 40m… » ou « nouveau ». Les QSO vont **dans le carnet général** (identifiant du contest, échanges envoyé et reçu, sous le TX call) ; à droite : liste des QSO du contest, compteurs par bande, doublons, cadence (10 min et 1 h). **Depuis** : date de début prise en compte (par défaut les 3 derniers jours) ; `CABRILLO` : fichier du contest (ses QSO seulement) à envoyer à l'organisateur. Le n° de série passe au suivant à chaque QSO enregistré.
   - Pendant une émission CW (macro, clé à distance ou clé branchée sur le TRX), la fréquence reste **rouge** jusqu’à la fin du message, même quand le break-in du TRX repasse en réception entre les lettres (encore 1,5 s après le dernier signe).
   - `Clé → TRX OFF` (au chargement de la page) : **entraînement**, écoute locale seule, rien n'est émis. `ON` avec la main : votre clé manipule le TRX. Le voyant jaune suit votre clé ; le badge **TX** s'allume quand le TRX du club émet votre manipulation.
   - `Réglages` : **Clé** (palettes iambique B, iambique A, ou pioche / clé droite), **Vitesse** (5 à 50 mots/min, celle du keyer de la page, indépendante de la vitesse des macros), **Poids** (50 % = normal), **Inverser point / trait**, **Écoute** (tonalité, volume et sortie son du sidetone : par exemple un casque, à part de la BF du TRX).
   - **Branchement** de votre clé sur votre PC :
      - **Adaptateur USB (Ctrl gauche / droit)** : les adaptateurs palettes → USB qui se présentent comme un clavier (type VBand / Vail) : Ctrl gauche = point, Ctrl droit = trait.
      - **Touches du clavier** : deux touches de votre choix (cliquez sur la case puis appuyez sur la touche).
      - **Adaptateur MIDI** : cliquez sur la case Point puis touchez la palette point, idem pour le trait (notes ou contrôleurs MIDI).
      - **Câble USB-série (DSR / CTS)** : le montage classique des logiciels de contest : contact point sur **DSR**, contact trait sur **CTS**, commun sur **DTR** (mis à 1 par la page). `Choisir le port…` ; Chrome ou Edge. Câblage détaillé ci-dessous.
      - **Palettes à l'écran** : les boutons `•` et `—` (souris ou écran tactile), toujours disponibles.
   - **Brancher une double palette (ou une pioche) sur votre PC**. Une clé n'est qu'un interrupteur : ni la carte son ni une prise USB ne savent la lire telle quelle, il faut une petite interface USB. **Rien ne se branche sur la carte son**, et il n'y a rien à installer (ni serveur au club, ni logiciel chez vous) : le chemin est clé → interface USB → votre PC (page TRX CW) → Internet → serveur → page Station du club → FTX-1.
      - **Adaptateur USB → RS-232 avec prise DB9 mâle** (puce CH340, PL2303 ou FTDI ; le modèle bleu transparent courant convient). Dans le Gestionnaire de périphériques (Ports COM et LPT), il doit apparaître **sans point d'exclamation** (Prolific « PL2303HXA phased out » / code 10 : puce copiée refusée par le pilote récent → autre câble ou ancien pilote). Sur une **prise DB9 femelle à bornier à vis** (« DB9 breakout »), on visse les **3 fils** de la clé :
         - **Commun** de la clé (souvent appelé « GND ») → **broche 4** (DTR : tension mise en marche par la page)
         - **Point** → **broche 6** (DSR : entrée lue « point »)
         - **Trait** → **broche 8** (CTS : entrée lue « trait »)
      - **Reconnaître les fils** : jack 3,5 mm stéréo : **pointe = point**, **bague = trait**, **corps = commun** ; fils nus : multimètre en « continuité », une pointe sur le commun, appuyer sur une palette et chercher le fil qui bipe. En cas de doute, branchez au hasard et cochez **Inverser point / trait** si besoin (aucun risque).
      - **Essai sans la clé** (CLÉ → TRX sur **OFF**) : TRX CW → **Câble USB-série (DSR / CTS)** → `Choisir le port…` → le CH340 → « port ouvert » ; un trombone entre les broches **4 et 6** donne des points, entre **4 et 8** des traits (écoute locale + voyant Clé).
      - **Ne conviennent pas** pour une double palette : les câbles USB « TTL » à 4 fils (rouge +5 V, noir GND, vert TX, blanc RX), les câbles USB → jack 3,5 mm « console » (pointe RX, bague TX), et le câble FTDI TTL 6 fils (une seule entrée CTS : pioche seulement, clé entre CTS et GND). Les câbles « USB CW avec jack » vendus pour faire manipuler un TRX par un logiciel servent à l'inverse (sortie vers le TRX).
      - **Autres solutions** : un adaptateur palette → USB tout fait de type **VBand** ou **Vail** (vu comme un clavier : « Adaptateur USB (Ctrl gauche / droit) ») ; ou une **Arduino Pro Micro** (ATmega32U4) avec un jack : masse → GND, point → A2, trait → A3 (même réglage).
   - **Spot CW cliqué** dans une carte de bande (BAND MAP de la face avant, où le mode est écrit à côté du spot, ou carte de bande des modes numériques) : le TRX se cale dessus **en CW**, l'onglet **CW** s'affiche et l'indicatif passe dans la case **QSO**, aussi dans la page **TRX CW** (en contest : dans la case **Indicatif** du log, doublon vérifié, prêt pour Entrée), qui revient au premier plan si elle est ouverte. Les macros `<CALL>` l'utilisent aussitôt.
   - **Macros et clé** : pendant une macro (F1…), **toucher la clé arrête la macro** : c'est votre clé qui prend la main sur le TRX. Vous pouvez donc lancer CQ par F1 et répondre à la clé.
   - Ce que vous manipulez s'affiche dans la fenêtre **Réception CW**, en couleur d'émission comme les macros (texte reconstitué à partir de vos points et traits, sans passer par le décodage du son).
   - `Échap` arrête l'émission ; la manipulation reprend à la prochaine pression après une courte pause.
   - Les touches clavier ne sont prises que quand l'onglet CW est affiché. Gardez la fenêtre **visible** pendant le trafic (Chrome ralentit les onglets cachés). Pour ne pas vous gêner avec le retour de votre propre signal, baissez le son du TRX pendant que vous manipulez.
   - Conditions et sécurités : celles des macros (la main, bande et puissance permises, TRX en CW sans SPLIT, durée maximale sans pause) ; la page Station relâche la clé si vos données n'arrivent plus (0,3 s), coupe une clé enfoncée plus de 5 s, et termine la rafale après une pause. Il faut le **port de manipulation CW (DTR)** ouvert sur la page Station (section 18) ; sinon le refus s'affiche.

<a id="sstv"></a>
### 12.7 SSTV

- **Réception** : les images arrivent toutes seules (code VIS) et s'affichent ligne après ligne. Modes Martin, Scottie, Robot et PD. La **galerie** garde les 12 dernières (clic = afficher) ; `PNG` enregistre l'image affichée sur votre PC.
- **Préparer une image** : `Images du PC…` (ou glisser-déposer une image), carte CQ, mire ou image reçue ; elle est recadrée au format du mode choisi. Le trait vertical entre **Réception SSTV** et **Émission** se glisse pour régler leur largeur (double-clic : moitié-moitié). **Format conseillé : 800 × 600 pixels** (paysage 4:3, JPG ou PNG, moins de 5 Mo) : aucun recadrage en Robot 36 / 72, 1 à 3 % coupés à gauche et à droite dans les autres modes ; gardez l'essentiel au centre et laissez de la place en haut et en bas pour les textes. Vos images viennent de **votre** PC (n'importe où, par internet) et restent dans **votre navigateur** (10 au plus, la plus ancienne s'efface) ; à l'émission, seule l'image émise passe par le serveur, le temps de fabriquer le signal, sans y être enregistrée. Trois lignes de texte (haut, centre, bas) avec les balises `<CALL>`, `<MYCALL>`, `<RST>`… ; taille et couleur du texte. Clic droit sur une vignette : la retirer.
- `▶ Écouter` joue le signal sur votre PC (sans émettre) ; `WAV` l'enregistre en fichier.
- **Émettre** : avec la main, VFO d'émission en **DATA-U**, `Émettre` envoie l'image affichée (au format du mode choisi) au serveur, qui fabrique le signal et le confie à la page Station ; le TRX passe en émission environ une seconde plus tard. Pendant l'émission, la partie de l'image pas encore émise est **assombrie**, le trait rouge suit la ligne en cours, et la note sous l'image donne la ligne et le temps restant. `■ Arrêter` ou `Échap` coupe l'émission. Mêmes sécurités que RTTY (bandes, puissance, ROS, liaison). Durée : de 37 s (Robot 36) à près de 5 min (PD 290) ; la limite des autres modes ne s'applique pas, mais le serveur refuse un mode plus long que son réglage `maxSstvSeconds` (300 s par défaut). Le TRX émet **sans interruption** pendant toute l'image : réduisez la puissance (25 à 50 % conseillé).

<a id="synchro"></a>
### 12.8 Synchro

Un onglet de contrôle : il montre si les horloges et la liaison sont bien calées. Vous n'avez rien à régler.

| Case | Signification |
|---|---|
| Heure du serveur (UTC) | La référence de tous les décodages. |
| Serveur : NTP | Synchronisation du serveur sur l'heure mondiale (chrony ou systemd-timesyncd sur le VPS) : écart en millisecondes et serveur de temps. C'est l'horloge qui compte pour les décodages et l'instant d'émission ; « NON SYNCHRONISÉ » ou plus de 50 ms : à corriger sur le VPS (voir le guide administrateur). |
| PC du club | Écart de l'horloge de Windows du PC du club avec le serveur, mesuré par la page Station. Il est **corrigé tout seul** pour l'émission FT8 / FT4 / FT2. `⟳ Mettre à l'heure` (responsables) : l'assistant carte son **version 4** règle Windows sur des serveurs NTP publics, comme NetTime, à la milliseconde ; il le fait aussi au démarrage et toutes les heures. NetTime n'est alors plus nécessaire sur le PC du club. |
| Votre PC | Écart actuel de l'horloge de votre PC avec le serveur, en millisecondes. N'a pas d'importance pour le dashboard. À ne pas confondre avec la colonne « Offset » de NetTime ou Meinberg (écart **avant** leur dernière correction). |
| Liaison station → serveur | Délai d'arrivée du son du club, mesuré et corrigé automatiquement. |
| DT médian | Moyenne des DT des derniers décodages FT8 / FT4 : proche de 0,0 s = tout est calé. |
| Décodages | Heure d'arrivée de chaque passe du décodeur après le début de la période. Si la passe normale arrive plus de 2 s après la fin de la période, le serveur est trop chargé et certaines réponses partent une période plus tard. |

<a id="qo100"></a>
### 12.9 QO-100

QO-100 est un satellite géostationnaire qu'on atteint en 2,4 GHz avec un convertisseur. Les listes FT8 · FT4, RTTY et CW proposent « **QO-100 · FI 2 m / 70 cm** » : la fréquence à mettre sur le TRX **avant le convertisseur**, pour monter sur 2400,040 MHz (FT8 / FT4), 2400,025 MHz (CW) ou 2400,090 MHz (RTTY). Exemple : FT8 sur **432,540 MHz** avec le convertisseur 70 cm du club. Seules les FI que le TRX branché peut atteindre sont proposées (FTX-1).

<a id="messages"></a>
## 13. Correspondant, macros et balises

**La ligne Correspondant** (sous les onglets des modes numériques)

| Champ | Ce qu'il contient |
|---|---|
| **QSO** (correspondant) | L'indicatif de la station contactée. Il se remplit tout seul quand vous cliquez sur un indicatif dans un onglet ; vous pouvez aussi le taper. |
| **Nom**, **QTH**, **Locator** | Prénom, ville et locator du correspondant. Ils sont cherchés sur **QRZ.com** dès qu'un nouveau correspondant est choisi (si un compte QRZ est réglé par les administrateurs) ; seules les cases vides sont remplies. |
| **RST TX** / **RST RX** | RST TX = report **envoyé** par la station du club ; RST RX = report **reçu** du correspondant. En FT8 / FT4 / FT2, WSPR et JT65 ce sont des dB (RST RX se remplit tout seul pendant la séquence) ; en RTTY, CW, SSTV et JTTY, des RST 599. |
| **TX call** | Indicatif des émissions numériques et du carnet : un indicatif de la station (**ON5VL** ou **OR0L**, réglage `clubCalls`) ou le vôtre. Choisi par celui qui a la main et retenu pour la prochaine fois. Les messages Tx1 à Tx6, les macros `<MYCALL>` et la fiche du carnet suivent. Un QSO enregistré sous votre indicatif reste dans le carnet du club, mais n'est pas envoyé vers les comptes en ligne du club (récupérez-le avec Exporter → Mes QSO). |
| `Log QSO` (ligne des onglets, à droite de Logbooks) | Ouvre la fiche « Enregistrer le QSO », déjà remplie avec ces informations, la fréquence et le mode. |

**Les macros** (RTTY, JTTY, CW) sont des textes tout prêts, sur une ligne au-dessus de la zone de texte : **F1 à F12** en RTTY et CW, **F1 à F8** en JTTY.

- Une macro qui commence par `<TX>` (liseré rouge à gauche ; c'est le cas de toutes les macros d'origine) **part tout de suite à l'émission** au clic ou avec sa touche `F1`…, puis le TRX repasse en réception.
- **Maj+clic** : ajoute la macro au texte à émettre sans émettre, pour composer un message puis « Émettre ».
- Une macro sans `<TX>` s'ajoute simplement au texte (en CW aussi : les macros d'origine ont `<TX>` et partent tout de suite).
- **Clic droit** sur une macro (ou `✎`) : la modifier — nom, texte, aperçu, retour au texte d'origine. Vos macros sont gardées sur le serveur, pour vous seul.
- Si une macro contient `<CALL>` alors qu'aucun correspondant n'est choisi, rien ne part.

| Balise | Remplacée par | Balise | Remplacée par |
|---|---|---|---|
| `<MYCALL>` | indicatif émis (TX call) | `<CALL>` | correspondant |
| `<NAME>` | son prénom | `<QTH>` | son QTH |
| `<RST>` | report envoyé | `<LOC>` | son locator |
| `<MYLOC>` | locator de la station | `<MYQTH>` | QTH de la station |
| `<OPCALL>` | votre indicatif (opérateur) | `<CNTR>` | numéro de série (001…) |
| `<INCR>` | passe au numéro suivant | `<ZT>` / `<ZD>` | heure / date UTC |
| `<TX>` | en tête : émission immédiate au clic | `<RX>` | retour en réception à la fin (toujours fait) |
| `<LOG>` | ouvre la fiche « Enregistrer le QSO » |  |  |

<a id="logs"></a>
## 14. Logbooks (carnet de trafic)

Onglet **Logbooks** (bouton cyan, à gauche de Log QSO et de Synchro) : le carnet de trafic de la station, partagé par tous les membres. Il sait envoyer les QSO vers **LoTW**, **eQSL**, **Club Log** et **QRZ.com**, les exporter en **ADIF** ou **Cabrillo**, et les transmettre en **UDP** aux logiciels de carnet du PC (Swisslog, HRD Logbook, Log4OM, N1MM Logger+…).

<a id="l-fiche"></a>
### 14.1 Enregistrer un QSO

La fiche en haut de l'onglet :

| Champ / bouton | Ce qu'il fait |
|---|---|
| **Indicatif** | L'indicatif du correspondant. La date et l'heure UTC se remplissent dès la première lettre tapée (début du QSO). Le **prénom et le nom**, le QTH et le locator sont cherchés sur QRZ.com (après une petite pause dans la frappe, cases vides seulement ; aussi à l'ouverture d'un QSO enregistré où ils manquent). Bouton `⇩ QRZ` (à côté du locator) : les reprend de QRZ.com en remplaçant ce qui est écrit. Le locator n'est donné par QRZ.com qu'avec un abonnement XML. |
| **Date UTC**, **Heure UTC** | Début du QSO, en heure UTC (pas l'heure belge). |
| `⟳ Maintenant` | Remet la date et l'heure à l'instant présent. |
| **Fréquence MHz**, **Mode** | Suivent tout seuls le VFO actif du TRX. Une valeur tapée à la main reste jusqu'au QSO suivant. |
| `⇩ TRX` | Reprend la fréquence et le mode du TRX (en DATA : le mode de l'onglet affiché, FT8, RTTY…), la puissance, et la ligne Correspondant (indicatif, nom, QTH, locator). |
| **RST env.** / **RST reçu** | Report envoyé et reçu (59, 599 ou dB selon le mode). |
| **Nom**, **QTH**, **Locator**, **Puiss. W**, **Remarque** | Informations du QSO ; la remarque est libre. |
| **TX call** | Indicatif sous lequel le QSO a été fait. Il suit celui de la ligne Correspondant ; avec la main, le changer ici change aussi l'indicatif d'émission. |
| ☐ **QO-100** | QSO par le satellite QO-100 : avec la FI du convertisseur (ex. 432,525 MHz), la case se coche toute seule et la fréquence de montée 2400,xxx MHz est enregistrée. |
| **IOTA**, **WWFF**, **POTA**, **BOTA**, **LLOTA** (en jaune, au bout de la 2e ligne, à droite de Remarque) | Références du correspondant quand il est en activation (île, réserve naturelle, parc, bunker, lac…). Tapez le début de la référence (`ONFF-`, `BE-00`, `EU-`…) ou un morceau du **nom** (« fagnes ») : une liste s'ouvre sous la case, choisissez avec la souris ou les flèches puis `Entrée`. Case vide et indicatif déjà tapé : la liste propose d'abord les références de son pays. Plusieurs références (ex. deux parcs POTA en même temps) : séparez-les par une virgule. Le locator de la référence remplit celui du QSO s'il est vide. Ces cases sont vidées après chaque QSO. |
| `＋ Ma référence (activation)` (1re ligne, à droite de QO-100) | Affiche une ligne **Ma réf. (activation)** pour les références **de la station**, quand le club active lui-même un parc, une île… Elles **restent remplies** d'un QSO à l'autre (dans ce navigateur) jusqu'à ce que vous les effaciez. Le bouton cache ou remontre la ligne (retenu). |
| `Enregistrer le QSO` (ou `Entrée`) | Ajoute le QSO au carnet. Un doublon (même indicatif, bande et mode dans la demi-heure) est signalé avant l'enregistrement ; si la fiche déjà au carnet n'a pas le nom, le QTH, le locator ou le RST reçu, on propose de la **compléter** au lieu de créer un 2e QSO. |
| `Supprimer` / `Annuler` | Apparaissent quand vous modifiez un QSO existant : supprimer le QSO (après confirmation ; les carnets en ligne ne sont pas modifiés) ou abandonner la modification. |

**Sans quitter l'onglet RTTY, JTTY ou CW** : le bouton `Log QSO` (à côté de « Émettre », et sur la ligne des onglets, à droite de Logbooks) ouvre une fiche déjà remplie : indicatif, prénom, QTH, locator et RST, fréquence (en RTTY : celle du signal) et mode, puissance, heure de début (quand le correspondant a été choisi) et de fin. Corrigez au besoin, puis `Enregistrer dans le carnet`. En FT8, cette fiche s'ouvre toute seule à la fin du QSO ; une macro qui contient `<LOG>` l'ouvre aussi.

| Champ de la fiche Log QSO | Contenu |
|---|---|
| **Indicatif**, **Nom**, **QTH**, **Locator** | Repris de la ligne Correspondant (et de QRZ.com). |
| **Date UTC**, **Début UTC**, **Fin UTC** | Début : quand le correspondant a été choisi ; fin : à l'ouverture de la fiche. Modifiables. |
| **Fréquence MHz**, **Mode** | Fréquence réelle du signal (RTTY : porteuse + décodeur marqué TX) et mode de l'onglet. |
| **RST envoyé**, **RST reçu**, **Puiss. W**, **Remarque** | Reports de la ligne Correspondant, puissance du TRX, texte libre. |
| `Enregistrer dans le carnet` / `Annuler` | Ajoute le QSO (contrôle des doublons comme dans l'onglet Logbooks) ou ferme sans rien noter. |

En **FT8 · FT4 · FT2**, à la fin de la séquence, une petite fenêtre « **QSO terminé** » résume le QSO (indicatif, locator, mode, fréquence, reports, heures) : `Enregistrer dans le carnet` l'enregistre, `Ne pas enregistrer` la ferme. Le choix **Log** de la barre d'émission FT8 (à droite de « Répondre au 1er ») évite cette fenêtre : **auto à l'envoi du RR73 / 73** (comme « Log automatically » de WSJT-X), **auto à la réception du RR73 / 73** (si la fin arrive par votre envoi sans RR73 / 73 reçu, la fiche reste à confirmer), ou **auto au 1er RR73 / 73** (envoyé ou reçu) ; le QSO va alors tout seul dans le carnet (nom et QTH du correspondant repris s'ils sont connus) et un message le confirme. Sans la séquence automatique, ou pour un QSO oublié : onglet **Logbooks**, tapez l'indicatif, `⇩ TRX` (fréquence et mode du TRX), les reports, puis enregistrez.

<a id="l-liste"></a>
### 14.2 La liste des QSO

- La liste montre les 300 derniers QSO. La case **Rechercher** trouve un indicatif, un nom ou un opérateur ; le nombre de QSO trouvés s'affiche à côté.
- **Clic sur une ligne** : le QSO s'ouvre dans la fiche. Son auteur **avec la main** (ou un administrateur) peut le modifier ou le supprimer ; tous les autres (membres sans la main, écouteurs, autres opérateurs) le voient **en lecture seule** (« Fermer » le referme). Personne ne peut jamais modifier ni supprimer le QSO d'un autre indicatif, sauf les administrateurs.
- Colonnes : date, heure, indicatif, bande, fréquence, mode, reports, nom, QTH, **locator**, pays DXCC, préfixe, TX call, opérateur, références (IOTA, POTA…), états des envois (LoTW, eQSL, Club Log, QRZ).
- **Largeur des colonnes** : glisser le bord droit d'un titre de colonne (double-clic : largeur d'origine). Réglage gardé dans votre navigateur.
- **Filtres** : le **▾** à côté de chaque titre propose les valeurs de la colonne (dates, bandes, modes, pays, TX call, état des envois…) avec leur nombre de QSO. Un choix filtre le carnet (le ▾ devient ●) ; plusieurs colonnes se combinent ; `✕ Filtres` les retire tous.

| Colonne | Signification |
|---|---|
| Date, UTC | Date et heure UTC du début du QSO. |
| Indicatif | Le correspondant. |
| Bande, MHz, Mode | Bande, fréquence exacte et mode. |
| Env., Reçu | Reports envoyé et reçu. |
| Nom, QTH | Prénom et ville du correspondant. |
| DXCC, Préfixe | Pays du correspondant (d'après son indicatif) et son préfixe principal (ON pour la Belgique, LA pour la Norvège, K pour les USA…). |
| TX call | L'indicatif sous lequel le QSO a été fait (celui du club ou celui de l'opérateur). |
| OP | L'opérateur : indicatif personnel du membre qui a fait le QSO, même sous l'indicatif du club (au survol : le compte qui l'a enregistré s'il est différent). |
| Contest | Le contest pendant lequel le QSO a été fait (identifiant Cabrillo, par exemple CQ-WW-SSB), rempli par les pages TRX SSB, TRX CW et le contest RTTY ; au survol : échange envoyé et reçu. Le ▾ du titre filtre les QSO d'un contest. |
| LoTW, eQSL, CL, QRZ | État de l'envoi vers chaque service : **·** pas encore envoyé, **✓** envoyé, **✗** refusé (survol = détail), **★** confirmé sur LoTW. |

<a id="l-export"></a>
### 14.3 Exporter

| Menu Exporter ▾ | Ce qu'il fait |
|---|---|
| **Mes QSO (.adi)** | Télécharge tout de suite les QSO faits sous **votre** indicatif (TX call), à importer dans votre propre logiciel de carnet. |
| **ADIF (.adi)…** | Fenêtre de choix : TX call et plage de dates, puis téléchargement d'un fichier ADIF 3. Un membre exporte ses QSO (sous son indicatif, ou ceux qu'il a faits lui-même sous ON5VL / OR0L : « mes QSO sous cet indicatif ») ; les administrateurs exportent tous les TX call. |
| **Cabrillo (.log)…** | Même choix, plus le nom du concours : fichier Cabrillo 3 à envoyer aux organisateurs d'un concours. |

<a id="l-sync"></a>
### 14.4 Synchronisation (LoTW, eQSL, Club Log, QRZ)

Menu **Synchronisation ▾** : il envoie les QSO du carnet vers les sites de confirmation. Une fenêtre par service, comme dans Swisslog. Les **administrateurs** gèrent tous les indicatifs (club et membres). Chaque **membre** qui émet sous son propre indicatif s'en sert pour **ses** QSO (voir « Vos propres logs en ligne » ci-dessous).

1. Choisissez le service : **Synchronisation LoTW…**, **Synchronisation eQSL…**, **Club Log…** ou **QRZ…**.
2. Onglet **Détails** : choisissez l'**indicatif (TX call)** dont les QSO partent (le TX call en cours est proposé).
3. Juste en dessous, le cadre jaune **« Identifiants <service> de <indicatif> »** montre les identifiants qui seront utilisés : identifiant, mot de passe, clé… Une note dit s'ils sont propres à cet indicatif, s'ils viennent de la configuration du club, ou ce qui manque. Complétez-les si besoin, puis `Enregistrer pour cet indicatif`. Les mots de passe restent sur le serveur et ne sont jamais affichés : un champ laissé vide garde la valeur enregistrée, `✕` l'efface, `👁` montre ce que vous tapez.
4. Facultatif : **plage de dates**, **Renvoyer aussi les QSO déjà envoyés**, **Temporisation** (pause en secondes entre deux QSO, pour ne pas être bloqué par le site). Club Log : « Effacer le log ClubLog existant » remplace tout le log en ligne (à n'utiliser que si ce carnet est complet). Le nombre de QSO à envoyer s'affiche en bas.
5. `Télécharger` : l'envoi commence ; l'onglet **Traitement** montre la progression et le compte rendu, QSO par QSO. `Arrêt` l'interrompt ; `Fermer` ferme la fenêtre : l'envoi continue sur le serveur et sa progression reste affichée sous la liste du carnet.

- **Indicatifs du club et indicatifs personnels** : les identifiants de la configuration générale (14.5) ne servent qu'aux indicatifs du club (ON5VL, OR0L). Un indicatif personnel (ON6DP…) a besoin de **ses propres identifiants**, sinon ses QSO sont marqués « non configuré ». Un envoi qui mélange plusieurs TX call est fait groupe par groupe, chacun avec ses identifiants.
- **Vos propres logs en ligne (membres)** : dans la fenêtre, l'indicatif est le vôtre et ne peut pas être changé. Entrez **vos** identifiants (eQSL, Club Log, clé API QRZ, identifiant du site LoTW), puis `Enregistrer pour cet indicatif` : ils restent sur le serveur, ne sont jamais affichés, et personne d'autre ne peut s'en servir. Cochez **Envoyer automatiquement chaque nouveau QSO** pour que chaque QSO fait sous votre indicatif parte tout seul vers ce service (la case n'existe pas pour ON5VL / OR0L : l'envoi automatique du club se règle dans ⚙ Configuration ; un administrateur choisit son propre indicatif dans la liste pour la voir). Vos QSO ne partent jamais vers les comptes du club, et ceux du club jamais vers les vôtres. LoTW : `Exporter pour TQSL` (vos QSO), signez avec **votre** TQSL, puis `Marquer comme envoyés` ; `Confirmations` lit vos confirmations avec l'identifiant de votre compte LoTW.
- Un mot de passe refusé n'arrête que l'indicatif concerné (ceux du club et des autres membres continuent) ; corrigez-le puis enregistrez-le.
- **Opérations LoTW** : exporter, signer avec TQSL, envoyer, lire les confirmations, statut. `Confirmations` lit seulement les confirmations reçues (★ dans la liste). Avec le serveur sur le VPS (sans TQSL) : `Exporter pour TQSL (.adi)`, signez le fichier avec TQSL sur le PC du club, puis `Marquer comme envoyés`.

<a id="l-config"></a>
### 14.5 Configuration

**Synchronisation ▾ → ⚙ Configuration…** (administrateurs) : les réglages généraux, en onglets **CLUBLOG**, **eQSL**, **LoTW**, **QRZ** et **UDP**.

- Case **« Télécharger automatiquement les QSO lors de leur enregistrement »** : chaque nouveau QSO sous un indicatif du club part tout seul vers ce service.
- Identifiants et mots de passe du club (`👁` pour les voir pendant la saisie), temporisation, et `Tester` pour vérifier la connexion au service. La fenêtre n'affiche que « enregistré » pour les mots de passe ; laisser le champ vide garde la valeur, `✕` l'efface.
- Onglet **QRZ**, **Recherche des correspondants** : identifiant et mot de passe d'un compte QRZ.com. Dès qu'un correspondant est choisi (clic sur un indicatif, ligne Correspondant, fiche du carnet), son prénom, sa ville et, avec un abonnement XML, son locator sont remplis tout seuls (cases vides seulement), avec un rappel « QRZ.com : … » sous les bandes.
- Onglet **QRZ**, tableau **Indicatif / Clé API** (envoi au carnet QRZ) : une ligne par indicatif (TX call) avec sa clé API ; `+ Ajouter un indicatif` ajoute une ligne, `✕` retire la clé.
- Onglet **UDP** : envoi de chaque QSO aux logiciels de carnet. Une ligne par destination : case **Actif**, **Nom**, **Adresse**, **Port**, **Format** (WSJT-X « Logged ADIF », WSJT-X « QSO Logged », N1MM Logger+, ADIF brut) ; les boutons `+ WSJT-X (port 2237)`, `+ N1MM Logger+ (port 12060)` et `+ ADIF brut` ajoutent une ligne déjà remplie (adresse 127.0.0.1) ; `✕` la retire.

| Service | À préparer |
|---|---|
| Club Log | E-mail du compte, mot de passe d'application (Club Log → Settings → App Passwords), clé API de l'application (demandée une fois au helpdesk Club Log). Un refus d'accès arrête les envois jusqu'au prochain test réussi. |
| eQSL | Indicatif et mot de passe eQSL ; « QTH Nickname » si le compte a plusieurs QTH. |
| QRZ.com | Une clé API du carnet QRZ par indicatif (QRZ → Logbook → Settings), abonnement XML ou supérieur. |
| LoTW | **TQSL** et le **certificat** de l'indicatif installés sur le PC où tourne le serveur, le nom du « Station Location » de TQSL, et l'identifiant du site LoTW pour les confirmations. Le certificat et son mot de passe ne quittent jamais ce PC. |
| UDP | Adresse, port et format attendus par le logiciel : WSJT-X « Logged ADIF » (Swisslog, Log4OM, HRD Logbook ; port 2237 en général), N1MM (port 12060), ou ADIF brut. Les paquets partent du serveur : 127.0.0.1 si le serveur tourne sur le PC du club. |

<a id="clavier"></a>
## 15. Raccourcis clavier

| Touche | Action |
|---|---|
| `Espace` (maintenir) | PTT ; en FT8 / FT4 / FT2, arrête l'émission automatique. Fonctionne aussi depuis une fenêtre séparée. |
| `W` (maintenir) | TXW : écoute de la fréquence d'émission (SPLIT). |
| `↑` `↓` | Fréquence ± un pas (celui de la ligne Step). |
| `F1` … `F12` | Macros dans les onglets RTTY et CW (`F1`…`F8` en JTTY). |
| `Ctrl` + `Entrée` / `Entrée` | Émettre le texte tapé en RTTY et en CW / en JTTY. |
| `Échap` | Arrêter l'émission RTTY, JTTY ou CW en cours. |
| `Entrée` (fiche du carnet) | Enregistrer le QSO. |
| `Maj` + molette | Sur la valeur RIT / XIT : décalage par pas de 100 Hz. Sur la cascade RTTY : VFO ± 10 Hz par cran. |
| `Échap` (menus) | Ferme le menu ouvert : Opérateurs, TRX du club, DX Cluster, taille du dashboard. |
| `Entrée` (discussion) | Envoie le message aux connectés. |
| `Ctrl` + `F5` | Recharger la page après une mise à jour. |

Ces touches sont ignorées pendant que vous tapez dans un champ de texte.

<a id="problemes"></a>
## 16. Problèmes fréquents

| Symptôme | Cause probable et solution |
|---|---|
| Affichage bizarre, bouton qui ne réagit pas après une mise à jour | Ancienne version en mémoire : `Ctrl` + `F5`. |
| « Ce navigateur n'est ni Chrome ni Edge » | Ouvrez la page dans Google Chrome ou Microsoft Edge. |
| Voyant Serveur rouge | Votre connexion internet est coupée ; la page se reconnecte toute seule quand elle revient. |
| « Station hors ligne » | La page Station du PC du club est fermée ou le PC n'a plus internet : prévenez un responsable du club. |
| Pas de son, cascade vide, « La page Station n'envoie pas la BF » | Au club, la page Station doit avoir l'audio activé et la bonne entrée son (section 18). Chez vous, vérifiez le volume du PC et le curseur Volume. |
| Commandes grisées, « Prenez la main… » | Vous n'avez pas la main : `Prendre la main` ou `Demander la main`. |
| Rien n'est décodé en FT8 / RTTY… | Vérifiez le mode du TRX (DATA-U ; CW en CW), la fréquence (bouton ↺), le SQUELCH à 0, et DUAL RX coupé. L'onglet Synchro montre si la BF arrive. |
| Ma réponse FT8 part une période trop tard | Le clic est arrivé trop tard (après 2 s dans la période suivante). Cliquez dès que le décodage s'affiche. Si cela arrive souvent, regardez la case « Décodages » de l'onglet Synchro. |
| PTT refusé | Le message indique la raison : hors bande autorisée, ROS (faire TUNE), émission non autorisée, indicatif d'écouteur, durée maximale, TXW enfoncé… |
| Le badge TX est rouge alors que je n'émets pas | Normal : rouge foncé = VFO d'émission. L'émission réelle se voit aux chiffres de la fréquence en rouge et au badge TX rouge vif. |
| Clic sur ATT / IPO de l'autre VFO : le TRX change de côté un instant | Normal sur le FTX-1 : ces réglages ne se font que sur le côté actif ; le TRX y passe 2 à 3 s, sans émettre, puis revient. |
| « TUNE sans accord », émission bloquée sur la bande | L'antenne ne s'accorde pas sur cette fréquence : refaites un TUNE, essayez l'autre antenne ou une autre bande, et prévenez un responsable. |
| Une fenêtre séparée ne s'ouvre pas | Autorisez les fenêtres pop-up pour remote.op0p.be (icône à droite de la barre d'adresse). |
| Nom et QTH pas remplis | Le compte QRZ.com n'est pas réglé, ou la station n'est pas sur QRZ.com : tapez-les à la main. |
| Synchronisation : « non configuré » | Pas d'identifiants pour ce TX call : complétez le cadre « Identifiants … » de la fenêtre de synchronisation (14.4). |
| « Passage MAIN ↔ SUB refusé en réception simple » | Normal sur le FTX-1 : en réception simple, un passage sur SUB par le dashboard l'a mis en émission (constaté au club). En HF, il n'écoute qu'un côté à la fois : pour écouter la fréquence du VFO B, `A ⇄ B`. Le VFO B se règle quand même (molette, flèches, bandes). |
| Plus de son, cascade muette (seulement un ronflement tout à gauche), alerte « Plus de son du TRX » | La carte son USB du TRX s'est figée. Un responsable clique `Relancer la carte son` (alerte du dashboard ou menu du TRX) ; si cela ne suffit pas, éteindre et rallumer le TRX au club (section 18). |
| BW grisé, « NARROW ✕ » à la place de la largeur | NARROW est enclenché de ce côté : clic sur `NARROW ✕` ou sur le badge NAR de l'écran VFO. |
| Un badge (NB, ATT…) revient tout seul à son état d'avant | Le TRX a refusé le réglage (sans effet dans ce mode, ou côté inactif) : lisez le message sous les bandes. |
| <-> DX Cluster en orange | Le cluster est ouvert, mais vous n'avez pas la main : prenez la main pour que ses spots calent le TRX. |
| « Passage MAIN ↔ SUB par le dashboard désactivé » | Un administrateur a mis `ftx1SubCat` à `false` dans `config.json` : MAIN / SUB sur la face avant seulement. |

<a id="admin"></a>
## 17. Pour les administrateurs

Un clic sur le voyant `● Station` ouvre le menu **TRX du club** :

| Commande | Ce qu'elle fait |
|---|---|
| Nom d'un TRX (FTX-1, FTDX10, FTDX101D / MP, IC-7300) | Passe sur ce TRX, après confirmation. La station redémarre quelques secondes et la main est conservée. Le TRX doit être branché au PC du club et son port choisi une fois sur la page Station. Impossible pendant une émission. |
| `↻ Recharger la page Station` | Recharge à distance la page Station du PC du club (nouvelle version, page bloquée…). La station revient en une dizaine de secondes. |
| `🔊 Relancer la carte son du TRX` | Seulement pour ON6DP et ON4LUC (`stationEditors`). Redémarre la carte son USB du TRX sur le PC du club, quand la BF ne passe plus (section 18). Confirmation demandée ; refusé pendant une émission. Le résultat s'affiche sous les bandes (« Carte son du TRX : … redémarré ; audio relancé »). |
| `⌨ Lecture CAT…` | Diagnostic : lit une valeur brute du TRX (lecture seulement, liste de commandes autorisées). Plusieurs lectures sur une ligne (« VS;FT;ST; ») ; `Effacer` vide la fenêtre. |

Les administrateurs ont aussi accès au menu Synchronisation du carnet (14.4 et 14.5), à l'export de tous les TX call, et peuvent reprendre la main (section 6). Ils peuvent enregistrer le **réglage du club** de l'égaliseur du TRX (bouton `Equalizer TRX`) et ouvrir la page des **statistiques** (bouton 📊 STATS). La gestion des membres, des mots de passe et du serveur est décrite dans le **Guide des administrateurs** (`GUIDE-ADMINISTRATEUR.md`, dépôt du projet).

<a id="club"></a>
## 18. Le PC du club (page Station)

Pour les responsables du club. Le PC relié au TRX ouvre **https://remote.op0p.be/station** dans Chrome (Web Serial). Sous Windows 10 / 11, l'installateur **RemoteStation-Setup** fait le nécessaire : raccourci « Remote Station - Page Station » (Chrome avec les bons réglages), lancement au démarrage de Windows, pas de mise en veille ; il peut aussi installer le serveur lui-même sur ce PC (voir LISEZMOI-WINDOWS).

La page Station est **réservée aux administrateurs** : à la première ouverture sur un PC, connectez-vous avec l'indicatif et le mot de passe d'un administrateur. Ce PC reste autorisé un an (renouvelé à chaque ouverture), jusqu'à « Se déconnecter ». Un membre non administrateur est refusé. Le navigateur du PC du club, qui garde le jeton de la station, se reconnecte aussi tout seul.

🔒 Les champs **Jeton de la station**, **Vitesse (bps)** et **Bits de stop** sont **verrouillés**, pour éviter une fausse manœuvre. Seuls **ON6DP** et **ON4LUC**, connectés à la page Station avec leur indicatif et leur mot de passe, peuvent les modifier : « Se déconnecter » en haut de la page, puis se reconnecter avec cet indicatif. La liste se règle dans `config.json` (`stationEditors`). Le choix du modèle, du port, de l'audio reste libre.

**FTDX101D / MP** : son USB en stéréo (récepteur MAIN à gauche, SUB à droite). En double réception (DUAL RX), la page Station envoie les deux voies : en RTTY, le décodeur B lit le récepteur SUB, avec sa propre cascade à droite de celle de A ; l'écoute reçoit le mélange des deux, comme au casque. En réception simple, une seule cascade, comme sur les autres TRX.

1. Le **jeton de la station** est repris tout seul du serveur dès qu'un administrateur est connecté à la page (rien à recopier). Choisir le **modèle** du TRX et son **port CAT** (la première fois). FTDX10 et FTDX101 : **CAT RTS** sur OFF dans le menu du TRX (sinon la liaison tombe toutes les 2 s). FTX-1 : l'**Enhanced COM Port** (CAT-1), et sur le TRX les réglages **RPTT SELECT** et **PC KEYING** sur OFF (réglage d'usine) : l'émission se commande par CAT.
2. **Activer l'audio** et choisir l'entrée son du TRX (« USB Audio CODEC » ou « USB Audio Device » selon le TRX) ; la barre de niveau doit bouger. Choisissez la carte elle-même, pas « Par défaut - … » ni « Communications - … » : ces entrées de Windows changent de carte quand un autre TRX est branché (la page les remplace d'ailleurs toute seule par la carte réelle).
3. **Sortie son vers le TRX** (émission FT8 / FT4 / FT2, RTTY, JTTY) : la carte son USB du TRX (« Haut-parleurs (USB Audio CODEC) »…), choisie toute seule si possible. Jamais les haut-parleurs du PC. Le TRX doit prendre la modulation DATA sur l'USB (menu du TRX). Régler le **niveau d'émission** pour que l'ALC reste faible. Limiteur facultatif : avec `"digiAlcMax": 8` dans `config.json`, la page Station **baisse toute seule** ce niveau dès que l'ALC dépasse 8 % en émission numérique, et garde le niveau atteint pour les émissions suivantes ; il ne remonte jamais tout seul. Par défaut (`0`), pas de limiteur. L'émission part à l'heure du serveur, même si l'horloge de Windows est décalée.
4. Garder la page Station **seule dans sa fenêtre** ; ouvrir le dashboard avec son bouton « Ouvrir le dashboard dans une autre fenêtre ».
5. Chrome → Paramètres → Performances : garder remote.op0p.be toujours actif ; Windows : mise en veille sur Jamais.

**Deux TRX (ou plus) branchés au même PC**, chacun sur son port USB : sélectionnez une fois chaque modèle sur la page Station, choisissez son port CAT et sa carte son (entrée et sortie). La page les retient **par modèle**. Ensuite, un administrateur passe de l'un à l'autre depuis le menu **STATION** du dashboard (section 17) : la page Station redémarre avec l'autre TRX, rouvre son port et sa carte son, en quelques secondes. Jamais pendant une émission.

### Les commandes de la page Station

| Commande / affichage | Ce qu'elle fait |
|---|---|
| Administrateur : … `Se déconnecter` | Indicatif connecté à la page. Se déconnecter (après confirmation) ferme la page Station : la station passe hors ligne jusqu'à la prochaine connexion d'un administrateur. |
| `Ouvrir le dashboard dans une autre fenêtre` | Pour piloter depuis le PC du club sans toucher à l'onglet Station (taper une autre adresse dans cet onglet coupe la station). |
| Voyant **Serveur** | Liaison avec remote.op0p.be ; en cas de coupure, nouvel essai après 1, 2, 4 puis toutes les 5 s. « Remplacée par une autre page Station » : une autre page a pris le relais, celle-ci se met en retrait (« Enregistrer et reconnecter » pour reprendre ici). |
| Voyant **TRX** et ligne de lecture | Port CAT ouvert, TRX qui répond ; fréquence, mode et état relus. |
| `Choisir le port du TRX` | Liste des ports série de Chrome ; choisir celui du TRX (FTX-1 : Enhanced COM Port). Le port est retenu **pour chaque modèle**, d'après l'identité USB du câble (fabricant, produit, rang) : en changeant de TRX à distance, la page retrouve le bon port même si Windows a renuméroté les ports COM. |
| `Libérer le port` | Ferme le port CAT (le TRX n'est plus piloté) et oublie le choix automatique au prochain chargement. |
| `Port de manipulation CW (DTR)…` (FTX-1) | Choisir une fois le **2e port USB** du TRX (« Standard COM Port », pas celui du CAT). La page manipule alors elle-même la CW par la ligne DTR de ce port, au rythme exact des points et des traits, au lieu de passer par la mémoire du manipulateur du TRX. Pendant chaque émission CW, le menu PC KEYING du TRX est mis sur DTR (et RPTT SELECT sur OFF), puis remis sur OFF à la fin. Le port est retenu et rouvert tout seul ; `Ne plus manipuler par DTR` revient à la mémoire du manipulateur. |
| `Tester sans radio (simulation)` | TRX virtuel pour essayer la page et le dashboard sans émettre. |
| **Entrée son** | Carte son du TRX (section ci-dessus). Les alias « Par défaut » et « Communications » sont remplacés par la carte réelle. L'entrée et la sortie son sont retenues **pour chaque modèle** de TRX, comme le port. |
| **Sortie son vers le TRX** + **Niveau d'émission** | Carte son qui reçoit le signal des émissions numériques, et son niveau (1 à 100 %) : réglez-le pour que l'ALC reste faible. « — aucune — » : pas d'émission numérique. |
| **Niveau phonie à distance** | Niveau de la voix des opérateurs (phonie à distance) envoyée par la même sortie son : réglez-le en SSB pour que l'ALC bouge à peine. Le menu « source de modulation » du TRX est mis sur USB tout seul pendant leurs émissions, puis remis (micro du club). |
| Barre de niveau, état de l'audio | La barre bouge avec le son du TRX ; « Audio envoyé aux membres à l'écoute » ou « Audio prêt (personne n'écoute…) ». En orange : « Entrée son muette… » (carte son figée). |
| `Activer l'audio` / `Arrêter l'audio` | Démarre ou arrête la capture du son ; retenu et relancé tout seul au rechargement de la page. |
| `Relancer la carte son du TRX` | Redémarre la carte son USB du TRX par l'assistant (ci-dessous), puis relance l'audio. Grisé si l'assistant n'est pas installé. |
| « Assistant carte son : … » | En marche, ou non installé (avec le lien **Télécharger l'assistant carte son**). Vérifié toutes les minutes. |
| **Modèle du TRX** | FTX-1, FTDX10, FTDX101D / MP ou IC-7300 ; les administrateurs le changent aussi à distance (section 17). |
| **Jeton de la station**, **Vitesse (bps)**, **Bits de stop** | 🔒 Modifiables seulement par ON6DP et ON4LUC. La vitesse et les bits de stop doivent être ceux du menu CAT du TRX (38400 bps et 1 bit de stop par défaut). |
| `Enregistrer et reconnecter` | Garde les réglages dans ce navigateur et relance la liaison. |
| **Journal** | Tout ce qui se passe : liaison, port, TRX, audio, émissions, relances de la carte son, demandes à distance (rechargement, changement de TRX…). |

### Carte son du TRX figée (plus de BF)

Il arrive que la carte son USB intégrée au TRX se fige en silence : barre de niveau vide sur la page Station, cascade muette (seulement un ronflement tout à gauche), plus rien à l'écoute. Après 45 s de silence avec le TRX connecté, la page Station l'indique en orange, et le dashboard aussi (sous « Écouter le TRX », avec un message aux responsables et à celui qui a la main).

- **Relancer la carte son du TRX** : bouton de la page Station, ou, pour ON6DP et ON4LUC, bouton « Relancer la carte son » de l'alerte du dashboard et menu du TRX (clic sur le voyant de la station). La carte son USB est redémarrée sur le PC du club, comme « Désactiver / Activer » dans le Gestionnaire de périphériques ; le son est coupé une dizaine de secondes, le TRX reste allumé, le port CAT n'est pas touché. Refusé pendant une émission.
- Il faut, une fois, installer sur le PC du club l'**assistant carte son** : lien « Télécharger l'assistant carte son » de la page Station (s'il n'est pas encore installé), décompresser, double-clic sur `installer-carte-son.cmd` et accepter la demande d'administrateur. Il démarre avec Windows, n'écoute que sur le PC lui-même (127.0.0.1:18099) et n'obéit qu'à la page Station de remote.op0p.be. La première fois, Chrome peut demander l'accès aux « appareils du réseau local » : Autoriser. La page Station indique « Assistant carte son : en marche ».
- **Relance automatique** : si l'assistant est installé, la page Station relance seule la carte son après 45 s de silence (TRX en réception, jamais pendant une émission), une fois toutes les 10 minutes au plus ; le résultat s'affiche comme pour une relance à la main.
- **Assistant version 2** : à chaque démarrage de Windows, il coupe aussi la **mise en veille USB** (suspension sélective USB du mode d'alimentation, et « Autoriser l'ordinateur à éteindre ce périphérique » sur les concentrateurs USB et les cartes son USB), cause fréquente d'une carte son figée. La page Station indique la version et l'état de la veille USB ; avec la version 1, elle propose de retélécharger l'assistant : refaire une fois `installer-carte-son.cmd`.
- **Assistant version 3** (0.37.175) : quand Windows met la carte son du TRX **en erreur** (« Périphérique USB composite » en erreur, « USB Audio CODEC » disparu du Gestionnaire de périphériques), un simple redémarrage ne suffit pas : l'assistant la **retire et la fait redétecter** (comme « Désinstaller » puis « Rechercher les modifications sur le matériel »). Il **surveille lui-même** cette carte son toutes les 20 s, même page Station fermée, et la répare seul (au plus une fois toutes les 5 min). La ligne « Assistant carte son » de la page Station donne l'état de la carte son du TRX et la dernière réparation. Pour passer en version 3 : retélécharger l'assistant et refaire une fois `installer-carte-son.cmd`.
- **Assistant version 4** (0.37.187) : met aussi l'**horloge de Windows** à l'heure à la milliseconde, comme NetTime (service Windows Time réglé sur be.pool.ntp.org, europe.pool.ntp.org et time.cloudflare.com, interrogés toutes les 1 à 4 minutes), au démarrage, toutes les heures, et à la demande (onglet Synchro, `⟳ Mettre à l'heure`). La ligne « Assistant carte son » de la page Station donne l'écart mesuré. Désinstallez NetTime du PC du club pour éviter deux réglages concurrents.
- **Jamais une autre carte son à la place de celle du TRX** : si la carte son du TRX a disparu de Windows, la page Station ne prend plus le son du PC (« Mixage stéréo », haut-parleurs Realtek…) à sa place ; elle affiche l'alerte « Carte son du TRX absente », demande la réparation à l'assistant et repart seule dès que la carte revient. Une sortie son vers le TRX qui disparaît est fermée (émission numérique refusée) au lieu de partir dans les haut-parleurs du PC. Choisir à la main une carte son du PC affiche un avertissement.
- Si la relance ne suffit pas : éteindre et rallumer le TRX (le FTX-1 ne peut pas être rallumé par CAT).

Installation et réglages du serveur : voir le **Guide des administrateurs**, `GUIDE-ADMINISTRATEUR.md` (dépôt du projet).
