<!-- Fichier produit par native/manual2md.js à partir de public/help.html : modifier la page HTML, puis relancer le script. -->

# Remote Station UBA-LGE — user manual

*Online version: **HELP** button on the dashboard or https://remote.op0p.be/help — [version française](MANUEL.md)*

- [1. Before you start](#intro)
- [2. Short glossary](#lexique)
- [3. Logging in](#connexion)
- [4. Guided first steps](#premiers)
   - [4.1 Listening to a band](#p-ecoute)
   - [4.2 A phone QSO (SSB) with your own microphone](#p-phonie)
   - [4.3 An FT8 QSO](#p-ft8)
   - [4.4 Logging the QSO](#p-log)
- [5. The screen at a glance](#ecran)
- [6. Taking and handing over control](#main)
- [7. Operating the TRX](#trx)
   - [7.1 The VFO displays](#vfo)
   - [7.2 Step row and bands](#step)
   - [7.3 Left column](#gauche)
   - [7.4 Right column](#droite)
   - [7.5 Operating SPLIT](#split)
- [8. Listening](#ecoute)
- [9. Transmitting and safety](#emission)
   - [9.1 Phone and contests: TRX SSB](#ssbcontest)
- [10. Operators and chat](#operateurs)
- [11. Layout and separate windows](#disposition)
   - [11.1 FTDX101 front panel](#face)
- [12. Digital modes](#numeriques)
   - [12.1 FT8 · FT4 · FT2](#ft8)
   - [12.2 JT65](#jt65)
   - [12.3 RTTY](#rtty)
   - [12.4 WSPR](#wspr)
   - [12.5 JTTY](#jtty)
   - [12.6 CW](#cw)
   - [12.7 SSTV](#sstv)
   - [12.8 Synchro](#synchro)
   - [12.9 QO-100](#qo100)
- [13. Correspondent, macros and tags](#messages)
- [14. Logbooks (station logbook)](#logs)
   - [14.1 Logging a QSO](#l-fiche)
   - [14.2 The QSO list](#l-liste)
   - [14.3 Exporting](#l-export)
   - [14.4 Synchronisation (LoTW, eQSL, Club Log, QRZ)](#l-sync)
   - [14.5 Configuration](#l-config)
- [15. Keyboard shortcuts](#clavier)
- [16. Common problems](#problemes)
- [17. For administrators](#admin)
- [18. The club PC (Station page)](#club)

> [!NOTE]
> The dashboard runs in **Google Chrome** or **Microsoft Edge**, on a PC, Mac, tablet or phone. It is designed for a **1920 × 1080** screen or larger; on a smaller screen, the panels stack one below the other. The interface is in French: button and field names are quoted below as they appear on screen, with an English translation. After a server update, press `Ctrl` + `F5` to reload the page.

<a id="intro"></a>
## 1. Before you start

The **Remote Station** lets members of the UBA-LGE section use the **club transceiver (TRX)** from home, with nothing more than a web browser. The TRX (a Yaesu FTX-1 with its SPA-1 amplifier, or depending on the setup an FTDX10, an FTDX101D / MP or an IC-7300) is at the club, connected to a PC. That PC is linked over the internet to the server **remote.op0p.be**, and that server is what you open in your browser.

1. You click a button on the dashboard (for example "20M").
2. The server passes the command on to the club PC.
3. The club PC sends the command to the TRX over its USB cable (the "CAT link").
4. The TRX changes band, and every connected member sees the new frequency.

The receiver audio travels the other way: it arrives in your browser, and the digital modes (FT8, RTTY, CW…) are decoded on the server.

> [!TIP]
> **The golden rules**
> - **Only one person operates** the TRX at a time: the one who "has control". Everybody else watches and listens.
> - **Everything you set acts on the real club TRX**, for everybody. If you are not sure about a setting, leave it as it is.
> - After a band change, always do a `TUNE` before transmitting (antenna tuning).
> - Respect your licence: authorised bands and power. The server checks this anyway.
> - When you leave, **release control** and switch SPLIT off if you used it.

<a id="lexique"></a>
## 2. Short glossary

Words that come up often in this manual and on the screen.

| Word | Meaning |
|---|---|
| TRX | Transceiver: the club's transmitter-receiver. |
| Having control (« avoir la main ») | Being the operator who is driving the TRX right now. Without control you can watch and listen, but not change settings or transmit. |
| VFO | The "tuning knob" of the TRX. There are two, **A** and **B** (on the FTX-1: **MAIN** and **SUB**), each with its own frequency and mode. |
| MAIN / SUB | The two receivers of the FTX-1. MAIN corresponds to VFO A, SUB to VFO B. The "active side" is the one you listen to and adjust. |
| PTT | Push To Talk: the button that keys the TRX into transmit for as long as you hold it. |
| CAT | The USB cable link between the club PC and the TRX, used to control it. |
| BF (AF) | Audio frequency ("basse fréquence" in French): the sound coming out of the receiver (what you hear, and what the decoder analyses). |
| Mode | The way of transmitting: **LSB / USB** (SSB, phone on HF), **CW** (Morse), **AM**, **FM**, **DATA-U** (digital modes through the TRX sound card), **RTTY**… |
| SSB (BLU) | Single sideband ("BLU" in French): phone on HF. LSB below 10 MHz, USB above. |
| Band | A frequency range: 80 m, 40 m, 20 m… (the smaller the number, the higher the frequency). |
| SWR (ROS) | Standing wave ratio ("ROS" in French): shows whether the antenna is properly matched. 1.0 is perfect, up to 1.5 is very good, above 2.5 transmission is cut. |
| TUNE / tuner | The tuner (antenna tuning unit) matches the antenna to the frequency. TUNE starts the tuning: the TRX sends a carrier for a few seconds. |
| ALC | Indicator showing whether the transmitter is being "driven" too hard. In digital modes, ALC must stay very low. |
| S-meter | Shows the strength of the received signal, from S1 (very weak) to S9, then S9+10, +20… dB (very strong). |
| Filter / BW | Width of the listening "window". Narrower = less noise and fewer neighbouring stations, but you must be tuned accurately. |
| SPLIT | Listening on one frequency and transmitting on another (for DX expeditions). |
| RIT / XIT | A small offset of the receive frequency (RIT) or transmit frequency (XIT), without touching the VFO. |
| Waterfall (« cascade ») | The scrolling picture in the digital-mode tabs: each coloured trace is a signal; the brighter or redder it is, the stronger. |
| QSO | A radio contact between two stations. |
| Correspondent (« Correspondant ») | The station you are making the QSO with (DX for short). |
| Report / RST | The signal report exchanged: **59** or **599** in phone / CW / RTTY, a number of **dB** (−15, +03…) in FT8. |
| Locator | Position as a Maidenhead grid square (e.g. JO20 for the Liège area). |
| TX call | The callsign under which digital transmissions go out and under which the QSO is logged: the club's (ON5VL, OR0L) or your own. |
| UTC | Universal time, used in radio (Belgian time − 1 h in winter, − 2 h in summer). |
| ADIF | Standard file format for exchanging QSOs between logging programs (.adi). |
| LoTW, eQSL, Club Log, QRZ | Websites to which you upload your QSOs to get confirmations (electronic QSLs) and awards. |
| DXCC | The official list of amateur-radio "countries" (entities). The prefix (ON, F, DL…) tells you the country of a callsign. |

<a id="connexion"></a>
## 3. Logging in

1. Open [https://remote.op0p.be](https://remote.op0p.be) in Chrome or Edge.
2. Enter **your callsign** and **your password** (given by a club administrator), then click `Se connecter` (log in).
3. The browser stays logged in for **7 days**: when you reload the page, you go straight back to the dashboard.
4. `Déconnexion` (log out, top right) ends the session and forgets the browser: do this on a PC that is not yours.

- **Listener** callsigns (ONL…) can see and hear everything, but cannot transmit or change the power.
- After **15 minutes without any action**, you are logged out. A warning appears one minute before, with a `Rester connecté` (stay logged in) button. This never happens during a transmission.
- The `HELP` button at the top right opens this manual in a new tab.

<a id="premiers"></a>
## 4. Guided first steps

Four "recipes" to get started. Each button is described in detail further on (sections 7 to 14).

<a id="p-ecoute"></a>
### 4.1 Listening to a band

1. On the right, **RX audio** panel: click `🔊 Écouter le TRX` (listen to the TRX). Set the **Volume** slider just below (it only affects you).
2. To change band or frequency you must **have control**: click `Prendre la main` (take control) at the top (if nobody has it).
3. Click a band, for example `40M`, in the band row below the VFOs.
4. Choose the mode in the **Mode** panel on the left: `LSB` for phone on 40 m, `USB` on 20 m and above.
5. Tune the frequency: put the mouse over the digits of **VFO A** and use the **mouse wheel**. Each digit is set separately; the digit under the mouse goes up or down.
6. A station too strong? Lower the **RF GAIN** (RF front end panel) or switch `ATT` on. Lots of noise? Try `DNR` (noise reduction).

<a id="p-phonie"></a>
### 4.2 A phone QSO (SSB) with your own microphone

Your microphone (PC microphone, headset, USB microphone…) is sent to the TRX while you hold PTT: this is **remote phone**. It works in **LSB / USB** (and AM / FM on the FTX-1 and IC-7300). A headset gives the best result (no feedback, voice close to the microphone).

1. Take control, choose the band and LSB or USB. Afterwards, at each band change, the dashboard automatically sets **LSB below 10 MHz** and **USB above** (USB on 60 m); DATA, CW, AM and FM are left alone.
2. Open the **TRX SSB** page (`SSB` tab of the dashboard MODES row, or the front-panel SSB button); **SSB configuration** line: click `Configuration micro` (MICRO). The first time, Chrome asks for microphone access: **Allow**. Pick your microphone in the list if there are several.
3. The dashboard **recognises the type of microphone** from its name (headset, USB studio microphone, webcam, Bluetooth, built-in PC microphone…) and proposes a matching equaliser setting. Speak: the level bar must stay in the **green**, never in the red (**SAT**).
4. `Equalizer micro`: low cut, three adjustable bands (frequency, level, width), high cut, microphone gain, noise reduction. Listen to yourself **on headphones** with `🎧 M’écouter` (**Volume** slider just below), then `Enregistrer pour ce micro`: these settings come back automatically whenever you use this microphone, on any PC.
5. **Accord** panel: `TUNE`, then check the **SWR** and the **power**.
6. Make sure the frequency is clear, then hold `PTT` (or the `Space` bar) and **speak when the TX lamp turns red** (about half a second on the first press, immediately on the following ones). Release to listen: while you speak, the TRX audio is muted on your side.

> [!NOTE]
> At the club, the Station page switches the TRX “modulation source” menu to USB just before your transmission, and puts it back 20 s after your last transmission or as soon as you release control: the club microphone works again. The level of your voice at the TRX input is set on the Station page (“Niveau phonie à distance”): the ALC should barely move.

**TRX equaliser** (FTX-1, FTDX10, FTDX101): `Equalizer TRX` button in the same panel. These are the TRX's own PRMTRC EQ1 to EQ3 menus (PROC off, then PROC on). Take control, `Lire le TRX`, adjust, `Essayer sur le TRX`, then `Enregistrer mon profil`: your profile is put on the TRX whenever you take control, and the club setting is restored when you release it. Administrators can save the club setting.

<a id="p-ft8"></a>
### 4.3 An FT8 QSO

FT8 is the easiest mode to use remotely: everything is done with the mouse and the dashboard handles the sequence just like WSJT-X.

1. Take control. In the **QSO** line at the bottom, choose the **TX call**: the club callsign (ON5VL) or your own.
2. `FT8 · FT4 · FT2` tab in the centre, `FT8` button, then choose a band in the frequency list (e.g. "14.074 · 20m"). The TRX goes there by itself, in DATA-U.
3. Do a `TUNE` (Accord panel), then set a reasonable power (20 to 40 W is plenty for FT8).
4. Wait one or two 15 s periods: the stations heard appear in **Activité de bande** (band activity). **CQ** calls are in green.
5. **To answer a CQ**: click the station's **callsign** (dotted underline) or double-click its line. The TRX sends your call at the start of the next period.
6. Let it run: the **sequence advances by itself** (report, R-report, RR73, 73). The bar below the lists is red while transmitting, green while receiving.
7. As soon as the correspondent sends RR73, the **« Enregistrer le QSO »** (log the QSO) form opens already filled in: check it and save.
8. To call CQ yourself: click `Tx6` (CQ). Tick **Répondre au 1er** (answer the first) so that the first station to answer is taken automatically.
9. To stop everything: `■ Arrêter` (stop) (or the `Space` bar).

<a id="p-log"></a>
### 4.4 Logging the QSO

1. After a digital QSO, the form opens by itself (FT8) or with the `Log QSO` button (RTTY, JTTY, CW; also on the tab row, right of Logbooks).
2. For a phone QSO: `LOGS` tab, type the callsign (the UTC time fills in by itself), click `⇩ TRX` (take from the TRX) to copy the frequency and mode, then complete the reports.
3. `Enregistrer le QSO` (save the QSO) (or `Enter`). The QSO appears in the list. Under the club callsign, it is also uploaded to the online logbooks if the administrators have set that up.
4. To get your QSOs into your own logging program: **Exporter ▾ → Mes QSO (.adi)** (Export → My QSOs).

<a id="ecran"></a>
## 5. The screen at a glance

### Top bar

| Item | What it is | What it does |
|---|---|---|
| `● Serveur` | Link lamp between your browser and the server. | Green = connected. Red or grey: check your internet connection; the page reconnects by itself. |
| `● Station` | Lamp of the Station page on the club PC. | Green = the club PC is online. For administrators, a click opens the TRX menu (section 17). |
| `● FTDX5000` | The transceiver in use (FTX-1, FTDX10, FTDX101D / MP, FTDX5000, IC-7300 or IC-7760). The list of transceivers is in the **Station** menu (administrators). | Green = the TRX answers over CAT; red = the TRX is transmitting. |
| Title in the centre | Callsign and name of the station. | — |
| `👥 n` | Number of members online. | Opens the **Opérateurs** (operators) panel: who is there, who has control, chat (section 10). A red dot means a new message. |
| Your callsign | The account you are logged in with. | — |
| GMT date and time (under "Remote Station UBA-LGE") | UTC date and time, as used in the log, to the second. | — |
| `Prendre la main` / `Libérer la main` | Large control button (take control / release control), coloured by state: gently pulsing **green** = control is free; **orange** = you have control; **amber** (administrator) = « Reprendre la main » (take control back) from whoever has it; **grey** = another member has control. | You become the operator, or you give control back (section 6). |
| `DX Cluster ▾` | Links the TRX to one of the club's DX clusters (top bar, between « Prendre la main » and the size menu). | Click: choose **dx.op0p.be** (Ultimate Cluster) or **cluster.op0p.be** (CC-Cluster OP0P), opened in its own window (put it on the 2nd screen); if already open, its window comes to the front. DX CLUSTER in green = a cluster in this browser is connected (« ● relié » in the menu with control; without control « ● ouvert, prenez la main »: its spots tune the TRX only with control); yellow = no cluster open. One way only: the link is opened from the dashboard (logged-in member); from the cluster page nothing opens or drives the dashboard on its own. |
| `DX Cluster ▾` menu: « Vos spots… votre cluster telnet » | Below the two web clusters, the list of telnet clusters (as in VE7CC's CC Cluster). Each member picks **their own** cluster for **their own** spots (band map, mode pages); green ● = the one in use. The server keeps the choice for your callsign. | Default: the club cluster (OP0P). Spots you send always go to the club cluster. |
| Click on a spot of dx.op0p.be / cluster.op0p.be | The TRX tunes to the station. | Open the cluster in another window (2nd screen) **of the same browser** as the dashboard. Click a spot: FT8 / FT4 / FT2, JT65, JTTY, WSPR → the mode's tab opens, VFO A goes to the calling frequency and receive onto the signal; RTTY → RTTY tab, transmit decoder on the signal; CW → CW tab, VFO on the station (CW-L below 10 MHz, CW-U above); phone (SSB, AM, FM) → chosen VFO (A or B) and mode (LSB below 10 MHz, USB above). The callsign goes into Correspondant. You must have control; refused while transmitting. The cluster site must be allowed (`qsyOrigins` in config.json) and served over https. A **Remote Station DX Cluster** badge (shown only to members already logged in to the dashboard in this browser), at the top of the Alert / Show Only / Hide column on dx.op0p.be, bottom right elsewhere (or inside an element `id="rs-qsy-badge"` of the page): DX CLUSTER in green = dashboard open with control, **orange** = dashboard open without control, red = no dashboard; after a click it says « TRX calé sur le spot » (TRX tuned) or what is missing. |
| `Auto 100 %` | Dashboard size. | **Auto** (recommended): the dashboard is designed for a 1920 × 1080 screen; on a larger screen it is enlarged in the same proportion to fill the screen, without moving anything (2560 × 1440: about 130 %; 4K 3840 × 2160: 200 %). The **height** decides: a very wide screen only 1080 high (2560 × 1080) stays at 100 %, the extra width widens the waterfall and windows. The top of the menu shows the PC's screen and the size chosen by Auto. If Windows already enlarges the display (Settings › Display › Scale, often 125 % or 150 % on a 2560 × 1440 or 4K screen), Auto takes it into account and only adds the rest: 125 % × 105 % ≈ 131 %, the same size as a 2560 × 1440 screen at 100 % with Auto at 133 %. The menu also lets you choose the size yourself, from **50 % to 200 %**: below 100 % everything is smaller and you see more (useful on a laptop); sizes larger than the screen (in grey) are still allowed, but the layout gets tighter and some columns scroll. Setting kept in this browser. On a screen smaller than 1920, the layout already adapts by itself; Chrome's `Ctrl` + `−` can help. |
| `HELP` | The manual. | Opens this page (French or English depending on your browser). |
| `Déconnexion` | End of session (log out). | Ends the session and forgets this browser. |

### The screen areas

1. **Left column**: Antenne (antenna), RF front end (receive), Mode, Filtres (filters), Station meters (measurements).
2. **Centre, top**: the two VFO displays (A / MAIN and B / SUB), the **Step** row (tuning step, VFO choice, SPLIT…) and the **band** row.
3. **Centre, bottom**: the tab row (no title above it): Modes (station activity log), FT8 · FT4 · FT2, SSB, RTTY, WSPR, JT65, JTTY, CW, SSTV (a mode tab opens that mode's page: TRX SSB, TRX CW, or TRX DIGI on that mode; each window — TRX SSB, TRX CW, TRX DIGI, logbook — reopens **at the place and size** it had when closed (TRX DIGI also stretches down to the bottom of the screen: taller message lists and band maps), and scrolls with the wheel when taller than the screen), then Logbooks (the dashboard opens on the **logbook**, which stays shown while the modes are in their own pages), the `Log QSO` button and Synchro.
4. **Right column**: RX audio (listening), DSP (noise reduction), Accord (tuner), TX (PTT and power).
5. Under the tabs: the **QSO** line (the station worked, its reports and the TX call), in the mode tabs and Synchro; it is hidden in the **Modes** and **Logbooks** tabs, where the logbook form already has the call, reports and TX call (chosen there, with control, it also changes the transmit callsign). `Log QSO` is on the tab row, right of Logbooks, followed by `👁 Suivre` (follow the operator). On the right, the **band map** (DX cluster spots), in every mode tab except SSTV.

- **Fold a panel**: click its title (for example "DSP"); a second click opens it again. Your choice is remembered.
- **Separate window**: the `⧉` button of a panel opens it in its own window (section 11).
- Below the band row, a message line shows confirmations and refusals (« Prenez la main… » (take control…), « PTT refusé : … » (PTT refused)).

<a id="main"></a>
## 6. Taking and handing over control

- Only one person **has control** (operates the TRX); everybody sees and hears the same thing.
- `Prendre la main` (take control, top bar): possible if nobody has it. The button then becomes `Libérer la main` (release control).
- If someone already has it: open the `👥` panel and click `Demander la main à …` (request control from …). The operator receives the request (their panel opens) and can click `Passer la main à …` (hand control to …). You can also send them a message in the chat.
- **Fairness**: if the operator has had control for **45 min** and another member has requested it (request valid 15 min), the operator is warned; control passes to the requester **2 min** later, never in the middle of a transmission (at its end). With no pending request, you can keep control as long as you are active (released after 15 min without any action).
- **📊 STATS** (administrators, top right): usage statistics page — time with control and time connected per callsign, transmitting, sessions, days, QSOs, bands and modes, chart per day, weekday × hour map (Belgian time), session log (who, when, how long, bands, modes, TRX), CSV export for Excel; period and callsign to choose. Recorded minute by minute in `logs/usage-YYYY-MM.jsonl`; before this version, durations estimated from the control log.
- **One account, one operator**: your account can be open in several tabs or on several devices **on the same network** (same internet address). A login from **another address** closes the sessions open elsewhere (they will have to type the password again) and administrators are told: do not lend your account.
- **Countdown**: next to `Libérer la main`, `⏱ 14:58` gives the time left before control is released (and the session closed) without any action; each setting or transmission resets it to 15 min; orange under 2 min, « ⏱ en émission » during a transmission. When a member is waiting for control (fairness), it turns into a red badge `⏱ main → ON4XXX dans 1:45`.
- **When you leave**, click `Libérer la main`. With no action for **15 minutes**, control is released automatically.
- The top-bar button shows `Main occupée` (control taken) when someone else has it, and `Prendre la main ici` (take control here) if you already have it in another tab or another browser. An administrator sees `Reprendre la main` (take back control): they can take it back if needed, after confirmation.
- Without control, the commands are greyed out and a message reminds you « Prenez la main » (take control).
- **Following the operator** (for remote training): `👁 Suivre` (follow) button just after the digital-mode tabs. When on (green), your screen shows the same tab as the operator in control (RTTY, FT8, CW…) and changes along with them. Clicking another tab yourself stops following; a click on `👁 Suivre` starts it again. This button is not shown to the operator in control. It switches on **by itself** when you arrive while another member has control, and each time another member takes control afterwards.

<a id="trx"></a>
## 7. Operating the TRX

All the commands in this section require **having control**, except listening and the volume. They act on the real club TRX and everybody sees the result. Some exist on only one TRX: they are greyed out or absent on the others. When a button is lit (coloured), the function is on; a click switches it off.

<a id="vfo"></a>
### 7.1 The VFO displays

At the top centre, two displays: **VFO A (MAIN)** on the left and **VFO B (SUB)** on the right. They look like the display of the TRX.

| Item | What it shows | What a click (or the mouse wheel) does |
|---|---|---|
| `RX` | Green: this is the VFO being listened to. | Click: this VFO becomes the receive VFO (like the MAIN / SUB key of the TRX; not on the IC-7300). |
| `TX` | Dark red: a transmission would go out on this VFO. Bright red with a glow: transmitting. | Click on the TX of the other VFO: SPLIT (listen on one VFO and transmit on the other, section 7.5). Click on the TX of the VFO being listened to: SPLIT off. |
| `BW 2.4K` | Receive filter width of this VFO. | **Mouse wheel** over it: forward = wider, towards you = narrower, one notch at a time among the widths the TRX offers in this mode (on the Yaesu: 300 Hz to 4 kHz in SSB, 50 Hz to 4 kHz in CW, RTTY and DATA). « FIX » in AM / FM (fixed width), « NAR » when NARROW is on (the wheel is then refused, with a message). IC-7300: the wheel steps through FIL1, FIL2 and FIL3. On VFO B (FTX-1, FTDX101): width of the SUB side. |
| `SFT −40` and the small filter | Filter shift (IF SHIFT, or TWIN PBT centre on Icom), next to `BW` above the S-meter. Below the S-meter, left of the frequency, a small white-framed graph, Icom style, shows the passband (orange, red low edge, blue high edge) around 1500 Hz (700 Hz in CW), on a fixed 7 kHz scale like the IC-7300 (filters under 1 kHz enlarged, AM 20 kHz): its width follows BW and its position SFT, independently; with an offset TWIN PBT both filters are outlined in red and blue and the orange is their overlap. Low · centre · high edges in Hz underneath, in bold white. NOTCH on: blue V cut in the filter, ▼ mark above and its frequency (« N 1100 »); it follows FRÉQ. NOTCH and the wheel on the NOTCH badge. **Mouse wheel** on the drawing's **BW** box: filter width; on the **SFT** box or the drawing: shift (IF SHIFT; Icom: both PBTs) — the BW / IF SHIFT sliders in the left column follow. On Icom rigs the badge shows the actual width "BW 2.8K" (instead of FIL1). Next to it (or below when space is short), a needle meter like the rig's own display: S (S1…S9 white, +20…+60 blue), PO in watts (full scale of the connected rig), then SWR; turn the **mouse wheel** on the meter for the next screen: S / PO / SWR → S / PO / COMP → S / SWR / ALC → Po / Id / Vd (on receive the needle then shows the Vd voltage); next to it, a 3rd **AF spectrum** box of the received audio (with « 🔊 Écouter le TRX »), the filter in red, the NOTCH (gap, orange line and square) and the CONTOUR (blue half-circle), like the FTDX101 filter box; the **mouse wheel** on this spectrum moves the NOTCH (FRÉQ. NOTCH in the right column follows). The three boxes sit on one line, next to the frequency or below it when space is short; **clicking** one of them (filter, meter or spectrum) **enlarges it in the middle of the screen** for a better view, with a banner above it showing the VFO (« VFO A · MAIN » in green, « VFO B · SUB » in pink), its frequency, mode, band and the box name (the wheel still works there); click it again, click beside it or press Esc to put it back; the needle follows the S-meter on receive and power on transmit. Scales change with the rig. | Set with the BW / IF SHIFT sliders in the left column. To make room the frequency digits are slightly smaller; the graph is hidden in narrow windows and in FM. |
| « TX VFO-A (MAIN) » / « TX VFO-B (SUB) » | Reminder of the VFO a transmission would go out on: orange frame, **solid orange background when SPLIT is on**; the **SPLIT** button also turns orange with SPLIT in bold white. | — |
| MAIN / SUB · 20M | Side of the TRX and band of this VFO. | — |
| S-meter (S1 … +60) | Received signal strength. Greyed out on the VFO not being listened to. | — (when transmitting, look at Station meters). |
| Frequency digits | The frequency in MHz. Red while transmitting; greyed out if this VFO is used neither to receive nor to transmit. | **Mouse wheel** on a digit (forward = up) or **drag** up / down (one step every 14 pixels; with a finger on a tablet): that digit goes up or down, from the MHz down to the last digit, the hertz; carries are handled automatically (7.099 → 7.100). **Single click on a digit**, without moving: that digit becomes the **step** of the Step row, of the ◀ ▶ arrows and of the `↑` `↓` keys (it is underlined). **Click** elsewhere on the display: this VFO becomes the one tuned by the arrows, the keyboard and the band keys (its letter is underlined). The frequency always stays within the TRX coverage. |
| Mode (USB, DATA-U…) | The mode of this VFO. | It is changed in the **Mode** panel on the left. |
| `RIT` | Offset of the receive frequency only. | On both VFOs; if the rig has a single clarifier (FTDX101, FTDX5000, IC-7300…), VFO B shows the same one as VFO A. Click: on / off. **Mouse wheel** over the displayed value (+0.00 kHz): ± 10 Hz, ± 100 Hz with `Shift`. Useful if the correspondent drifts a little. |
| `XIT` | Offset of the transmit frequency only. | Click: on / off. Mouse wheel over the value: as for RIT. Useful for a small split of a few kHz. |
| `CLEAR` | — | Resets the RIT / XIT offset to zero. |
| `ATT` | Input attenuator. | Click: on / off. For a very strong local station or an overloaded band (the noise drops too). Greyed out on 2 m / 70 cm. On the FTDX10: OFF, 6, 12 or 18 dB. |
| `IPO` / `AMP1` / `AMP2` | Preamplifier (HF and 6 m). IPO = no preamp. | Each click moves to the next one. AMP1 / AMP2 help on quiet high bands (15, 10, 6 m); on 80 / 40 m, IPO is usually enough. |
| `AMP` | Preamp on 2 m / 70 cm. | Click: on / off. |
| `NB` | Noise blanker: suppresses impulse noise (engines, electric fences). | Click: on / off (the level is set in the DSP panel). |
| `DNR` | Digital noise reduction (hiss). | Click: on / off; level in the DSP panel. |
| `NOTCH` | Manual filter that cuts out one frequency (a whistle). | Click: on / off; its frequency is set in the DSP panel. |
| `DNF` | Automatic notch: removes whistling carriers by itself. | Click: on / off. Avoid it in CW and digital modes (it can remove the wanted signal). |
| `NAR` | Narrow filter (NARROW). When on, the TRX imposes its narrow width: the BW slider of the Filters box is greyed and shows « NARROW ✕ ». | Click: on / off. Clicking « NARROW ✕ » in the Filters box also turns it off and gives the BW slider back. |
| `AGC AUTO` | Reminder of the AGC setting. | It is changed in RF front end (this badge is not clickable). |
| `RFG 80` | Reminder: RF GAIN is turned down (here to 80 %). Absent when it is at maximum. | Turn it back up with the RF GAIN slider of the RF front end panel. |
| `LOCK` | The front panel of the TRX at the club is locked. | Turned off with `LOCK` in the Step row. |

> [!TIP]
> **Clickable badges (ATT, IPO / AMP, NB, DNR, NOTCH, DNF, NAR)**
> - **Grey** = function off; **coloured** = on (green for ATT and preamp, orange for NB, DNR, NOTCH, DNF, blue for NAR). On hover the badge only brightens and gets a dotted outline, without changing colour: you can see its state under the mouse.
> - **One click** is enough: the new state shows at once, then the TRX read-back confirms it within a second. If the badge goes back to its previous state, the TRX refused it (function without effect in this mode, for example): the message under the bands says so.
> - **Mouse wheel** on `NB`, `DNR` (or NR): changes their level (shown in the badge, « NB 5 », and in « Niveau NB / DNR » in the right column); on `NOTCH`: the notch frequency. You need control.
> - You must have control; refused while transmitting. On hover, a tooltip recalls the name of the setting and what the click does.
> - NB and DNR: the click switches on at the last level used (or mid-range) and off; the exact level is set in the DSP panel. IPO / AMP1 / AMP2 and multi-step ATT (FTDX10, FTDX101: 6 / 12 / 18 dB): each click goes to the next step.

> [!TIP]
> **FTX-1: the two sides, MAIN and SUB**
> - The VFO B display sets NB, DNR, NOTCH, DNF and NAR of the SUB side.
> - ATT and preamp belong to each side, but the TRX only reports them for the active side: a click on those of the other VFO switches the TRX to that side for 2 to 3 s, without transmitting, then back. As long as they have never been read, they show "?".
> - The RF front end, Filtres and DSP panels set the **VFO chosen** with the `VFO A` / `B` keys (or MAIN / SUB), like the modes: their title shows « A · MAIN » or « B · SUB ». On the FTDX101 and FTDX5000, choosing B sets the SUB side without changing the rig's active side (MAIN stays lit); on the FTX-1 they follow the rig's active side.
> - **FTDX101D / MP** (true dual receiver): the VFO B display sets the SUB side directly (ATT, IPO / AMP, NB, DNR, NOTCH, DNF, NAR, BW), without changing side or TRX state.
> - **FTDX5000** (also a true dual receiver): same as the FTDX101 for VFO B; `DUAL RX` listens to MAIN and SUB together. SPLIT means transmitting on the other VFO (the TRX has no separate SPLIT command). Preamp IPO1 / AMP1 / AMP2 / IPO2, power 5 to 200 W. Not yet: CONTOUR / APF, keyboard CW macros, dual decoding of digital modes (audio comes from one receiver only).
> - **IC-7760** (trial, two true receivers): MAIN = VFO A, SUB = VFO B, as on the FTDX101. `DUAL WATCH` listens to MAIN and SUB together, `MAIN` / `SUB` picks the receiver of the main dial, `A ⇄ B` swaps MAIN and SUB, `A = B` equalises them; SPLIT transmits on SUB. Each receiver has its own settings (badges under each VFO): FIL1 / FIL2 / FIL3 and width, PBT, ATT (3 to 45 dB), P.AMP1 / P.AMP2, AGC, NB, NR, NOTCH, AUTO NOTCH, antenna ANT 1-4; S-meter on each side; power 5 to 200 W. The radio's scope (MAIN) goes to the page, CW uses the radio's keyer. To check on the first trial: power in watts, USB audio (one channel or MAIN | SUB in stereo). Front-panel page: **/ic7760**.

<a id="step"></a>
### 7.2 Step row and band row

Below the VFO displays.

| Command | What it does | When to use it |
|---|---|---|
| `1 Hz` … `100 kHz` (Step) | Chooses the step of the ◀ ▶ arrows and of the keyboard arrows `↑` `↓`; the matching digit of the VFO display is underlined. A single click on a digit of a VFO display also chooses the step. Remembered in your browser. | 100 Hz to 1 kHz to search in SSB; 10 Hz for fine tuning, 1 Hz for the finest (RTTY, digital modes, CW zero beat); 10 to 100 kHz to move across a band. |
| `A` / `B` (VFO) | Chooses the VFO tuned by the arrows and the band keys. On the FTX-1, also switches the TRX to that side (like MAIN / SUB). | To work on VFO B. |
| `◀` `▶` | Moves the frequency down / up by one step. | Step-by-step searching. |
| `MAIN` / `SUB` | Active side of the TRX (receive and transmit together), like the front-panel key, without transmitting. Takes 1 to 2 seconds. **FTX-1: only in dual receive (DUAL RX, one VFO on 144 / 430 MHz).** In single receive the dashboard refuses: the transceiver went into transmit (seen at the club on 24 and 25/10). To listen to the VFO B frequency on HF: `A ⇄ B`. An administrator can allow it for tests (`ftx1SubSingle`). | FTX-1: listen and transmit on VFO B. |
| `SPLIT` | Transmit on the other VFO than the one being listened to. | DX expeditions (section 7.5). |
| `TXW` | **Hold** the button (or the `W` key): you listen on the transmit frequency; release = back to the DX. The VFOs are put back automatically (also after 15 s or if the link drops). PTT is refused while TXW is held. | In SPLIT, to listen to the pile-up and find a gap. |
| `DUAL RX` | FTX-1: dual receive (MAIN and SUB heard together) or single receive. The FTX-1 refuses dual receive with both VFOs on HF / 50 MHz, even on the same band (tried at the club: 20 m + 15 m, then 7.074 + 7.090 MHz); one VFO must be on 144 / 430 MHz. The button is then greyed out (explanation on hover). To follow two stations on the same HF band: the two decoders of the RTTY tab. | Monitoring two frequencies. In digital modes, switch it off so that only the active side is decoded. |
| `A → B` / `B → A` | Copies the frequency and mode of one VFO to the other. | Preparing a SPLIT. |
| `A ⇄ B` | Swaps the two VFOs. | Switching quickly between two frequencies. |
| `LOCK` | Locks the **front-panel controls of the TRX at the club**. The dashboard remains usable. | So that someone at the club does not change anything during your operating. |
| **Bands**: `160M` … `70CM` | Changes band, on the chosen VFO (A / B): the FTX-1 and the FTDX101 return to the last frequency and mode used on that band (like their BAND key); the FTDX10 and the IC-7300 go to the usual frequency of the band (e.g. 7.100 MHz in LSB, 14.200 MHz in USB). Only the bands of the connected TRX are offered: `4M` (70 MHz) with the FTDX10, the FTDX101 and the IC-7300, `2M` and `70CM` only with the FTX-1. The current band is highlighted. The small `⧉` in the top right corner of the panel opens it in a separate window. | Changing band. A « **TUNE obligatoire** » (TUNE required) reminder then flashes on the right until the next TUNE. |
| `Mode auto` | Green = on. When the VFO enters another part of the band (band key, wheel, arrows), the TRX takes the **IARU Region 1 band plan mode**: CW in the CW segment, DATA-U in the digital segment and on the FT8 / FT4 / WSPR / JT65 / JTTY and SSTV frequencies (e.g. 7.074, 14.230), phone in **LSB below 10 MHz** and **USB above** (USB on 60 m), FM at the top of 10 m, on 2 m and 70 cm. Example on 20 m: 14.000–14.070 CW, 14.070–14.099 DATA-U, 14.101–14.350 USB, except 14.227–14.236 (SSTV) in DATA-U. **Your choice wins**: a mode picked by hand stays as long as you remain in the same segment (USB on 14.004 for example); a digital tab or a cluster spot also sets its own. Beacons and mixed segments: nothing changes. One click switches it off or on (kept in your browser). | Leave it on: you always land in the right mode. |

The grey line below the bands is a reminder of useful actions; the message line just below it shows confirmations and refusals.

<a id="gauche"></a>
### 7.3 Left column

**Antenne** (antenna)

| Command | What it does |
|---|---|
| `ANT 1` / `ANT 2` | Chooses the antenna socket of the SPA-1 amplifier (FTX-1), or ANT 1 / ANT 2 / ANT 3 on the FTDX101. Refused during a transmission. The FTDX10 and IC-7300 do not allow this choice remotely (buttons greyed out). After changing antenna, do a new TUNE. |

**RF front end** (the receiver input)

| Command | What it does | Advice |
|---|---|---|
| **RF GAIN** | Receiver sensitivity (0 to 100 %). | Usually leave it at maximum; lower it if a band is very noisy or a nearby station overloads the receiver. |
| **AGC** `OFF` `FAST` `MID` `SLOW` `AUTO` | Automatic gain control: how fast the receiver turns the volume down after a strong signal. | AUTO is almost always fine. FAST for CW, SLOW for SSB. Avoid OFF (very loud, distorted sound). |
| Preamp, ATT | Same as the badges on the VFO display (section 7.1). | — |

**Mode**

| Button | Use |
|---|---|
| `LSB` / `USB` | SSB phone: LSB below 10 MHz (160, 80, 40 m), USB above (20 m…). |
| `CW-L` / `CW-U` | Morse. Both are used; the dashboard picks **CW-L below 10 MHz** and **CW-U above** by itself when it changes the mode (DX cluster spot, band map, frequency list of the CW tab), like LSB / USB in phone. |
| `RTTY-L` / `RTTY-U` | RTTY decoded by the TRX itself. For the dashboard's RTTY, use DATA-U. |
| `DATA-L` / `DATA-U` | Digital modes through the TRX sound card: **DATA-U** for the dashboard's FT8, FT4, FT2, RTTY, JTTY, WSPR, JT65, SSTV. |
| `PSK` | PSK31 decoded by the TRX. |
| `AM` / `AM-N`, `FM` / `FM-N`, `DATA-FM` | Amplitude modulation, frequency modulation (N = narrow), digital over FM (repeaters, packet…). |
| IC-7300: `CW` / `CW-R`, `RTTY` / `RTTY-R`, `USB-D` / `LSB-D`, `AM-D`, `FM-D` | Icom names: CW = CW-U, CW-R = CW-L (reverse); **USB-D** replaces DATA-U for the dashboard digital modes. |

Below the buttons, « Mode appliqué à **VFO A** » (mode applied to VFO A) shows which VFO changes mode (the one chosen with A / B).

**Filtres** (filters)

| Command | What it does | Advice |
|---|---|---|
| **BW** (WIDTH) | Receive filter width. FTDX101: up to 4.0 kHz, and at the very bottom of the scale **« défaut »** (default, badge « BW DEF »): the TRX returns to its default width and its WIDTH indicator goes off. | SSB: 2.4 to 2.7 kHz; CW: 300 to 500 Hz; FT8: 3 kHz (the whole audio band). |
| **ROOFING** (FTDX101D / MP) | Roofing filter (R.FIL on the TRX): 12k, 3k, 1.2k, 600, 300 Hz. 1.2k and 300 only if the optional filter is fitted. Like BW, it sets the VFO shown in the panel title (A · MAIN or B · SUB). | 12k or 3k in SSB and digital; 600 or 300 in CW against a strong station close by. |
| **IF SHIFT** | Slides the passband up or down without changing frequency. | Pushes an interfering station out on one side. Set it back to 0 afterwards. |
| `CONTOUR` | Tone control that attenuates part of the audio. | Makes a voice easier to understand. |
| `APF` | Audio peak filter, CW only. | Makes a weak CW signal stand out. |
| `NARROW` | Narrow filter: switched on and off with the `NAR` badge of the VFO display. When on, the TRX imposes its narrow width: the BW slider is greyed and shows `NARROW ✕` (explanation on hover); clicking `NARROW ✕` turns NARROW off and gives the BW slider back. | Crowded band. If BW is greyed on one VFO and not on the other, NARROW is on for that side. |
| IC-7300: **FILTRE**, **PBT** | FIL1 / FIL2 / FIL3 (wide, medium, narrow) and Twin PBT (narrowing from both edges). | — |

**Station meters** (measurements, mostly useful when transmitting)

| Meter | Meaning | Normal value |
|---|---|---|
| RX / TX | State of the TRX; on the right, duration of the current transmission. | — |
| **Po** | Output power (watts). | The power set in the TX panel. |
| **SWR** | Antenna match. | Below 1.5; above 2.5, transmission is cut. |
| **ALC** | Is the transmitter being driven too hard? | Digital modes: as low as possible (ideally 0). Phone: a little ALC on the peaks. |
| **Id** / **Vd** | Current and voltage of the final stage. | For the station managers (monitoring). |
| **COMP** | Compression of the speech processor (phone). | A few dB when PROC is on. |
| **S** | S-meter of the active side. | — |

<a id="droite"></a>
### 7.4 Right column

**RX audio**

| Command | What it does | Who it affects |
|---|---|---|
| `🔊 Écouter le TRX` | Plays the receiver audio in your browser (listen to the TRX). A second click mutes it. | Only you (no control needed). |
| **Volume** | Volume of your listening (0 to 150 %). | Only you. |
| **AF LEVEL** | Volume of the TRX loudspeaker at the club. | Everybody (with control). Does not affect your listening or the decoders. |
| **SQUELCH** | Mutes the audio until a signal rises above the threshold. | Everybody. Useful in FM; leave it at 0 on HF and in digital modes, otherwise the decoders no longer hear anything. |
| « ⚠ Plus de son du TRX sur le PC du club » (no more audio from the TRX) | Orange alert: for 45 s the Station page has received no audio from the TRX although it is connected (frozen TRX USB sound card). | Everybody sees it. ON6DP and ON4LUC have the `Relancer la carte son` (restart the sound card) button (section 18). It disappears as soon as audio is back. |

**DSP** (signal processing)

| Command | What it does |
|---|---|
| **NB** | Noise blanker level (OFF, then 1 to 10). Start low and raise it until the clicks disappear. |
| **DNR** | Noise reduction level (OFF, then 1 to 10; up to 15 on the FTDX10). Too high and the voice sounds "metallic". |
| `NOTCH` + **Fréq. NOTCH** | Switches the manual notch on and sets its frequency (10 to 3200 Hz): turn it until the whistle disappears. |
| `DNF` | Automatic notch. |

**Accord (tuner)**

| Command | What it does |
|---|---|
| `TUNER` | Switches the antenna tuner in or out of line (the SPA-1's for the FTX-1). It is switched back in automatically when the TRX connects and at every HF / 6 m band change. |
| `TUNE` | Starts tuning: the TRX sends a carrier for a few seconds while the tuner looks for the best match. **Required after a band change**; then check the SWR. TUNE counts as a transmission: you need control and transmit permission. |

**TX**

| Command | What it does |
|---|---|
| `RX` / `TX` lamp | Real state of the TRX (green when receiving, red when transmitting). |
| `PTT` | **Hold** to transmit (or the `Space` bar); release = back to receive. The small text below says why PTT is unavailable (« Prenez la main pour émettre » (take control to transmit)…). |
| **Puissance** (power) `−` `+` | Lowers or raises the TRX power, one step per click: 5 W (0.5 W on the FTX-1 without the SPA-1 amplifier). Ranges: FTX-1 0.5 to 10 W alone, 5 to 100 W with the SPA-1; FTDX10, FTDX101D and IC-7300 5 to 100 W; FTDX101MP 5 to 200 W. Your licence limit is shown below (ON2: 100 W, ON3: 25 W); above it, the power is brought back down automatically. **ON3 licence**: transmitting only on 80, 40, 30, 20, 15, 10 m, 2 m and 70 cm (refused on 160, 60, 17, 12, 6 and 4 m, with the reason shown); receiving stays free everywhere. |
| **Fréquence CONTOUR / Fréquence APF** | **FILTRES** panel, under the CONTOUR and APF buttons: contour frequency (10 to 3200 Hz, FTDX5000: 100 to 4000 Hz) and APF (in CW). Follows the selected VFO (MAIN / SUB). |
| **Gain micro** (mic gain) | Level of the **club microphone** in phone (TRX MIC GAIN menu). Remote phone has its own level (Station page, « Niveau phonie à distance »). Greyed for a few seconds on opening, until the TRX gives its value. |
| `PROC` + **Niveau PROC** (PROC level) | Speech processor (compressor): the voice "punches through" the noise better. Keep the level moderate, otherwise the modulation sounds unpleasant. On the IC-7300: COMP. |
| `MIC EQ` (FTDX10, FTDX101) | Switches the TRX parametric equaliser on or off (set with `Equalizer TRX`). |
| `VOX` | Voice-operated transmit: can only be **switched off** remotely, never on. |
| **SSB CONFIGURATION** | Remote phone (section 4.2): `Configuration micro` (your microphone to the TRX; green dot = on; click again = off), `Equalizer TRX` (TRX PRMTRC menus, your profile), microphone choice and recognised type, level bar (stay in the green, never **SAT**), `Equalizer micro` (equaliser of your microphone in the browser), status line, `🎧 M'écouter` (listen to yourself, headphones) and its **Volume** (0 to 300 %, no effect on what goes to the TRX). |

<a id="split"></a>
### 7.5 Operating SPLIT (transmit and receive on two frequencies)

SPLIT is mainly used for a **DX expedition** listening away from its own frequency ("UP 5", "listening 14 200 to 14 210"). You **listen to the DX on VFO A** and **transmit on VFO B**.

1. Set **VFO A** to the DX frequency, in the right mode. Check that `RX` is green on VFO A.
2. Click `A → B`: VFO B takes the same frequency and mode.
3. Set the **transmit frequency on VFO B** with the mouse wheel on its digits, for example +5 kHz for "UP 5". On the FTX-1, the wheel on VFO B does not change the side you are listening to: you stay on A.
4. Click `SPLIT` (or `TX` on the VFO B display). The **TX** lamp and the glowing frame move to VFO B; the reminder shows « Émission sur B » (transmit on B).
5. Listen to the DX on A; **hold TXW** (or `W`) to listen to the pile-up on your transmit frequency. To call, **PTT**: the transmission goes out on VFO B (digits in red). On release, back to receive on A.
6. To finish: click `SPLIT` again (or `TX` on VFO A). The TX lamp goes back to A.

> [!TIP]
> **Good to know**
> - Transceiver rule: without SPLIT you transmit on the VFO you listen on; with SPLIT, on the other one.
> - **FTX-1**: SPLIT is handled by the dashboard, by swapping the VFOs. On PTT, the Station page swaps A and B on the transceiver (A ⇄ B), transmits from the active side on the frequency and in the mode of the transmit VFO, then, once receive is confirmed, puts the VFOs back. On the transceiver display the frequencies swap during the transmission: this is normal; the dashboard shows the VFOs in place. A very short press (under a quarter of a second) does not transmit. A SPLIT set on the front panel is followed by the dashboard.
> - The frequency **actually transmitted** (VFO B, XIT included) is checked: outside the authorised bands, PTT is refused.
> - Small offset (a few kHz): `XIT` on VFO A is enough, without SPLIT.
> - In **FT8 / FT4 / FT2**, there is no need for SPLIT: the transmission is placed within the audio passband with the TX marker of the waterfall (right click).
> - Switch SPLIT off at the end of the pile-up: otherwise the next operator would transmit on VFO B without knowing it.

<a id="ecoute"></a>
## 8. Listening

- **RX audio** panel → `🔊 Écouter le TRX`, then set your **Volume**. Everybody can listen, even without control.
- The audio arrives with a small delay (a fraction of a second): this is normal over the internet.
- If you hear nothing: check your PC volume, then the Station lamp. The club's Station page must have audio enabled (section 18). The message below the button says what is missing.
- **AF LEVEL** and **SQUELCH** act on the TRX itself, for everybody.
- No more audio, a silent waterfall with only a hum at the far left, and the orange « Plus de son du TRX » alert: the TRX USB sound card has frozen. A station manager restarts it remotely (`Relancer la carte son` button), otherwise the TRX must be switched off and on at the club (section 18).

<a id="emission"></a>
## 9. Transmitting and safety

1. **Have control** and an account allowed to transmit (ONL listeners cannot).
2. Be in a **band authorised** for your licence.
3. After a band change: `TUNE`, then check the **SWR**. A reminder flashes to the right of the 70CM key until the TUNE (on 2 m and 70 cm there is no tuner: only "check the SWR"). The SPA-1 tuner only works on HF and 6 m, and the amplifier must be switched on.
4. Set the **power** (TX panel).
5. Transmit: hold `PTT` (or `Space`), or use the transmit buttons of the digital modes.

> [!WARNING]
> **Automatic safety features** (cannot be bypassed from the dashboard):
> - Transmission only in the authorised bands, checked on the frequency actually transmitted (SPLIT and XIT included).
> - Maximum length of one transmission: **120 s**, then it is cut; release the PTT before transmitting again.
> - Immediate cut if you lose the link, if the club PC loses internet, or if the Station page closes.
> - **SWR** above 2.5:1, or **HI-SWR** reported by the TRX: transmission cut and PTT refused on that frequency (± 25 kHz) until a successful TUNE. The `TUNE` button itself is always allowed (it is the cure).
> - **TUNE without a match**: if the FTX-1 reports HI-SWR at the end of a TUNE, transmitting is **blocked on the whole band** (except TUNE) to protect the amplifier. A red message appears to the right of the bands. The block is lifted as soon as a TUNE succeeds; otherwise, try the other antenna or tell a station manager.
> - At the club, the TRX goes back to receive if it transmits without modulation for 2 min (**20 s in digital modes**: DATA, RTTY, PSK — e.g. a frozen sound card during an FT8 series) or for 5 min without a break.
> - Power limited to your licence class; listener callsigns: no transmission at all.

Transmitting is only possible if the administrators have enabled it on the server.

<a id="ssbcontest"></a>
### 9.1 Phone and contests: the TRX SSB page

`SSB` tab of the dashboard tab row, or `SSB` button of the front-panel **MODES** line: a separate page (address **/ssb**), attached to the page that opened it (same connection, same control), like TRX CW; with control, the TRX goes to LSB (below 10 MHz) or USB if it was not already in SSB. At the top: TRX frequency and mode (orange outside LSB / USB), who has control (`PRENDRE LA MAIN`), large **RX / TX** lamp. Just below, **phone** as under the front panel: the large `PTT` button (hold, or the space bar when the cursor is not in a box; it turns **red**, "PTT · ÉMISSION", as soon as the TRX transmits, also during a voice memory) and the **SSB CONFIGURATION** line (`MICRO`, `EQUALIZER MICRO`, mic level, `EQUALIZER TRX`, `Profil de …`, sound **input** and **output**, `M'ÉCOUTER` and its volume). Switch `MICRO` on in this page to talk from it; the voice goes through the opening page's connection, same safety as the front-panel PTT. On the left of the page (and of TRX CW), the **band map**: DX cluster spots of the TRX band, phone part (TRX SSB) or CW part (TRX CW), red line = TRX frequency; call in green, struck in red if already in the contest log on this band, greyed after 20 min; `−` / `+`: narrower / wider range, wheel: scroll, double-click: back; click on a spot: the call in the page and, with control, the TRX on its frequency (LSB / USB or CW). In the TRX DIGI page, the band map is also on the left. Below the phone line, the **two VFOs** box (two-VFO TRX, also in TRX CW, below the keyer): without SPLIT, only the active VFO; in SPLIT, VFO A and VFO B side by side with frequency and mode, **RX** in green on the receive VFO, **TX** in red on the transmit one (red background while transmitting); `SPLIT ON / OFF` (receive on one VFO, transmit on the other; the dashboard shows the same SPLIT), `A ⇄ B` (swap), `A → B` (copy), **B = A** −1 / +1 / +2 / +5 / +10 kHz (VFO B next to VFO A, SPLIT set automatically), and a **kHz** box per VFO to type a frequency (Enter). To transmit on your frequency while listening elsewhere: your frequency in VFO B (transmit), the listened frequency in VFO A (receive), SPLIT ON. With control, not while transmitting. The title starts with the **TX call** (callsign used on the air, e.g. "ON5VL TRX SSB" or "ON6DP TRX SSB"): without a contest, the one chosen in the form's TX CALL box; in a contest, the station's (TX call chosen with control). Same in TRX CW. Next to the title, the **TX CALL** list (also in TRX CW; the TRX DIGI page has it in each mode's bar): with control, the callsign used on the air **and** for the QSOs logged (ON5VL, OR0L, OP0P of the station, or your own), hence in ADIF and Cabrillo exports; the logbook form follows it.

**Band map** (phone spots from the DX cluster) on the left; with a TRX that has two true receivers (IC-7760, FTDX101, FTDX5000…), a 2nd map on the right: the **VFO-A** (MAIN) band on the left, the **VFO-B** (SUB) band on the right. Click a spot: the call goes into the form and, with control, that VFO goes to its frequency.

**Without a contest** ("— pas de contest —"): **LOG DU QSO** box, the logbook entry form as in the Logbooks tab (call, UTC date and time, ⟳ Maintenant, frequency from the TRX, mode **USB or LSB only** (the TRX's, otherwise LSB below 10 MHz and USB above), ⇩ TRX, RST, TX call, QO-100, name, QTH, locator, power, remark, IOTA / WWFF / POTA / BOTA / LLOTA references, ＋ Ma référence) and `ENREGISTRER LE QSO`: the QSO goes to the general logbook. Dupe questions appear in this page only; the dashboard form is left alone. Below the form, down to the bottom of the page: the **latest phone QSOs outside contests** (SSB, LSB, USB) from the general logbook, newest at the top (date, time, call, band, frequency, reports, name, QTH, country, TX call, operator); **Depuis** (since) and `ADIF`: .adi file of your phone QSOs outside contests since that date. In a contest, the page only shows the chosen contest's QSOs (log on the right); they are also in the general logbook, with the contest name in the **Contest** column.

- **Contest**: list of phone contests with, for each one, the **exchange** a Belgian station gives and the entry **categories**; next to the list, the usual date, a note and the `Règlement ↗` (rules) link. Contests marked ***** have "usual" categories: check that year's rules.
   - CQ WW DX SSB: **59 + CQ zone (14)**; single-op HP / LP / QRP, multi-single HP / LP, multi-two, multi-multi, multi-distributed, checklog; Classic, Rookie, Youth overlays.
   - CQ WPX SSB: **59 + serial number**; single-op HP / LP / QRP (36 of 48 h), multi-one HP / LP, multi-two, multi-multi, multi-distributed; Tribander-wires, Rookie, Classic, Youth overlays.
   - ARRL DX SSB: **59 + power** (100, 400, KW…); only W / VE stations are worked; single-op HP / LP / QRP, multi-single, multi-two, multi-multi.
   - IARU HF: **59 + ITU zone (27)** (IARU HQ stations send their abbreviation); single-op phone, single-op mixed, multi-single, multi-two.
   - WAE DX SSB (DARC): **59 + serial number**; single-op LP / HP, multi; QTCs are not handled by the page.
   - UBA DX SSB: **59 + serial number + UBA section** (LGE for the club; XXX for a non-member); CH / CL (24 h), BH / BL (12 h), AH / AL (6 h), D multi-op, E QRP, BASE (ON3).
   - ON Contest SSB: **59 + serial number + section** (LGE); categories A and A2.
   - EU HF Championship: **59 + year of first licence** ("00" to replace); SSB HP / LP, mixed HP / LP, unlimited, QRP.
   - The others (RDXC, SP DX, HA DX, OK/OM, YO DX, King of Spain, Helvetia, PACC, WAG, Coupe du REF, ARI, Ukrainian DX, CQ-M, ARRL 10 m: 59 + serial number; CQ 160 m, JIDX: 59 + CQ zone; LZ DX: 59 + ITU zone; All Asian: 59 + age) and "Other contest".
- **Category**: your entry category; depending on the contest, **Power** (when the category does not set it), **Band** (single band), **Assisted** (DX cluster spots used) and **Overlay** are added. It is written in the Cabrillo header (CATEGORY-OPERATOR, -POWER, -BAND, -ASSISTED, -MODE, -TRANSMITTER, -OVERLAY, -TIME). Kept per contest in this browser.
- **Exchange**: editable (`<CNTR>` serial number, `<CQZ>` CQ zone, `<ITUZ>` ITU zone); in green, what to say on the microphone. **N°**: serial number, **automatic +1 at each logged QSO** (only when the exchange contains `<CNTR>`), `−1` / `+1` to correct; same number as the TRX CW page and the RTTY contest.
- **Contest log** (N1MM style): line **Call · RS · Sent · RS · Received** (**Sent** is filled in by itself with what to say: zone, power… or **this QSO's serial number**, which moves to the next one as soon as the QSO is logged; you can change it by hand), `LOG ↵`, `EFFACER` (wipe, `Alt`+`W`), `Space` = next field; **DUPE** blinking on a red background when the call is already in the contest log on the same band (hover: time of the earlier QSO); nothing shown = valid QSO; **Spot cluster** box (see below); on the right, the QSOs, counts per band, rate (QSO / h), **Depuis** (start date) `ADIF` (.adi file of the contest QSOs) and `CABRILLO` (contest file with the chosen category). QSOs go to the **general logbook** (contest, sent and received exchange, LSB / USB from the TRX). A spot clicked in a band map puts the call in the **Indicatif** box.
- **Score** (below the voice memories): per band, QSOs, points and multipliers, then the **estimated score** from the contest rules (CQ WW, CQ WPX, ARRL DX, IARU HF, WAE, UBA DX, ON Contest, EU HF; hover the score for the rule used; other contests: generic rule, "estimation"). Dupes not counted; WAE QTCs and the UBA DX bonus not counted. **Évolution**: hour by hour (UTC), the QSOs of the hour, the running total and the score at the end of the hour.
- **Indicatifs probables** (likely calls): while typing the start of a call (2 characters or more), the known calls containing it: those of the contest log, then the **Super Check Partial** list (MASTER.SCP, active contest calls, downloaded weekly by the server), green if not yet in the log, struck through if already worked on the band; click to put it in the call box. Empty box: the **stations spotted in SSB** on the TRX band (DX cluster), newest first; click puts the call and, with control, the TRX on its frequency.
- The **contest log** (right) runs down to the bottom of the page; every QSO is also in the general logbook, **Contest** column.
- **Spot cluster** (box next to LOG ↵, also under the "LOG DU QSO" form without a contest, in the TRX CW and TRX DIGI pages and in the logbook): ticked, each QSO **when it is logged** is also spotted on the band-map DX cluster (call, frequency, mode and contest, or "TNX QSO"), under **your operator call** (your account, e.g. ON6DP) — not the TX CALL. Same setting in every page. Only for accounts allowed to transmit; at most one spot every 20 s and 30 per hour; the result is shown ("Spot envoyé au cluster de ON6DP…" or the reason for a refusal).
- **Enter key** (ESM): **RUN** (you call CQ): empty box → voice memory **T1** (CQ); call typed → cursor in **Reçu** (say the exchange on the microphone); received exchange typed → QSO logged, then **T3** (TU / QRZ) if recorded. **S&P** (you answer): call → **T4** (your call); received exchange → QSO logged.
- `🗣 Messages vocaux…` (next to the Voice memories title): 8 standard messages in **English** or **French** (**Langue** list: one message set per language; in French, messages for the Coupe du REF contest, French female and male voices, digits said in French, letters in the international alphabet), spoken by the server's speech synthesis: **natural voices** (Piper, much closer to a human voice, "Voix naturelles (Piper)" group of the Voix list, once installed on the server by an administrator) or espeak-ng voices (more robotic). Messages are made at the level of a microphone voice (about −18 dB); on the air, switch the speech processor (**PROC**) off for these memories and adjust VOICE TX **TX LEVEL** if needed: an over-driven synthetic voice sounds "robotic". **Prononciations** box: "word=said as", one line per word (e.g. `Romeo=Roméo`), to fix a mispronounced word; in French, the international alphabet (Roméo, Zoulou, Québec…) and abbreviations (QRZ, QSO, CQ said the French way) are already adapted. In English: T1 CQ contest, T2 CQ, T3 Thank you / QRZ, T4 your call, T5 Again please, T6 Your number again, T7 Is this frequency in use, T8 73. **{CALL}** is replaced by the **TX call** spelled in the phonetic alphabet (ON6DP → Oscar November Six Delta Papa). Texts and names can be edited; voice to choose: several **female voices** (Femme 1 to 4, Annie, Linda, Belinda, Steph, Victoria, US or GB English) and male ones, `▶ Écouter` to hear it on your PC without transmitting, the **speed** (100 to 320 words per minute; 170 to 200 gives a contest pace) and the **letter spacing** (short pause between the spelled words of the call, 0 to 300 ms, 70 ms by default) — at the top of the box; tick the memories wanted then `GÉNÉRER POUR …`: the box closes (`✕ Fermer` closes it without generating); the settings are kept. When the TX call changes, these messages are **remade by themselves** with the new call (also at transmit time if needed); a memory re-recorded with the microphone is no longer remade. Their keys show "EN".
- **Voice memories** `F1` … `F8` = your memories **T1 … T8** (VOICE TX: recorded with your microphone, MENU → VOICE → REC on the front panel), duration under the name; the key turns red while transmitting, `Esc` stops it. The rest is said on the microphone with the `PTT` of the page that opened the SSB station page. Same safety as phone.

<a id="operateurs"></a>
## 10. Operators and chat

- The **Opérateurs** (operators) panel opens and closes with the `👥` button in the top bar. A red dot on `👥` means a new message. When another member's message arrives, `👥` **blinks** (until the panel is opened), the author's callsign blinks in the list for 20 s, the message shows at the bottom of the screen and a **beep-beep** sounds; `🔔` next to « Envoyer » turns the beep off or on (🔕 = off), kept in this browser.
- ON6DP, ON4LUC and ON5VL (the station's own account) are **never logged out** for inactivity (only with « Déconnexion »); control is still released after 15 min without any action. Server setting `idleExempt`.
- It shows the connected members and who has control.
- **Chat**: type a message in « Message aux connectés… » (message to connected members) then `Envoyer` (send) (or `Enter`). All connected members see it. Messages are not kept after a server restart.
- The `Demander la main à …` and `Passer la main à …` buttons appear there when relevant (section 6).
- The **Modes** tab (first tab in the centre) is the station log: logins, control taken and handed over, transmissions (frequency, mode, power, duration), tuning, safety cuts, station online, TRX connected…

<a id="disposition"></a>
## 11. Layout and separate windows

- `⧉` button at the top right of a panel: the panel opens in **its own window**, to place wherever you like (on a 2nd screen…). In that window, `⧉ Ramener` (bring back) puts it back in the dashboard.
- **The whole dashboard in its own window**: `⧉ Fenêtre` button in the top bar. The dashboard reopens in a window of its own, without address bar or tabs, that you place and size wherever you like; its position and size are remembered for next time. The original tab shows « Dashboard ouvert dans sa fenêtre » (with a button to bring it back or to the front). Chrome must **allow pop-ups** for remote.op0p.be.
- **Install it as an app** (Chrome, Edge): `⤓ Installer` button in the top bar (or the install icon at the right of the address bar). Remote Station then gets its **desktop icon** and Start-menu entry and always opens in its own window. The button disappears once installed; to uninstall: ⋮ menu of its window → Uninstall.
- On the front-panel page (/ftdx101), **band maps** on each side of the TRX: VFO A's band on the left, VFO B's on the right (cluster spots around the VFO frequency; − / + (or Shift + wheel): range 5 to 200 kHz, or the whole band of the VFO (default: all the band's spots); when the calls do not fit, a **scrollbar** appears and the wheel scrolls the list (the VFO is kept in view, except for 15 s after you scroll by hand); in SPLIT both maps switch to ±10 kHz around their VFO; click a call: that VFO goes there; under the band name, ALL · FT8/4/2 · SSB · CW · RTTY shows only the spots of that mode, click again for all).
- On the front-panel page (/ftdx101), the digital modes have their own page: `📟 Numériques` button in the top bar (`✕ Fermer` closes it).
- The `⧉` button to the right of the tabs opens **all the digital modes** in a separate window. `⧉ Ramener dans le dashboard` (bring back into the dashboard) (or `Ramener ici` (bring back here) in the dashboard) puts them back.
- The `Space` bar (PTT) also works from a separate window.
- The layout is remembered: on the next load, the windows reopen in place if Chrome **allows pop-up windows** for remote.op0p.be (icon at the right of the address bar → Always allow).
- **Collapse a panel**: click its title (or `Enter` when the title has focus); a second click reopens it. Remembered in this browser.
- **Size of the whole dashboard**: `Auto 100 %` menu in the top bar (section 5), from 50 to 200 %.
- **Drag handles** (double-click: original size, remembered in this browser): under the waterfall (height of the waterfall and lists), between the two FT8 lists and between the two RTTY decoders (widths), on the left edge of the band map (its width), on the right edge of the logbook column titles (column widths).
- **Band map**: on a 1920 × 1080 screen or larger, it is a column of its own, **far right**, full height (the RX audio / DSP / Tuner / TX column sits just to its left). It only appears on tabs with spots (FT8 · FT4 · FT2, JT65, RTTY, WSPR, JTTY, CW). On a smaller screen it stays at the right edge of the centre window.

<a id="face"></a>
### 11.1 FTDX101 front panel (separate page)

Address: **https://remote.op0p.be/ftdx101**. The FTDX101MP front panel, where **each key and knob does the same as on the TRX**, with the **digital modes** below it (FT8, RTTY, WSPR, JT65, JTTY, CW, SSTV, Synchro) as in the dashboard. Same login, same `Prendre la main` button, same safety rules. Only useful when the FTDX101 is the TRX in service.

**FTDX5000** (trial): **https://remote.op0p.be/ftdx5000** (digital modes: **/ftdx5000/digi.html**). The picture is the front panel drawn by Yaesu's PCC-5000 software. Its display follows the radio live: VFO-A frequency, clarifier, MAIN and SUB ANT / ATT / IPO / AGC values, TX, mode, BUSY, NAR, FAST, LOCK, NB, MONI, KEYER, BK-IN, PROC, TUNER, HI-SWR boxes; VFO-B display and the small filter displays (BW, SHIFT). Under the front panel: on the left, an **enlarged replica of the display**, laid out like the radio's: **VFO-A** (MAIN) at the top, the VFO-B S-meter bar in the middle, **VFO-B** (SUB) at the bottom; for each, every ANT / ATT / FLT / IPO / R.FLT / AGC value is listed and the radio's one lights up in yellow, and the status grid on the right (TX, LSB, USB, CW, BUSY, AM, FM, NAR, FAST, RTTY, PKT, LOCK, NB) lights up in white (TX in red); top strip: VFO-A (large) and VFO-B frequencies, clarifier, active VFO name lit; FLT (VRF / μ-T) and R.FLT stay dark (no CAT command), on the right the page screen (meters, frequencies, received-audio scope; CENTER, SPAN, 3DSS, MONO, MULTI, EXPAND, HOLD keys at the bottom; no DISP key on the FTDX5000: normal layout, even if another front panel was left in « enlarged filters »). The scope and waterfall come from the received audio sent by the Station page: nothing in simulation without an audio input chosen. The `MENU` key opens the FTDX5000 settings (RF POWER, MIC GAIN, PROC, MONI, VOX GAIN / DELAY, KEY SPEED, CW PITCH, NB, DNR, SQL, STEP DIAL); its numbered menu 001-176 stays at the club. Two receivers: `A` / `B` keys = VFO of the main dial, **CLAR/VFO-B** knob = VFO-B frequency (or clarifier offset with RX CLAR / TX CLAR), `RX` under the VFO-B display = dual receive, `TX` = transmit on VFO-B (SPLIT). Under each VFO, the knob sets SHIFT (centre) and WIDTH (ring); MIC ◎ RF PWR, SPEED ◎ PITCH, VOX ◎ DELAY, MONI ◎ PROC, NB ◎ SQL and AF ◎ RF GAIN as on the radio. Keys without a CAT command (VRF, CONT/APF, R.FLT, TXW, memories…) show an explanation. Picture: Yaesu PCC-5000. The function screen (RF POWER, MIC GAIN…) opens and closes with the front-panel **MENU** key or the **MULTI** box at the bottom right of the screen; the keyboard Esc key also closes it. The **ANT**, **ATT**, **IPO**, **R.FLT** and **AGC** keys act on the VFO chosen with the A / B keys (VFO-A = MAIN, VFO-B = SUB), as on the radio. **A ► B** (copies VFO-A into VFO-B) and **A ⇄ B** (swaps the two VFOs) keys, as on the radio. In TX, the **TX** indicator under the display becomes a bright red box with bold white text. **CONT/APF** of each VFO: CONTOUR ON / OFF (in CW: APF ON / OFF; CO command of the manual, only one of the two at a time), key lit when on; press for at least 1 s: CONTOUR frequency (100 – 4000 Hz, − / + or mouse wheel); also in the dashboard for both VFOs. **R.FLT** (roofing filter, RF command of the CAT manual): the R.FLT key steps AUTO → 15 kHz → 6 kHz → 3 kHz → 600 Hz → 300 Hz (MAIN; 600 and 300 Hz are optional filters); the display lights the filter in use for VFO-A and VFO-B (in AUTO too), the screen's R.FLT box and the dashboard show and set it (VFO-B: AUTO, 15k, 6k, 3k).

**FTDX10**: same idea at **https://remote.op0p.be/ftdx10** (digital modes: **/ftdx10/digi.html**). The FTDX10 has **a single receiver**: one S-meter, VFO-A large and VFO-B small (greyed), ATT / IPO / R.FIL / AGC cells, the filter (WIDTH, NAR, R.FIL 12k / 3k / 500 Hz, IF SHIFT, NOTCH, CONTOUR) and the audio scope; no MAIN / SUB, DISP, MONO or dual receive. **BAND** opens a band table on the screen; **A/B** swaps the VFOs (hold: A → B); **STEP/MCH** = fast tuning; **FINE** = 1 Hz per notch; **CONT/APF** = CONTOUR, or APF in CW; **VOX/MOX**: click = VOX, hold = MOX; the **FUNC** knob adjusts the function shown right of VFO-B (click the knob or that box for the FUNC menu).

**FTX-1** (Field head with the Optima amplifier): **https://remote.op0p.be/ftx1** (digital modes: **/ftx1/digi.html**). Same screen as the FTDX101 front panel (two receivers), but as on the radio the **SUB is on the left** and the **MAIN on the right**; cells ANT, ATT, IPO, NAR, AGC; bottom row CENTER, 3DSS, MULTI, SCOPE (scope settings), SPAN, SPEED. Keys: BAND, N/W MODE (short press: NARROW ⇄ WIDE on the active receiver; hold 1 s: mode list), SPLIT (FTX-1 virtual split), CLAR, DISP, BACK, FINE/FAST, LOCK; BUSY/TX SUB / MAIN LEDs. Knobs: main dial, **SUB DIAL** (VFO B frequency; click: active VFO MAIN ⇄ SUB, in dual receive only), FUNC (hold 2 s: the TRX FUNC screen, 3 pages; turn FUNC to move the orange frame, push FUNC to adjust the item, push again when done; hold 2 s to exit), SUB and MAIN AF/RF. Frequencies with the last 3 digits (Hz) smaller and filters drawn as on the radio (white outline, grey inside). **SPAN** (5 kHz to 1 MHz) is read from and sent to the radio; the radio's scope data is not available over CAT, so in CENTER, when the SPAN is wider than the received audio, the page shows that audio (3 kHz) across the full width with its own frequency scale (« son reçu : 3 kHz » top right); in CURSOR / FIX it shows the whole SPAN window, the green ▼ can be anywhere and follows the mouse when dragging with the left button; the right button (click or drag) sets the red TX line on the other VFO and turns SPLIT on if needed; in SPLIT, as on the radio: in CURSOR / FIX the page uses the real SPAN window, fixed, with red ▼ at the TX frequency and green ▼ (listening) moving across it with the main dial; in CENTER only the red TX line moves; a « SPLIT » badge (black on white, blinks twice) appears next to FAST / FINE; **click (or drag) on the spectrum or waterfall**: that VFO goes to the clicked frequency (hover shows it), as when touching the radio's screen. ATT / IPO of the SUB: the FTX-1 CAT only reads and sets them on the side in use (« — » until SUB has been the active side). Page 3 (FM/C4FM): SQL TYPE in all modes, TONE FREQ and DCS in FM, **DTMF** screen (memories 1 to 10, read and editable). **RADIO / CW / OPERATION / DISPLAY / EXTENSION / APRS SETTING** and **APRS BEACON** menus, laid out as on the radio, are **for administrators only** (ON6DP, ON4LUC): values read from the radio and re-read every 8 s, click a setting to see all its values, then − / +, wheel or FUNC; DATE&TIME can be set from your PC clock; PRMTRC EQ items open EQUALIZER TRX. Still locked even for administrators: CAT-1 / CAT-3 link, MOD SOURCE, USB MOD GAIN, RPTT SELECT, PC KEYING, CW MEMORY 5, TX equaliser (profiles), AUTO POWER OFF. Band maps in the same order as the screen: VFO-B (SUB) on the left, VFO-A (MAIN) on the right. **🎧 Stereo MAIN | SUB**: DUAL RX, MAIN in the left ear and SUB in the right ear (the FTX-1 sends both receivers in stereo over USB).

**IC-7300**: **https://remote.op0p.be/ic7300** (digital modes: **/ic7300/digi.html**). Single receiver, same screen as the FTDX10 with Icom settings: ATT, P.AMP, FILTER (FIL1/2/3), AGC; the drawn filter follows FIL1/2/3 and the **TWIN PBT** (centre = inner PBT, ring = outer PBT, click = CLR). **MENU** = the IC-7300 MENU screen (2 pages; VOICE becomes KEYER in CW, DECODE in RTTY), **FUNCTION** = Icom function screen, pushing **MULTI** = MULTI menu of the mode (RF POWER, MIC GAIN, COMP, MONITOR; CW: KEY SPEED, CW PITCH), click the mode on the screen to change it, **M.SCOPE** = expanded scope, **QUICK** = QUICK MENU (BAND, SPLIT, A=B…), **EXIT** closes it, **▼ ▲** = previous / next band, **A/B** swaps the VFOs (hold: A = B), **TRANSMIT** = latched TX.

**IC-7760** (trial): **https://remote.op0p.be/ic7760** (digital modes: **/ic7760/digi.html**). Photo of the control head (Icom). Screen as on the radio at power-on: on the left the **ANT, P.AMP, ATT, DIGI-SEL, IP+, AGC, COMP** key column (selected receiver; click to change; cyan bar on the key's right edge = on, grey = OFF, as on the radio; **hold AGC for 1 s**: **AGC** time-constant table (SSB, CW, RTTY, PSK, AM, FM × FAST, MID, SLOW) — the current mode / FAST-MID-SLOW cell is highlighted, the **main dial** (or the wheel on the cell) changes it, **DEF** restores the factory value, ↩ or EXIT close it; other modes are set when the radio is in them (until read, their cells show the factory values); **hold DIGI-SEL for 1 s**: MULTI column with DIGI-SEL selected — the MULTI knob tunes the DIGI-SEL (marker on the slider), a short click on an already selected cell turns its function ON / OFF (DIGI-SEL, COMP, MONITOR); in SSB the COMP cell only shows when COMP is on; in CW / RTTY / PSK the 7th key becomes **1/4**: main dial 4 times slower, 25 Hz per notch). At the top of each half: **bar S-meter** (S · 1 · 3 · 5 · 7 · 9 · +20 +40 +60dB; Po 0 – 200 W in TX) and **SWR** below, as on the radio's main screen; the **needle meter** (S, Po, SWR, COMP) is in the right-hand **small screen** with « MET Po » and the date; the **SUB DISP** key cycles the needle meter, the **filter** ([MAIN] [BW] [SFT], FIL, SHARP / SOFT, MN keys) and **band keys** (**TWIN-PBT**: the outer ring sets the width (BW), the inner knob the shift (SFT) of the selected receiver; a BW / SFT box with the filter drawing and the passband edges in orange shows for 2 s on the main screen, on the left for MAIN and on the right for SUB; BW and SFT are the same in the header, the small screen and the box while turning; the small white LED right of the knob lights as soon as the passband is shifted or narrowed; pushing the knob (CLR) centres both and turns the LED off; needle meter: S, Po, SWR, COMP, ALC and Vd as on the radio; clicking it opens the **METER** window — Po, SWR, ALC, COMP, Vd or Id = what the needle shows in TX (“MET Po”…), **Multi-function** = S/Po, ALC, COMP, SWR and Id bars in the small screen (clicking the bars: METER window with **OFF** = back to the needle meter); the back arrow closes the window; the filter: grid, spectrum and **waterfall of the received audio** inside the passband, passband edges in orange, e.g. 0 · 1500 · 3000 for 3.0 kHz; touching the small screen shows FIL, SHARP / SOFT and MN, hidden again after 10 s) (1.8 … 50, GENE, F-INP) of the selected receiver. **Click ANT, BW or SFT** at the top of a VFO: settings window for that receiver — ANT 1 to 4 and RX ANT; FIL1 / FIL2 / FIL3 and width (main dial, wheel or − / +); SFT: both PBT together, CLR to centre. If the screen shows « TRX muet : RF deck alimenté et relié à la tête ? », the radio does not answer: at the club, check the RF deck (the large box) is powered and connected to the control head, then restart the IC-7760 (it shows « The RF deck is not detected »). **RFG** (orange): that receiver's RF gain is not at maximum — turn the outer ring of AF-RF/SQL (usually around 12 o'clock) until RFG disappears. Front-panel LEDs: POWER blue when the radio is linked to the station, small white LED in TUNER when the tuner is on, in NB, NR, APF/TPF and NOTCH when the function is on (selected receiver), blue LED in VOX/BK-IN when VOX (phone) or BK-IN (CW) is on; TX/RX next to AF-RF/SQL: green while receiving (SUB: with DUAL-W), red for the transmitting VFO, the other stays green if it receives (SPLIT or DUAL-W). **Click a kHz or Hz digit** of a frequency: small **▼** above it — the main dial and the wheel (over the frequency) then change that digit (100 kHz, 10 kHz, 1 kHz…); click the same digit again: ▼ removed; **hold the MHz digits 1 s**: ▼ on MHz (1 MHz steps). **Click the MHz digits**: **BAND STACKING REGISTER** (1.8 … 50, GENE: last frequency and mode used on that band, remembered by the page in this browser) and **F-INP**: the radio's keypad (PC keyboard works too; orange « F-INP » next to FIL while typing) — « 14.074 » then ENT; SPLIT puts the typed frequency on SUB and turns SPLIT on; MEMO is not remote. **Click a VFO's mode**: **MODE** window (SSB — LSB below 10 MHz, USB above —, CW ⇄ CW-R, RTTY ⇄ RTTY-R, PSK ⇄ PSK-R, AM, FM, DATA = USB-D1 even below 10 MHz); it closes as soon as a mode is chosen. ↩ or EXIT close these windows. **Scope**: a click opens a **magnifier** (×3) around the clicked point, a click inside it puts that scope's VFO on that frequency, a click elsewhere closes it; mouse button **held and dragged**: the frequency follows the mouse. **DUAL-W** also sets the scopes to DUAL; without DUAL-W, **one scope** (the current VFO's) and the radio's single-scope screen: needle meters at the top (SUB greyed), larger frequencies, filter in the small screen. With two scopes: bar S-meters and the needle meter in the small screen. MULTI column in CW: RF POWER, KEY SPEED, CW PITCH, DIGI-SEL, SIDETONE; in RTTY / PSK: RF POWER, DIGI-SEL, MONITOR., then MAIN on the left and SUB on the right, each with its **ANT · BW · SFT** header (AN / MN), « MET Po », its meter, **TX** and power, « **VFO [mode] [FIL]** » (click the mode: mode table; FIL: next filter) and the large frequency; **DUAL-W** / **SPLIT** in the middle; below, the **SPECTRUM SCOPE**: the **radio's own scope** (sent over CI-V) — in **DUAL**, MAIN on top and SUB below, each with its waterfall, an **orange** frame around the active VFO's one, « CENTER MAIN » / « FIX SUB »; click in a scope = that VFO to the clicked frequency (without the radio's scope: the received audio). Row **<MENU1> · SPAN (EDGE in FIX) · HOLD · CENT/FIX · MAIN/SUB · DUAL · EXPD/SET**: blue keys as on the radio (front-panel **MENU** key: the radio's MENU screen — SCOPE, AUDIO (M.SCOPE screen), VOICE / KEYER / DECODE, **METER** (MULTI-FUNCTION METER under the shortened scope: S, Po, ALC, COMP, SWR, Id, SUB S, Vd — TEMP cannot be read over CI-V; P-HOLD: peak hold; the **M.SCOPE** key cycles “scope + MULTI-FUNCTION METER” → “METER only” → “scope only”; under the waterfall, frequencies in MHz in CENTER too (14.28 · 14.30 … for ±50k), spacing following the SPAN, and ±SPAN at the top left and right; **MAIN** / **SUB** keys: the white curved band above the main dial shows the selected receiver; red **NOTCH** box right of SFT in the header of the VFO whose manual notch is on; **scope header** as on the radio, with the settings read back from the radio for the selected receiver: M (Max Hold), S, T (Scope during Tx), HOLD (white when on), speed ▸▸▸ / ▸▸ / ▸ (FAST / MID / SLOW), RBW and VBW (bright blue when RBW is not WIDE or VBW is WIDE), CENTER / FIX / SCROLL, MAIN (red) or SUB (blue), “Grid 5k/10dB” (grid step); 1-second press on **<MENU1>**: **<MENU2>** row — REF (mouse wheel on the key: ± 0.5 dB, 1-second press: 0 dB), SPEED (FAST / MID / SLOW), RBW (WIDE / MID / NAR), VBW (NARROW / WIDE), MARKER — another 1-second press goes back to <MENU1>; 1-second press on **EXPD/SET**: **SCOPE SET** (3 pages in radio order: Scope during Tx, Max Hold, CENTER Type Display, Marker Position, Averaging, Waveform Type, colours (same R / G / B window), Waterfall Display / Speed / Size / Peak Color Level / Marker Auto-hide, Dual Scope Type, Dual Scope Auto Select, Fixed Edges of the current range); a 1-second press on the main-screen meter scale (bars or needles) shows the MULTI-FUNCTION METER alone, and **M.SCOPE** (or another 1-second press) goes back to the previous screen; EXIT does not change that screen: leaving MENU, SET, ANTENNA or FUNCTION brings you back to the screen chosen with M.SCOPE, as on the radio), SWR (read in TX), **ANTENNA** (under the shortened scope: ANTENNA MEMORY = antenna 1 – 4 for each of the 12 frequency ranges, the current range in light blue, click = next antenna; [ANT] Switch Manual / Auto; TYPE ANT1 – ANT4, RX-ANT and external tuner (EXT) read-only; Temporary Memory; ANT, RX-ANT, ANT MR, ANT MW, TEMP-M, [ANT] SW, TYPE keys; ANTENNA MEMORY, TEMP-M and [ANT] SW settings are admin-only; leave with ↩ right of the title or EXIT); **FUNCTION** key: FUNCTION panel under the (shortened) scope, as on the radio — APF (CW only), NOTCH, NB, NR, TRACKING / VOX (BK-IN in CW), TBW, MONI, DPD; click: next value or ON / OFF, blue frame = on; FUNCTION or EXIT closes it. **Manual NOTCH (MN)** on: MN box next to FIL, FUNCTION NOTCH key « MN (WIDE) », **NOTCH** column on the right — POSITION with the MULTI knob (or wheel), WIDTH: click WIDE → MID → NAR; in the small screen (filter), orange « N » marker at the notch position and 300 · 1500 · 2700 Hz scale. **NB** and **NR** (front-panel or FUNCTION keys): short click = ON / OFF; **hold at least 1 s** = settings column on the right — NB: LEVEL, DEPTH 1 – 10, WIDTH 1 – 100; NR: LEVEL 0 – 15; click a cell then turn MULTI; NB / NR off: the column closes. **SET** → **Tone Control/TBW**: RX (SSB, AM, FM, CW, RTTY, PSK: RX HPF/LPF, RX Bass, RX Treble) and TX (SSB: TX Bass, TX Treble, TBW WIDE / MID / NAR; SSB-D: TBW; AM, FM: TX Bass, TX Treble) — click a setting: window with + / − (or the main dial, or the wheel), ↩ or EXIT sends the value to the radio and the list shows it; ↩ goes up one level; **Display** (3 pages, radio order: LCD Backlight, LED Bright, Display Font, Meter Response, Meter Type, Meter Peak Hold, Memory Name, Filter Effect Screen (Waveform Type: Line = white line over the small-screen spectrum, Fill = spectrum only; Waveform Color: R / G / B window with − / + and the main dial, selected value on a blue background; the small-screen spectrum takes that colour), Screen Saver, External Display and its resolution, Opening Message; My Call and Display Language read-only); a list setting opens a **choice window** (current value in light blue): one click chooses, the window closes and you are back in the settings, as on the radio; **Others → Information**: Version (firmware versions noted on the club radio on 11/11/2026, not readable over CI-V: update after a firmware update), MAC addresses and serial numbers not readable over CI-V (so not shown); **DPD Adjustment**: the three procedures (IC-7760 Single, IC-PW2 200 V / 100 V) are listed, to be done at the radio; **Network**: read-only, admins only, addresses greyed when DHCP is ON, Different Segment Settings (RF deck IP, mask, gateway and audio buffer), never changed remotely (it would cut the link between the head and the RF deck) (DHCP, IP addresses, mask, gateway, DNS, Audio Buffer Size, Different Segment, Network Name; Remote Settings not remote); SD Card, USB Flash Drive and DPD Adjustment are not remote, the other SET items will follow; MEMORY, SCAN, MPAD, RECORD and PRESET greyed: not remote yet; only names row MENU 1; row MENU 2 is not on the page yet). SPAN / EDGE, HOLD and CENT/FIX set the active VFO's scope on the radio, as on the IC-7300: SPAN (in CENTER) sets the width, EDGE (in FIX) picks edges 1 to 4, HOLD freezes the scope, CENT/FIX switches CENTER / FIX (long press: SCROLL-C / SCROLL-F). MAIN/SUB changes the active VFO, DUAL switches between one and two scopes. With the MULTI column open, EXPD/SET disappears and the column's ↩ key closes it. The small right-hand screen shows the selected receiver's filter (width, TWIN PBT, NOTCH). `MAIN` / `SUB` keys above the main dial: receiver of the main dial; `NB`, `NR`, `NOTCH` (OFF → AN → MN), `APF/TPF`, the **TWIN PBT** knob (push: CLR) and the `FIL` key of the small screen act on the selected receiver, as on the radio. **MAIN AF ◎ RF/SQL** and **SUB AF ◎ RF/SQL**: volume and gain of each receiver. `CHANGE` swaps MAIN and SUB (1 s press: MAIN = SUB), `DUAL-W` dual receive, `SPLIT` transmits on SUB, `XFC` listens on the transmit frequency while held. `RIT` / `ΔTX` / `CLEAR` and the **RIT/ΔTX** knob for the offset. Below the screen: `MENU` = mode table, `FUNCTION` = Icom FUNCTION screen (P.AMP, ATT, AGC, NOTCH, NB, NR, DIGI-SEL, IP+, APF, VOX/BK-IN, COMP, TBW, MONI, TRACKING, DUAL-W), **MULTI** knob pushed = MULTI column on the right of the screen (RF POWER, MIC GAIN, COMP, DIGI-SEL, MONITOR; in CW KEY SPEED and CW PITCH instead of MIC GAIN and COMP): click a box then turn the MULTI knob (the value changes), `↩` to leave, `M.SCOPE` = multi-function screen (scope, oscilloscope, AF-FFT), `QUICK` = band table, `EXIT`. Small screen: selected receiver, filter width, filter drawing, FIL, APF, AN / MN.

- **Band keys** act on the active receiver (MAIN or SUB); white LED under = MAIN band, blue above = SUB band. **MAIN / SUB**, **MAIN/SUB** choose the receiver (the chosen key is lit as on the TRX: MAIN white with black text, SUB blue). **RX** SUB = dual receive; **TX** MAIN / SUB = transmit VFO. SPLIT on: transmission moves to the VFO that is not selected (MAIN selected → TX SUB; SUB selected → TX MAIN); SPLIT off: it returns to the selected VFO; **MAIN⇆SUB** swaps (hold 1 s: copy MAIN → SUB).
- **MODE**: next mode; **hold at least 1 s**: the table of all modes, click the one you want. **SSB**, **CW** (switching to CW from another mode turns BK-IN on; BK-IN can then be turned off or on again without changing mode), **BK-IN**, **SPLIT**, **CLAR RX / TX**, big **CLAR** (hold: offset to zero), **LOCK**, **FAST** (1 kHz per notch) / **FINE** (1 Hz per notch).
- **NB DNR DNF NOTCH CONT APF**: top row SUB, bottom row MAIN; NB / DNR: short click on / off, hold at least 1 s: « NB LEVEL » / « DNR LEVEL » box on the screen (− / + or wheel). **Knobs**: wheel or drag; dual knobs: centre = inner knob, edge = ring; SHIFT ◎ WIDTH: WIDTH 300–4000 Hz in SSB with the default width in the middle, SHIFT −1200 to +1200 Hz; small orange LEDs above when not at default; hold the centre at least 1 s: SHIFT 0 and default WIDTH; the screen filter follows the width.
- **MULTI**: clarifier offset when CLAR is on, otherwise the function shown in the last box of the screen (« MULTI RF POWER » at first), chosen in **FUNC**. **FUNC** opens the function menu in the screen, used with the mouse: click a box (red frame), then click **−** (left of the box) or **+** (right), wheel over it or turn MULTI (RF POWER, MONI LEVEL, DNR LEVEL, NB LEVEL, VOX GAIN, VOX DELAY, ANTI VOX, R.FIL, MIC EQ, STEP DIAL, and in FM RPT, ENC/DEC, TONE FREQ of the selected VFO, read from the TRX; SPEED, PEAK, MARKER, COLOR, LEVEL for the page waterfall and, with control, the TRX scope (MAIN or SUB, selected side; changes made at the club are followed by the page); SPAN too (1 kHz to 1 MHz on the TRX, the page showing received audio, 5 kHz max). RADIO / CW / OPERATION / DISPLAY SETTING open the **TRX menus** as on its screen (sub-menus on the left, settings with their value read from the TRX on the right; click a setting then − / +, wheel or MULTI, with control: written to the TRX and read back; greyed settings are read-only). EXTENSION SETTING: at the club only. Grey boxes: not available remotely (memories, SCAN, DECODE, REC/PLAY). As on the TRX, some boxes grey out depending on the selected VFO's mode: RPT, ENC/DEC and TONE FREQ outside FM; MIC EQ in CW, DATA, RTTY and PSK; DECODE in FM.
- Below the panel, on one line: the big **PTT** button (hold, or the space bar) and **👁 Suivre l'opérateur**; below, the **MODES** row. Remote phone settings (microphone, audio input / output, equalisers, M'écouter, operator profile) are in the **TRX SSB** page, as from the dashboard, so the whole front panel fits on the screen (its width follows the window height). **MOX**: latched transmit (click: TX, next click: RX). **MONI**: hear your own modulation (« M'écouter », headphones; microphone on first). **Band map**: full-height column on the right.
- **TUNE**: tuner on / off; hold at least 1 s: tune (after confirmation). **VOX** (can only be switched off), **PROC**.
- **PHONES** jack: listen. `🎧 Stéréo MAIN | SUB`: switches dual receive on, then MAIN in the left ear and SUB in the right ear (handy in SPLIT with a headset).
- **Screen**: meters (S MAIN / SUB; TX: PO, SWR) with each receiver's filter (in CW, below the filter, the tuning indicator « − … + » as on the TRX: red mark in the middle = the pitch, small grey line = the strongest signal within ± 200 Hz; line in the middle (white) = tuned, it stays in the middle when transmitting; NOTCH on: a dip in the passband at its frequency; CONT on: a small shallow blue « V » at the top of the filter at the CONTOUR frequency, following the CONT knob (the deep dip is the NOTCH), as on the TRX), frequencies (click to type), ANT / ATT / IPO / R.FIL / AGC (click: next value), and instead of the TRX scope (not sent over CAT) the **spectrum and waterfall of the received audio**, MAIN | SUB side by side in dual receive (FAST: also switches the FTDX101's FAST key on the selected side, MAIN or SUB; LED read from the TRX); each part runs from 0 to the top of its filter passband (within the SPAN) so it fills its whole width; in the small filters next to the S-meters the spectrum is drawn on the filter scale. The **MULTI** box at the bottom of the screen shows, as on the TRX, the selected VFO's scope with an **OSCILLOSCOPE** (10 ms/div) and an **AF-FFT** (0–4 kHz with waterfall) below; click again to go back. Bottom row: SPAN (2 to 6 kHz), MONO (as on the TRX: a single VFO on screen, the selected one — meter left, large filter right, frequency, full-width boxes, one scope; MONO shown in blue; click again: MAIN and SUB), EXPAND (as on the TRX: meters reduced to their top part, flattened filters, frequencies moved up and larger scope; EXPAND shown in blue; click again: normal display), MULTI (FUNC menu), HOLD (freeze). Top right: **👥** and the number of connected members; click: their callsigns (connection IP address for administrators), who has control, and **messages** between members (🔔 beep and red dot when a message arrives), as in the dashboard; next to Take / Release control, your callsign (and the controller's if someone else). **👁 Suivre** (follow the operator, for remote training; below the front panel, right of Profil de …, greyed out for the one in control): your front panel shows the same screen as the operator (DISP, MONO, EXPAND, MULTI, 3DSS, FUNC menu); it turns on by itself when another member has control; one of those keys stops it, a click on 👁 Suivre restarts it. In the 📟 Digital page, the button of the same name follows the digital-mode tab. Above SSB CONFIGURATION, the **MODES** line (FT8/FT4/FT2, SSB, RTTY, WSPR, JT65, JTTY, CW, SSTV): SSB opens TRX SSB, CW opens TRX CW, the others open TRX DIGI (/ftdx101/digi.html) on that mode, or switch it there if already open. Right after: **DX Cluster**, as in the dashboard: opens dx.op0p.be or cluster.op0p.be in its own window linked to the TRX (click a spot: the selected VFO goes there, with control); « open automatically at each connection » box (opens on the first click in the page). The server's cluster spots always reach the band maps.
- **Front-panel digital modes**: the **MODES** row opens **TRX DIGI** (digital modes page, /ftdx101/digi.html) on that mode (SSB: TRX SSB; CW: TRX CW); the mode shown there is lit in light blue. On that page: **LOGBOOKS** opens the station log in its own window (entry, list, sync to LoTW / eQSL / Club Log / QRZ, ADIF or Cabrillo export; all QSOs go to the same station log), **SYNCHRO** (FT8 / FT4 / FT2, WSPR, JT65 only), **Follow the operator** (same as the front-panel FOLLOW button), and in every mode's top bar the **TX call** choice (fluo yellow). Announcements are fluo yellow and blink for 1 s. Hover a call to see its DXCC country, distance and bearing.
- **FT8 / FT4 / FT2 on MAIN and SUB**: with DUAL RX on, both receivers are decoded at once: two waterfalls side by side (VFO-A · MAIN left, VFO-B · SUB right) with each VFO's frequency large — on red with « TX » for the transmitting VFO — and its mode; four columns (band activity and RX frequency for each VFO) separated by a grey line, each with its own scrollbar. Each waterfall has its RX / TX marks (the TX flag is blue on the VFO that doesn't transmit), **mouse-wheel zoom** (down to 300 Hz; the same for both waterfalls, so both VFOs show the same width), its own settings and a height grip. Double-click a message (or click its call) in a VFO-B column: the reply goes out on SUB; in a VFO-A column, on MAIN. The **TX VFO-A / VFO-B** buttons show and change it and follow the TX VFO chosen on the TRX. Two band maps: VFO-A on the left, VFO-B on the right, each with its own filters and scrollbar. Same in the **TRX DIGI** page opened from the **dashboard** (FTDX101 with DUAL RX): both VFOs may be on different bands, each band map shows its own VFO's band. DUAL RX off, or a single-receiver rig (FTDX10, IC-7300…): one waterfall, two columns and one band map.
- **JT65, WSPR, JTTY on MAIN and SUB**: same layout as FT8 in DUAL RX — two waterfalls side by side, VFO-A decodes on the left and VFO-B decodes on the right (WSPR: stations heard by each receiver; JTTY: activity and RX frequency of each VFO; double-click a VFO-B message to transmit on VFO-B), two band maps.
- **CW on MAIN and SUB**: FTDX101 in DUAL RX — two separate CW receivers: two waterfalls and two receive panes, each with its own filter, squelch, level, tone and speed. Click a waterfall to lock onto the nearest signal, hold the left button to drag the marker. Double-click a received callsign: it becomes the DX station and transmission moves to the VFO it was heard on.
- **CW zoom and TRX filter**: mouse wheel on a CW waterfall zooms around the pointer (down to 200 Hz wide). The two light-blue bars show that VFO's TRX filter (WIDTH or NAR) centred on the CW pitch, following the TRX. With control: drag a bar, or Ctrl + wheel on the waterfall, to set the TRX bandwidth.
- **RX MAIN / RX SUB (FTDX101 front panel)**: like the TRX RX keys — RX MAIN mutes or restores the MAIN receiver (e.g. to listen to SUB only), RX SUB switches DUAL RX on or off. Green LED = receiver on.
- **RTTY on MAIN and SUB**: two decoders, one per receiver, each with its waterfall and band map. Each decoder header shows the **VFO frequency large, as on the TRX** (red « TX » for the transmitting decoder) and the tracked signal frequency small. Decoders start on **1500 Hz**. The **frequency scale** above each waterfall **tunes the VFO** (wheel: 10 Hz per notch, 50 Hz when spinning fast; or drag), across the whole band, while the decoder marks stay put; set the marks **inside the waterfall** (click / drag; wheel there = zoom), as in FLDIGI and MixW. Height grip under the decoding windows. Default squelch 9 dB (about −6 dB SNR in 3 kHz).
- **RTTY macros and contests**: 12 personal macros (F1–F12, saved on the server under your call; right-click or ✎ to edit). **F11 « TX »** sends the typed text, **F12 « RX »** returns to receive. The editor lists the macro tags (FLDIGI standard fields) by group with help on hover and a preview. **Contests**: contest list taken from N1MM Logger+, editable exchange (<EXCH>), name, CQ / ITU zones, **serial number** (advanced by the TU macro once per station; −1 / +1 / ↺ 001), and a second row of 12 contest macros on F1–F12 when a contest is chosen. The QSO form keeps sent / received exchange and contest for Cabrillo.
- **SYNC** (LED on): SUB takes the MAIN frequency and the main dial then tunes both receivers together; click again: off. **KEYER**: CW electronic keyer. Clicking the **MIC/SPEED ◎ PROC** knob without turning: KEYER in CW, PROC in SSB (LED on; click again: off).
- Finer spectrum (2048-point analysis, each column keeps the strongest peak).
- **Band map**: right-hand column, full height. Its `⧉` button moves it into **its own window** (another screen, any size); `⧉ Ramener` or closing the window brings it back. Reopened on the next page load if Chrome allows pop-ups for the site.
- **Digital modes**: the `⧉` button at the end of the tabs opens them in their own window (with their band map, same connection); `⧉ Ramener sous la face avant` brings them back.
- **CONT/APF** ring around the NOTCH knob: CONTOUR frequency (10–3200 Hz); in CW with APF on: APF frequency (−250 to +250 Hz). Hold the NOTCH centre at least 1 s: NOTCH 1500 Hz, CONTOUR 1000 Hz, NOTCH / CONT / APF off. LEDs above SYNC, SPLIT, CLAR RX / TX, FAST, LOCK light orange when on. PROC only in SSB / AM on the transmit VFO.
- **PROC** / **KEYER**: bright orange LED above the MIC/SPEED knob while the processor (SSB) or keyer (CW) is on; click again: off.
- **DISP**, as on the transceiver, one click after another: MAIN waterfall → SUB above MAIN → MAIN | SUB side by side → enlarged filters (each receiver's width and shift with its audio spectrum) → back. To see SUB: `🎧 Stéréo MAIN | SUB`.
- **VC TUNE**: the small key switches the preselector of the active receiver on / off (orange LED, off when stopped). The large VC TUNE key, independent, makes the **outer ring** of the main dial tune the preselector (LED to its left); click again: the ring tunes the frequency of the **other receiver** than the selected one (SUB selected → VFO A, MAIN selected → VFO B). As on the TRX, a red « − … + » bar above the filter shows the preselector position.
- **S.MENU**: the **SCOPE MENU** as on the transceiver, over the top of the waterfall: SPEED, PEAK (peak hold OFF / LV1 … LV3), MARKER (filter passband and centre marker), COLOR, LEVEL (click left −, right +, or wheel). Closes by itself 3 s after the last action.
- No effect remotely (a message explains): ON/OFF, ZIN/SPOT, QMB, C.S, memories.

<a id="numeriques"></a>
## 12. Digital modes

The centre tabs: **Modes**, **FT8 · FT4 · FT2**, **RTTY**, **WSPR**, **JT65**, **JTTY**, **CW**, **SSTV**, then **Logbooks**, the `Log QSO` button and **Synchro**. With control, clicking the tab of a digital mode (FT8 · FT4 · FT2, RTTY, WSPR, JT65, JTTY, SSTV) puts the TRX in **DATA-U** (USB-D on the IC-7300) on the VFO being received, even below 10 MHz; the **CW** tab puts it in CW (CW-L below 10 MHz, CW-U above; CW-R / CW on the IC-7300), unless it already is. On the right of the FT8 · FT4 · FT2, RTTY, WSPR, JT65, JTTY and CW tabs, the **band map** shows the DX cluster spots (see 12.3, « Band map »). You have **no software to install** (no WSJT-X, FLDIGI…): everything happens in the page.

- **Decoding runs on the server**, on the server's (synchronised) clock: the time on your PC and on the club PC does not matter.
- The TRX audio is only sent while someone is listening or watching a digital-mode tab: decodes start a few seconds after the tab is opened.
- **Frequency list** (at the top of each tab): choosing a line sends the TRX to that frequency, in **DATA-U** (in CW for the CW tab). You need control. The `↺` button next to it brings the TRX back to the chosen frequency if someone has turned the VFO in the meantime.
- **Waterfall**: each tab shows the scrolling spectrum from 0 to 3000 Hz. A signal is a coloured trace; its horizontal position is its audio frequency.
- **Status line** (on the right of the tab bar): reports problems (station offline, audio not enabled, TRX not in DATA-U…) or the decoder state.
- **Transmitting** in FT8 · FT4 · FT2, RTTY, JTTY, CW and SSTV, under the **TX call** chosen in the Correspondant line (ON5VL or your callsign). You need control and transmit permission. WSPR and JT65 are **receive**-only for now *(soon)*.

**Waterfall settings** (above the scale, shared by all tabs and remembered in your browser)

| Setting | What it does |
|---|---|
| **Gain** | Contrast: further to the right, weak signals stand out more. |
| **Zéro** (zero) | Background level: further to the right, the background is brighter. |
| **Plat** (flat) | Makes the background noise even across the whole width (corrects the slope of the TRX filter). Leave it ticked. |
| **Couleurs** (colours) | JTDX (default: blue noise, yellow signals, strong ones in red), blue, rainbow, grey. |
| **Vitesse** (speed) | Fast, normal or slow scrolling (slow = more compact signals and more history), like JTDX's "Spd". |
| `↺` | Restores the default settings. |
| Handle below the waterfall | Drag it up or down: height of the waterfall and of the lists (double-click: original size). |

<a id="ft8"></a>
### 12.1 FT8 · FT4 · FT2

FT8 is a digital mode designed for very weak signals: each station sends a short message for 15 seconds (a **period**), then listens during the next period. A complete QSO takes about a minute and a half. **FT4** is twice as fast (7.5 s), **FT2** faster still (3.75 s).

**The bar at the top of the tab**

| Command | What it does |
|---|---|
| `FT8` / `FT4` / `FT2` | Chooses the mode; the TRX goes to that mode's calling frequency on its band. FT2 is the fast mode of Decodium (IU8LMC), incompatible with the "FT2" of WSJT-X Improved. |
| Frequency list | Calling frequencies per band (e.g. 14.074 · 20m), and QO-100 (section 12.9). |
| `↺` | Brings the TRX back to the chosen frequency (VFO A, DATA-U). |
| RX … Hz / TX … Hz | Receive (green) and transmit (red) audio frequencies within the 3 kHz passband. |
| `TX ← RX` | Transmit on the same audio frequency as receive. |
| `RX ← TX` | Receive on the transmit audio frequency. |
| **Période** (period) auto / 1re / 2e | Which period to transmit in. « auto »: opposite to the chosen correspondent (almost always what you want); « 1re » (1st) = 00 and 30 s, « 2e » (2nd) = 15 and 45 s in FT8. |
| **Activité** NORMALE / HOUND · FOX / HOUND · SuperFox | FT8 only. To work a **DXpedition** running FOX or SuperFox (see "HOUND" below). Chosen by whoever has control, for the whole station; purple when a HOUND mode is on. |
| ☐ **Répondre au 1er** (answer the first) | When you call CQ (Tx6), the first station to answer becomes the correspondent and the QSO runs by itself (WSJT-X's "Call 1st"). |
| ☐ **Spot cluster** | Each QSO logged (« QSO terminé » window, automatic logging or the Log QSO form of the RTTY, JTTY and CW tabs) is also spotted on the DX cluster under **your operator call**, not the TX call (same box in the « QSO terminé » window and in the TRX SSB / TRX CW pages). Independently of this box, the FT8 / FT4 / FT2 stations **decoded** by the station are sent every 5 minutes to **PSK Reporter** (pskreporter.info), under the station call and locator, as WSJT-X does. |
| `DUAL RX` (FTDX101) | Purple when both VFOs are shown (two waterfalls, four columns, two band maps). Click: only one VFO shown (VFO-A), the rig keeps its dual receive; click again: both. With the rig in single receive, the click turns DUAL RX on in the rig (with control). |
| `■ Arrêter` | At the end of the Tx1 to Tx7 message line, right of the free text (black background, red frame). Stops automatic transmission at once ("Halt Tx"). The `Space` bar does the same. |
| Clock | Server UTC time. |

**The waterfall**: **left click** = receive frequency (green « RX 1500 » flag and green line), **right click** = transmit frequency (red flag and red line). Button **held down** (left for receive, right for transmit): the line follows the mouse continuously, as in RTTY and CW (FT8 · FT4 · FT2, WSPR, JT65, JTTY); members following the operator see it move. For transmitting, choose a clear spot in the waterfall. A white line marks the start of each period, with the UTC time and the band.

**The spectrum**, below the waterfall (like WSJT-X's "Spectrum"): green curve of the level of each audio frequency, averaged over the last lines (same Gain, Zero and Flat settings as the waterfall); a signal stands out as a peak. At the top left of the spectrum, `X1` / `X2` / `X4` set its **speed**: X1 = slow average (calm curve), X4 = follows signals faster (kept in this browser). The **handle between the waterfall and the spectrum** sets the waterfall height; the **handle at the very bottom** sets the spectrum height (double-click: original size). With dual receive, VFO-B has its own spectrum, of the same height.

**The two message lists**

- **Activité de bande** (band activity, on the left): all decoded messages. **CQ** calls are in green, messages addressed to your TX call (ON5VL, OR0L or yours) in red, your own transmissions in yellow. `Effacer` (clear) empties the list.
- **Fréquence RX** (RX frequency, on the right): only the messages close to your receive frequency, i.e. your QSO in progress.
- A line separates each period; messages are in chronological order.
- **Width of the two lists**: drag the vertical line between them (double-click: half and half).

| Column | Meaning |
|---|---|
| UTC | Start of the period in which the message was received. |
| dB | Signal-to-noise ratio (as in WSJT-X): −24 = very weak, +10 = strong. This is the report you send. |
| DT | Time offset of the signal (seconds). Close to 0 when everything is in step. |
| Fréq | Audio frequency of the signal (Hz). |
| Message | The decoded text, e.g. "CQ F4ABC JN18". A mark **a1**…**a7** at the end means a decode obtained with a priori help (see below). |
| Pays | DXCC country of the transmitting station. |
| km / Az | Distance and direction (azimuth in degrees) from the club. "≈": approximate (no locator in the message, centre of the country). |

- **Stations already worked**: messages from a station already in the log **under the current TX call**, on the same band and in the same mode, are shown green and struck through ("worked before"). With another TX call, only QSOs made under that callsign count.

**Messages Tx1 to Tx7** (below the lists, as in WSJT-X)

| Message | Example | When |
|---|---|---|
| `Tx1` | F4ABC ON5VL JO20 | Answering a CQ (your callsign and locator). |
| `Tx2` | F4ABC ON5VL −12 | Giving the correspondent a report. |
| `Tx3` | F4ABC ON5VL R−12 | Acknowledging their report and giving yours. |
| `Tx4` | F4ABC ON5VL RR73 | Everything received, goodbye. |
| `Tx5` | F4ABC ON5VL 73 | Last message. |
| `Tx6` | CQ ON5VL JO20 | Calling CQ. |
| `Tx7` | free text | Free message of 13 characters at most. Right click or `✎` to edit it. |

- **Clicking a Tx message** sends it **every period** (one in two) until an answer comes, like WSJT-X's "Enable Tx". You need control, the transmit VFO in **DATA-U** and power within your limit.
- **Answering a station**: click its **callsign** (dotted underline) or **double-click** its message. It becomes the correspondent (callsign, locator, report) and, with control, the right message goes out in the next period, opposite to theirs. A click elsewhere on the line only sets the receive frequency.
- **The sequence advances by itself** from the answer: their locator → Tx2; their report → Tx3; R+report → Tx4 (RR73); RRR or RR73 → Tx5 (73). After RR73 or 73: end of QSO, transmission stopped, back to Tx6, and the **Enregistrer le QSO** form opens already filled in.
- **When the answer goes out**: in FT8, a transmission must start at the beginning of a period (at most 2.3 s late, otherwise it is no longer decoded; FT4: 0.8 s). Decodes arrive around 12.7 s: a click before the end of the correspondent's period (or in the first 2 seconds of the next one) sends the answer at once. Transmission always stops at the end of the period. A message at the bottom of the screen says when your answer goes out.
- **Period bar** (below the lists): green while receiving, red while transmitting; it fills up during the period.
- **Automatic stops**: `■ Arrêter` or `Space`; the correspondent answers someone else; the same message for 6 minutes without an answer; control lost.
- In **SPLIT**, the message goes out on the other VFO, like the PTT.

**The QSO window** (below the Tx1 to Tx7 messages). In the **TRX DIGI page opened from the dashboard**, it is the **logbook form** (like "Log QSO"): callsign, UTC date and time (QSO start), frequency, mode, RST sent / received (the FT reports), TX call, QO-100, name, QTH, locator (⇩ QRZ), power, remark, the correspondent's IOTA / WWFF / POTA / BOTA / LLOTA / SOTA references — filled by itself with the chosen correspondent (double-click) and the sequence's reports. Buttons: `Enregistrer le QSO`, then `Modifier le QSO` (reopens the last QSO saved from here to correct it) and `Supprimer le QSO` (removes it from the logbook; online logs are not changed) — these two buttons are also in the TRX SSB page form. Elsewhere (front panel pages, modes brought back into the dashboard): short card of the current correspondent — **callsign** and **locator** (editable by hand, like WSJT-X's "DX Call / DX Grid"), country, distance and azimuth, **report sent** and **received**, start time (when the correspondent was chosen) and transmit step ("Tx3 à la prochaine période", "● Tx3 en émission"). `LOG QSO` opens the logbook form at any time (interrupted QSO, manual logging); `EFFACER` clears the correspondent.

**HOUND: working a DXpedition in FOX or SuperFox mode**

Big FT8 DXpeditions run **FOX** mode: the DXpedition (the FOX) works several stations at once, and the callers (the **HOUNDS**) follow strict rules that the Remote Station applies by itself, as WSJT-X does.

- **Activité** (top bar, FT8): **HOUND · FOX** for classic FOX (several FT8 signals below 1000 Hz), **HOUND · SuperFox** for SuperFox (one wide signal of about 1.5 kHz around 750 Hz, addressing up to 9 stations at once). The DXpedition's announcement says which one and its frequency (often not the usual FT8 frequency).
- **Calling**: double-click the FOX's CQ → **Tx1** ("FOX ON5VL JO20") goes out in the **2nd period** (the FOX transmits in the 1st). Only **Tx1** and **Tx3** can be used; no CQ, no 73. The period is locked to "2e".
- **Classic FOX**: call **above 1000 Hz** (if your TX marker is lower, a random frequency between 1000 and 2900 Hz is used). When the FOX gives you a report, **Tx3** ("FOX ON5VL R-10") goes out by itself **on the frequency where the FOX called you**, then 300 Hz away if it must be repeated. Its messages can address two stations: "K1ABC RR73; ON5VL <KH7Z> -12".
- **SuperFox**: put the RX marker (left click) on the low edge of the SuperFox signal (around 750 Hz). The 1st period is decoded by WSJT-X's SuperFox decoder: each part of the message is shown on its own line marked **SF** (CQ, reports, RR73), and the DXpedition's password marked **OTP** ("$VERIFY$ …": it proves the signal really comes from the DXpedition; it can be checked on 9dx.cc). The whole QSO stays on your calling frequency (you may call anywhere, below 1000 Hz too).
- **End of QSO**: the FOX's **RR73** ends the QSO (no 73 is sent); the "QSO terminé" form opens (or the QSO is logged by itself, according to "Log"). With no RR73 within 11 periods after its report, transmitting stops: call it again with Tx1.
- Go back to **Normale** after the DXpedition, otherwise other stations cannot be worked normally (CQ, 73…).

> [!TIP]
> **The decoder**
> - It is the **WSJT-X 3** engine, with the multi-pass decoder of **JTDX**. In FT8, three passes per period: an early one around 12 s (so you can answer right away), a normal one at the end of the signal, then a deep one that adds the weakest stations a few seconds later.
> - **A priori help (AP)**: during a QSO, the decoder knows who the correspondent is and which message is expected; it can then find it down to 2 to 3 dB lower. These decodes carry the mark a1 … a7.
> - Sensitivity: FT8 about −22 dB (−24 dB with a priori help), FT4 about −17.5 dB. A database of ~100,000 callsigns (JTDX's) rejects very weak false decodes.

<a id="jt65"></a>
### 12.2 JT65

Same window as FT8, but with one-minute periods; the TRX goes to the JT65 frequency of its band. Decodes arrive around the 52nd second. Receive only.

<a id="rtty"></a>
### 12.3 RTTY

RTTY is radio "teletype": you type text that scrolls on the other station's screen. Widely used in contests. The tab has **two independent decoders**: **A** (VFO-A, left) and **B** (VFO-B, right), each with its own received text and settings. The FTX-1, FTDX10 and IC-7300 send a single audio stream to the PC (the FTDX101 in single receive; in dual receive it sends both receivers in stereo: one waterfall per decoder, A = MAIN, B = SUB), so there is **one waterfall**, full width, carrying the markers of both decoders. You can follow two stations on the same band at once (contest, a DX and its pile-up). A transceiver that sends its two receivers separately (FTDX101D / MP) will get one waterfall per decoder, side by side.

Above the waterfall, the help line (« clic gauche : décodeur A… ») is shown for **3 seconds** when you open the tab, then disappears to leave more room for the receive windows; it stays as a tooltip on the waterfall. The status line only appears when something is wrong (no audio, TRX not in DATA-U…).

| Control | What it does |
|---|---|
| Frequency list + `↺` | RTTY frequencies per band; the transceiver goes there in DATA-U. |
| **Bande** 3 kHz / 4 kHz (band) | Audio width shown. The transceiver only sends the audio after its filter: for 4 kHz also open its filter (BW 4.0K), otherwise the right edge stays black. It cannot go wider with these transceivers (their screen's scope does not go through USB). |
| **Zoom** ×1 to ×8, or **mouse wheel** on the waterfall | As in MixW: the waterfall shows a narrower, more detailed range (×4: 750 Hz in the 3 kHz band). **Wheel towards you**: narrower, around the mouse; **wheel away**: wider, up to the whole band (×1). The list does the same, centred on the decoder marked TX; the window follows that decoder when it gets near an edge. |
| `SPLIT` | Receive on VFO A, transmit on VFO B (same command as SPLIT on the Step row). Lit in red: « SPLIT · TX sur B ». |
| Waterfall scale | In **kHz**, real frequency (VFO dial + audio); the small white triangle marks the middle of the audio band. In **DATA-U** (the mode to use for RTTY) low frequencies are on the left; in LSB the scale is reversed and so is the RTTY transmission: switch to DATA-U. |
| Markers on the waterfall | Decoder **A**: yellow (Mark) and blue (Space). Decoder **B**: mauve (Mark) and green (Space). Dark colours and thick frames: visible even on a very bright screen. The letter **A** or **B** is written large, on a badge of its colour, above the markers. |
| Left button / right button | **Left click** on a signal: tune decoder **A** on it; **right click**: decoder **B**. **Holding the button down** and dragging, both bars of the decoder (Mark and Space) follow the mouse **continuously**: left for A, right for B; decoding follows while moving. Release: the decoder stays there. |
| `Shift` + drag / `Shift` + wheel on the waterfall | `Shift` + **dragging** the waterfall left or right (or dragging with the middle button, wheel pressed) tunes the VFO (you "grab" the band, signals follow the mouse); `Shift` + **wheel**: VFO ± 10 Hz per notch. Both decoders stay on their signals. You need control. |
| Frequency (e.g. 7 074,9 kHz) | Next to VFO-A / VFO-B: frequency of the signal followed by this decoder (dial of the VFO being received + Mark / Space centre, − in LSB), handy for the log or a spot. In single receive (always the case with both VFOs on HF on the FTX-1), both decoders read the same receiver: their frequencies are computed from the VFO being received, shown in brackets, e.g. « 7 079,1 kHz (VFO A) ». |
| **Shift** (170, 200, 425, 850 Hz) / **Speed** (45,45 … 100 Bd) | Amateur radio: 170 Hz and 45.45 baud. |
| `Inversé` (reversed) | Swaps Mark and Space when the received text makes no sense (signal "upside down"). |
| **Silencieux** (squelch) | Higher = fewer random characters on noise; too high and weak signals are no longer decoded. |
| M / S indicator | The two bars should beat alternately when the decoder is tuned correctly. |
| Centre … Hz | Audio frequency the decoder is tuned to. |
| `⌖ Centrer` (centre) | Moves the VFO so that the signal followed by this decoder falls in the middle of the audio band (white triangle): its frequency does not change. The other decoder stays on its signal if it is still in the band. |
| `TX` / click in the window | Chooses the decoder whose settings are used for transmitting (audio frequency, shift, speed): **one click anywhere in the VFO-A or VFO-B window** is enough, or the `TX` button in its header. The button becomes `▶ TX ici` (TX here, red), the header turns pink and a red frame surrounds the decoder; the other window shows `RX ici` (RX here) in green, with a green frame (receive only). A click on `RX ici` swaps the roles. The zoom centres on it. **A click on `▶ TX ici` transmits the custom text** typed in the bottom box (like `Émettre`); while transmitting it becomes `■ Arrêter` (stop). Macros `F1`…`F12` also go out on this window. |
| `Effacer` (clear) | Clears the received text of this decoder. The window has a scroll bar and always follows the latest decoding (the oldest history is removed as it goes); if you scroll back to read (wheel or scroll bar), it resumes following 10 s later. |
| Vertical bar between the two texts | Drag it: width of the two decoders (double-click: half and half). |

1. **Receive**: left click on a signal for decoder A, right click for decoder B (button held: the bars follow the mouse continuously, to place them exactly on the traces). The two markers should sit on the two traces of the signal. The text appears under the waterfall, A on the left, B on the right.
2. **Double-click a received callsign**: it becomes the correspondent.
3. **Choose the transmit decoder**: a click in its window (VFO-A or VFO-B), or the `TX` button in its header; your reply goes out on the frequency of the station it follows. Double-clicking a callsign in window B therefore does both: B becomes the transmit decoder and the callsign goes into Correspondant.
4. **Transmit**: text in the bottom box, then `Émettre` (transmit) (or `Ctrl`+`Enter`). The text goes out with the settings of the decoder marked TX (and on VFO B if SPLIT is on), then the transceiver returns to receive. It appears in grey in that decoder's received text, then each letter turns red as it is sent. While transmitting the button becomes `■ Arrêter` (stop). 600 characters at most; transmit audio frequency between 300 and 2800 Hz.
5. **Macros** `F1` to `F12` (keyboard keys or click): transmit at once; **Shift+click** adds the macro to the text without transmitting (section 13). `Esc` stops the current transmission.
6. `Effacer` (under the transmit button) clears the text to send; `Log QSO` opens the logbook form, with the frequency of the decoder marked TX.

1. **Take control**, **RTTY** tab, TRX in **DATA-U** (`↺` button of the frequency list).
2. **Find a station**: click a green callsign on the **band map**. The TRX tunes to it, the transmit decoder decodes it and its callsign goes into Correspondant. Or: left click on a trace in the waterfall (decoder A), right click (decoder B).
3. **Choose the transmit window**: one click in the VFO-A or VFO-B window (« ▶ TX ici »). Double-clicking a received callsign puts it in Correspondant and selects its window at the same time.
4. **Reply**: `F2` key (or the reply macro), then the report macro. For custom text: type it in the bottom box, then `▶ TX ici` (or `Ctrl`+`Enter`). `Esc` stops the current transmission.
5. **Log the QSO**: a macro containing `<LOG>` (form opens by itself) or the `Log QSO` button. In contest, **Sent exchange** is filled in by itself: the exchange sent to this station by a macro, otherwise the one to give (fixed report, zone… or this QSO's serial number). When the QSO is logged, the **serial number moves to the next one** (once per station, not again if the TU macro already did it). **Spot cluster** box next to Log QSO (and in the form): the logged QSO is also spotted on the DX cluster, under your operator call.
6. **Call yourself** (CQ): choose the transmit window, then `F1`. With two decoders you can call CQ on A while watching another station on B.
7. **Station outside the waterfall and not spotted**: click the band map at that frequency (the TRX goes there), or wheel / drag on the **frequency scale** above the waterfall (also Shift + drag, `Shift` + wheel in the waterfall).

On the right of the FT8 · FT4 · FT2, RTTY, WSPR, JT65, JTTY and CW tabs (not SSTV: a single frequency), a **vertical column** shows the band as a ruler (on a large screen it goes up to the top, next to the VFO A and B displays, both narrowed by the same width): low frequencies **at the top**, high at the bottom (by default 7030–7120 kHz on 40 m, 14080–14150 kHz on 20 m, 3570–3600 kHz on 80 m…). **Spots** from the club's DX cluster (OP0P, including stations found by the Reverse Beacon Network) appear at their frequency. You see the whole RTTY part of the band at a glance, while the waterfall only shows 3 or 4 kHz.

| Item | What it shows or does |
|---|---|
| Green / red dot, **20 m** | Link to the cluster (green = connected), band of the VFO being heard. |
| `Filtres ▾` (filters, yellow) / `Tous` (all) | Under the band number (large). **Filtres** opens the list of the tab's modes (RTTY: RTTY, PSK, OLIVIA; FT8 · FT4 · FT2: FT8, FT4, FT2; JT65: JT65, JT9, Q65…) and « Spots sans mode indiqué » (spots with no mode): tick those to show. Kept per tab; `Par défaut` (default) goes back to the tab's mode + spots with no mode. **Tous** (green when on): all spots in the range, whatever their mode. |
| Two kHz boxes | Range shown, kept for each band, separately for RTTY, CW and the other digital modes. Type your limits (e.g. 7030 and 7120). Defaults on 40 m: RTTY 7030–7120, CW 7000–7040, FT8 and others 7038–7080 kHz. |
| Callsign in green | Station calling (CQ, RBN skimmer spot). |
| Struck-out callsign | Already worked in RTTY on this band (under the chosen TX call). |
| Faded callsign | Old spot (kept 30 minutes). On hover: comment, who spotted it, how many minutes ago. |
| Blue area | The part of the band visible in the waterfall right now. |
| Yellow / mauve line | RTTY: decoder A / B; « TX » next to the transmit one, « RX » next to the other. FT8, JT65, JTTY: green line = receive frequency, red = transmit. CW: yellow line = VFO frequency. « ▲ VFO » or « ▼ VFO »: the VFO is outside the range. |
| **Click on a spot** | The transceiver tunes to the station: if it is already in the waterfall, only the transmit decoder moves onto it; otherwise the VFO moves to put it in the middle of the waterfall, with the decoder on it. The callsign goes into Correspondant. Then just press the reply macro (`F2`…). You must have control. |
| Click elsewhere on the map | Same on that frequency, without a callsign (to scan the band). |
| Click in the other tabs | **CW**: the VFO goes to the station (it comes out at the TRX pitch, where the CW decoder is set). **FT8 · FT4 · FT2, JT65, JTTY, WSPR**: the receive frequency moves onto the signal; if it is outside the audio band, the VFO moves to put it at 1500 Hz. |
| Handle on the left edge | Drag left or right: width of the band map (kept in this browser); double-click: original width. |
| **Wheel** / drag / double-click | Wheel: zoom around the mouse; drag up or down: move the range; double-click: the band's original range. FT8 · FT4 · FT2 tab: the original range is the chosen mode's calling frequency ± 20 kHz (e.g. 20 m: FT8 14,054 to 14,094 kHz, FT4 14,060 to 14,100 kHz); switching between FT8, FT4 and FT2 re-centres the map on the new mode's frequency (each mode keeps its own range); with dual receive, each map follows its own VFO's band. |

Cluster settings (administrator, `config.json`, then restart the service): `clusterHost` (op0p.be by default; empty = no cluster), `clusterPort` (8000), `clusterCall` (login callsign with an SSID; empty = digiCall followed by -7, i.e. ON5VL-7) and `clusterCmds` (commands sent after logging in: `set/skimmer` for RBN spots).

<a id="wspr"></a>
### 12.4 WSPR

WSPR is used to study propagation: low-power beacons transmit their callsign, locator and power every 2 minutes. Choose the band in the list; about ten seconds after each even minute, the list grows: time, dB, DT, frequency, drift, callsign, locator, power and distance from the station. Receive only.

- WSPR beacons only use **200 Hz** of the audio band, from **1400 to 1600 Hz** (reminder at the top of the tab): the frequency in the list (e.g. 14.0956 MHz) is the VFO frequency in USB / DATA-U.
- The `↺` button brings VFO A back to the chosen WSPR frequency; `Effacer` (clear) empties the list; the number of stations heard shows in the title.
- The clock shows the server UTC time: each 2-minute period starts on even minutes.

<a id="jtty"></a>
### 12.5 JTTY

- WSJT-X 3.3 mode for keyboard-to-keyboard and contests: no periods, each message appears **frame by frame** (1.9 s); `▌` = message still being received.
- As in FT8: left click = receive, right click = transmit, double-click = correspondent. Two lists: Activité JTTY (JTTY activity) and Fréquence RX (RX frequency).
- Macros `F1` to `F8`: a click transmits at once, **Shift+click** adds them to the message.
- `Émettre` (or `Enter`): the message goes out at once on the TX frequency, then back to receive. 80 characters per message (longer: two messages in a row); TRX in **DATA-U**.

<a id="cw"></a>
### 12.6 CW

| Command | What it does |
|---|---|
| Frequency list + `↺` | CW frequencies per band; the TRX switches to CW. |
| **Filtre** (filter) 50 … 400 Hz | Decoder filter width: 100 Hz by default, 50 Hz with QRM, 200 to 400 Hz for searching. **With control and the TRX in CW**, the choice also sets the **TRX BW** to the nearest width (for everybody, like the Filtres panel; NARROW is turned off if it was on; IC-7300: FIL3 up to 250 Hz, FIL2 above): the audio you hear narrows too. The TRX centres its filter on its own CW tone (pitch): the station must be tuned to that tone (click on the band map, or VFO), otherwise it disappears from the waterfall with a narrow filter. Without control, only the decoder changes. |
| **Silencieux** (squelch) | Signal level (dB) below which nothing is displayed: higher = fewer random letters on noise, but very weak signals disappear. 5 by default; 3 or 4 for a very weak signal. The decoder keeps tracking the signal even with the squelch closed. |
| **Vitesse** (speed, Émission box, right of its title) | **Transmit** speed of the TRX keyer, 5 to 60 wpm (48 on the IC-7300); a higher value is brought back to the TRX maximum. No effect on reception: the received speed is measured by itself. |
| LED and level bar | Follow the keying: the LED flashes in time with the Morse when the decoder is properly locked. |
| Tonalité / Vitesse (tone / speed) | Audio frequency being tracked and measured speed (words per minute). |

- **Click a signal** in the waterfall: the decoder locks onto the nearest signal and learns its speed. Right click: exact tuning where you click. **Left button held** while dragging: the yellow decoder marker follows the mouse **continuously** (decoding follows during the move) and stays exactly where you release, like the RTTY bars.
- Double-click a received callsign = correspondent; `Log QSO` opens the logbook form.
- **The decoder** (since 0.23.1) works like the ear: it retunes by itself to the exact tone of the signal (up to ± 60 Hz from the marker with the 100 Hz filter), filters as narrowly as the speed allows (about 1 / dot), and runs three decoders in parallel (fast, medium, slow), keeping the one whose dots and dashes have the most consistent lengths. It copies much weaker signals than before; it needs a few letters to find the speed of a new station.
- **CW transmission**, by the **TRX keyer** (no audio is sent: the TRX makes the Morse itself, as with its memories):
   - **Vitesse** (speed, 5 to 60 wpm, 48 on the IC-7300): keyer speed, sent to the TRX with each transmission.
   - **Macros** `F1` to `F12` (key or click): **red edge = immediate transmission** (CQ, Appel, Report, R TU, 73, QRZ?, AGN?), as in RTTY; **Shift+click** adds it to the text without transmitting. `<CALL>` without a correspondent: nothing is sent.
   - **Text**: typed in the box (upper case), then `Émettre` (transmit) or `Ctrl`+`Enter`; the box empties when transmission starts. Characters sent: letters, digits, `/ ? . , = + -` and spaces; `<AR>` becomes + and `<BT>` becomes =; anything else is ignored. 300 characters at most, and no longer than the maximum transmit time.
   - While transmitting, a big flashing red `■ ARRÊTER (Échap)` (stop) button appears in the Émission title, above the macros (macro sent by mistake…); the `Émettre` button also becomes `■ Arrêter` and the bottom line shows « ● En émission CW (callsign, speed, duration) ». A click or `Esc` stops at once.
   - Conditions: control, transmit permission, an allowed band and power, the TRX in **CW** (CW-L / CW-U, CW / CW-R on the IC-7300) and **no SPLIT** (the keyer transmits on the receive VFO).
   - **FTX-1: DTR keying** (recommended): if the « Port de manipulation CW (DTR) » is chosen on the Station page (section 18), the page keys the TRX itself through that port; otherwise it uses the keyer memory, described below.
   - What the Station page does: keyer speed, **break-in** on (the TRX transmits by itself during the Morse and returns to receive), text written to a keyer memory and played, in 50-character pieces (30 on the IC-7300). **Note**: memory 5 of the FTX-1 (menu CW MEMORY 5, set to TEXT by the dashboard) and memory 1 of the FTDX10 / FTDX101 are replaced by the transmitted text. Each step (memory written, playback accepted, transmission) shows under the bands; one click is enough: transmission is recognised from the TRX TX state or from the output power (Po); if nothing is seen after 1.6 s, the page repeats the playback once (break-in turned on again) and then lets it play. The actual delay shows under the bands ("on air 1.2 s after the request"). A macro clicked during a message replaces it at once (no need to wait for the end). The transmitted text appears in the CW receive area as in RTTY: **red** for letters already sent, **grey** for those still to go (struck through if transmission is stopped early). **Preparation in advance**: the macro under the mouse, the text being typed and, when idle, the first macro (F1, CQ) are already written to the TRX memory (without transmitting); the click then only starts playback, so transmission starts as fast as the TRX allows. TRX menu PC KEYING on **OFF**: on DTR or RTS the FTX-1 refuses to play its memories (KY05 refused). On the FTX-1 the memory method is slow (the TRX does not play a memory just written, and does not always report transmission): **DTR keying** (Station page) is recommended, transmission then starts in under half a second. Fast switching: speed, break-in and text already in memory are not sent again for the next message, so a repeated macro goes out at once (everything is sent again after a stop, an error or 20 minutes). A setting already in place that the FTX-1 refuses ("?") is only written to the log. On stop, playback is interrupted (FTX-1: KY00, break-in left as it is; FTDX10 / FTDX101: break-in turned off).
   - Safety: the same as any transmission (bands, power, SWR), stop if control is lost, if the link or the station drops, and maximum duration.
- **CW key from home** (paddles or straight key, since 0.37.174): the `Clé → TRX` line under the Transmit frame. The keyer runs in **your browser** with a local sidetone, so you hear your keying without delay; dots and dashes are sent time-stamped to the server and the Station page replays them at the same rhythm on the DTR line of the TRX's 2nd USB port. The TRX transmits **about 0.2 to 0.3 s later** (Internet): no QSK, the TRX's break-in returns to receive after each pause.
   - **TRX CW page** (blue `🎛 TRX CW` button at the end of the key line): a full page in the spirit of the W1VE Keyer Suite, attached to the dashboard (same connection, same control): large speed display and sliders (speed, weight, pitch, volume), key type and connection, large on-screen paddles, large `CLÉ → TRX` button, F1 to F12 macros (right click or ✎: edit), other station, text to send (Enter), `■ ARRÊTER`, CW reception, large **RX / TX** light, and at the bottom the link state (round trip in ms). The speed there applies to the key and to macros. While this page is open, the key of the dashboard CW tab is on standby (one key at a time). Refusals ("put the TRX in CW first"…) are shown there too.
   - **CW contest** (**CONTEST** line of the TRX CW page): list of CW contests (CQ WW, CQ WPX, ARRL DX, IARU HF, WAE, UBA DX, ON Contest, EU HF, OK/OM, RDXC, SP DX, HA DX, YO DX, LZ DX, King of Spain, Helvetia, PACC, WAG, All Asian, JIDX, CWops CWT, other) with the **exchange** of a Belgian station, editable (`<CNTR>` = serial number, `<CQZ>` CQ zone 14, `<ITUZ>` ITU zone 27; a first name required by the contest is typed directly in the exchange; "00" to fill in: age, licence year; UBA DX and ON Contest: section, LGE for the club); on the right, in green, what will be sent. **N°**: serial number, **automatic +1** with the **TU** macro (`<INCR>`), only once per station (sending TU again does not skip a number); `−1` / `+1` to correct. Choosing a contest shows 12 **contest macros** (yellow): CQ TEST, Exchange, TU, My call, His call, Answer, AGN?, NR?, ?, QRZ?, R, Log (QSO form with the sent exchange and the contest); `F1`…`F12` then go to the contest macros, the usual macros stay available by click. Same serial number as the RTTY contest.
   - **Contest log** (N1MM style, under the CONTEST line): entry line **Call · RST · Sent · RST · Received**, `LOG ↵` and `EFFACER` (wipe, `Alt`+`W`). `Space` jumps from the call to the received exchange. **Enter** does it all (N1MM ESM): in `RUN` (you call CQ): empty line → CQ (F1), call typed → call + exchange (F2), received exchange typed → QSO logged + TU (F3); in `S&P` (you answer): call typed → your call (F4), received exchange typed → TU + exchange (F6) and QSO logged. **Sent** is filled in by itself, as in the TRX SSB page: the contest's fixed report or exchange (e.g. the zone in CQ WW) or **this QSO's serial number**, which moves to the next one as soon as the QSO is logged (editable by hand; EFFACER resets it). As soon as the call is typed: **DUPE** blinking on a red background when it is already in the contest log on this band (hover: QSO time, other bands); nothing shown = valid QSO. **Indicatifs probables** (likely calls, under the contest macros), as in the TRX SSB page: typing 2 characters or more lists the calls of the contest log, then of the Super Check Partial list, that contain them (green: not yet worked, struck through: dupe on the band; click = into the call box); empty box: the stations spotted in CW on the TRX band (DX cluster, Reverse Beacon Network), click = call and TRX on its frequency with control. **Spot cluster**: each logged QSO is also spotted on the DX cluster under your operator call (see the TRX SSB page). QSOs go **into the general logbook** (contest id, sent and received exchanges, under the TX call); on the right: list of the contest QSOs, counts per band, dupes, rate (10 min and 1 h). **Depuis** (since): start date taken into account (last 3 days by default); `ADIF`: .adi file of the contest QSOs; `CABRILLO`: the contest file (its QSOs only) to send to the organiser. The serial number moves on at each logged QSO.
   - During a CW transmission (macro, remote key or key plugged into the TRX), the frequency stays **red** until the end of the message, even when the TRX break-in returns to receive between letters (1.5 s more after the last element).
   - `Clé → TRX OFF` (when the page loads): **practice**, local sidetone only, nothing is transmitted. `ON` with control: your key keys the TRX. The yellow light follows your key; the **TX** badge lights when the club TRX transmits your keying.
   - `Réglages` (settings): **key** (iambic B paddles, iambic A, or straight key), **speed** (5 to 50 wpm, the page keyer's own speed, independent of the macro speed), **weight** (50 % = normal), **swap dot / dash**, **sidetone** pitch, volume and audio output (e.g. headphones, separate from the TRX audio).
   - **Connecting** your key to your PC:
      - **USB adapter (left / right Ctrl)**: paddle → USB adapters that appear as a keyboard (VBand / Vail type): left Ctrl = dot, right Ctrl = dash.
      - **Keyboard keys**: two keys of your choice (click the box, then press the key).
      - **MIDI adapter**: click the Dot box then touch the dot paddle, same for the dash (MIDI notes or controllers).
      - **USB-serial cable (DSR / CTS)**: the classic contest-software wiring: dot contact on **DSR**, dash on **CTS**, common on **DTR** (set high by the page). `Choisir le port…`; Chrome or Edge. Detailed wiring below.
      - **On-screen paddles**: the `•` and `—` buttons (mouse or touch screen), always available.
   - **Connecting dual paddles (or a straight key) to your PC**. A key is only a switch: neither the sound card nor a USB socket can read it as is, a small USB interface is needed. **Nothing goes to the sound card**, and there is nothing to install (no server at the club, no software at home): the path is key → USB interface → your PC (TRX CW page) → Internet → server → club Station page → FTX-1.
      - **USB → RS-232 adapter with a male DB9 plug** (CH340, PL2303 or FTDI chip; the common clear-blue model is fine). In Device Manager (Ports COM & LPT) it must show **without an exclamation mark** (Prolific "PL2303HXA phased out" / code 10: counterfeit chip refused by the recent driver → another cable or an old driver). On a **female DB9 screw-terminal plug** ("DB9 breakout"), screw the key's **3 wires**:
         - Key **common** (often called "GND") → **pin 4** (DTR: voltage switched on by the page)
         - **Dot** → **pin 6** (DSR: input read as "dot")
         - **Dash** → **pin 8** (CTS: input read as "dash")
      - **Identifying the wires**: 3.5 mm stereo jack: **tip = dot**, **ring = dash**, **sleeve = common**; bare wires: multimeter on "continuity", one probe on the common, press a paddle and find the wire that beeps. If in doubt, connect at random and tick **Swap dot / dash** if needed (no risk).
      - **Test without the key** (CLÉ → TRX **OFF**): CW station → **USB-serial cable (DSR / CTS)** → `Choisir le port…` → the CH340 → "port open"; a paper clip between pins **4 and 6** gives dots, between **4 and 8** dashes (local sidetone + Key light).
      - **Not suitable** for dual paddles: 4-wire USB "TTL" cables (red +5 V, black GND, green TX, white RX), USB → 3.5 mm "console" jack cables (tip RX, ring TX), and the 6-wire FTDI TTL cable (one CTS input only: straight key only, key between CTS and GND). "USB CW cables with jack" sold to let software key a TRX do the opposite (output to the TRX).
      - **Other options**: a ready-made paddle → USB adapter of the **VBand** or **Vail** type (seen as a keyboard: "USB adapter (left / right Ctrl)"); or an **Arduino Pro Micro** (ATmega32U4) with a jack: ground → GND, dot → A2, dash → A3 (same setting).
   - **CW spot clicked** in a band map (front-panel BAND MAP, where the mode is written next to the spot, or the digital-modes band map): the TRX tunes to it **in CW**, the **CW** tab is shown and the call goes into the **QSO** box (other station), also in the **CW station** page (in a contest: in the log's **Indicatif** box, dupe checked, ready for Enter), which comes to the front if it is open. `<CALL>` macros use it at once.
   - **Macros and key**: during a macro (F1…), **touching the key stops the macro** and your key takes over the TRX. So you can call CQ with F1 and answer with the key.
   - What you key is shown in the **CW receive** window, in transmit colour like macros (text rebuilt from your dots and dashes, without going through audio decoding).
   - `Esc` stops the transmission; keying resumes at the next press after a short pause.
   - Keyboard keys are only taken while the CW tab is shown. Keep the window **visible** while operating (Chrome slows hidden tabs). Turn the TRX audio down while keying so your own delayed signal does not disturb you.
   - Conditions and safety: the same as macros (control, allowed band and power, TRX in CW without SPLIT, maximum duration without a pause); the Station page releases the key if your data stops arriving (0.3 s), cuts a key held down more than 5 s, and ends the burst after a pause. The **CW keying port (DTR)** must be open on the Station page (section 18); otherwise the refusal is shown.

<a id="sstv"></a>
### 12.7 SSTV

- **Receiving**: pictures arrive by themselves (VIS code) and are drawn line by line. Martin, Scottie, Robot and PD modes. The **gallery** keeps the last 12 (click = show); `PNG` saves the picture shown to your PC.
- **Preparing a picture**: `Images du PC…` (pictures from your PC) (or drag and drop a picture), CQ card, test pattern or received picture; it is cropped to the format of the chosen mode. The vertical line between **Réception SSTV** and **Émission** can be dragged to set their width (double click: half and half). **Recommended size: 800 × 600 pixels** (landscape 4:3, JPG or PNG, under 5 MB): no cropping in Robot 36 / 72, 1 to 3 % cut left and right in the other modes; keep the essentials in the centre and leave room at the top and bottom for the texts. Your pictures come from **your** PC (anywhere, over the internet) and stay in **your browser** (10 at most, the oldest is removed); when transmitting, only the transmitted picture goes through the server, just to build the signal, without being saved there. Three text lines (top, centre, bottom) with the tags `<CALL>`, `<MYCALL>`, `<RST>`…; text size and colour. Right click a thumbnail: remove it.
- `▶ Écouter` (play) plays the signal on your PC (without transmitting); `WAV` saves it as a file.
- **Transmitting**: with control, TX VFO in **DATA-U**, `Émettre` (transmit) sends the picture shown (in the format of the chosen mode) to the server, which builds the signal and hands it to the Station page; the TRX transmits about one second later. During transmission, the part of the picture not yet sent is **darkened**, the red line follows the current line, and the note under the picture gives the line and the time left. `■ Arrêter` or `Esc` stops. Same safety checks as RTTY (bands, power, SWR, link). Duration: from 37 s (Robot 36) to almost 5 min (PD 290); the limit of the other modes does not apply, but the server refuses a mode longer than its `maxSstvSeconds` setting (300 s by default). The TRX transmits **continuously** for the whole picture: reduce power (25 to 50 % advised).

<a id="synchro"></a>
### 12.8 Synchro

A monitoring tab: it shows whether the clocks and the link are in step. There is nothing for you to set.

| Box | Meaning |
|---|---|
| Heure du serveur (UTC) (server time) | The reference for all decoding. |
| Serveur : NTP (server NTP) | The server's synchronisation to world time (chrony or systemd-timesyncd on the VPS): offset in milliseconds and time server. This clock is the one that matters for decoding and the transmit instant; "NON SYNCHRONISÉ" (not synchronised) or more than 50 ms: to be fixed on the VPS (see the administrator guide). |
| PC du club (club PC) | Offset of the club PC's Windows clock from the server, measured by the Station page. It is **corrected automatically** for FT8 / FT4 / FT2 transmission. `⟳ Mettre à l'heure` (set the time, station managers): the sound-card assistant **version 4** sets Windows on public NTP servers, like NetTime, to the millisecond; it also does it at start-up and every hour. NetTime is then no longer needed on the club PC. |
| Votre PC (your PC) | Current offset between your PC clock and the server, in milliseconds. Does not matter for the dashboard. Not to be confused with the "Offset" column of NetTime or Meinberg (the error **before** their last correction). |
| Liaison station → serveur (station → server link) | Arrival delay of the audio from the club, measured and corrected automatically. |
| DT médian (median DT) | Average DT of the latest FT8 / FT4 decodes: close to 0.0 s = everything is in step. |
| Décodages (decodes) | Arrival time of each decoder pass after the start of the period. If the normal pass arrives more than 2 s after the end of the period, the server is overloaded and some answers go out one period later. |

<a id="qo100"></a>
### 12.9 QO-100

QO-100 is a geostationary satellite reached on 2.4 GHz with an up-converter. The FT8 · FT4, RTTY and CW lists offer « **QO-100 · FI 2 m / 70 cm** » (IF 2 m / 70 cm): the frequency to set on the TRX **before the converter**, to uplink on 2400.040 MHz (FT8 / FT4), 2400.025 MHz (CW) or 2400.090 MHz (RTTY). Example: FT8 on **432.540 MHz** with the club's 70 cm converter. Only the IFs the connected TRX can reach are offered (FTX-1).

<a id="messages"></a>
## 13. Correspondent, macros and tags

**The Correspondant line** (under the digital-mode tabs)

| Field | What it contains |
|---|---|
| **QSO** (correspondent) | The callsign of the station worked. It fills in by itself when you click a callsign in a tab; you can also type it. |
| **Nom** (name), **QTH**, **Locator** | First name, town and locator of the correspondent. They are looked up on **QRZ.com** as soon as a new correspondent is chosen (if a QRZ account has been set up by the administrators); only empty boxes are filled. |
| **RST TX** / **RST RX** | RST TX = report **sent** by the club station; RST RX = report **received** from the correspondent. In FT8 / FT4 / FT2, WSPR and JT65 they are dB (RST RX fills itself in during the sequence); in RTTY, CW, SSTV and JTTY, RST 599. |
| **TX call** | Callsign for digital transmissions and the logbook: one of the station's (**ON5VL** or **OR0L**, setting `clubCalls`) or yours. Chosen by the operator in control and remembered for next time. Messages Tx1 to Tx6, `<MYCALL>` macros and the logbook form follow it. A QSO logged under your callsign stays in the club logbook, but is not uploaded to the club's online accounts (get it with Exporter → Mes QSO). |
| `Log QSO` (tab row, right of Logbooks) | Opens the « Enregistrer le QSO » (log the QSO) form, already filled in with this information, the frequency and the mode. |

**Macros** (RTTY, JTTY, CW) are ready-made texts, on a row above the text box: **F1 to F12** in RTTY and CW, **F1 to F8** in JTTY.

- A macro starting with `<TX>` (red edge on the left; this is the case for all default macros) **is transmitted at once** when clicked or with its `F1`… key, then the TRX returns to receive.
- **Shift+click**: adds the macro to the text to send without transmitting, to build a message and then « Émettre ».
- A macro without `<TX>` is simply added to the text (in CW too: the original macros have `<TX>` and go out at once).
- **Right click** a macro (or `✎`): edit it — name, text, preview, back to the default text. Your macros are stored on the server, for you only.
- If a macro contains `<CALL>` while no correspondent is chosen, nothing is sent.

| Tag | Replaced by | Tag | Replaced by |
|---|---|---|---|
| `<MYCALL>` | transmitted callsign (TX call) | `<CALL>` | correspondent |
| `<NAME>` | their first name | `<QTH>` | their QTH |
| `<RST>` | report sent | `<LOC>` | their locator |
| `<MYLOC>` | station locator | `<MYQTH>` | station QTH |
| `<OPCALL>` | your callsign (operator) | `<CNTR>` | serial number (001…) |
| `<INCR>` | moves to the next serial number | `<ZT>` / `<ZD>` | UTC time / date |
| `<TX>` | at the start: transmit at once on click | `<RX>` | back to receive at the end (always done) |
| `<LOG>` | opens the « Enregistrer le QSO » form |  |  |

<a id="logs"></a>
## 14. Logbooks (station logbook)

**Logbooks** tab (cyan button, left of Log QSO and Synchro): the station logbook, shared by all members. It can upload QSOs to **LoTW**, **eQSL**, **Club Log** and **QRZ.com**, export them as **ADIF** or **Cabrillo**, and forward them over **UDP** to logging programs on the PC (Swisslog, HRD Logbook, Log4OM, N1MM Logger+…).

<a id="l-fiche"></a>
### 14.1 Logging a QSO

The form at the top of the tab:

| Field / button | What it does |
|---|---|
| **Indicatif** (callsign) | The correspondent's callsign. The UTC date and time fill in as soon as you type the first letter (start of the QSO). The name, QTH and locator are looked up on QRZ.com. |
| **Date UTC**, **Heure UTC** (UTC time) | Start of the QSO, in UTC (not Belgian time). |
| `⟳ Maintenant` (now) | Resets the date and time to the present moment. |
| **Fréquence MHz** (frequency), **Mode** | Follow the active VFO of the TRX by themselves. A value typed by hand is kept until the next QSO. |
| `⇩ TRX` | Takes the frequency and mode from the TRX (in DATA: the mode of the tab on screen, FT8, RTTY…), the power, and the Correspondant line (callsign, name, QTH, locator). |
| **RST env.** (sent) / **RST reçu** (received) | Report sent and received (59, 599 or dB depending on the mode). |
| **Nom**, **QTH**, **Locator**, **Puiss. W** (power), **Remarque** (comment) | QSO information; the comment is free text. |
| **TX call** | Callsign under which the QSO was made. It follows the one on the Correspondant line; with control, changing it here also changes the transmit callsign. |
| ☐ **QO-100** | QSO via the QO-100 satellite: with the converter IF (e.g. 432.525 MHz), the box ticks itself and the 2400.xxx MHz uplink frequency is logged. |
| **IOTA**, **WWFF**, **POTA**, **BOTA**, **LLOTA**, **SOTA** (in yellow, at the end of the 2nd row, right of Remarque) | The other station's references when it is activating (island, nature reserve, park, bunker, lake, summit…). Type the start of the reference (`ONFF-`, `BE-00`, `EU-`, `ON/ON-`…) or part of the **name** (« fagnes »): a list opens under the box, pick with the mouse or the arrows then `Enter`. Empty box and callsign already typed: the list first offers the references of its country. Several references (e.g. two POTA parks at once): separate them with a comma. The reference locator fills the QSO locator if empty. These boxes are cleared after each QSO. |
| `＋ Ma référence (activation)` (my reference, 1st row, right of QO-100) | Shows a row **Ma réf. (activation)** for the **station's** references, when the club itself activates a park, an island… They **stay filled** from one QSO to the next (in this browser) until you clear them. The button hides or shows the row again (remembered). |
| `Enregistrer le QSO` (or `Enter`) | Adds the QSO to the logbook. A duplicate (same callsign, band and mode within half an hour) is reported before saving; if the entry already in the logbook lacks the name, QTH, locator or received RST, you are offered to **complete** it instead of creating a 2nd QSO. |
| `Supprimer` (delete) / `Annuler` (cancel) | Appear when you edit an existing QSO: delete the QSO (after confirmation; online logbooks are not changed) or abandon the edit. |

**Without leaving the RTTY, JTTY or CW tab**: the `Log QSO` button (next to « Émettre », and on the tab row, right of Logbooks) opens a form already filled in: callsign, first name, QTH, locator and RST, frequency (in RTTY: the signal frequency) and mode, power, start time (when the correspondent was chosen) and end time. Correct if needed, then `Enregistrer dans le carnet` (save to the logbook). In FT8, this form opens by itself at the end of the QSO; a macro containing `<LOG>` also opens it.

| Log QSO form field | Content |
|---|---|
| **Indicatif** (callsign), **Nom** (name), **QTH**, **Locator** | Taken from the Correspondant row (and from QRZ.com). |
| **Date UTC**, **Début UTC** (start), **Fin UTC** (end) | Start: when the correspondent was chosen; end: when the form opens. Editable. |
| **Fréquence MHz**, **Mode** | Actual signal frequency (RTTY: carrier + decoder marked TX) and mode of the tab. |
| **RST envoyé** (sent), **RST reçu** (received), **Puiss. W** (power), **Remarque** (remark) | Reports from the Correspondant row, TRX power, free text. |
| `Enregistrer dans le carnet` (save) / `Annuler` (cancel) | Adds the QSO (duplicate check as in the Logbooks tab) or closes without logging anything. |

In **FT8 · FT4 · FT2**, at the end of the sequence, a small « **QSO terminé** » (QSO finished) window summarises the QSO (callsign, locator, mode, frequency, reports, times): `Enregistrer dans le carnet` saves it, `Ne pas enregistrer` (don't save) closes it. The **Log** choice in the FT8 transmit bar (right of "Répondre au 1er") avoids this window: **auto when sending RR73 / 73** (like WSJT-X "Log automatically"), **auto when receiving RR73 / 73** (if the QSO ends with your sending and no RR73 / 73 received, the form still asks), or **auto at the first RR73 / 73** (sent or received); the QSO then goes into the logbook on its own (other station's name and QTH included when known) and a message confirms it. Without the automatic sequence, or for a forgotten QSO: **Logbooks** tab, type the call, `⇩ TRX` (TRX frequency and mode), the reports, then save.

<a id="l-liste"></a>
### 14.2 The QSO list

- The list shows the last 300 QSOs. The **Rechercher** (search) box finds a callsign, a name or an operator; the number of QSOs found is shown next to it.
- **Click a row**: the QSO opens in the form. Its author **with control** (or an administrator) can edit or delete it; everyone else (members without control, listeners, other operators) sees it **read-only** (« Fermer » closes it). Nobody can ever edit or delete a QSO logged by another callsign, except administrators.
- Columns: date, time, callsign, band, frequency, mode, reports, name, QTH, **locator**, DXCC country, prefix, TX call, operator, references (IOTA, POTA…), **Contest** (contest during which the QSO was made, Cabrillo identifier such as CQ-WW-SSB, filled by the TRX SSB / TRX CW pages and the RTTY contest; hover: sent and received exchange), upload states (LoTW, eQSL, Club Log, QRZ).
- **VFO A / B** of the STEP row (VFO tuned by the wheel, arrows and bands): A on dark green, B on dark pink, only one at a time.
- **Small filter in each VFO display** (left of the frequency, when the display is wide enough): the VFO's [BW] and [SFT], passband in orange around 1500 Hz (700 Hz in CW) shifted by the SHIFT, edges in orange; it follows the BW and IF SHIFT settings of the left column (Icom: width and TWIN PBT).
- **MODES row** of the dashboard: the chosen mode (its page opens separately) stays marked on an azure background, even after a reload.
- **Column order**: click a column title and, holding the left button, drag it elsewhere (a blue line shows where it will go). Order remembered in your browser; double-click a title: original order.
- **Column width**: drag the right edge of a column title (double-click: original width). Setting remembered in your browser.
- **Filters**: the **▾** next to each title offers the values of that column (dates, bands, modes, countries, TX call, upload state…) with their QSO count. A choice filters the logbook (the ▾ becomes ●); several columns combine; `✕ Filtres` (filters) removes them all.

| Column | Meaning |
|---|---|
| Date, UTC | UTC date and time of the start of the QSO. |
| Indicatif | The correspondent. |
| Bande, MHz, Mode | Band, exact frequency and mode. |
| Env., Reçu | Reports sent and received. |
| Nom, QTH | First and last name, and town of the correspondent. A new QSO logged without name, QTH or locator (SSB or CW contest, automatic FT8…) is completed by itself from its QRZ.com record (empty boxes only, if the QRZ.com account is set). |
| DXCC, Préfixe | Country of the correspondent (from their callsign) and its main prefix (ON for Belgium, LA for Norway, K for the USA…). |
| TX call | The callsign under which the QSO was made (the club's or the operator's). |
| OP | The operator: personal callsign of the member who made the QSO, even under the club callsign (on hover: the account that logged it, if different). |
| LoTW, eQSL, CL, QRZ | Upload state for each service: **·** not sent yet, **✓** sent, **✗** rejected (hover = details), **★** confirmed on LoTW. |

<a id="l-export"></a>
### 14.3 Exporting

| Exporter ▾ menu (export) | What it does |
|---|---|
| **Mes QSO (.adi)** (my QSOs) | Immediately downloads the QSOs made under **your** callsign (TX call), to import into your own logging program. |
| **ADIF (.adi)…** | Selection window: TX call and date range, then download of an ADIF 3 file. A member exports their own QSOs (under their callsign, or those they made themselves under ON5VL / OR0L: « mes QSO sous cet indicatif », my QSOs under this callsign); administrators export every TX call. |
| **Cabrillo (.log)…** | Same choice, plus the contest name: Cabrillo 3 file to send to a contest's organisers. |

<a id="l-sync"></a>
### 14.4 Synchronisation (LoTW, eQSL, Club Log, QRZ)

**Synchronisation ▾** menu: it uploads the logbook QSOs to the confirmation websites. One window per service, as in Swisslog. **Administrators** handle every callsign (club and members). Each **member** who transmits under their own callsign uses it for **their own** QSOs: the callsign is theirs and cannot be changed; they enter **their own** credentials (kept on the server, never shown, usable by nobody else), can tick « send each new QSO automatically » (not shown for ON5VL / OR0L: the club's automatic upload is set in ⚙ Configuration), and their QSOs never go to the club accounts (nor the club's to theirs). A refused password only stops that callsign.

1. Choose the service: **Synchronisation LoTW…**, **Synchronisation eQSL…**, **Club Log…** or **QRZ…**.
2. **Détails** (details) tab: choose the **callsign (TX call)** whose QSOs are uploaded (the current TX call is suggested).
3. Just below, the yellow **« Identifiants <service> de <indicatif> »** (<service> credentials of <callsign>) box shows the credentials that will be used: login, password, key… A note says whether they belong to this callsign, come from the club configuration, or what is missing. Complete them if needed, then `Enregistrer pour cet indicatif` (save for this callsign). Passwords stay on the server and are never displayed: a field left empty keeps the stored value, `✕` deletes it, `👁` shows what you type.
4. Optional: **date range**, **Renvoyer aussi les QSO déjà envoyés** (also resend QSOs already sent), **Temporisation** (delay in seconds between two QSOs, so as not to be blocked by the website). Club Log: « Effacer le log ClubLog existant » (clear the existing Club Log log) replaces the whole online log (only use it if this logbook is complete). The number of QSOs to upload is shown at the bottom.
5. `Télécharger` (upload): the upload starts; the **Traitement** (processing) tab shows the progress and the report, QSO by QSO. `Arrêt` (stop) interrupts it; `Fermer` (close) closes the window: the upload continues on the server and its progress stays visible below the logbook list.

- **Club callsigns and personal callsigns**: the credentials in the general configuration (14.5) are only used for the club callsigns (ON5VL, OR0L). A personal callsign (ON6DP…) needs **its own credentials**, otherwise its QSOs are marked « non configuré » (not configured). An upload mixing several TX calls is done group by group, each with its own credentials.
- **LoTW operations**: export, sign with TQSL, upload, read confirmations, status. `Confirmations` only reads the confirmations received (★ in the list). With the server on the VPS (no TQSL): `Exporter pour TQSL (.adi)` (export for TQSL), sign the file with TQSL on the club PC, then `Marquer comme envoyés` (mark as sent).

<a id="l-config"></a>
### 14.5 Configuration

**Synchronisation ▾ → ⚙ Configuration…** (administrators): the general settings, in tabs **CLUBLOG**, **eQSL**, **LoTW**, **QRZ** and **UDP**.

- **« Télécharger automatiquement les QSO lors de leur enregistrement »** box (upload QSOs automatically when they are logged): every new QSO under a club callsign is uploaded to that service by itself.
- Club logins and passwords (`👁` to see them while typing), delay, and `Tester` (test) to check the connection to the service. The window only shows « enregistré » (stored) for passwords; leaving the field empty keeps the value, `✕` deletes it.
- **QRZ** tab, **Recherche des correspondants** (correspondent lookup): login and password of a QRZ.com account. As soon as a correspondent is chosen (click on a callsign, Correspondant line, logbook form), their first and last name (logbook form), town and, with an XML subscription, locator are filled in automatically (empty boxes only; the logbook form's `⇩ QRZ` button, next to the locator, fetches them again and replaces what is written), with a « QRZ.com : … » note below the bands.
- **QRZ** tab, **Indicatif / Clé API** table (upload to the QRZ logbook): one line per callsign (TX call) with its API key; `+ Ajouter un indicatif` (add a callsign) adds a line, `✕` removes the key.
- **UDP** tab: forwarding of each QSO to logging programs. One line per destination: **Actif** (enabled) box, **Nom** (name), **Adresse** (address), **Port**, **Format** (WSJT-X « Logged ADIF », WSJT-X « QSO Logged », N1MM Logger+, raw ADIF); the `+ WSJT-X (port 2237)`, `+ N1MM Logger+ (port 12060)` and `+ ADIF brut` buttons add a pre-filled line (address 127.0.0.1); `✕` removes it.

| Service | What you need |
|---|---|
| Club Log | Account e-mail, an application password (Club Log → Settings → App Passwords), the application API key (requested once from the Club Log helpdesk). An access refusal stops uploads until the next successful test. |
| eQSL | eQSL callsign and password; "QTH Nickname" if the account has several QTHs. |
| QRZ.com | One QRZ logbook API key per callsign (QRZ → Logbook → Settings), XML subscription or higher. |
| LoTW | **TQSL** and the callsign's **certificate** installed on the PC running the server, the TQSL "Station Location" name, and the LoTW website login for confirmations. The certificate and its password never leave that PC. |
| UDP | Address, port and format expected by the program: WSJT-X "Logged ADIF" (Swisslog, Log4OM, HRD Logbook; usually port 2237), N1MM (port 12060), or raw ADIF. Packets are sent by the server: 127.0.0.1 if the server runs on the club PC. |

<a id="clavier"></a>
## 15. Keyboard shortcuts

| Key | Action |
|---|---|
| `Space` (hold) | PTT; in FT8 / FT4 / FT2, stops automatic transmission. Also works from a separate window. |
| `W` (hold) | TXW: listen on the transmit frequency (SPLIT). |
| `↑` `↓` | Frequency ± one step (the one on the Step row). |
| `F1` … `F12` | Macros in the RTTY and CW tabs (`F1`…`F8` in JTTY). |
| `Ctrl` + `Enter` / `Enter` | Transmit the typed text in RTTY and CW / in JTTY. |
| `Esc` | Stop the current RTTY, JTTY or CW transmission. |
| `Enter` (logbook form) | Save the QSO. |
| `Shift` + mouse wheel | On the RIT / XIT value: offset in 100 Hz steps. On the RTTY waterfall: VFO ± 10 Hz per notch. |
| `Esc` (menus) | Closes the open menu: Operators, club TRX, DX Cluster, dashboard size. |
| `Enter` (chat) | Sends the message to the connected members. |
| `Ctrl` + `F5` | Reload the page after an update. |

These keys are ignored while you are typing in a text field.

<a id="problemes"></a>
## 16. Common problems

| Symptom | Likely cause and solution |
|---|---|
| Odd display, a button does not respond after an update | Old version in memory: `Ctrl` + `F5`. |
| « Ce navigateur n'est ni Chrome ni Edge » (this browser is neither Chrome nor Edge) | Open the page in Google Chrome or Microsoft Edge. |
| Serveur lamp red | Your internet connection is down; the page reconnects by itself when it comes back. |
| « Station hors ligne » (station offline) | The Station page on the club PC is closed or the PC has lost internet: tell a club manager. |
| No sound, empty waterfall, « La page Station n'envoie pas la BF » (the Station page is not sending audio) | At the club, the Station page must have audio enabled and the right sound input (section 18). At home, check your PC volume and the Volume slider. |
| Commands greyed out, « Prenez la main… » | You do not have control: `Prendre la main` or `Demander la main` (request control). |
| Nothing decoded in FT8 / RTTY… | Check the TRX mode (DATA-U; CW for CW), the frequency (↺ button), SQUELCH at 0, and DUAL RX off. The Synchro tab shows whether audio is arriving. |
| My FT8 answer goes out one period too late | The click came too late (more than 2 s into the next period). Click as soon as the decode appears. If it happens often, look at the "Décodages" box in the Synchro tab. |
| PTT refused | The message gives the reason: outside the authorised bands, SWR (do a TUNE), transmitting not enabled, listener callsign, maximum duration, TXW held… |
| The TX badge is red although I am not transmitting | Normal: dark red = transmit VFO. An actual transmission shows red frequency digits and a bright red TX badge. |
| Clicking ATT / IPO of the other VFO: the TRX changes side for a moment | Normal on the FTX-1: these settings can only be made on the active side; the TRX goes there for 2 to 3 s, without transmitting, then comes back. |
| « TUNE sans accord » (TUNE without a match), transmitting blocked on the band | The antenna cannot be matched on that frequency: do another TUNE, try the other antenna or another band, and tell a station manager. |
| A separate window does not open | Allow pop-up windows for remote.op0p.be (icon at the right of the address bar). |
| Name and QTH not filled in | The QRZ.com account is not set up, or the station is not on QRZ.com: type them in by hand. |
| Synchronisation: « non configuré » (not configured) | No credentials for that TX call: complete the « Identifiants … » box in the synchronisation window (14.4). |
| « Passage MAIN ↔ SUB refusé en réception simple » (MAIN ↔ SUB switching refused in single receive) | Normal on the FTX-1: in single receive, switching to SUB from the dashboard keyed it (seen at the club). On HF it only receives one side at a time: to listen to the VFO B frequency, use `A ⇄ B`. VFO B can still be tuned (mouse wheel, arrows, bands). |
| No more audio, silent waterfall (only a hum at the far left), « Plus de son du TRX » alert | The TRX USB sound card has frozen. A station manager clicks `Relancer la carte son` (dashboard alert or TRX menu); if that is not enough, switch the TRX off and on at the club (section 18). |
| BW greyed, « NARROW ✕ » instead of the width | NARROW is on for that side: click `NARROW ✕` or the NAR badge of the VFO display. |
| A badge (NB, ATT…) goes back to its previous state by itself | The TRX refused the setting (no effect in this mode, or inactive side): read the message under the bands. |
| DX Cluster green, but a click on a spot does nothing | The cluster is open, but you do not have control: take control so that its spots tune the TRX. |
| « Passage MAIN ↔ SUB par le dashboard désactivé » (MAIN ↔ SUB switching from the dashboard disabled) | An administrator has set `ftx1SubCat` to `false` in `config.json`: MAIN / SUB from the front panel only. |

<a id="admin"></a>
## 17. For administrators

A click on the `● Station` lamp opens the **TRX du club** (club TRX) menu:

| Command | What it does |
|---|---|
| Name of a TRX (FTX-1, FTDX10, FTDX101D / MP, IC-7300) | Switches to that TRX, after confirmation. The station restarts for a few seconds and control is kept. The TRX must be connected to the club PC and its port chosen once on the Station page. Not possible during a transmission. |
| `↻ Recharger la page Station` (reload the Station page) | Reloads the Station page on the club PC remotely (new version, page stuck…). The station is back within about ten seconds. |
| `🔊 Relancer la carte son du TRX` (restart the TRX sound card) | Only for ON6DP and ON4LUC (`stationEditors`). Restarts the TRX USB sound card on the club PC when the audio no longer comes through (section 18). Asks for confirmation; refused while transmitting. The result shows under the bands (« Carte son du TRX : … redémarré ; audio relancé »). |
| `⌨ Lecture CAT…` (CAT read) | Diagnostics: reads a raw value from the TRX (read only, list of allowed commands). Several reads on one line (« VS;FT;ST; »); `Effacer` (clear) empties the window. |

Administrators also have access to the logbook Synchronisation menu (14.4 and 14.5), to the export of every TX call, and can take back control (section 6). They can save the **club setting** of the TRX equaliser (`Equalizer TRX` button) and open the **statistics** page (📊 STATS button). Management of members, passwords and the server is described in the **Administrator guide** (`GUIDE-ADMINISTRATEUR.md`, project repository, in French).

<a id="club"></a>
## 18. The club PC (Station page)

For club managers. The PC connected to the TRX opens **https://remote.op0p.be/station** in Chrome (Web Serial). On Windows 10 / 11, the **RemoteStation-Setup** installer does everything needed: « Remote Station - Page Station » shortcut (Chrome with the right settings), start with Windows, no sleep; it can also install the server itself on that PC (see LISEZMOI-WINDOWS).

The Station page is **reserved for administrators**: the first time it is opened on a PC, log in with the callsign and password of an administrator. That PC then stays authorised for one year (renewed each time the page is opened), until « Se déconnecter » (log out). A non-administrator member is refused. The club PC's browser, which keeps the station token, also logs back in by itself.

🔒 The **Jeton de la station** (station token), **Vitesse (bps)** (speed) and **Bits de stop** (stop bits) fields are **locked**, to avoid mistakes. Only **ON6DP** and **ON4LUC**, logged in to the Station page with their callsign and password, can change them: « Se déconnecter » (log out) at the top of the page, then log in again with that callsign. The list is set in `config.json` (`stationEditors`). Choosing the model, port and audio remains free.

**FTDX101D / MP**: USB audio in stereo (MAIN receiver on the left, SUB on the right). In dual receive (DUAL RX), the Station page sends both channels: in RTTY, decoder B reads the SUB receiver, with its own waterfall to the right of A's; listening gets the mix of both, as in headphones. In single receive, one waterfall, as on the other transceivers.

1. The **station token** is fetched from the server automatically as soon as an administrator is logged in to the page (nothing to copy). Choose the TRX **model** and its **CAT port** (the first time). FTDX10 and FTDX101: **CAT RTS** OFF in the TRX menu (otherwise the link drops every 2 s). FTX-1: the **Enhanced COM Port** (CAT-1), and on the TRX the **RPTT SELECT** and **PC KEYING** settings at OFF (factory default): transmission is controlled through CAT.
2. **Activer l'audio** (enable audio) and choose the TRX sound input ("USB Audio CODEC" or "USB Audio Device" depending on the TRX); the level bar must move. Pick the card itself, not « Par défaut - … » / « Communications - … »: those Windows entries switch to another card when another TRX is plugged in (the page replaces them with the real card anyway).
3. **Sortie son vers le TRX** (sound output to the TRX, for FT8 / FT4 / FT2, RTTY, JTTY transmission): the TRX's USB sound card ("Speakers (USB Audio CODEC)"…), chosen automatically when possible. Never the PC speakers. The TRX must take DATA modulation from USB (TRX menu). Set the **transmit level** so that ALC stays low. Optional limiter: with `"digiAlcMax": 8` in `config.json`, the Station page **lowers that level by itself** as soon as ALC goes above 8 % during a digital transmission, and keeps the reached level for the following transmissions; it never goes back up by itself. By default (`0`), no limiter. Transmissions start on the server clock, even if the Windows clock is off.
4. Keep the Station page **alone in its window**; open the dashboard with its « Ouvrir le dashboard dans une autre fenêtre » (open the dashboard in another window) button.
5. Chrome → Settings → Performance: always keep remote.op0p.be active; Windows: sleep set to Never.

**Two TRX (or more) plugged into the same PC**, each on its own USB port: select each model once on the Station page, choose its CAT port and its sound card (input and output). The page remembers them **per model**. An administrator then switches from one to the other from the **STATION** menu of the dashboard (section 17): the Station page restarts with the other TRX and reopens its port and sound card within a few seconds. Never during a transmission.

### Station page controls

| Control / display | What it does |
|---|---|
| Administrateur: … `Se déconnecter` (log out) | Callsign logged in to the page. Logging out (after confirmation) closes the Station page: the station goes offline until an administrator logs in again. |
| `Ouvrir le dashboard dans une autre fenêtre` (open the dashboard in another window) | To operate from the club PC without touching the Station tab (typing another address in that tab cuts the station off). |
| **Serveur** (server) lamp | Link with remote.op0p.be; when it drops, new attempt after 1, 2, 4 then every 5 s. « Remplacée par une autre page Station » (replaced by another Station page): another page took over, this one steps back (« Enregistrer et reconnecter » to resume here). |
| **TRX** lamp and read-out line | CAT port open, TRX answering; frequency, mode and state read back. |
| `Choisir le port du TRX` (choose the TRX port) | Chrome's list of serial ports; choose the TRX one (FTX-1: Enhanced COM Port). The port is remembered **for each model**, from the USB identity of the cable (vendor, product, rank): when switching TRX remotely, the page finds the right port even if Windows renumbered the COM ports. |
| `Libérer le port` (release the port) | Closes the CAT port (the TRX is no longer controlled) and forgets the automatic choice on the next load. |
| `Port de manipulation CW (DTR)…` (CW keying port, FTX-1) | Choose once the TRX **2nd USB port** (« Standard COM Port », not the CAT one). The page then keys the CW itself through the DTR line of that port, with exact dot and dash timing, instead of using the TRX keyer memory. During each CW transmission the TRX menu PC KEYING is set to DTR (and RPTT SELECT to OFF), then back to OFF at the end. The port is remembered and reopened automatically; `Ne plus manipuler par DTR` (stop DTR keying) goes back to the keyer memory. |
| `Tester sans radio (simulation)` (test without radio) | Virtual TRX to try the page and the dashboard without transmitting. |
| **Entrée son** (sound input) | The TRX sound card (section above). The « Par défaut » and « Communications » aliases are replaced by the real card. Sound input and output are remembered **for each TRX model**, like the port. |
| **Sortie son vers le TRX** (sound output to the TRX) + **Niveau d'émission** (transmit level) | Sound card receiving the digital transmit signal, and its level (1 to 100 %): set it so that ALC stays low. « — aucune — » (none): no digital transmission. |
| **Niveau phonie à distance** (remote phone level) | Level of the operators' voice (remote phone) sent through the same sound output: set it in SSB so that ALC barely moves. The TRX "modulation source" menu is switched to USB automatically during their transmissions, then put back (club microphone). |
| Level bar, audio state | The bar moves with the TRX audio; « Audio envoyé aux membres à l'écoute » (audio sent to listening members) or « Audio prêt (personne n'écoute…) » (audio ready, nobody listening). In orange: « Entrée son muette… » (silent input: frozen sound card). |
| `Activer l'audio` / `Arrêter l'audio` (start / stop audio) | Starts or stops the audio capture; remembered and restarted automatically when the page reloads. |
| `Relancer la carte son du TRX` (restart the TRX sound card) | Restarts the TRX USB sound card through the helper (below), then restarts the audio. Greyed if the helper is not installed. |
| « Assistant carte son : … » (sound card helper) | Running, or not installed (with the **Télécharger l'assistant carte son** download link). Checked every minute. |
| **Modèle du TRX** (TRX model) | FTX-1, FTDX10, FTDX101D / MP or IC-7300; administrators also change it remotely (section 17). |
| **Jeton de la station**, **Vitesse (bps)**, **Bits de stop** (token, speed, stop bits) | 🔒 Only ON6DP and ON4LUC can change them. Speed and stop bits must match the TRX CAT menu (38400 bps and 1 stop bit by default). |
| `Enregistrer et reconnecter` (save and reconnect) | Keeps the settings in this browser and restarts the link. |
| **Journal** (log) | Everything that happens: link, port, TRX, audio, transmissions, sound card restarts, remote requests (reload, TRX switch…). |

### Frozen TRX sound card (no more audio)

The TRX's built-in USB sound card sometimes freezes silent: empty level bar on the Station page, silent waterfall (only a hum at the far left), nothing to listen to. After 45 s of silence with the TRX connected, the Station page shows it in orange, and so does the dashboard (under « Écouter le TRX », with a message to the station managers and to whoever has control).

- **Relancer la carte son du TRX** (restart the TRX sound card): button on the Station page, or, for ON6DP and ON4LUC, the « Relancer la carte son » button of the dashboard alert and the TRX menu (click the station lamp). The USB sound card is restarted on the club PC, like « Disable / Enable » in Device Manager; audio stops for about ten seconds, the TRX stays on, the CAT port is not touched. Refused while transmitting.
- Once, install the **sound card helper** on the club PC: « Télécharger l'assistant carte son » link on the Station page (while it is not installed), unzip, double-click `installer-carte-son.cmd` and accept the administrator prompt. It starts with Windows, listens only on the PC itself (127.0.0.1:18099) and only obeys the remote.op0p.be Station page. The first time, Chrome may ask for access to « local network devices »: Allow. The Station page shows « Assistant carte son : en marche ».
- **Automatic restart**: with the assistant installed, the Station page restarts the sound card by itself after 45 s of silence (receive only, never while transmitting), at most once every 10 minutes.
- **Assistant version 2**: at every Windows start it also turns off **USB power saving** (USB selective suspend, and "Allow the computer to turn off this device" on USB hubs and USB sound cards), a frequent cause of a frozen sound card. Run `installer-carte-son.cmd` once more to upgrade from version 1.
- **Assistant version 3** (0.37.175): when Windows puts the TRX sound card **in error** ("USB Composite Device" in error, "USB Audio CODEC" gone from Device Manager), a simple restart is not enough: the assistant **removes it and has Windows detect it again** (like "Uninstall" then "Scan for hardware changes"). It **watches** this sound card itself every 20 s, even with the Station page closed, and repairs it on its own (at most once every 5 min). The "Assistant carte son" line of the Station page shows the TRX sound card state and the last repair. To upgrade to version 3: download the assistant again and run `installer-carte-son.cmd` once.
- **Assistant version 4** (0.37.187): also sets the **Windows clock** to the millisecond, like NetTime (Windows Time service set on be.pool.ntp.org, europe.pool.ntp.org and time.cloudflare.com, polled every 1 to 4 minutes), at start-up, every hour and on request (Synchro tab, `⟳ Mettre à l'heure`). The "Assistant carte son" line of the Station page shows the measured offset. Uninstall NetTime from the club PC to avoid two competing settings.
- **Never another sound card instead of the TRX's**: if the TRX sound card has vanished from Windows, the Station page no longer takes the PC sound ("Stereo mix", Realtek speakers…) instead; it shows the "TRX sound card missing" alert, asks the assistant to repair it and restarts on its own as soon as the card is back. A TRX audio output that disappears is closed (digital transmission refused) instead of playing through the PC speakers. Choosing a PC sound card by hand shows a warning.
- If the restart is not enough: switch the TRX off and on (the FTX-1 cannot be switched on by CAT).

Server installation and settings: see the Administrator guide, `GUIDE-ADMINISTRATEUR.md` (project repository).
