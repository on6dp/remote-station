/*
 * digi.js — fenêtres des modes numériques : onglets Activité / FT8·FT4 / RTTY / WSPR / JT65 / Synchro,
 * et fenêtre FT8 / FT4 (cascade, activité de bande, fréquence RX).
 * Le décodage se fait sur le serveur ; cette page affiche les messages et la cascade qu'il envoie.
 * app.js appelle RSDIGI.init(api) au démarrage, puis onMessage / onBinary / onState / onHello.
 * Fenêtre séparée (digi.html) : ce même fichier s'y accroche au dashboard qui l'a ouverte (window.opener.RSHOST)
 * et utilise sa connexion ; le dashboard lui transmet les messages tant qu'elle est ouverte.
 */
(function () {
  'use strict';
  const $ = (id) => document.getElementById(id) || (window.RSPANELS ? window.RSPANELS.find(id) : null);
  const store = {
    get(k, d) { try { const v = localStorage.getItem('rs.dg.' + k); return v == null ? d : v; } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('rs.dg.' + k, String(v)); } catch (e) {} }
  };

  // Fréquences d'appel usuelles (kHz, VFO en DATA-U / USB)
  const DIAL = {
    FT8: [['160 m', 1840], ['80 m', 3573], ['60 m', 5357], ['40 m', 7074], ['30 m', 10136], ['20 m', 14074], ['17 m', 18100],
      ['15 m', 21074], ['12 m', 24915], ['10 m', 28074], ['6 m', 50313], ['2 m', 144174], ['70 cm', 432174]],
    JT65: [['160 m', 1838], ['80 m', 3576], ['40 m', 7076], ['30 m', 10138], ['20 m', 14076], ['17 m', 18102], ['15 m', 21076],
      ['12 m', 24917], ['10 m', 28076], ['6 m', 50310]],
    FT4: [['80 m', 3575.5], ['40 m', 7047.5], ['30 m', 10140], ['20 m', 14080], ['17 m', 18104], ['15 m', 21140],
      ['12 m', 24919], ['10 m', 28180], ['6 m', 50318], ['2 m', 144170]]
  };
  // QO-100 (Es'hail-2) : on émet sur la FI du convertisseur 2,4 GHz (2 m, 70 cm ou 23 cm). qoIf = FI (MHz) qui
  // correspond à 2400,000 MHz (réglage qo100If du serveur ; 432,500 pour un convertisseur à OL 1967,5 MHz).
  let qoIf = { '2m': 144.5, '70cm': 432.5, '23cm': 1296.5 };
  // Fréquences de montée (MHz) : FT8 / FT4 2400,040 (WSJT-X), CW 2400,025, RTTY 2400,090 (plan de bande AMSAT-DL)
  const QO_UP = { FT8: 2400.040, FT4: 2400.040, RTTY: 2400.090, CW: 2400.025 };
  const QO_LBL = { '2m': '2 m', '70cm': '70 cm', '23cm': '23 cm' };
  function qoEntries(m) {
    const up = QO_UP[m];
    if (!up) return [];
    // FI hors de la couverture du TRX (ex. 23 cm sur FTX-1, FTDX10, IC-7300) : pas proposée
    const R = api && api.rig && api.rig();
    const max = R && R.FREQ_MAX ? R.FREQ_MAX : Infinity;
    return Object.keys(QO_LBL).filter((k) => Number(qoIf[k]) > 0).map((k) => ['QO-100 · FI ' + QO_LBL[k], Math.round((Number(qoIf[k]) + up - 2400) * 1e6) / 1000])
      .filter((x) => x[1] * 1000 <= max);
  }
  const withQo = (list, m) => list.filter((x) => !/^QO-100/.test(x[0])).concat(qoEntries(m));
  const dialList = (m) => withQo(DIAL[m], m);
  let lastRig = '';
  function refillQo() {
    if (!$('dgDial')) return;
    lastBand = 0;
    fillDial();
    fillList($('rtDial'), withQo(RTTY_DIAL, 'RTTY'), store.get('rtdial', '14085'));
    fillList($('cwDial'), withQo(CW_DIAL, 'CW'), store.get('cwdial', '14030'));
  }
  // Fréquences candidates pour suivre la bande du TRX : une fréquence QO-100 seulement si le TRX est déjà
  // tout près (± 250 kHz) — on ne bascule pas sur le convertisseur depuis une fréquence terrestre 70 cm
  const nearList = (m, f) => { const l = dialList(m).filter((x) => !/^QO-100/.test(x[0]) || Math.abs(x[1] * 1000 - f) < 250000); return l.length ? l : DIAL[m]; };
  // Remplit une liste de fréquences en gardant le choix en cours
  function fillList(sel, list, keep) {
    if (!sel) return;
    sel.textContent = '';
    for (const [b, khz] of list) {
      const o = document.createElement('option');
      o.value = String(khz);
      o.textContent = b + ' · ' + khz.toLocaleString('fr-BE', { minimumFractionDigits: khz % 1 ? 1 : 0 }) + ' kHz';
      sel.appendChild(o);
    }
    if (keep != null) sel.value = String(keep);
  }
  const WF_MAX_HZ = 3000;
  const RX_WIDTH = 60; // Hz de part et d'autre de la fréquence RX

  const POPUP = document.body.dataset.digiPopup === '1';
  let api = null;
  let detached = false;  // dashboard : les modes numériques sont dans la fenêtre séparée
  let needHist = true;   // demander l'historique des décodages à la prochaine annonce
  let clockOff = 0;      // écart horloge du serveur − horloge de ce PC (ms)
  let bestRtt = Infinity;
  let tab = store.get(POPUP ? 'ptab' : 'tab', POPUP ? 'ftx' : 'events');
  let mode = store.get('ftmode', store.get('mode', 'FT8')) === 'FT4' ? 'FT4' : 'FT8';
  let rxF = Number(store.get('rxf', '1500')) || 1500;
  let txF = Number(store.get('txf', '1500')) || 1500; // fréquence audio d'émission (split : différente de RX)
  const SCALE_H = 30;
  let lastDecode = 0;
  let lastBand = 0;
  let stationCalls = ['ON5VL', 'OR0L'];


  // ------------------------------------------------------------------ construction des onglets et des fenêtres
  // Même code pour le centre du dashboard et pour la fenêtre séparée (digi.html, sans l'onglet Activité).
  const TABS = [
    ['events', 'Activité'], ['ftx', 'FT8 · FT4'], ['rtty', 'RTTY'], ['wspr', 'WSPR'], ['jt65', 'JT65'], ['jtty', 'JTTY'], ['cw', 'CW'], ['sstv', 'SSTV'], ['gap', ''], ['sync', 'Synchro'], ['log', 'Logs online']
  ];
  const MODE_TABS = ['ftx', 'rtty', 'wspr', 'jt65', 'jtty', 'cw', 'sstv', 'sync'];
  const WF_TABS = ['ftx', 'jt65', 'rtty', 'wspr', 'jtty', 'cw', 'sstv']; // onglets avec cascade
  const SOON = {
  };
  const FTX_PANE = `
    <div class="dg-bar">
      <div class="seg" id="dgModes">
        <button class="btn" type="button" data-mode="FT8" aria-pressed="true">FT8</button>
        <button class="btn" type="button" data-mode="FT4" aria-pressed="false">FT4</button>
      </div>
      <select id="dgDial" aria-label="Fréquence d'appel"></select>
      <button class="btn" type="button" id="dgQsy" title="Met le VFO A sur la fréquence choisie, en DATA-U">QSY</button>
      <span class="dg-split">
        <span class="dg-f rx">RX <b id="dgRxF2">1500</b> Hz</span>
        <button class="btn" type="button" id="dgTxRx" title="Émettre sur la fréquence de réception">TX ← RX</button>
        <button class="btn" type="button" id="dgRxTx" title="Recevoir sur la fréquence d'émission">RX ← TX</button>
        <span class="dg-f tx">TX <b id="dgTxF">1500</b> Hz</span>
      </span>
      <span class="dg-clock" id="dgClock">--:--:--</span>
      <span class="dg-status" id="dgStatus"></span>
    </div>
    <div class="dg-wf-slot" data-slot="ftx"><div class="dg-wf">
      <canvas id="dgScale" height="30"></canvas>
      <canvas id="dgWf" height="140"></canvas>
      <i class="dg-mk dg-mk-tx" id="dgMkTx"></i><i class="dg-mk dg-mk-rx" id="dgMkRx"></i>
    </div></div>
    <div class="dg-cols">
      <div class="dg-col">
        <div class="dg-h"><span>Activité de bande</span><button class="dg-mini" type="button" id="dgClear">Effacer</button></div>
        <div class="dg-th"><span>UTC</span><span>dB</span><span>DT</span><span>Fréq</span><span>Message</span></div>
        <div class="dg-list" id="dgBand"></div>
      </div>
      <div class="dg-col">
        <div class="dg-h"><span>Fréquence RX <b id="dgRxF">1500 Hz</b></span><span class="dg-note">clic gauche : RX · clic droit : TX · double-clic : correspondant</span></div>
        <div class="dg-th"><span>UTC</span><span>dB</span><span>DT</span><span>Fréq</span><span>Message</span></div>
        <div class="dg-list" id="dgRx"></div>
      </div>
    </div>
    <p class="dg-tx">Émission FT8 / FT4 sous l'indicatif <b>ON5VL</b> : prochaine étape (messages Tx1 à Tx6, séquence automatique).</p>`;
  const RTTY_PANE = `
    <div class="dg-bar">
      <select id="rtShift" aria-label="Shift"><option value="170">Shift 170 Hz</option><option value="200">Shift 200 Hz</option><option value="425">Shift 425 Hz</option><option value="850">Shift 850 Hz</option></select>
      <select id="rtBaud" aria-label="Vitesse"><option value="45.45">45,45 bauds</option><option value="50">50 bauds</option><option value="75">75 bauds</option><option value="100">100 bauds</option></select>
      <button class="btn" type="button" id="rtRev" aria-pressed="false" title="Échange Mark et Space (signal reçu « à l'envers »)">Inversé</button>
      <label class="rt-sq" title="Seuil de contraste Mark/Space : plus haut = moins de caractères au hasard sur le bruit">Silencieux
        <input type="range" id="rtSq" min="4" max="25" step="1" aria-label="Silencieux"><output id="rtSqV">12</output></label>
      <select id="rtDial" aria-label="Fréquence RTTY"></select>
      <button class="btn" type="button" id="rtQsy" title="Met le VFO A sur la fréquence choisie, en DATA-U">QSY</button>
      <span class="rt-tune" title="Accord : les deux barres doivent battre en alternance"><span>M</span><i><b id="rtM"></b></i><span>S</span><i><b id="rtS"></b></i></span>
      <span class="dg-f rx">Centre <b id="rtF">1500</b> Hz</span>
      <span class="dg-status" id="rtStatus"></span>
    </div>
    <div class="dg-wf-slot" data-slot="rtty"></div>
    <div class="rt-grid">
      <div class="dg-col rt-rx-col">
        <div class="dg-h"><span>Réception RTTY</span><span class="dg-note">clic sur la cascade : se caler · double-clic sur un indicatif : le reprendre</span><button class="dg-mini" type="button" id="rtClear">Effacer</button></div>
        <pre class="rt-rx" id="rtRx"></pre>
      </div>
      <div class="dg-col rt-tx-col">
        <div class="dg-h"><span>Émission</span><label class="rt-call">Correspondant <input id="rtCall" maxlength="12" placeholder="indicatif" autocomplete="off" spellcheck="false"></label></div>
        <div class="rt-macros" id="rtMacros"></div>
        <textarea id="rtTxt" rows="4" placeholder="Texte à émettre (les macros s'ajoutent ici)…" spellcheck="false"></textarea>
        <div class="rt-tx-act">
          <button class="btn btn-tx" type="button" id="rtSend" disabled>Émettre</button>
          <button class="btn" type="button" id="rtTxClear">Effacer</button>
          <span class="dg-note">Émission RTTY sous <b>ON5VL</b> : avec l'émission des modes numériques (prochaine version).</span>
        </div>
      </div>
    </div>`;
  const WSPR_PANE = `
    <div class="dg-bar">
      <select id="wsDial" aria-label="Fréquence WSPR"></select>
      <button class="btn" type="button" id="wsQsy" title="Met le VFO A sur la fréquence WSPR choisie">QSY</button>
      <span class="dg-f">Bande WSPR : <b>1400 – 1600 Hz</b> audio</span>
      <span class="dg-clock" id="wsClock">--:--</span>
      <span class="dg-status" id="wsStatus"></span>
    </div>
    <div class="dg-wf-slot" data-slot="wspr"></div>
    <div class="dg-col ws-col">
      <div class="dg-h"><span>Stations WSPR entendues <b id="wsCount"></b></span><span class="dg-note">périodes de 2 minutes · décodage une dizaine de secondes après la minute paire</span><button class="dg-mini" type="button" id="wsClear">Effacer</button></div>
      <div class="ws-th"><span>UTC</span><span>dB</span><span>DT</span><span>Fréquence</span><span>Dérive</span><span>Indicatif</span><span>Locator</span><span>Puiss.</span><span>Distance</span></div>
      <div class="dg-list ws-list" id="wsList"></div>
    </div>`;
  const JTTY_PANE = `
    <div class="dg-bar">
      <select id="jtDial" aria-label="Fréquence JTTY"></select>
      <button class="btn" type="button" id="jtQsy" title="Met le VFO A sur la fréquence JTTY choisie, en DATA-U">QSY</button>
      <span class="dg-f rx">RX <b id="jtRxF">1500</b> Hz</span>
      <span class="dg-f tx">TX <b id="jtTxF">1500</b> Hz</span>
      <span class="dg-note">4-GFSK · 31,25 bauds · 127 Hz · trames de 1,9 s, à tout moment</span>
      <span class="dg-status" id="jtStatus"></span>
    </div>
    <div class="dg-wf-slot" data-slot="jtty"></div>
    <div class="dg-cols">
      <div class="dg-col">
        <div class="dg-h"><span>Activité JTTY</span><button class="dg-mini" type="button" id="jtClear">Effacer</button></div>
        <div class="jt-th"><span>UTC</span><span>dB</span><span>Fréq</span><span>Message</span></div>
        <div class="dg-list" id="jtBand"></div>
      </div>
      <div class="dg-col">
        <div class="dg-h"><span>Fréquence RX <b id="jtRxF2">1500 Hz</b></span><span class="dg-note">clic gauche : RX · clic droit : TX · double-clic : correspondant</span></div>
        <div class="dg-list jt-chat" id="jtRx"></div>
      </div>
    </div>
    <div class="jt-tx">
      <div class="rt-macros" id="jtMacros"></div>
      <div class="jt-tx-row">
        <input id="jtTxt" maxlength="160" placeholder="Texte à émettre (F1 à F8 : macros)…" autocomplete="off" spellcheck="false">
        <button class="btn btn-tx" type="button" id="jtSend" disabled>Émettre</button>
      </div>
      <p class="dg-tx">Émission JTTY sous <b>ON5VL</b> : avec l'émission des modes numériques (prochaine version).</p>
    </div>`;
  const CW_PANE = `
    <div class="dg-bar">
      <select id="cwDial" aria-label="Fréquence CW"></select>
      <button class="btn" type="button" id="cwQsy" title="Met le VFO A sur la fréquence choisie, en CW">QSY</button>
      <select id="cwBw" aria-label="Filtre du décodeur" title="Largeur du filtre du décodeur : étroit = moins de bruit et de QRM, mais il faut être bien calé"><option value="50">Filtre 50 Hz</option><option value="100">Filtre 100 Hz</option><option value="200">Filtre 200 Hz</option><option value="400">Filtre 400 Hz</option></select>
      <label class="rt-sq" title="Niveau minimal du signal au-dessus du bruit : plus haut = moins de lettres au hasard sur le bruit">Silencieux
        <input type="range" id="cwSq" min="0" max="20" step="1" aria-label="Silencieux"><output id="cwSqV">5</output></label>
      <span class="cw-lvl" title="Niveau du signal au-dessus du bruit (dB) ; le voyant suit la manipulation"><i class="cw-led" id="cwLed"></i><i class="cw-bar"><b id="cwBar"></b></i><span id="cwDb">0 dB</span></span>
      <span class="dg-f rx">Tonalité <b id="cwF">700</b> Hz</span>
      <span class="dg-f">Vitesse <b id="cwWpm">—</b> mots/min</span>
      <span class="dg-status" id="cwStatus"></span>
    </div>
    <div class="dg-wf-slot" data-slot="cw"></div>
    <div class="rt-grid">
      <div class="dg-col rt-rx-col">
        <div class="dg-h"><span>Réception CW</span><span class="dg-note">clic sur la cascade : se caler sur le signal le plus proche · double-clic sur un indicatif : le reprendre</span><button class="dg-mini" type="button" id="cwClear">Effacer</button></div>
        <pre class="rt-rx" id="cwRx"></pre>
      </div>
      <div class="dg-col rt-tx-col">
        <div class="dg-h"><span>Émission</span><label class="rt-call">Vitesse <input id="cwSpeed" type="number" min="5" max="50" step="1" title="Vitesse du manipulateur du TRX (mots/minute)"> mots/min</label></div>
        <div class="rt-macros" id="cwMacros"></div>
        <textarea id="cwTxt" rows="4" placeholder="Texte à émettre (F1 à F12 : macros)…" spellcheck="false"></textarea>
        <div class="rt-tx-act">
          <button class="btn btn-tx" type="button" id="cwSend" disabled>Émettre</button>
          <button class="btn" type="button" id="cwTxClear">Effacer</button>
          <span class="dg-note">Émission CW sous <b>ON5VL</b> par le manipulateur du TRX : prochaine version.</span>
        </div>
      </div>
    </div>`;
  const SSTV_PANE = `
    <div class="dg-bar">
      <select id="ssDial" aria-label="Fréquence SSTV"></select>
      <button class="btn" type="button" id="ssQsy" title="Met le VFO A sur la fréquence SSTV choisie">QSY</button>
      <span class="dg-f">Image : <b>1500 – 2300 Hz</b> · synchro 1200 Hz</span>
      <span class="ss-prog"><i><b id="ssProg"></b></i><span id="ssProgT"></span></span>
      <span class="dg-status" id="ssStatus"></span>
    </div>
    <div class="dg-wf-slot" data-slot="sstv"></div>
    <div class="ss-grid">
      <div class="dg-col ss-rx">
        <div class="dg-h"><span>Réception SSTV <b id="ssCap"></b></span><span class="dg-note">Martin, Scottie, Robot, PD : départ automatique sur le code VIS</span><button class="dg-mini" type="button" id="ssSave" title="Enregistrer l'image affichée sur votre PC">PNG</button></div>
        <div class="ss-view"><canvas id="ssCanvas" width="320" height="256"></canvas><p class="ss-empty" id="ssEmpty">En attente d'une image…</p></div>
        <div class="ss-gal" id="ssGal" aria-label="Dernières images reçues"></div>
      </div>
      <div class="dg-col ss-tx">
        <div class="dg-h"><span>Émission</span>
          <select id="ssTxMode" aria-label="Mode d'émission"></select><span class="dg-note" id="ssDur"></span></div>
        <div class="ss-src">
          <label class="btn ss-file" title="Choisir une ou plusieurs images sur votre PC">Images du PC…<input type="file" id="ssFile" accept="image/*" multiple hidden></label>
          <div class="ss-thumbs" id="ssThumbs"></div>
        </div>
        <div class="ss-txbody">
          <div class="ss-cview"><canvas id="ssCompose" class="ss-compose" width="320" height="256"></canvas></div>
          <div class="ss-text">
            <input id="ssT0" maxlength="40" spellcheck="false" autocomplete="off" placeholder="Texte en haut" aria-label="Texte en haut" title="Texte en haut de l'image">
            <input id="ssT1" maxlength="40" spellcheck="false" autocomplete="off" placeholder="Texte au centre" aria-label="Texte au centre" title="Texte au centre de l'image">
            <input id="ssT2" maxlength="40" spellcheck="false" autocomplete="off" placeholder="Texte en bas" aria-label="Texte en bas" title="Texte en bas de l'image">
            <div class="ss-opt">
              <select id="ssSize" aria-label="Taille du texte"><option value="0.075">Petit</option><option value="0.1">Moyen</option><option value="0.13">Grand</option></select>
              <input type="color" id="ssColor" value="#ffe14a" aria-label="Couleur du texte" title="Couleur du texte">
            </div>
            <div class="ss-tags" id="ssTags"></div>
            <div class="ss-act">
              <button class="btn" type="button" id="ssPlay" title="Joue le signal SSTV sur les haut-parleurs de votre PC (essai, sans émission)">▶ Écouter</button>
              <button class="btn" type="button" id="ssWav" title="Enregistre le signal SSTV en fichier WAV (essai avec un autre logiciel)">WAV</button>
              <button class="btn btn-tx" type="button" id="ssSend" disabled>Émettre</button>
            </div>
          </div>
        </div>
        <p class="dg-tx ss-note">Émission SSTV sous <b>ON5VL</b> : avec l'émission des modes numériques (prochaine version). Clic droit sur une vignette : la retirer · glisser-déposer accepté.</p>
      </div>
    </div>`;
  const SYNC_PANE = `
    <div class="sy-grid">
      <div class="sy-box"><span>Heure du serveur (UTC)</span><b id="syVps">--:--:--</b><small>référence de tous les décodages</small></div>
      <div class="sy-box"><span>Votre PC</span><b id="syPc">—</b><small id="syPcNote">écart avec le serveur</small></div>
      <div class="sy-box"><span>Liaison station → serveur</span><b id="syLat">—</b><small>délai mesuré et corrigé automatiquement</small></div>
      <div class="sy-box"><span>DT médian</span><b id="syDt">—</b><small id="syDtNote">derniers décodages FT8 / FT4</small></div>
    </div>
    <p class="sy-note">Le décodage se cale sur l'horloge du serveur (synchronisée par NTP) : l'heure du PC du club et celle de votre PC
      n'interviennent pas. Le délai de la liaison est mesuré d'après les stations décodées ; un DT médian proche de 0,0 s montre que tout est calé.</p>`;

  function buildDom() {
    const bar = $('ctabs');
    bar.textContent = '';
    for (const [id, label] of TABS) {
      if (id === 'events' && POPUP) continue;
      if (id === 'log' && (POPUP || !window.RSLOG)) continue; // carnet de trafic : dashboard seulement
      if (id === 'gap') { const g = document.createElement('span'); g.className = 'ctab-gap'; bar.appendChild(g); continue; }
      const b = document.createElement('button');
      b.className = 'ctab';
      b.type = 'button';
      b.setAttribute('role', 'tab');
      b.dataset.tab = id;
      b.textContent = label;
      bar.appendChild(b);
    }
    const det = document.createElement('button');
    det.className = 'ctab-detach';
    det.type = 'button';
    det.id = 'dgDetach';
    det.textContent = POPUP ? '⧉ Ramener dans le dashboard' : '⧉';
    det.title = POPUP ? 'Fermer cette fenêtre et ramener les modes numériques dans le dashboard' : 'Ouvrir les modes numériques dans une fenêtre séparée';
    bar.appendChild(det);
    const panel = $('centerPanel');
    const add = (id, cls, html) => {
      const d = document.createElement('div');
      d.className = 'ctab-pane ' + cls;
      d.dataset.pane = id;
      d.hidden = true;
      d.innerHTML = html;
      panel.appendChild(d);
    };
    add('ftx', 'dg', FTX_PANE);
    add('rtty', 'dg rt', RTTY_PANE);
    add('wspr', 'dg ws', WSPR_PANE);
    add('jtty', 'dg jt', JTTY_PANE);
    add('cw', 'dg rt cwp', CW_PANE);
    add('sstv', 'dg ss', SSTV_PANE);
    for (const k in SOON) add(k, 'dg-soon', '<p>' + SOON[k] + '</p><p class="dg-note">En préparation.</p>');
    add('sync', 'dg-sync', SYNC_PANE);
    if (!POPUP && window.RSLOG) { add('log', 'lg', ''); window.RSLOG.mount(panel.lastElementChild); }
    add('away', 'dg-soon', '<p>Les modes numériques sont ouverts dans une <b>fenêtre séparée</b>.</p><p><button class="btn" type="button" id="dgBack">Ramener ici</button></p>');
  }

  // ------------------------------------------------------------------ onglets
  function showTab(t) {
    if (!document.querySelector('#centerPanel .ctab[data-tab="' + t + '"]')) t = POPUP ? 'ftx' : 'events';
    tab = t;
    store.set(POPUP ? 'ptab' : 'tab', t);
    // JT65 utilise la même fenêtre que FT8 / FT4 (cascade, activité de bande, fréquence RX, split)
    let pane = detached && MODE_TABS.indexOf(t) >= 0 ? 'away' : t === 'jt65' ? 'ftx' : t;
    if (pane === 'ftx') {
      const want = t === 'jt65' ? 'JT65' : (store.get('ftmode', 'FT8') === 'FT4' ? 'FT4' : 'FT8');
      if (mode !== want) { mode = want; modeChanged(); if (api && t === 'jt65' && api.iControl()) setTimeout(autoQsy, 0); }
      const seg = $('dgModes');
      if (seg) seg.style.display = t === 'jt65' ? 'none' : ''; // JT65 : pas de choix FT8 / FT4
    }
    document.querySelectorAll('#centerPanel .ctab').forEach((b) => b.setAttribute('aria-selected', String(b.dataset.tab === t)));
    document.querySelectorAll('#centerPanel .ctab-pane').forEach((p) => { p.hidden = p.dataset.pane !== pane; });
    // Une seule cascade, déplacée dans la fenêtre affichée (FT8/FT4 ou RTTY)
    if (WF_TABS.indexOf(pane) >= 0) {
      const slot = document.querySelector('.dg-wf-slot[data-slot="' + pane + '"]');
      const el = document.querySelector('.dg-wf');
      if (slot && el && el.parentElement !== slot) slot.appendChild(el);
      el.classList.toggle('is-rtty', pane === 'rtty' || pane === 'cw');
      sizeCanvas();
    }
    if (pane === 'sync') drawSync();
    if (pane === 'log' && window.RSLOG) window.RSLOG.show();
    if (pane === 'sstv' && ssShown) { const it = ssImgs.get(ssShown); if (it && it.data) ssCanvasFor(it.meta).putImageData(it.data, 0, 0); ssThumbs(); }
    announce();
  }
  function setDetached(on) {
    detached = !!on;
    if (!on) { needHist = true; wsNeedHist = true; jtNeedHist = true; ssNeedHist = true; } // retour de la fenêtre séparée : on récupère ce qui a été décodé entre-temps
    // Fenêtre séparée ouverte : le centre du dashboard revient sur l'activité de la station
    showTab(on && !POPUP && MODE_TABS.indexOf(tab) >= 0 ? 'events' : tab);
  }
  // Le serveur ne décode (et la station n'envoie la BF) que si au moins un membre regarde la fenêtre
  function announce() {
    if (!api || (detached && !POPUP)) return; // la fenêtre séparée annonce elle-même
    const watching = WF_TABS.indexOf(tab) >= 0 && !$('centerPanel').classList.contains('collapsed') && !document.hidden;
    if (watching && tab === 'cw') return api.send({ t: 'digi', mode: 'CW', cw: cwc });
    if (watching && tab === 'sstv') { api.send({ t: 'digi', mode: 'SSTV', hist: ssNeedHist }); ssNeedHist = false; return; }
    if (watching && tab === 'jtty') { api.send({ t: 'digi', mode: 'JTTY', hist: jtNeedHist }); jtNeedHist = false; return; }
    if (watching && tab === 'rtty') return api.send({ t: 'digi', mode: 'RTTY', rtty: rt });
    if (watching && tab === 'wspr') { api.send({ t: 'digi', mode: 'WSPR', hist: wsNeedHist }); wsNeedHist = false; return; }
    api.send({ t: 'digi', mode: watching ? mode : null, hist: watching && needHist });
    if (watching) needHist = false;
  }

  // ------------------------------------------------------------------ cascade
  const wf = { ctx: null, sctx: null, w: 0, h: 140, img: null };
  function sizeCanvas() {
    const c = $('dgWf');
    const s = $('dgScale');
    const w = Math.max(200, Math.floor(c.clientWidth || c.parentElement.clientWidth));
    if (w === wf.w && wf.ctx) return drawScale();
    const old = wf.ctx ? wf.ctx.getImageData(0, 0, wf.w, wf.h) : null;
    c.width = w;
    s.width = w;
    wf.w = w;
    wf.ctx = c.getContext('2d');
    wf.sctx = s.getContext('2d');
    wf.ctx.fillStyle = '#05080d';
    wf.ctx.fillRect(0, 0, w, wf.h);
    if (old) wf.ctx.putImageData(old, 0, 0);
    drawScale();
  }
  // Palette : bruit sombre → bleu → cyan → jaune → rouge
  const PAL = (() => {
    const stops = [[0, 5, 8, 13], [0.25, 10, 40, 110], [0.5, 0, 170, 220], [0.75, 240, 220, 70], [1, 255, 60, 30]];
    const p = new Uint8Array(256 * 3);
    for (let i = 0; i < 256; i++) {
      const x = i / 255;
      let k = 0;
      while (k < stops.length - 2 && x > stops[k + 1][0]) k++;
      const a = stops[k], b = stops[k + 1];
      const u = (x - a[0]) / (b[0] - a[0]);
      for (let j = 0; j < 3; j++) p[i * 3 + j] = Math.round(a[j + 1] + (b[j + 1] - a[j + 1]) * u);
    }
    return p;
  })();
  let floor = null;
  function onRow(bytes) {
    if (WF_TABS.indexOf(tab) < 0 || detached || !wf.ctx) return;
    // bytes[0] = 0x10, puis une case de 6,25 Hz par octet (dB*2+240), depuis 0 Hz
    const n = Math.min(bytes.length - 1, Math.ceil(WF_MAX_HZ / 6.25));
    const vals = bytes.subarray(1, 1 + n);
    if (tab === 'cw') { cwRows.push(Uint8Array.from(vals)); if (cwRows.length > 12) cwRows.shift(); }
    // Plancher de bruit : médiane de la ligne, lissée
    const sorted = Array.from(vals).sort((a, b) => a - b);
    const med = sorted[sorted.length >> 1];
    floor = floor == null ? med : floor * 0.9 + med * 0.1;
    const ctx = wf.ctx;
    ctx.drawImage(ctx.canvas, 0, 0, wf.w, wf.h - 1, 0, 1, wf.w, wf.h - 1); // la cascade descend d'une ligne
    if (!wf.img || wf.img.width !== wf.w) wf.img = ctx.createImageData(wf.w, 1);
    const d = wf.img.data;
    for (let x = 0; x < wf.w; x++) {
      const v = vals[Math.min(n - 1, Math.floor((x / wf.w) * n))];
      // 0 dB au-dessus du bruit → sombre ; +25 dB → rouge (octets : 2 par dB)
      let i = Math.round(((v - floor) / 50 + 0.06) * 255);
      i = i < 0 ? 0 : i > 255 ? 255 : i;
      d[x * 4] = PAL[i * 3];
      d[x * 4 + 1] = PAL[i * 3 + 1];
      d[x * 4 + 2] = PAL[i * 3 + 2];
      d[x * 4 + 3] = 255;
    }
    ctx.putImageData(wf.img, 0, 0);
  }
  function drawScale() {
    const c = wf.sctx;
    if (!c) return;
    const w = wf.w;
    const H = SCALE_H;
    c.clearRect(0, 0, w, H);
    c.fillStyle = '#0b1018';
    c.fillRect(0, 0, w, H);
    c.font = '10px "Roboto Mono", monospace';
    c.textBaseline = 'top';
    for (let f = 0; f <= WF_MAX_HZ; f += 100) {
      const x = Math.round((f / WF_MAX_HZ) * (w - 1)) + 0.5;
      const big = f % 500 === 0;
      c.strokeStyle = big ? '#5a6878' : '#2b3644';
      c.beginPath();
      c.moveTo(x, big ? 12 : 17);
      c.lineTo(x, H);
      c.stroke();
      if (big && f > 0 && f < WF_MAX_HZ) {
        c.fillStyle = '#8b98a8';
        c.fillText(String(f), x - c.measureText(String(f)).width / 2, 1);
      }
    }
    if (tab === 'rtty') return drawRttyMarks(c, w);
    if (tab === 'wspr') return drawWsprMarks(c, w);
    if (tab === 'cw') return drawCwMarks(c, w);
    if (tab === 'sstv') return drawSstvMarks(c, w);
    // Largeur d'un signal FT8 (50 Hz) / FT4 (83 Hz) / JT65 (178 Hz) / JTTY (127 Hz, centré) : TX en rouge, RX en vert
    const bw = tab === 'jtty' ? 127 : mode === 'FT4' ? 83 : mode === 'JT65' ? 178 : 50;
    const mark = (f, y, h, fill, edge) => {
      const x0 = (f / WF_MAX_HZ) * w;
      const x1 = ((f + bw) / WF_MAX_HZ) * w;
      c.fillStyle = fill;
      c.fillRect(x0, y, Math.max(2, x1 - x0), h);
      c.fillStyle = edge;
      c.fillRect(x0, y, 2, h);
    };
    mark(txF, 12, 8, 'rgba(255, 32, 32, .45)', '#ff5a4a');
    mark(rxF, 21, 9, 'rgba(0, 204, 102, .45)', '#4ED37B');
    // Repères sur la cascade
    const pos = (el, f) => { el.style.left = (f / WF_MAX_HZ) * 100 + '%'; el.style.width = (bw / WF_MAX_HZ) * 100 + '%'; };
    pos($('dgMkRx'), rxF);
    pos($('dgMkTx'), txF);
    $('dgRxF').textContent = Math.round(rxF) + ' Hz';
    $('dgRxF2').textContent = Math.round(rxF);
    $('dgTxF').textContent = Math.round(txF);
    if ($('jtRxF')) { $('jtRxF').textContent = Math.round(rxF); $('jtTxF').textContent = Math.round(txF); $('jtRxF2').textContent = Math.round(rxF) + ' Hz'; }
  }
  // ------------------------------------------------------------------ RTTY
  const RTTY_DIAL = [['80 m', 3590], ['40 m', 7040], ['30 m', 10142], ['20 m', 14085], ['17 m', 18101], ['15 m', 21085], ['12 m', 24910], ['10 m', 28085]];
  const rt = (() => {
    let o = {};
    try { o = JSON.parse(store.get('rtty', '{}')) || {}; } catch (e) { o = {}; }
    return { f: Number(o.f) || 1500, shift: [170, 200, 425, 850].indexOf(o.shift) >= 0 ? o.shift : 170,
      baud: [45.45, 50, 75, 100].indexOf(o.baud) >= 0 ? o.baud : 45.45, rev: !!o.rev, squelch: Number(o.squelch) || 12 };
  })();
  // ------------------------------------------------------------------ macros (comme FLDIGI : F1 à F12, modifiables)
  // Balises : <MYCALL> <CALL> <NAME> <QTH> <RST> <LOC> <MYLOC> <MYQTH> <OPCALL> <CNTR> <INCR> <ZT> <ZD>
  const DEF_MACROS = {
    RTTY: [
      { name: 'CQ', text: 'CQ CQ CQ DE <MYCALL> <MYCALL> <MYCALL>\nCQ CQ CQ DE <MYCALL> <MYCALL> <MYCALL> PSE K\n' },
      { name: 'Appel', text: '<CALL> <CALL> DE <MYCALL> <MYCALL> <MYCALL> K\n' },
      { name: 'QSO', text: '<CALL> DE <MYCALL> TNX FER CALL <NAME>\nUR RST <RST> <RST> QTH <MYQTH> <MYQTH> LOC <MYLOC>\nHW? <CALL> DE <MYCALL> K\n' },
      { name: 'Station', text: 'STATION DU CLUB UBA-LGE <MYCALL> - OPERATEUR <OPCALL>\n' },
      { name: 'BTU', text: 'BTU <CALL> DE <MYCALL> K\n' },
      { name: '73', text: '<CALL> TNX FER QSO <NAME> 73 GL\n<CALL> DE <MYCALL> SK\n' },
      { name: 'QRZ?', text: 'QRZ? DE <MYCALL> K\n' },
      { name: 'Contest', text: '<CALL> 599 <CNTR> <CNTR>\n' },
      { name: 'TU', text: 'TU <INCR><MYCALL> TEST\n' },
      { name: 'AGN?', text: 'AGN? AGN? PSE\n' },
      { name: 'RYRY', text: 'RYRYRYRYRYRYRYRYRYRYRYRY\n' },
      { name: 'Heure', text: 'UTC <ZT> <ZD>\n' }
    ],
    // JTTY : les 8 touches de fonction de WSJT-X (forme compacte : 1 ou 2 trames par message)
    JTTY: [
      { name: 'CQ', text: 'CQ <MYCALL> CQ' },
      { name: 'Échange', text: '<CALL> 599 <CNTR>' },
      { name: 'TU', text: '<CALL> TU CQ <MYCALL> CQ' },
      { name: 'Mon ind.', text: '<MYCALL>' },
      { name: 'Son ind.', text: '<CALL>' },
      { name: 'TU NOW', text: 'TU NOW <CALL> 599 <CNTR>' },
      { name: 'AGN?', text: '<CALL> AGN?' },
      { name: '599', text: '599 <CNTR>' }
    ],
    CW: [
      { name: 'CQ', text: 'CQ CQ CQ DE <MYCALL> <MYCALL> <MYCALL> K' },
      { name: 'Appel', text: '<CALL> DE <MYCALL> <MYCALL> K' },
      { name: 'Report', text: '<CALL> TU UR 5NN 5NN BK' },
      { name: 'R TU', text: 'R TU 73 <CALL> DE <MYCALL> SK' },
      { name: '73', text: '<CALL> TNX FER QSO 73 DE <MYCALL> SK' },
      { name: 'QRZ?', text: 'QRZ? DE <MYCALL> K' },
      { name: 'AGN?', text: 'AGN? AGN?' }
    ]
  };
  const TAGS = [
    ['<MYCALL>', 'indicatif émis (ON5VL)'], ['<CALL>', 'correspondant'], ['<NAME>', 'son prénom'], ['<QTH>', 'son QTH'],
    ['<RST>', 'report envoyé'], ['<LOC>', 'son locator'], ['<MYLOC>', 'locator de la station'], ['<MYQTH>', 'QTH de la station'],
    ['<OPCALL>', 'votre indicatif (opérateur)'], ['<CNTR>', 'numéro de série'], ['<INCR>', 'numéro suivant'], ['<ZT>', 'heure UTC'], ['<ZD>', 'date UTC']
  ];
  let macros = (() => { try { return JSON.parse(store.get('macros', '{}')) || {}; } catch (e) { return {}; } })();
  const macroList = (mode) => (macros[mode] && macros[mode].length ? macros[mode] : DEF_MACROS[mode] || []);
  function saveRtty(reannounce) {
    store.set('rtty', JSON.stringify(rt));
    if (reannounce) announce();
  }
  function drawRttyMarks(c, w) {
    const half = rt.shift / 2;
    const fm = rt.rev ? rt.f - half : rt.f + half;
    const fs = rt.rev ? rt.f + half : rt.f - half;
    const bw = Math.max(20, rt.baud);
    const bar = (f, y, h, fill, edge) => {
      const x0 = ((f - bw / 2) / WF_MAX_HZ) * w;
      c.fillStyle = fill;
      c.fillRect(x0, y, Math.max(2, (bw / WF_MAX_HZ) * w), h);
      c.fillStyle = edge;
      c.fillRect((f / WF_MAX_HZ) * w - 1, y, 2, h);
    };
    bar(fm, 14, 16, 'rgba(242, 207, 74, .35)', '#F2CF4A');
    bar(fs, 14, 16, 'rgba(0, 212, 255, .3)', '#00D4FF');
    const pos = (el, f) => { el.style.left = ((f - bw / 2) / WF_MAX_HZ) * 100 + '%'; el.style.width = (bw / WF_MAX_HZ) * 100 + '%'; };
    pos($('dgMkRx'), fm);
    pos($('dgMkTx'), fs);
    $('rtF').textContent = Math.round(rt.f);
  }
  function setRttyF(f) {
    rt.f = Math.max(200 + rt.shift / 2, Math.min(WF_MAX_HZ - 100 - rt.shift / 2, Math.round(f)));
    saveRtty(true);
    drawScale();
  }
  function rttyAppend(text) {
    const el = $('rtRx');
    const atEnd = el.scrollHeight - el.scrollTop - el.clientHeight < 30;
    el.appendChild(document.createTextNode(text));
    if (el.textContent.length > 20000) el.textContent = el.textContent.slice(-15000);
    if (atEnd) el.scrollTop = el.scrollHeight;
  }
  function rttyLevels(m) {
    // Barres Mark / Space : 0 à 40 dB au-dessus du plancher
    $('rtM').style.width = Math.max(0, Math.min(100, (m.m / 40) * 100)) + '%';
    $('rtS').style.width = Math.max(0, Math.min(100, (m.s / 40) * 100)) + '%';
  }
  // Remplace les balises d'une macro ; <INCR> fait avancer le numéro de série (seulement si apply)
  function macroText(t, apply) {
    const up = (v) => String(v || '').trim().toUpperCase();
    const d = new Date(now());
    const p2 = (n) => String(n).padStart(2, '0');
    let cntr = Number(store.get('cntr', '1')) || 1;
    let out = String(t)
      .replace(/<MYCALL>|\{MY\}/g, myCall)
      .replace(/<CALL>|\{CALL\}/g, up(dx.call) || '???')
      .replace(/<NAME>/g, up(dx.name))
      .replace(/<QTH>/g, up(dx.qth))
      .replace(/<RST>/g, up(dx.rst) || '599')
      .replace(/<LOC>/g, up(dx.grid))
      .replace(/<MYLOC>/g, myGrid)
      .replace(/<MYQTH>/g, myQth)
      .replace(/<OPCALL>/g, opCall)
      .replace(/<ZT>/g, p2(d.getUTCHours()) + p2(d.getUTCMinutes()))
      .replace(/<ZD>/g, d.getUTCFullYear() + p2(d.getUTCMonth() + 1) + p2(d.getUTCDate()));
    const pad3 = (n) => String(n).padStart(3, '0');
    out = out.replace(/<CNTR>/g, pad3(cntr));
    if (/<INCR>/.test(out)) {
      if (apply) { cntr++; store.set('cntr', cntr); }
      out = out.replace(/<INCR>/g, '');
    }
    return out;
  }
  function initRtty() {
    $('rtShift').value = String(rt.shift);
    $('rtBaud').value = String(rt.baud);
    $('rtRev').setAttribute('aria-pressed', String(rt.rev));
    $('rtSq').value = String(rt.squelch);
    $('rtSqV').textContent = String(rt.squelch);
    $('rtShift').addEventListener('change', () => { rt.shift = Number($('rtShift').value); setRttyF(rt.f); });
    $('rtBaud').addEventListener('change', () => { rt.baud = Number($('rtBaud').value); saveRtty(true); drawScale(); });
    $('rtRev').addEventListener('click', () => { rt.rev = !rt.rev; $('rtRev').setAttribute('aria-pressed', String(rt.rev)); saveRtty(true); drawScale(); });
    $('rtSq').addEventListener('input', () => { $('rtSqV').textContent = $('rtSq').value; });
    $('rtSq').addEventListener('change', () => { rt.squelch = Number($('rtSq').value); saveRtty(true); });
    const dial = $('rtDial');
    fillList(dial, withQo(RTTY_DIAL, 'RTTY'), store.get('rtdial', '14085'));
    // Choisir une bande dans la liste y envoie directement le TRX (QSY)
    dial.addEventListener('change', () => { store.set('rtdial', dial.value); qsyTo(Number(dial.value)); });
    $('rtQsy').addEventListener('click', () => qsyTo(Number(dial.value)));
    $('rtClear').addEventListener('click', () => { $('rtRx').textContent = ''; });
    $('rtTxClear').addEventListener('click', () => { $('rtTxt').value = ''; });
    // Double-clic sur un mot reçu qui ressemble à un indicatif : il devient le correspondant
    $('rtRx').addEventListener('dblclick', () => {
      const w = String(window.getSelection() || '').trim().toUpperCase();
      if (CALL_RE.test(w)) setDx({ call: w });
    });
    drawRttyMacros();
  }


  // ------------------------------------------------------------------ WSPR
  const WSPR_DIAL = [['160 m', 1836.6], ['80 m', 3568.6], ['60 m', 5364.7], ['40 m', 7038.6], ['30 m', 10138.7], ['20 m', 14095.6],
    ['17 m', 18104.6], ['15 m', 21094.6], ['12 m', 24924.6], ['10 m', 28124.6], ['6 m', 50293], ['2 m', 144489], ['70 cm', 432300]];
  let wsNeedHist = true;
  const wsHist = []; // { slot, list }
  let wsLast = 0;
  // Locator Maidenhead → latitude / longitude (centre du carré)
  function grid2ll(g) {
    g = String(g || '').toUpperCase();
    if (!/^[A-R]{2}\d{2}([A-X]{2})?$/.test(g)) return null;
    let lon = (g.charCodeAt(0) - 65) * 20 - 180 + Number(g[2]) * 2;
    let lat = (g.charCodeAt(1) - 65) * 10 - 90 + Number(g[3]);
    if (g.length === 6) { lon += (g.charCodeAt(4) - 65) / 12 + 1 / 24; lat += (g.charCodeAt(5) - 65) / 24 + 1 / 48; }
    else { lon += 1; lat += 0.5; }
    return [lat, lon];
  }
  function distKm(a, b) {
    const r = Math.PI / 180;
    const d = Math.sin((b[0] - a[0]) * r / 2) ** 2 + Math.cos(a[0] * r) * Math.cos(b[0] * r) * Math.sin((b[1] - a[1]) * r / 2) ** 2;
    return Math.round(6371 * 2 * Math.asin(Math.sqrt(d)));
  }
  const dbmW = (dbm) => { const w = Math.pow(10, dbm / 10) / 1000; return w >= 1 ? (Math.round(w * 10) / 10) + ' W' : Math.round(w * 1000) + ' mW'; };
  function wsRow(slot, d) {
    const r = document.createElement('div');
    r.className = 'ws-row' + (stationCalls.indexOf(String(d.call).toUpperCase()) >= 0 ? ' me' : '');
    const me = grid2ll(myGrid);
    const them = grid2ll(d.grid);
    const km = me && them ? distKm(me, them) : null;
    const fmtF = d.freq > 100000 ? (d.freq / 1e6).toFixed(6) + ' MHz' : d.f + ' Hz';
    const cells = [utc(slot).slice(0, 4), (d.db >= 0 ? '+' : '') + d.db, Number(d.dt).toFixed(1), fmtF, d.drift, d.call, d.grid || '—',
      d.dbm != null ? d.dbm + ' dBm (' + dbmW(d.dbm) + ')' : '—', km != null ? km.toLocaleString('fr-BE') + ' km' : '—'];
    for (const v of cells) { const s = document.createElement('span'); s.textContent = String(v); r.appendChild(s); }
    r.title = d.msg;
    r.addEventListener('dblclick', () => setDx({ call: d.call, grid: d.grid || '', rpt: fmtRpt(d.db) }));
    return r;
  }
  function wsAdd(item) {
    const el = $('wsList');
    stickToBottom(el, () => {
      if (item.list.length) el.appendChild(sepEl(item.slot, 'WSPR'));
      for (const d of item.list) el.appendChild(wsRow(item.slot, d));
    });
    $('wsCount').textContent = '(' + new Set(wsHist.flatMap((h) => h.list.map((d) => d.call))).size + ' stations)';
  }
  function wsRedraw() {
    $('wsList').textContent = '';
    for (const it of wsHist) wsAdd(it);
  }
  function drawWsprMarks(c, w) {
    // Sous-bande WSPR (1400–1600 Hz audio)
    const x0 = (1400 / WF_MAX_HZ) * w;
    const x1 = (1600 / WF_MAX_HZ) * w;
    c.fillStyle = 'rgba(154, 120, 224, .35)';
    c.fillRect(x0, 14, x1 - x0, 16);
    c.fillStyle = '#b79cf0';
    c.fillRect(x0, 14, 1, 16);
    c.fillRect(x1 - 1, 14, 1, 16);
    const pos = (el, f, bw) => { el.style.left = (f / WF_MAX_HZ) * 100 + '%'; el.style.width = (bw / WF_MAX_HZ) * 100 + '%'; };
    pos($('dgMkRx'), 1400, 200);
    pos($('dgMkTx'), 1400, 0);
  }
  function initWspr() {
    const dial = $('wsDial');
    for (const [b, khz] of WSPR_DIAL) {
      const o = document.createElement('option');
      o.value = String(khz);
      o.textContent = b + ' · ' + khz.toLocaleString('fr-BE', { minimumFractionDigits: khz % 1 ? 1 : 0 }) + ' kHz';
      dial.appendChild(o);
    }
    dial.value = store.get('wsdial', '14095.6');
    dial.addEventListener('change', () => { store.set('wsdial', dial.value); qsyTo(Number(dial.value)); });
    $('wsQsy').addEventListener('click', () => qsyTo(Number(dial.value)));
    $('wsClear').addEventListener('click', () => { wsHist.length = 0; wsRedraw(); $('wsCount').textContent = ''; });
  }
  function wsClock() {
    const t = now() / 1000;
    const s = 120 - (t % 120);
    const st = api && api.state();
    const busy = s > 6 && t % 120 < 115;
    $('wsClock').textContent = 'Prochaine période dans ' + Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0');
    const el = $('wsStatus');
    let txt;
    let warn = false;
    if (!st || !st.station) { txt = 'Station hors ligne'; warn = true; }
    else if (!st.audio || !st.audio.active) { txt = 'La page Station n’envoie pas la BF : « Activer l’audio » sur le PC du club'; warn = true; }
    else txt = wsLast ? 'BF reçue · dernier décodage à ' + utc(wsLast).replace(/(\d\d)(\d\d)(\d\d)/, '$1:$2') + ' UTC' : 'BF reçue · premier décodage à la fin de la période en cours' + (busy ? '' : '…');
    el.textContent = txt;
    el.classList.toggle('warn', warn);
  }

  // ------------------------------------------------------------------ JTTY (WSJT-X 3.3) : clavier à clavier, trames de 1,9 s
  // Fréquences d'appel JTTY de WSJT-X (FrequencyList) — USB / DATA-U
  const JTTY_DIAL = [['160 m', 1839], ['80 m', 3572], ['40 m', 7078], ['30 m', 10140], ['20 m', 14090], ['17 m', 18104],
    ['15 m', 21090], ['12 m', 24920], ['10 m', 28090], ['6 m', 50160], ['2 m', 144160]];
  const JT_RX_WIDTH = 80;
  let jtNeedHist = true;
  const jtMsgs = new Map(); // clé → dernière version du message { key, f, db, done, t, text }
  let jtLast = 0;
  const jtMe = (u) => String(u.text || '').toUpperCase().split(/[^A-Z0-9/]+/).some((x) => stationCalls.indexOf(x) >= 0);
  function jtRow(u) {
    const r = document.createElement('div');
    const up = String(u.text || '').toUpperCase();
    const me = jtMe(u);
    r.className = 'dg-row jt-row' + (me ? ' me' : /^CQ\b/.test(up) ? ' cq' : '') + (u.done ? ' done' : ' live');
    r.dataset.key = u.key;
    const cells = [utc(u.t).slice(0, 6), (u.db >= 0 ? '+' : '') + u.db, u.f, u.text + (u.done ? '' : ' ▌')];
    for (const v of cells) { const s = document.createElement('span'); s.textContent = String(v); r.appendChild(s); }
    r.title = u.f + ' Hz · ' + (u.done ? 'message terminé' : 'réception en cours') + ' · clic gauche : réception ici · clic droit : émission ici · double-clic : correspondant';
    r.addEventListener('click', () => setRx(u.f));
    r.addEventListener('contextmenu', (e) => { e.preventDefault(); setTx(u.f); });
    r.addEventListener('dblclick', () => jtPick(u));
    return r;
  }
  const jtInRx = (u) => Math.abs(u.f - rxF) <= JT_RX_WIDTH || jtMe(u);
  // Double-clic : l'indicatif du message (après CQ / DE, sinon le dernier) devient le correspondant
  function jtPick(u) {
    const w = String(u.text || '').toUpperCase().split(/\s+/).filter(Boolean);
    const calls = w.filter((x) => CALL_RE.test(x) && stationCalls.indexOf(x) < 0);
    let call = '';
    const i = w.findIndex((x) => x === 'CQ' || x === 'DE');
    if (i >= 0) call = w.slice(i + 1).find((x) => CALL_RE.test(x) && stationCalls.indexOf(x) < 0) || '';
    if (!call) call = calls[calls.length - 1] || '';
    if (!call) { setRx(u.f); return api && api.say('Pas d’indicatif à reprendre dans ce message.', 'warn'); }
    const g = w.find((x) => GRID_RE.test(x) && x !== 'RR73');
    setDx({ call, grid: g || '', rpt: fmtRpt(u.db) });
    setRx(u.f);
  }
  // Mise à jour d'un message : la ligne existante est remplacée (le texte grandit trame après trame)
  function jtUpdate(u) {
    if (!u || !u.key) return;
    jtMsgs.set(u.key, u);
    if (jtMsgs.size > 300) jtMsgs.delete(jtMsgs.keys().next().value);
    jtLast = Date.now();
    for (const [id, inRx] of [['jtBand', true], ['jtRx', jtInRx(u)]]) {
      const box = $(id);
      if (!box) continue;
      const old = box.querySelector('[data-key="' + CSS.escape(u.key) + '"]');
      if (old) { old.replaceWith(jtRow(u)); continue; }
      if (inRx) stickToBottom(box, () => box.appendChild(jtRow(u)));
    }
  }
  function jtRedraw() {
    const band = $('jtBand');
    const rx = $('jtRx');
    if (!band) return;
    band.textContent = '';
    rx.textContent = '';
    const list = Array.from(jtMsgs.values()).sort((a, b) => a.t - b.t);
    for (const u of list) {
      band.appendChild(jtRow(u));
      if (jtInRx(u)) rx.appendChild(jtRow(u));
    }
    band.scrollTop = band.scrollHeight;
    rx.scrollTop = rx.scrollHeight;
  }
  function insertJtty(t) {
    showTab('jtty');
    const el = $('jtTxt');
    // JTTY : une ligne, majuscules ; les retours à la ligne des macros deviennent des espaces
    const add = macroText(t, true).replace(/\s*\n\s*/g, ' ').trim().toUpperCase();
    el.value = (el.value.trim() ? el.value.trim() + ' ' : '') + add;
    el.focus();
  }
  function initJtty() {
    const dial = $('jtDial');
    for (const [b, khz] of JTTY_DIAL) {
      const o = document.createElement('option');
      o.value = String(khz);
      o.textContent = b + ' · ' + khz.toLocaleString('fr-BE') + ' kHz';
      dial.appendChild(o);
    }
    dial.value = store.get('jtdial', '14090');
    dial.addEventListener('change', () => { store.set('jtdial', dial.value); qsyTo(Number(dial.value)); });
    $('jtQsy').addEventListener('click', () => qsyTo(Number(dial.value)));
    $('jtClear').addEventListener('click', () => { jtMsgs.clear(); jtRedraw(); });
    $('jtTxt').addEventListener('input', (e) => {
      const el = e.target;
      const p = el.selectionStart;
      el.value = el.value.toUpperCase();
      el.setSelectionRange(p, p);
    });
    $('jtSend').title = 'Émission JTTY : prochaine version';
    drawMacroRow($('jtMacros'), 'JTTY', (t) => insertJtty(t));
  }
  function jtStatus() {
    const st = api && api.state();
    const el = $('jtStatus');
    if (!el) return;
    let txt;
    let warn = false;
    if (!st || !st.station) { txt = 'Station hors ligne'; warn = true; }
    else if (!st.audio || !st.audio.active) { txt = 'La page Station n’envoie pas la BF : « Activer l’audio » sur le PC du club'; warn = true; }
    else txt = jtLast && Date.now() - jtLast < 60000 ? 'BF reçue · réception JTTY en cours' : 'BF reçue · à l’écoute (décodage continu, 200 à 2800 Hz)';
    if (st && st.radio && st.radio.mode && !/DATA|USB|-D/i.test(st.radio.mode)) { txt += ' · mode ' + st.radio.mode + ' : passez en DATA-U'; warn = true; }
    el.textContent = txt;
    el.classList.toggle('warn', warn);
  }

  // ------------------------------------------------------------------ CW (décodeur sur le serveur, à la manière de FLDIGI)
  const CW_DIAL = [['160 m', 1830], ['80 m', 3530], ['40 m', 7025], ['30 m', 10115], ['20 m', 14030], ['17 m', 18080],
    ['15 m', 21030], ['12 m', 24900], ['10 m', 28030], ['6 m', 50090], ['2 m', 144050]];
  const cwc = (() => {
    let o;
    try { o = JSON.parse(store.get('cw', '{}')) || {}; } catch (e) { o = {}; }
    return { f: Number(o.f) || 700, bw: [50, 100, 200, 400].indexOf(o.bw) >= 0 ? o.bw : 100, squelch: Number.isFinite(o.squelch) ? o.squelch : 5 };
  })();
  const cwRows = []; // dernières lignes de cascade (calage sur le signal)
  let cwLast = 0;
  function saveCw(reannounce) {
    store.set('cw', JSON.stringify(cwc));
    if (reannounce) announce();
  }
  function drawCwMarks(c, w) {
    const x0 = ((cwc.f - cwc.bw / 2) / WF_MAX_HZ) * w;
    c.fillStyle = 'rgba(242, 207, 74, .35)';
    c.fillRect(x0, 14, Math.max(2, (cwc.bw / WF_MAX_HZ) * w), 16);
    c.fillStyle = '#F2CF4A';
    c.fillRect((cwc.f / WF_MAX_HZ) * w - 1, 12, 2, 18);
    const el = $('dgMkRx');
    el.style.left = ((cwc.f - cwc.bw / 2) / WF_MAX_HZ) * 100 + '%';
    el.style.width = (cwc.bw / WF_MAX_HZ) * 100 + '%';
    $('dgMkTx').style.width = '0';
    $('cwF').textContent = Math.round(cwc.f);
  }
  // Clic sur la cascade : calage sur le signal le plus fort à ±60 Hz (sinon, là où l'on a cliqué)
  function setCwF(f, snap) {
    if (snap && cwRows.length) {
      const b0 = Math.max(0, Math.floor((f - 60) / 6.25));
      const b1 = Math.ceil((f + 60) / 6.25);
      let best = -1;
      let bv = -1;
      const sum = (b) => cwRows.reduce((a, r) => a + (r[b] || 0), 0);
      const all = [];
      for (let b = b0; b <= b1; b++) { const v = sum(b); all.push(v); if (v > bv) { bv = v; best = b; } }
      all.sort((a, b) => a - b);
      // Pic au moins 6 dB (12 octets par ligne) au-dessus de la médiane du voisinage
      if (best >= 0 && bv - all[all.length >> 1] > 12 * cwRows.length) f = best * 6.25;
    }
    cwc.f = Math.max(200, Math.min(2800, Math.round(f)));
    saveCw(true);
    drawScale();
  }
  function cwAppend(text) {
    const el = $('cwRx');
    if (!el) return;
    const atEnd = el.scrollHeight - el.scrollTop - el.clientHeight < 30;
    el.appendChild(document.createTextNode(text));
    if (el.textContent.length > 20000) el.textContent = el.textContent.slice(-15000);
    if (atEnd) el.scrollTop = el.scrollHeight;
    cwLast = Date.now();
  }
  function cwLevels(m) {
    if (!$('cwBar')) return;
    $('cwBar').style.width = Math.max(0, Math.min(100, (m.s / 30) * 100)) + '%';
    $('cwDb').textContent = m.s + ' dB';
    $('cwLed').classList.toggle('on', !!m.on);
    $('cwBar').classList.toggle('low', m.s < cwc.squelch);
    if (m.s >= cwc.squelch) $('cwWpm').textContent = String(m.wpm);
  }
  function insertCw(t) {
    showTab('cw');
    const ta = $('cwTxt');
    ta.value += macroText(t, true).toUpperCase();
    ta.scrollTop = ta.scrollHeight;
    ta.focus();
  }
  function initCw() {
    $('cwBw').value = String(cwc.bw);
    $('cwSq').value = String(cwc.squelch);
    $('cwSqV').textContent = String(cwc.squelch);
    $('cwBw').addEventListener('change', () => { cwc.bw = Number($('cwBw').value); saveCw(true); drawScale(); });
    $('cwSq').addEventListener('input', () => { $('cwSqV').textContent = $('cwSq').value; });
    $('cwSq').addEventListener('change', () => { cwc.squelch = Number($('cwSq').value); saveCw(true); });
    const sp = $('cwSpeed');
    sp.value = store.get('cwspeed', '22');
    sp.addEventListener('change', () => { const v = Math.max(5, Math.min(50, Math.round(Number(sp.value) || 22))); sp.value = v; store.set('cwspeed', v); });
    const dial = $('cwDial');
    fillList(dial, withQo(CW_DIAL, 'CW'), store.get('cwdial', '14030'));
    dial.addEventListener('change', () => { store.set('cwdial', dial.value); qsyTo(Number(dial.value), 'CW'); });
    $('cwQsy').addEventListener('click', () => qsyTo(Number(dial.value), 'CW'));
    $('cwClear').addEventListener('click', () => { $('cwRx').textContent = ''; });
    $('cwTxClear').addEventListener('click', () => { $('cwTxt').value = ''; });
    $('cwTxt').addEventListener('input', (e) => {
      const el = e.target;
      const p = el.selectionStart;
      el.value = el.value.toUpperCase();
      el.setSelectionRange(p, p);
    });
    $('cwRx').addEventListener('dblclick', () => {
      const w = String(window.getSelection() || '').trim().toUpperCase();
      if (CALL_RE.test(w)) setDx({ call: w });
    });
    $('cwSend').title = 'Émission CW : prochaine version';
    drawMacroRow($('cwMacros'), 'CW', (t) => insertCw(t));
  }
  function cwStatus() {
    const st = api && api.state();
    const el = $('cwStatus');
    if (!el) return;
    let txt;
    let warn = false;
    if (!st || !st.station) { txt = 'Station hors ligne'; warn = true; }
    else if (!st.audio || !st.audio.active) { txt = 'La page Station n’envoie pas la BF : « Activer l’audio » sur le PC du club'; warn = true; }
    else txt = cwLast && Date.now() - cwLast < 20000 ? 'BF reçue · décodage en cours' : 'BF reçue · cliquez sur un signal CW dans la cascade';
    if (st && st.radio && st.radio.mode && !/CW/i.test(st.radio.mode)) txt += ' · TRX en ' + st.radio.mode + ' (CW conseillé : filtre étroit, tonalité = pitch)';
    el.textContent = txt;
    el.classList.toggle('warn', warn);
  }

  // ------------------------------------------------------------------ SSTV : réception (décodeur du serveur) et préparation des images à émettre
  const SSTV_DIAL = [['80 m', 3735], ['40 m', 7165], ['20 m', 14230], ['20 m (2)', 14233], ['17 m', 18160], ['15 m', 21340], ['12 m', 24975], ['10 m', 28680], ['6 m', 50510]];
  let ssNeedHist = true;
  const ssImgs = new Map(); // id → { meta, data: ImageData | null }
  let ssShown = 0;
  let ssLive = 0;
  let ssLast = 0;
  function ssCanvasFor(meta) {
    const c = $('ssCanvas');
    if (c.width !== meta.w || c.height !== meta.h) { c.width = meta.w; c.height = meta.h; }
    return c.getContext('2d');
  }
  function ssShow(id) {
    const it = ssImgs.get(id);
    if (!it) return;
    ssShown = id;
    const ctx = ssCanvasFor(it.meta);
    if (it.data) ctx.putImageData(it.data, 0, 0);
    else { ctx.fillStyle = '#000'; ctx.fillRect(0, 0, it.meta.w, it.meta.h); api.send({ t: 'sstv_get', id }); }
    $('ssEmpty').hidden = true;
    ssCaption();
    ssGallery();
  }
  function ssCaption() {
    const it = ssImgs.get(ssShown);
    if (!it) { $('ssCap').textContent = ''; return; }
    const m = it.meta;
    $('ssCap').textContent = m.name + ' · ' + utc(m.at).replace(/(\d\d)(\d\d)(\d\d)/, '$1:$2') + ' UTC' + (m.done ? (m.ok ? '' : ' · incomplète') : ' · en cours');
  }
  function ssGallery() {
    const g = $('ssGal');
    if (!g) return;
    g.textContent = '';
    const list = Array.from(ssImgs.values()).sort((a, b) => b.meta.at - a.meta.at);
    for (const it of list) {
      const c = document.createElement('canvas');
      c.width = 96;
      c.height = Math.round(96 * it.meta.h / it.meta.w);
      c.className = 'ss-thumb' + (it.meta.id === ssShown ? ' sel' : '');
      c.title = it.meta.name + ' · ' + utc(it.meta.at).replace(/(\d\d)(\d\d)(\d\d)/, '$1:$2') + ' UTC';
      const x = c.getContext('2d');
      if (it.data) { const t = document.createElement('canvas'); t.width = it.meta.w; t.height = it.meta.h; t.getContext('2d').putImageData(it.data, 0, 0); x.drawImage(t, 0, 0, c.width, c.height); }
      else if (it.thumb) {
        // Vignette envoyée par le serveur (image complète chargée au clic)
        const raw = atob(it.thumb.b64);
        const id = new ImageData(it.thumb.w, it.thumb.h);
        for (let i = 0, j = 0; i < raw.length; i += 3, j += 4) { id.data[j] = raw.charCodeAt(i); id.data[j + 1] = raw.charCodeAt(i + 1); id.data[j + 2] = raw.charCodeAt(i + 2); id.data[j + 3] = 255; }
        const t = document.createElement('canvas'); t.width = it.thumb.w; t.height = it.thumb.h; t.getContext('2d').putImageData(id, 0, 0);
        x.drawImage(t, 0, 0, c.width, c.height);
      } else { x.fillStyle = '#10161f'; x.fillRect(0, 0, c.width, c.height); x.fillStyle = '#8b98a8'; x.font = '10px sans-serif'; x.fillText(it.meta.mode, 6, 14); }
      c.addEventListener('click', () => ssShow(it.meta.id));
      g.appendChild(c);
    }
  }
  function ssAdd(meta) {
    const old = ssImgs.get(meta.id);
    if (old) { old.meta = meta; return old; }
    const it = { meta, data: null };
    ssImgs.set(meta.id, it);
    while (ssImgs.size > 12) ssImgs.delete(Array.from(ssImgs.values()).sort((a, b) => a.meta.at - b.meta.at)[0].meta.id);
    return it;
  }
  // Trame binaire 0x11 : une ligne d'image
  function ssLine(b) {
    const dv = new DataView(b.buffer, b.byteOffset, b.byteLength);
    const id = dv.getUint32(1);
    const y = dv.getUint16(5);
    const w = dv.getUint16(7);
    const it = ssImgs.get(id);
    if (!it || w !== it.meta.w || y >= it.meta.h) return;
    if (!it.data) it.data = new ImageData(it.meta.w, it.meta.h);
    const d = it.data.data;
    for (let x = 0; x < w; x++) { const o = (y * w + x) * 4; d[o] = b[9 + x * 3]; d[o + 1] = b[10 + x * 3]; d[o + 2] = b[11 + x * 3]; d[o + 3] = 255; }
    if (id === ssShown && tab === 'sstv') {
      const ctx = ssCanvasFor(it.meta);
      ctx.putImageData(it.data, 0, 0, 0, y, w, 1);
    }
    if (id === ssLive) {
      it.meta.lines = Math.max(it.meta.lines || 0, y + 1);
      ssProgress(it.meta);
    }
    if (y === it.meta.h - 1 || (y % 32 === 31 && id === ssShown)) ssGallery();
  }
  function ssProgress(meta) {
    const p = meta ? Math.min(100, Math.round((meta.lines / meta.h) * 100)) : 0;
    if ($('ssProg')) { $('ssProg').style.width = p + '%'; $('ssProgT').textContent = meta && !meta.done ? meta.name + ' · ligne ' + meta.lines + ' / ' + meta.h : ''; }
  }
  function ssSave() {
    const it = ssImgs.get(ssShown);
    if (!it || !it.data) return api && api.say('Pas d’image à enregistrer.', 'warn');
    const c = document.createElement('canvas');
    c.width = it.meta.w;
    c.height = it.meta.h;
    c.getContext('2d').putImageData(it.data, 0, 0);
    const d = new Date(it.meta.at);
    const p2 = (n) => String(n).padStart(2, '0');
    const name = 'SSTV-' + d.getUTCFullYear() + p2(d.getUTCMonth() + 1) + p2(d.getUTCDate()) + '-' + p2(d.getUTCHours()) + p2(d.getUTCMinutes()) + '-' + it.meta.mode + '.png';
    c.toBlob((blob) => {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = name;
      document.body.appendChild(a);
      a.click();
      setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
    }, 'image/png');
  }
  function ssMessage(m) {
    if (m.t === 'sstv_list') {
      for (const meta of m.items || []) { const th = meta.thumb; delete meta.thumb; const it = ssAdd(meta); if (th) it.thumb = th; }
      const last = (m.items || []).slice(-1)[0];
      if (last && !ssShown) ssShow(last.id); else ssGallery();
      return true;
    }
    if (m.t === 'sstv_img') {
      const it = ssAdd(m.img);
      it.data = new ImageData(m.img.w, m.img.h);
      if (ssShown === m.img.id) ssCanvasFor(m.img);
      return true;
    }
    if (m.t === 'sstv_start') {
      const it = ssAdd(m.img);
      it.data = new ImageData(m.img.w, m.img.h);
      ssLive = m.img.id;
      ssLast = Date.now();
      ssShown = m.img.id;
      const ctx = ssCanvasFor(m.img);
      ctx.fillStyle = '#000';
      ctx.fillRect(0, 0, m.img.w, m.img.h);
      $('ssEmpty').hidden = true;
      ssCaption();
      ssGallery();
      ssProgress(m.img);
      if (api) api.say('SSTV : réception d’une image ' + m.img.name + (m.shift ? ' (décalage ' + (m.shift > 0 ? '+' : '') + m.shift + ' Hz)' : ''), 'ok', 4000);
      return true;
    }
    if (m.t === 'sstv_end') {
      const it = ssAdd(m.img);
      if (ssLive === m.img.id) ssLive = 0;
      ssLast = Date.now();
      ssProgress(null);
      // Image redressée par le serveur (pente corrigée) : on la recharge
      if (m.refreshed) { it.data = null; if (ssShown === m.img.id) api.send({ t: 'sstv_get', id: m.img.id }); }
      ssCaption();
      ssGallery();
      return true;
    }
    return false;
  }
  function drawSstvMarks(c, w) {
    const X = (f) => (f / WF_MAX_HZ) * w;
    c.fillStyle = 'rgba(154, 120, 224, .3)';
    c.fillRect(X(1500), 14, X(2300) - X(1500), 16);
    c.fillStyle = '#b79cf0';
    c.fillRect(X(1500), 14, 1, 16);
    c.fillRect(X(2300) - 1, 14, 1, 16);
    c.fillStyle = '#F2CF4A';
    c.fillRect(X(1200) - 1, 12, 2, 18);
    const pos = (el, f, bw) => { el.style.left = (f / WF_MAX_HZ) * 100 + '%'; el.style.width = (bw / WF_MAX_HZ) * 100 + '%'; };
    pos($('dgMkRx'), 1500, 800);
    pos($('dgMkTx'), 1200, 0);
  }
  function sstvStatus() {
    const st = api && api.state();
    const el = $('ssStatus');
    if (!el) return;
    let txt;
    let warn = false;
    if (!st || !st.station) { txt = 'Station hors ligne'; warn = true; }
    else if (!st.audio || !st.audio.active) { txt = 'La page Station n’envoie pas la BF : « Activer l’audio » sur le PC du club'; warn = true; }
    else txt = ssLive ? 'BF reçue · réception en cours' : 'BF reçue · en attente d’une image (code VIS)';
    if (st && st.radio && st.radio.mode && /CW|AM|LSB/i.test(st.radio.mode)) { txt += ' · mode ' + st.radio.mode + ' : SSTV en USB / DATA-U'; warn = true; }
    el.textContent = txt;
    el.classList.toggle('warn', warn);
  }

  // --- Préparation de l'image à émettre : images du PC, texte par-dessus, aperçu au format du mode
  const SS_TX_MODES = ['M1', 'M2', 'S1', 'S2', 'SDX', 'R36', 'R72', 'PD50', 'PD90', 'PD120', 'PD160', 'PD180', 'PD240', 'PD290'];
  let ssSrc = []; // { name, url } (images du PC, réduites, gardées dans ce navigateur)
  try { ssSrc = JSON.parse(store.get('sstvsrc', '[]')) || []; } catch (e) { ssSrc = []; }
  let ssSel = store.get('sstvsel', 'cq');
  const ssImgCache = new Map();
  function ssSaveSrc() {
    // Stockage local limité : on retire les plus anciennes si nécessaire
    for (;;) {
      try { localStorage.setItem('rs.dg.sstvsrc', JSON.stringify(ssSrc)); return; } catch (e) { if (!ssSrc.length) return; ssSrc.shift(); }
    }
  }
  function ssLoadFiles(files) {
    for (const f of Array.from(files || []).slice(0, 10)) {
      if (!/^image\//.test(f.type)) continue;
      const rd = new FileReader();
      rd.onload = () => {
        const im = new Image();
        im.onload = () => {
          // Réduite à 800 × 616 au plus (plus grand format SSTV), en JPEG
          const k = Math.min(1, 800 / im.width, 616 / im.height);
          const c = document.createElement('canvas');
          c.width = Math.round(im.width * k);
          c.height = Math.round(im.height * k);
          c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
          const url = c.toDataURL('image/jpeg', 0.85);
          ssSrc.push({ name: f.name.slice(0, 60), url });
          while (ssSrc.length > 10) ssSrc.shift();
          ssSel = 'u' + (ssSrc.length - 1);
          store.set('sstvsel', ssSel);
          ssSaveSrc();
          ssThumbs();
          ssCompose();
        };
        im.src = rd.result;
      };
      rd.readAsDataURL(f);
    }
  }
  function ssImage(url, cb) {
    if (ssImgCache.has(url)) { const im = ssImgCache.get(url); if (im.complete) return cb(im); im.addEventListener('load', () => cb(im)); return; }
    const im = new Image();
    im.onload = () => cb(im);
    im.src = url;
    ssImgCache.set(url, im);
  }
  function ssThumbs() {
    const box = $('ssThumbs');
    if (!box) return;
    box.textContent = '';
    const mk = (key, title, draw) => {
      const c = document.createElement('canvas');
      c.width = 64;
      c.height = 48;
      c.className = 'ss-thumb' + (ssSel === key ? ' sel' : '');
      c.title = title;
      draw(c.getContext('2d'), c);
      c.addEventListener('click', () => { ssSel = key; store.set('sstvsel', key); ssThumbs(); ssCompose(); });
      box.appendChild(c);
      return c;
    };
    mk('cq', 'Carte CQ (fond dégradé)', (x, c) => { ssBackground(x, c.width, c.height); });
    mk('bars', 'Mire de couleurs', (x, c) => { ssBars(x, c.width, c.height); });
    if (ssShown && ssImgs.get(ssShown) && ssImgs.get(ssShown).data) mk('rx', 'Image reçue affichée à gauche', (x, c) => { const it = ssImgs.get(ssShown); const t = document.createElement('canvas'); t.width = it.meta.w; t.height = it.meta.h; t.getContext('2d').putImageData(it.data, 0, 0); x.drawImage(t, 0, 0, c.width, c.height); });
    ssSrc.forEach((s, i) => {
      const c = mk('u' + i, s.name + ' (clic droit : retirer)', (x, cv) => ssImage(s.url, (im) => ssCover(x, im, cv.width, cv.height)));
      c.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        ssSrc.splice(i, 1);
        ssSaveSrc();
        if (ssSel === 'u' + i) ssSel = 'cq';
        ssThumbs();
        ssCompose();
      });
    });
  }
  function ssBackground(x, w, h) {
    const g = x.createLinearGradient(0, 0, w, h);
    g.addColorStop(0, '#0a2a6b');
    g.addColorStop(0.55, '#1b6fb3');
    g.addColorStop(1, '#f0a020');
    x.fillStyle = g;
    x.fillRect(0, 0, w, h);
  }
  function ssBars(x, w, h) {
    const cols = ['#fff', '#ff0', '#0ff', '#0f0', '#f0f', '#f00', '#00f', '#000'];
    cols.forEach((c, i) => { x.fillStyle = c; x.fillRect(Math.floor(i * w / 8), 0, Math.ceil(w / 8), h * 0.7); });
    const g = x.createLinearGradient(0, 0, w, 0);
    g.addColorStop(0, '#000');
    g.addColorStop(1, '#fff');
    x.fillStyle = g;
    x.fillRect(0, h * 0.7, w, h * 0.3);
  }
  // Image recadrée pour remplir tout le format (comme « remplir » d'un fond d'écran)
  function ssCover(x, im, w, h) {
    const k = Math.max(w / im.width, h / im.height);
    const iw = im.width * k;
    const ih = im.height * k;
    x.drawImage(im, (w - iw) / 2, (h - ih) / 2, iw, ih);
  }
  function ssCompose() {
    const c = $('ssCompose');
    if (!c) return;
    const m = SSTV.MODES[$('ssTxMode').value] || SSTV.MODES.M1;
    if (c.width !== m.w || c.height !== m.h) { c.width = m.w; c.height = m.h; }
    const x = c.getContext('2d');
    const w = m.w;
    const h = m.h;
    const texts = () => {
      const size = Math.round(h * (Number($('ssSize').value) || 0.1));
      x.font = '700 ' + size + 'px "Roboto", "Arial", sans-serif';
      x.textAlign = 'center';
      x.lineJoin = 'round';
      const lines = [[$('ssT0').value, size * 1.05, 'top'], [$('ssT1').value, h / 2, 'middle'], [$('ssT2').value, h - size * 0.5, 'bottom']];
      for (const [t, y, base] of lines) {
        // Sans correspondant : « CQ » à la place de « ??? »
        const txt = macroText(String(t || ''), false).replace(/\?\?\?/g, 'CQ').replace(/\s*\n\s*/g, ' ').replace(/^[\s·\-–]+|[\s·\-–]+$/g, '').trim();
        if (!txt) continue;
        x.textBaseline = base === 'top' ? 'middle' : base === 'bottom' ? 'alphabetic' : 'middle';
        const yy = base === 'top' ? size * 0.75 : y;
        x.lineWidth = Math.max(3, size / 6);
        x.strokeStyle = '#000';
        x.strokeText(txt, w / 2, yy, w * 0.96);
        x.fillStyle = $('ssColor').value || '#ffe14a';
        x.fillText(txt, w / 2, yy, w * 0.96);
      }
    };
    const sel = ssSel;
    if (sel === 'bars') { ssBars(x, w, h); texts(); }
    else if (sel === 'rx' && ssImgs.get(ssShown) && ssImgs.get(ssShown).data) {
      const it = ssImgs.get(ssShown);
      const t = document.createElement('canvas');
      t.width = it.meta.w;
      t.height = it.meta.h;
      t.getContext('2d').putImageData(it.data, 0, 0);
      ssCover(x, t, w, h);
      texts();
    } else if (/^u\d+$/.test(sel) && ssSrc[Number(sel.slice(1))]) {
      ssImage(ssSrc[Number(sel.slice(1))].url, (im) => { if (ssSel !== sel) return; ssCover(x, im, w, h); texts(); });
    } else { ssBackground(x, w, h); texts(); }
    const d = SSTV.duration(m.id);
    $('ssDur').textContent = m.w + ' × ' + m.h + ' · ' + Math.floor(d / 60) + ' min ' + String(Math.round(d % 60)).padStart(2, '0') + ' s';
  }
  function ssSignal(rate) {
    const c = $('ssCompose');
    const id = $('ssTxMode').value;
    const px = c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
    return SSTV.encode(id, px, rate, 4);
  }
  let ssPlayer = null;
  function ssPlay() {
    if (ssPlayer) { try { ssPlayer.src.stop(); ssPlayer.ctx.close(); } catch (e) {} ssPlayer = null; $('ssPlay').textContent = '▶ Écouter'; return; }
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const sig = ssSignal(ctx.sampleRate);
    const buf = ctx.createBuffer(1, sig.length, ctx.sampleRate);
    buf.copyToChannel(sig, 0);
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const g = ctx.createGain();
    g.gain.value = 0.5;
    src.connect(g).connect(ctx.destination);
    src.onended = () => { if (ssPlayer && ssPlayer.src === src) { ssPlayer = null; $('ssPlay').textContent = '▶ Écouter'; try { ctx.close(); } catch (e) {} } };
    src.start();
    ssPlayer = { ctx, src };
    $('ssPlay').textContent = '■ Arrêter';
  }
  function ssWav() {
    const rate = 12000;
    const sig = ssSignal(rate);
    const b = new ArrayBuffer(44 + sig.length * 2);
    const v = new DataView(b);
    const str = (o, t) => { for (let i = 0; i < t.length; i++) v.setUint8(o + i, t.charCodeAt(i)); };
    str(0, 'RIFF'); v.setUint32(4, 36 + sig.length * 2, true); str(8, 'WAVE'); str(12, 'fmt ');
    v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true); v.setUint32(24, rate, true);
    v.setUint32(28, rate * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true); str(36, 'data'); v.setUint32(40, sig.length * 2, true);
    for (let i = 0; i < sig.length; i++) v.setInt16(44 + i * 2, Math.max(-32767, Math.min(32767, Math.round(sig[i] * 32767))), true);
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([b], { type: 'audio/wav' }));
    a.download = 'SSTV-' + $('ssTxMode').value + '.wav';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
  }
  function initSstv() {
    const dial = $('ssDial');
    for (const [b, khz] of SSTV_DIAL) {
      const o = document.createElement('option');
      o.value = String(khz);
      o.textContent = b + ' · ' + khz.toLocaleString('fr-BE') + ' kHz';
      dial.appendChild(o);
    }
    dial.value = store.get('ssdial', '14230');
    dial.addEventListener('change', () => { store.set('ssdial', dial.value); qsyTo(Number(dial.value)); });
    $('ssQsy').addEventListener('click', () => qsyTo(Number(dial.value)));
    $('ssSave').addEventListener('click', ssSave);
    const tm = $('ssTxMode');
    for (const id of SS_TX_MODES) { const o = document.createElement('option'); o.value = id; o.textContent = SSTV.MODES[id].name; tm.appendChild(o); }
    tm.value = store.get('sstvtx', 'M1');
    tm.addEventListener('change', () => { store.set('sstvtx', tm.value); ssCompose(); });
    const defs = ['<CALL> DE <MYCALL>', '', 'UR <RST> · <MYLOC>'];
    ['ssT0', 'ssT1', 'ssT2'].forEach((id, i) => {
      const el = $(id);
      el.value = store.get(id, defs[i]);
      el.addEventListener('input', () => { store.set(id, el.value); ssCompose(); });
      el.addEventListener('focus', () => { ssFocus = el; });
    });
    $('ssSize').value = store.get('sssize', '0.1');
    $('ssSize').addEventListener('change', () => { store.set('sssize', $('ssSize').value); ssCompose(); });
    $('ssColor').value = store.get('sscolor', '#ffe14a');
    $('ssColor').addEventListener('input', () => { store.set('sscolor', $('ssColor').value); ssCompose(); });
    // Balises : ajoutées dans la dernière ligne de texte utilisée
    let ssFocus = $('ssT0');
    for (const t of ['<CALL>', '<MYCALL>', '<RST>', '<NAME>', '<MYLOC>', '<ZT>']) {
      const b = document.createElement('button');
      b.className = 'dg-mini';
      b.type = 'button';
      b.textContent = t;
      b.title = 'Ajouter ' + t + ' au texte';
      b.addEventListener('mousedown', (e) => e.preventDefault());
      b.addEventListener('click', () => { ssFocus.value = (ssFocus.value ? ssFocus.value + ' ' : '') + t; store.set(ssFocus.id, ssFocus.value); ssCompose(); });
      $('ssTags').appendChild(b);
    }
    $('ssFile').addEventListener('change', (e) => { ssLoadFiles(e.target.files); e.target.value = ''; });
    $('ssPlay').addEventListener('click', ssPlay);
    $('ssWav').addEventListener('click', ssWav);
    $('ssSend').title = 'Émission SSTV : prochaine version';
    // Glisser-déposer d'images sur la zone d'émission
    const zone = document.querySelector('.ss-tx');
    zone.addEventListener('dragover', (e) => { e.preventDefault(); zone.classList.add('drop'); });
    zone.addEventListener('dragleave', () => zone.classList.remove('drop'));
    zone.addEventListener('drop', (e) => { e.preventDefault(); zone.classList.remove('drop'); ssLoadFiles(e.dataTransfer.files); });
    ssThumbs();
    ssCompose();
  }

  // ------------------------------------------------------------------ correspondant et messages pré-enregistrés
  // Correspondant commun à tous les modes (bas du dashboard, fenêtre RTTY, fenêtre séparée : synchronisés)
  let myCall = 'ON5VL';
  let myGrid = '';
  let myQth = '';
  let opCall = '';
  const loadDx = () => { try { return Object.assign({ call: '', grid: '', rpt: '-10', name: '', qth: '', rst: '599' }, JSON.parse(store.get('dx', '{}')) || {}); } catch (e) { return { call: '', grid: '', rpt: '-10', name: '', qth: '', rst: '599' }; } };
  let dx = loadDx();
  let ftxSel = Number(store.get('ftxsel', '5')) || 0;
  const CALL_RE = /^[A-Z0-9]{1,3}[0-9][A-Z0-9]{0,4}[A-Z](\/[A-Z0-9]+)?$/;
  const GRID_RE = /^[A-R]{2}[0-9]{2}([A-X]{2})?$/;
  const fmtRpt = (db) => (db >= 0 ? '+' : '-') + String(Math.min(30, Math.abs(Math.round(db)))).padStart(2, '0');
  function setDx(o) {
    const before = loadDx();
    // Nouveau correspondant : son prénom et son QTH repartent à vide
    if (o.call != null && String(o.call).toUpperCase() !== String(before.call).toUpperCase() && o.name == null) { before.name = ''; before.qth = ''; }
    dx = Object.assign(before, o);
    dx.call = String(dx.call || '').toUpperCase().slice(0, 12);
    dx.grid = String(dx.grid || '').toUpperCase().slice(0, 6);
    store.set('dx', JSON.stringify(dx));
    syncDx();
  }
  function syncDx() {
    const put = (id, v) => { const el = $(id); if (el && document.activeElement !== el) el.value = v; };
    put('dxCall', dx.call);
    put('dxGrid', dx.grid);
    put('dxRpt', dx.rpt);
    put('rtCall', dx.call);
    put('dxName', dx.name || '');
    put('dxQth', dx.qth || '');
    put('dxRst', dx.rst || '599');
    drawMsgs();
  }
  window.addEventListener('storage', (e) => { if (e.key === 'rs.dg.dx') { dx = loadDx(); syncDx(); } });
  // Double-clic sur un message FT8/FT4 : son émetteur devient le correspondant (comme dans WSJT-X)
  function pickFromDecode(d) {
    const w = d.msg.toUpperCase().split(/\s+/).map((x) => x.replace(/^<|>$/g, ''));
    let call = '';
    if (w[0] === 'CQ') call = CALL_RE.test(w[1] || '') ? w[1] : (w[2] || '');
    else call = w[1] || '';
    if (!CALL_RE.test(call)) return api && api.say('Pas d’indicatif à reprendre dans ce message.', 'warn');
    const last = w[w.length - 1];
    setDx({ call, grid: GRID_RE.test(last) && last !== 'RR73' ? last : '', rpt: fmtRpt(d.db) });
    setRx(d.f);
    ftxSel = w[0] === 'CQ' ? 0 : 1;
    store.set('ftxsel', ftxSel);
    drawMsgs();
  }
  function ftxMsgs() {
    const c = dx.call || '{CORRESP}';
    const g = myGrid ? myGrid.slice(0, 4) : '{LOCATOR}'; // FT8 / FT4 : locator à 4 caractères
    const r = /^[+-]?\d{1,2}$/.test(dx.rpt) ? (dx.rpt[0] === '+' || dx.rpt[0] === '-' ? dx.rpt : '+' + dx.rpt) : '-10';
    return [c + ' ' + myCall + ' ' + g, c + ' ' + myCall + ' ' + r, c + ' ' + myCall + ' R' + r, c + ' ' + myCall + ' RR73', c + ' ' + myCall + ' 73', 'CQ ' + myCall + ' ' + g];
  }
  function drawMsgs() {
    if (!$('msgFtx')) return;
    const mk = (box, label, text, onClick, sel) => {
      const b = document.createElement('button');
      b.className = 'btn' + (sel ? ' sel' : '');
      b.type = 'button';
      if (label) { const s = document.createElement('small'); s.textContent = label; b.appendChild(s); }
      b.appendChild(document.createTextNode(text));
      b.addEventListener('click', onClick);
      box.appendChild(b);
      return b;
    };
    const f = $('msgFtx');
    f.textContent = '';
    ftxMsgs().forEach((t, i) => mk(f, 'Tx' + (i + 1), t, () => { ftxSel = i; store.set('ftxsel', i); drawMsgs(); }, i === ftxSel)
      .title = 'Prochain message FT8/FT4 à émettre (émission : prochaine version)');
    // Tx7 : texte libre de 13 caractères au plus (comme WSJT-X)
    const free = String(store.get('ftxfree', '')).toUpperCase();
    const fb = mk(f, 'Tx7', free || 'texte libre…', () => { ftxSel = 6; store.set('ftxsel', 6); drawMsgs(); }, ftxSel === 6);
    fb.title = 'Texte libre FT8/FT4 (13 caractères) · clic droit pour le modifier';
    fb.addEventListener('contextmenu', (e) => { e.preventDefault(); editFree(fb.ownerDocument); });
    const ed = mk(f, '', '✎', () => editFree(f.ownerDocument));
    ed.title = 'Modifier le texte libre (Tx7)';
    ed.classList.add('mini');
    drawMacroRow($('msgRtty'), 'RTTY', (t) => {
      const inst = (window.DG && window.DG()) || window.RSDIGI;
      inst.insertRtty(t);
    });
    drawMacroRow($('msgJtty'), 'JTTY', (t) => {
      const inst = (window.DG && window.DG()) || window.RSDIGI;
      inst.insertJtty(t);
    });
    drawMacroRow($('msgCw'), 'CW', (t) => {
      const inst = (window.DG && window.DG()) || window.RSDIGI;
      inst.insertCw(t);
    });
  }
  // Rangée de macros : clic = utiliser, clic droit = modifier, ✎ = modifier
  function drawMacroRow(box, mode, use) {
    if (!box) return;
    box.textContent = '';
    macroList(mode).forEach((m, i) => {
      const b = box.ownerDocument.createElement('button');
      b.className = 'btn';
      b.type = 'button';
      if (mode !== 'FT8') { const s = box.ownerDocument.createElement('small'); s.textContent = 'F' + (i + 1); b.appendChild(s); }
      b.appendChild(box.ownerDocument.createTextNode(m.name || '—'));
      b.title = macroText(m.text).replace(/\n/g, ' ⏎ ') + '\n(clic droit : modifier)';
      b.addEventListener('mouseenter', () => { b.title = macroText(m.text).replace(/\n/g, ' ⏎ ') + '\n(clic droit : modifier)'; });
      b.addEventListener('click', () => use(m.text));
      b.addEventListener('contextmenu', (e) => { e.preventDefault(); editMacro(box.ownerDocument, mode, i); });
      box.appendChild(b);
    });
    const ed = box.ownerDocument.createElement('button');
    ed.className = 'btn mini';
    ed.type = 'button';
    ed.textContent = '✎';
    ed.title = 'Modifier les macros ' + mode;
    ed.addEventListener('click', () => editMacro(box.ownerDocument, mode, 0));
    box.appendChild(ed);
  }
  function drawRttyMacros() {
    drawMacroRow($('rtMacros'), 'RTTY', (t) => insertRtty(t, true));
  }
  // ------------------------------------------------------------------ éditeur de macros (fenêtre de dialogue)
  function editMacro(doc, mode, idx) {
    const list = macroList(mode).map((m) => Object.assign({}, m));
    while (mode !== 'FT8' && list.length < (mode === 'JTTY' ? 8 : 12)) list.push({ name: '', text: '' });
    let cur = Math.min(idx, list.length - 1);
    const old = doc.getElementById('macroDlg');
    if (old) old.remove();
    const dlg = doc.createElement('dialog');
    dlg.id = 'macroDlg';
    dlg.className = 'macro-dlg';
    dlg.innerHTML = '<form method="dialog">' +
      '<h3>Macros ' + mode + '</h3>' +
      '<div class="md-keys"></div>' +
      '<label>Nom du bouton <input name="name" maxlength="14" autocomplete="off"></label>' +
      '<label>Texte <textarea name="text" rows="6" spellcheck="false"></textarea></label>' +
      '<div class="md-tags"></div>' +
      '<p class="md-prev"></p>' +
      '<div class="md-act"><button class="btn" value="reset" type="button" data-a="reset">Défaut</button>' +
      '<span></span><button class="btn" value="cancel" data-a="cancel">Annuler</button><button class="btn btn-primary" type="button" data-a="save">Enregistrer</button></div>' +
      '</form>';
    doc.body.appendChild(dlg);
    const f = dlg.querySelector('form');
    const keys = dlg.querySelector('.md-keys');
    const prev = () => { dlg.querySelector('.md-prev').textContent = 'Aperçu : ' + macroText(f.text.value).replace(/\n/g, ' ⏎ '); };
    const keep = () => { list[cur] = { name: f.name.value.trim(), text: f.text.value }; };
    const show = () => {
      keys.textContent = '';
      list.forEach((m, i) => {
        const k = doc.createElement('button');
        k.type = 'button';
        k.className = 'btn' + (i === cur ? ' on' : '');
        k.textContent = (mode === 'RTTY' ? 'F' + (i + 1) + ' ' : '') + (m.name || '—');
        k.addEventListener('click', () => { keep(); cur = i; show(); });
        keys.appendChild(k);
      });
      f.name.value = list[cur].name || '';
      f.text.value = list[cur].text || '';
      prev();
    };
    for (const [tag, help] of TAGS) {
      const t = doc.createElement('button');
      t.type = 'button';
      t.className = 'md-tag';
      t.textContent = tag;
      t.title = help;
      t.addEventListener('click', () => {
        const ta = f.text;
        const a = ta.selectionStart, z = ta.selectionEnd;
        ta.value = ta.value.slice(0, a) + tag + ta.value.slice(z);
        ta.selectionStart = ta.selectionEnd = a + tag.length;
        ta.focus();
        prev();
      });
      dlg.querySelector('.md-tags').appendChild(t);
    }
    f.text.addEventListener('input', prev);
    dlg.querySelector('[data-a="reset"]').addEventListener('click', () => {
      const d = (DEF_MACROS[mode] || [])[cur] || { name: '', text: '' };
      f.name.value = d.name; f.text.value = d.text; prev();
    });
    dlg.querySelector('[data-a="save"]').addEventListener('click', () => {
      keep();
      const clean = list.filter((m, i) => mode === 'RTTY' || m.name || m.text);
      macros[mode] = clean;
      store.set('macros', JSON.stringify(macros));
      if (api) api.send({ t: 'macros_set', mode, list: clean });
      dlg.close();
      redrawMacros();
    });
    dlg.addEventListener('close', () => dlg.remove());
    show();
    dlg.showModal();
  }
  function editFree(doc) {
    const v = (doc.defaultView || window).prompt('Texte libre FT8 / FT4 (13 caractères au plus : lettres, chiffres, espace + - . / ?)', store.get('ftxfree', ''));
    if (v == null) return;
    store.set('ftxfree', String(v).toUpperCase().replace(/[^A-Z0-9 +\-./?]/g, '').slice(0, 13));
    drawMsgs();
  }
  function redrawMacros() {
    drawMsgs();
    drawRttyMacros();
    drawMacroRow($('jtMacros'), 'JTTY', (t) => insertJtty(t));
    drawMacroRow($('cwMacros'), 'CW', (t) => insertCw(t));
  }
  function insertRtty(t) {
    showTab('rtty');
    const ta = $('rtTxt');
    ta.value += macroText(t, true);
    ta.scrollTop = ta.scrollHeight;
    ta.focus();
  }
  function initMsgs() {
    for (const [id, k] of [['dxCall', 'call'], ['dxGrid', 'grid'], ['dxRpt', 'rpt'], ['rtCall', 'call'], ['dxName', 'name'], ['dxQth', 'qth'], ['dxRst', 'rst']]) {
      const el = $(id);
      if (el) el.addEventListener('input', () => setDx({ [k]: el.value.trim() }));
    }
    syncDx();
  }

  function setTx(f) {
    txF = Math.max(100, Math.min(WF_MAX_HZ - 100, Math.round(f)));
    store.set('txf', txF);
    drawScale();
  }
  function setRx(f) {
    rxF = Math.max(100, Math.min(WF_MAX_HZ - 100, Math.round(f)));
    store.set('rxf', rxF);
    drawScale();
    redrawRx();
    if (tab === 'jtty') jtRedraw();
  }

  // ------------------------------------------------------------------ listes de messages
  const hist = []; // { slot, mode, list }
  const pad = (n) => String(n).padStart(2, '0');
  const utc = (ms) => { const d = new Date(ms); return pad(d.getUTCHours()) + pad(d.getUTCMinutes()) + pad(d.getUTCSeconds()); };
  const callsIn = (msg) => msg.toUpperCase().split(/\s+/).map((w) => w.replace(/^<|>$/g, ''));
  function cls(msg) {
    const w = callsIn(msg);
    if (w.some((x) => stationCalls.indexOf(x) >= 0)) return 'me';
    if (w[0] === 'CQ') return 'cq';
    return '';
  }
  function rowEl(slot, d) {
    const r = document.createElement('div');
    r.className = 'dg-row ' + cls(d.msg);
    r.title = d.f + ' Hz · clic gauche : réception ici · clic droit : émission ici · double-clic : répondre à cette station';
    const cells = [utc(slot), (d.db >= 0 ? '+' : '') + d.db, d.dt.toFixed(1), d.f, d.msg];
    for (const v of cells) {
      const s = document.createElement('span');
      s.textContent = String(v);
      r.appendChild(s);
    }
    r.addEventListener('click', () => setRx(d.f));
    r.addEventListener('contextmenu', (e) => { e.preventDefault(); setTx(d.f); });
    r.addEventListener('dblclick', () => pickFromDecode(d));
    return r;
  }
  function sepEl(slot, m) {
    const s = document.createElement('div');
    s.className = 'dg-sep';
    const d = new Date(slot);
    s.textContent = '— ' + pad(d.getUTCHours()) + ':' + pad(d.getUTCMinutes()) + ':' + pad(d.getUTCSeconds()) + ' UTC · ' + m + ' —';
    return s;
  }
  function stickToBottom(el, fn) {
    const atEnd = el.scrollHeight - el.scrollTop - el.clientHeight < 30;
    fn();
    while (el.children.length > 400) el.removeChild(el.firstChild);
    if (atEnd) el.scrollTop = el.scrollHeight;
  }
  function addSlot(item, quiet) {
    const band = $('dgBand');
    stickToBottom(band, () => {
      if (item.list.length) band.appendChild(sepEl(item.slot, item.mode));
      for (const d of item.list) band.appendChild(rowEl(item.slot, d));
    });
    const mine = item.list.filter(inRx);
    if (mine.length) {
      const rx = $('dgRx');
      stickToBottom(rx, () => { for (const d of mine) rx.appendChild(rowEl(item.slot, d)); });
    }
  }
  function inRx(d) { return Math.abs(d.f - rxF) <= RX_WIDTH || cls(d.msg) === 'me'; }
  function redrawRx() {
    const rx = $('dgRx');
    rx.textContent = '';
    for (const it of hist) if (it.mode === mode) for (const d of it.list) if (inRx(d)) rx.appendChild(rowEl(it.slot, d));
    rx.scrollTop = rx.scrollHeight;
  }
  function redrawAll() {
    $('dgBand').textContent = '';
    for (const it of hist) if (it.mode === mode) addSlot(it, true);
    redrawRx();
  }

  // ------------------------------------------------------------------ état, horloge, QSY
  function fillDial() {
    const sel = $('dgDial');
    sel.textContent = '';
    fillList(sel, dialList(mode));
    // Par défaut : la fréquence d'appel de la bande où se trouve le TRX
    const st = api && api.state();
    const f = st && st.radio && st.radio.freq;
    const near = f && nearList(mode, f).length ? nearList(mode, f).reduce((a, x) => (Math.abs(x[1] * 1000 - f) < Math.abs(a[1] * 1000 - f) ? x : a)) : null;
    const saved = store.get('dial.' + mode, '');
    if (near && Math.abs(near[1] * 1000 - f) < 500000) sel.value = String(near[1]);
    else if (f) {
      // Pas de fréquence d'appel de ce mode sur la bande du TRX (ex. FT4 sur 70 cm) : on le dit au lieu d'afficher 80 m
      const o = document.createElement('option');
      o.value = '';
      o.textContent = 'Pas de fréquence ' + mode + ' sur cette bande';
      o.disabled = true;
      sel.insertBefore(o, sel.firstChild);
      sel.value = '';
    } else if (saved) sel.value = saved;
  }
  function setMode(m) {
    mode = m;
    if (m !== 'JT65') store.set('ftmode', m);
    modeChanged();
    announce();
  }
  function modeChanged() {
    document.querySelectorAll('#dgModes .btn').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.mode === mode)));
    lastBand = 0;
    fillDial();
    drawScale();
    redrawAll();
  }
  function qsy() {
    if (!api) return;
    if (!api.iControl()) return api.say('Prenez la main pour changer de fréquence.', 'warn');
    const st = api.state();
    if (st && st.ptt && st.ptt.active) return api.say('Réglage bloqué pendant l’émission.', 'warn');
    const khz = Number($('dgDial').value);
    if (!khz) return api.say('Choisissez d’abord une fréquence d’appel dans la liste.', 'warn');
    store.set('dial.' + mode, khz);
    qsyTo(khz);
  }
  function qsyTo(khz, want) {
    if (!api.iControl()) {
      lastBand = 0; // la liste revient sur la bande réelle du TRX
      if ($('rtDial')) $('rtDial').value = store.get('rtdial', '14085');
      if ($('cwDial')) $('cwDial').value = store.get('cwdial', '14030');
      return api.say('Prenez la main pour changer de fréquence.', 'warn');
    }
    const st = api.state();
    if (st && st.ptt && st.ptt.active) return api.say('Réglage bloqué pendant l’émission.', 'warn');
    api.setFreq(Math.round(khz * 1000), 'A');
    // Mode DATA-U (Yaesu) / USB-D (Icom) : le filtre et la sortie audio conviennent aux modes numériques
    const R = api.rig();
    const mk = want === 'CW'
      ? (R.MODE_KEYS || []).find((x) => /^(CW-U|CW|CW-USB)$/i.test(x[1]))
      : (R.MODE_KEYS || []).find((x) => /^(DATA-U|USB-D|D-U|USB-DATA)$/i.test(x[1])) || (R.MODE_KEYS || []).find((x) => /^USB$/i.test(x[1]));
    if (mk) setTimeout(() => api.send({ t: 'set', mode: mk[0], sub: false }), 250);
  }
  function autoQsy() {
    const st = api && api.state();
    const f = st && st.radio && st.radio.freq;
    const khz = Number($('dgDial').value);
    if (!f || !khz) return api.say('Pas de fréquence ' + mode + ' sur cette bande : choisissez une bande dans la liste puis QSY.', 'warn');
    if (Math.abs(f - khz * 1000) < 50 && st.radio.mode && /DATA|-D/i.test(st.radio.mode)) return; // déjà dessus
    if (!api.iControl()) return api.say('Prenez la main pour aller sur ' + khz.toLocaleString('fr-BE') + ' kHz (' + mode + ').', 'warn');
    qsy();
  }
  function status() {
    if (!api || (tab !== 'ftx' && tab !== 'jt65' && tab !== 'rtty')) return;
    const st = api.state();
    const el = $(tab === 'rtty' ? 'rtStatus' : 'dgStatus');
    let txt = '';
    let warn = false;
    if (!st || !st.station) { txt = 'Station hors ligne'; warn = true; }
    else if (!st.audio || !st.audio.active) { txt = 'La page Station n’envoie pas la BF : « Activer l’audio » sur le PC du club'; warn = true; }
    else if (tab === 'rtty') txt = 'BF reçue';
    else if (!lastDecode || Date.now() - lastDecode > (mode === 'JT65' ? 130000 : mode === 'FT8' ? 40000 : 20000)) txt = 'BF reçue · décodage au prochain cycle' + (mode === 'JT65' ? ' (vers la 52e seconde de chaque minute)' : '') + '…';
    else txt = 'BF reçue · décodage OK' + (st.digi && st.digi.latency != null ? ' · délai ' + st.digi.latency + ' ms' : '');
    if (st && st.radio && st.radio.mode && !/DATA|USB|-D/i.test(st.radio.mode)) { txt += ' · mode ' + st.radio.mode + ' : passez en DATA-U'; warn = true; }
    el.textContent = txt;
    el.classList.toggle('warn', warn);
  }
  const now = () => Date.now() + clockOff; // heure du serveur
  function clock() {
    const d = new Date(now());
    const L = mode === 'JT65' ? 60 : mode === 'FT8' ? 15 : 7.5;
    const s = (d.getTime() / 1000) % L;
    $('dgClock').textContent = pad(d.getUTCHours()) + ':' + pad(d.getUTCMinutes()) + ':' + pad(d.getUTCSeconds()) + ' UTC · ' + (L - s).toFixed(0).padStart(2, ' ') + ' s';
  }

  // ------------------------------------------------------------------ synchro
  function medianDt() {
    const v = [];
    for (let i = hist.length - 1; i >= 0 && v.length < 80; i--) for (const d of hist[i].list) if (Math.abs(d.dt) < 2.5) v.push(d.dt);
    if (v.length < 3) return null;
    v.sort((a, b) => a - b);
    return { med: v[v.length >> 1], n: v.length };
  }
  function drawSync() {
    if (tab !== 'sync' || detached) return;
    const d = new Date(now());
    $('syVps').textContent = pad(d.getUTCHours()) + ':' + pad(d.getUTCMinutes()) + ':' + pad(d.getUTCSeconds());
    if (bestRtt < Infinity) {
      const s = -clockOff / 1000; // positif : ce PC est en avance
      $('syPc').textContent = (Math.abs(s) < 0.05 ? '0,0' : (s > 0 ? '+' : '−') + Math.abs(s).toFixed(1).replace('.', ',')) + ' s';
      $('syPc').className = Math.abs(s) < 1 ? 'ok' : 'warn';
      $('syPcNote').textContent = Math.abs(s) < 1 ? 'à l’heure (aucune incidence sur le décodage)' : (s > 0 ? 'en avance' : 'en retard') + ' sur le serveur (aucune incidence sur le décodage)';
    }
    const st = api && api.state();
    const lat = st && st.digi && st.digi.latency;
    $('syLat').textContent = lat != null ? lat + ' ms' : '—';
    const m = medianDt();
    $('syDt').textContent = m ? (m.med >= 0 ? '+' : '−') + Math.abs(m.med).toFixed(1).replace('.', ',') + ' s' : '—';
    $('syDt').className = m ? (Math.abs(m.med) <= 0.3 ? 'ok' : 'warn') : '';
    $('syDtNote').textContent = m ? m.n + ' messages récents' + (Math.abs(m.med) > 0.3 ? ' · recalage en cours' : ' · calé') : 'en attente de décodages FT8 / FT4';
  }

  // ------------------------------------------------------------------ interface avec app.js
  window.RSDIGI = {
    setDetached,
    isPopup: POPUP,
    /** Mode numérique affiché (pour le carnet de trafic quand le TRX est en DATA) */
    logMode() {
      const t = tab;
      if (t === 'ftx') return mode;
      return { jt65: 'JT65', rtty: 'RTTY', jtty: 'JTTY', cw: 'CW', sstv: 'SSTV', wspr: 'WSPR' }[t] || store.get('ftmode', 'FT8');
    },
    qo100If: () => Object.assign({}, qoIf),
    init(a) {
      const again = !!api;
      api = a;
      if (again) { announce(); return; } // fenêtre séparée raccrochée à un dashboard rechargé
      buildDom();
      document.querySelectorAll('#centerPanel .ctab').forEach((b) => b.addEventListener('click', (e) => { e.stopPropagation(); showTab(b.dataset.tab); }));
      $('dgDetach').addEventListener('click', (e) => {
        e.stopPropagation();
        if (POPUP) return window.close();
        // La fenêtre séparée s'ouvre sur le mode affiché
        if (MODE_TABS.indexOf(tab) >= 0) store.set('ptab', tab);
        const w = window.open('/digi.html', 'rs-digi', 'width=1200,height=860');
        if (!w) api.say('Fenêtre bloquée par Chrome : autorisez les fenêtres pop-up pour ce site.', 'warn');
      });
      $('dgBack').addEventListener('click', () => { if (window.RSHOST) window.RSHOST.closePopup(); });
      // Clic sur FT8 / FT4 : comme dans WSJT-X, le TRX va sur la fréquence d'appel de ce mode dans sa bande
      document.querySelectorAll('#dgModes .btn').forEach((b) => b.addEventListener('click', () => { setMode(b.dataset.mode); autoQsy(); }));
      $('dgQsy').addEventListener('click', qsy);
      // Choisir une fréquence dans la liste y envoie directement le TRX (QSY)
      $('dgDial').addEventListener('change', () => { store.set('dial.' + mode, $('dgDial').value); qsy(); });
      $('dgClear').addEventListener('click', () => { hist.length = 0; redrawAll(); });
      // Split : clic gauche = fréquence de réception, clic droit = fréquence d'émission
      const fAt = (e) => { const r = e.currentTarget.getBoundingClientRect(); return ((e.clientX - r.left) / r.width) * WF_MAX_HZ; };
      for (const id of ['dgWf', 'dgScale']) {
        $(id).addEventListener('click', (e) => (tab === 'sstv' ? null : tab === 'rtty' ? setRttyF(fAt(e)) : tab === 'cw' ? setCwF(fAt(e), true) : setRx(fAt(e))));
        $(id).addEventListener('contextmenu', (e) => { e.preventDefault(); if (tab === 'sstv') return; if (tab === 'rtty') setRttyF(fAt(e)); else if (tab === 'cw') setCwF(fAt(e), false); else setTx(fAt(e)); });
      }
      initRtty();
      initWspr();
      initJtty();
      initCw();
      initSstv();
      initMsgs();
      // Touches F1 à F12 dans la fenêtre RTTY : macros (comme FLDIGI)
      document.addEventListener('keydown', (e) => {
        const MODE = { rtty: 'RTTY', jtty: 'JTTY', cw: 'CW' }[tab];
        if (!MODE || detached || e.ctrlKey || e.altKey || e.metaKey) return;
        const n = /^F(\d{1,2})$/.exec(e.key);
        if (!n) return;
        const m = macroList(MODE)[Number(n[1]) - 1];
        if (!m) return;
        e.preventDefault();
        if (tab === 'jtty') insertJtty(m.text); else if (tab === 'cw') insertCw(m.text); else insertRtty(m.text);
      });
      $('dgTxRx').addEventListener('click', () => setTx(rxF));
      $('dgRxTx').addEventListener('click', () => setRx(txF));
      // Repli du panneau ou onglet du navigateur caché : le serveur arrête de décoder pour ce membre
      new MutationObserver(announce).observe($('centerPanel'), { attributes: true, attributeFilter: ['class'] });
      document.addEventListener('visibilitychange', announce);
      window.addEventListener('resize', () => { if (WF_TABS.indexOf(tab) >= 0) sizeCanvas(); });
      fillDial();
      setMode(mode);
      showTab(tab);
      setInterval(() => {
        if (detached) return;
        if (tab === 'ftx' || tab === 'jt65') { clock(); status(); followBand(); }
        if (tab === 'rtty') status();
        if (tab === 'wspr') wsClock();
        if (tab === 'jtty') jtStatus();
        if (tab === 'cw') cwStatus();
        if (tab === 'sstv') sstvStatus();
        if (tab === 'sync') drawSync();
      }, 500);
    },
    insertRtty,
    insertJtty,
    insertCw,
    onHello(me, info) {
      needHist = true;
      wsNeedHist = true;
      jtNeedHist = true;
      if (info && info.digiCall) myCall = info.digiCall;
      if (info) myGrid = info.stationGrid || '';
      if (info) myQth = info.stationQth || '';
      if (info && info.qo100If && typeof info.qo100If === 'object') qoIf = Object.assign({}, info.qo100If);
      refillQo();
      if (me && me.call) opCall = me.call;
      drawMsgs();
      if (info && info.stationCall) stationCalls = String(info.stationCall).toUpperCase().split(/[\s/,]+/).filter(Boolean);
      announce(); // reprise après reconnexion
    },
    onMessage(m) {
      if (m.t === 'pong' && Number.isFinite(m.now) && Number.isFinite(m.ts)) {
        // Écart d'horloge avec le serveur, d'après l'aller-retour le plus court
        const rtt = Date.now() - m.ts;
        if (rtt >= 0 && rtt <= bestRtt * 1.5 + 20) {
          bestRtt = Math.min(bestRtt, rtt);
          clockOff = m.now - (m.ts + rtt / 2);
        }
        return false;
      }
      if (m.t === 'macros') {
        macros = m.data || {};
        store.set('macros', JSON.stringify(macros));
        redrawMacros();
        return true;
      }
      if (m.t === 'rtty') { rttyAppend(m.text || ''); return true; }
      if (m.t === 'jtty') { jtUpdate(m.u); return true; }
      if (m.t === 'cw') { cwAppend(m.text || ''); return true; }
      if (/^sstv_/.test(m.t)) return ssMessage(m);
      if (m.t === 'cw_lvl') { cwLevels(m); return true; }
      if (m.t === 'jtty_hist') { jtMsgs.clear(); for (const u of m.items || []) jtMsgs.set(u.key, u); jtRedraw(); return true; }
      if (m.t === 'rtty_lvl') { rttyLevels(m); return true; }
      if ((m.t === 'ftx_hist' || m.t === 'ftx') && m.mode === 'WSPR') {
        if (m.t === 'ftx_hist') {
          wsHist.length = 0;
          for (const it of m.items || []) wsHist.push({ slot: it.slot, list: it.list || [] });
          wsRedraw();
        } else {
          wsLast = m.slot;
          const it = { slot: m.slot, list: m.list || [] };
          wsHist.push(it);
          while (wsHist.length > 60) wsHist.shift();
          wsAdd(it);
        }
        return true;
      }
      if (m.t === 'ftx_hist') {
        // Historique à l'ouverture : on remplace ce qu'on a pour ce mode
        for (let i = hist.length - 1; i >= 0; i--) if (hist[i].mode === m.mode) hist.splice(i, 1);
        for (const it of m.items || []) hist.push({ slot: it.slot, mode: m.mode, list: it.list || [] });
        hist.sort((a, b) => a.slot - b.slot);
        if (m.mode === mode) redrawAll();
        return true;
      }
      if (m.t === 'ftx') {
        lastDecode = Date.now();
        const it = { slot: m.slot, mode: m.mode, list: m.list || [] };
        hist.push(it);
        while (hist.length > 120) hist.shift();
        if (m.mode === mode) addSlot(it, false);
        return true;
      }
      return false;
    },
    onBinary(bytes) {
      if (bytes[0] === 0x10) { onRow(bytes); return true; }
      if (bytes[0] === 0x11) { ssLine(bytes); return true; }
      return false;
    },
    onState() {
      // Autre TRX (couverture différente) : les fréquences QO-100 proposées changent
      const R = api && api.rig && api.rig();
      if (R && R.ID !== lastRig) { lastRig = R.ID; refillQo(); }
      if (tab === 'ftx' || tab === 'jt65') { status(); followBand(); }
    }
  };
  // Le TRX a changé de bande : la liste des fréquences d'appel suit (vérifié aussi chaque demi-seconde)
  function followBand() {
      const st = api && api.state();
      const f = st && st.radio && st.radio.freq;
      if (!f) return;
      const band = f ? nearList(mode, f).reduce((a, x) => (Math.abs(x[1] * 1000 - f) < Math.abs(a[1] * 1000 - f) ? x : a))[1] : 0;
      if (band !== lastBand) { lastBand = band; fillDial(); }
  }

  // ------------------------------------------------------------------ fenêtre séparée (digi.html)
  if (POPUP) {
    let host = null;
    const toast = (msg, level) => {
      const el = $('dgToast');
      el.textContent = msg || '';
      el.className = 'dg-toast ' + (level || '');
      clearTimeout(toast.t);
      if (msg) toast.t = setTimeout(() => { el.textContent = ''; }, 6000);
    };
    const link = () => {
      const op = window.opener;
      const h = op && !op.closed && op.RSHOST;
      if (h && h !== host) {
        host = h;
        // Même connexion que le dashboard ; les messages d'alerte s'affichent dans cette fenêtre
        h.attach(window, window.RSDIGI, Object.assign({}, h.api, { say: toast }));
        $('dgOrphan').hidden = true;
      } else if (!h) {
        host = null;
        $('dgOrphan').hidden = false;
      }
    };
    window.addEventListener('pagehide', () => { if (host) try { host.detach(window.RSDIGI); } catch (e) {} });
    link();
    setInterval(link, 1000); // dashboard rechargé : on s'y raccroche ; fermé : avertissement
  }
})();
