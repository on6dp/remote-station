/*
 * yaesu.js — base commune des pilotes CAT texte Yaesu (FTX-1, FTDX10…)
 *
 * Chaque pilote décrit seulement ses différences (puissance, atténuateur, processeur, largeurs…) ;
 * ce module fournit le reste : lectures, réglages, analyse des réponses, simulateur.
 *
 * Format CAT : 2 lettres + paramètres + ';'. Erreur renvoyée par la radio : "?;".
 * Références : manuels CAT Yaesu (FTX-1 2508-C, FTDX10) et RigPlane Core (MIT, voir TIERS.md).
 */
(function (root) {
  'use strict';

  const pad = (n, w) => String(Math.abs(Math.round(Number(n)))).padStart(w, '0');
  const signed4 = (v) => (Number(v) < 0 ? '-' : '+') + pad(v, 4);
  const sgn = (s) => (s === '-' ? -1 : 1);

  // Codes P2 de la commande MD, communs aux Yaesu récents
  const MODES = {
    '1': 'LSB', '2': 'USB', '3': 'CW-U', '4': 'FM', '5': 'AM',
    '6': 'RTTY-L', '7': 'CW-L', '8': 'DATA-L', '9': 'RTTY-U', 'A': 'DATA-FM',
    'B': 'FM-N', 'C': 'DATA-U', 'D': 'AM-N', 'E': 'PSK', 'F': 'DATA-FM-N'
  };
  const SETTABLE = ['1', '2', '3', '7', '4', 'B', '5', 'D', '8', 'C', 'A', 'F', '6', '9', 'E'];
  // Touches de mode de la face avant : [code, libellé]
  const MODE_KEYS = [
    ['1', 'LSB'], ['2', 'USB'], ['7', 'CW-L'], ['3', 'CW-U'], ['6', 'RTTY-L'], ['9', 'RTTY-U'],
    ['8', 'DATA-L'], ['C', 'DATA-U'], ['E', 'PSK'], ['5', 'AM'], ['D', 'AM-N'], ['4', 'FM'],
    ['B', 'FM-N'], ['A', 'DATA-FM']
  ];

  // Largeurs de filtre (code 1..n → Hz)
  const WIDTH_SSB = [300, 400, 600, 850, 1100, 1200, 1500, 1650, 1800, 1950, 2100, 2250, 2400, 2450, 2500, 2600, 2700, 2800, 2900, 3000, 3200, 3500, 4000];
  const WIDTH_NARROW = [50, 100, 150, 200, 250, 300, 350, 400, 450, 500, 600, 800, 1200, 1400, 1700, 2000, 2400, 3000, 3200, 3500, 4000];
  const NARROW_MODES = ['CW-U', 'CW-L', 'DATA-L', 'DATA-U', 'RTTY-L', 'RTTY-U', 'PSK'];

  // Étalonnages indicatifs (RigPlane, mesurés sur FTX-1)
  const S_CAL = [[0, 'S0'], [26, 'S1'], [39, 'S2'], [52, 'S3'], [65, 'S4'], [78, 'S5'], [91, 'S6'], [103, 'S7'], [117, 'S8'], [130, 'S9'], [165, 'S9+10'], [200, 'S9+20'], [240, 'S9+40']];
  const SWR_CAL = [[0, 1.0], [48, 1.5], [96, 2.0], [160, 3.0], [255, 5.0]];

  /** Lectures communes (toutes les secondes). Chaque entrée : commande, motif de réponse, analyse, réponse simulée. */
  // AC P1 P2 P3 : P1 = tuner interne (0) / externe (1), P2 = tuner (0) / ATAS (2). On renvoie ceux relus au TRX
  // (le FTX-1 refuse « AC00x » si son menu TUNER SELECT est sur EXT ou ATAS).
  function acHead(r) { return (r && /^[01][0-2]$/.test(r.acHead || '')) ? r.acHead : '00'; }

  function baseReads() {
    return [
      { cmd: 'ST;', re: /^ST([0-2])$/, parse: (m) => ({ split: m[1] === '0' ? 0 : 1 }), sim: 'ST0' },
      { cmd: 'VS;', re: /^VS([01])$/, parse: (m) => ({ vfoSel: +m[1] }), sim: 'VS0' },
      { cmd: 'CF000;', re: /^CF000([01])([01])\d{3}$/, parse: (m) => ({ rit: +m[1], xit: +m[2] }), sim: 'CF00000000' },
      { cmd: 'CF001;', re: /^CF001([+-])(\d{4})$/, parse: (m) => ({ clar: sgn(m[1]) * +m[2] }), sim: 'CF001+0000' },
      { cmd: 'LK;', re: /^LK([01])$/, parse: (m) => ({ lock: +m[1] }), sim: 'LK0' },
      { cmd: 'SH0;', re: /^SH0(\d{3})$/, parse: (m) => ({ width: +m[1] }), sim: 'SH0013' },
      { cmd: 'NA0;', re: /^NA0([01])$/, parse: (m) => ({ narrow: +m[1] }), sim: 'NA00' },
      { cmd: 'IS0;', re: /^IS00([+-])(\d{4})$/, parse: (m) => ({ shift: sgn(m[1]) * +m[2] }), sim: 'IS00+0000' },
      { cmd: 'CO00;', re: /^CO00(\d{4})$/, parse: (m) => ({ contour: +m[1] ? 1 : 0 }), sim: 'CO000000' },
      { cmd: 'CO02;', re: /^CO02(\d{4})$/, parse: (m) => ({ apf: +m[1] ? 1 : 0 }), sim: 'CO020000' },
      { cmd: 'BC0;', re: /^BC0([01])$/, parse: (m) => ({ dnf: +m[1] }), sim: 'BC00' },
      { cmd: 'BP00;', re: /^BP00(\d{3})$/, parse: (m) => ({ notch: +m[1] ? 1 : 0 }), sim: 'BP00000' },
      { cmd: 'BP01;', re: /^BP01(\d{3})$/, parse: (m) => ({ notchFreq: +m[1] * 10 }), sim: 'BP01150' },
      { cmd: 'NL0;', re: /^NL0(\d{3})$/, parse: (m) => ({ nb: +m[1] }), sim: 'NL0000' },
      { cmd: 'RL0;', re: /^RL0(\d{2})$/, parse: (m) => ({ nr: +m[1] }), sim: 'RL000' },
      { cmd: 'AG0;', re: /^AG0(\d{3})$/, parse: (m) => ({ af: +m[1] }), sim: 'AG0128' },
      { cmd: 'RG0;', re: /^RG0(\d{3})$/, parse: (m) => ({ rf: +m[1] }), sim: 'RG0255' },
      { cmd: 'SQ0;', re: /^SQ0(\d{3})$/, parse: (m) => ({ sql: +m[1] }), sim: 'SQ0000' },
      { cmd: 'GT0;', re: /^GT0(\d)$/, parse: (m) => ({ agc: Math.min(4, +m[1]) }), sim: 'GT04' }, // 5-6 = variantes AUTO
      { cmd: 'PA0;', re: /^PA0([0-2])$/, parse: (m) => ({ preamp: +m[1] }), sim: 'PA00' },
      { cmd: 'RA0;', re: /^RA0([01])$/, parse: (m) => ({ att: +m[1] }), sim: 'RA00' },
      { cmd: 'MG;', re: /^MG(\d{3})$/, parse: (m) => ({ mic: +m[1] }), sim: 'MG050' },
      { cmd: 'PR0;', re: /^PR0([01])$/, parse: (m) => ({ proc: +m[1] }), sim: 'PR00' },
      { cmd: 'PL;', re: /^PL(\d{3})$/, parse: (m) => ({ procLvl: +m[1] }), sim: 'PL050' },
      { cmd: 'VX;', re: /^VX([01])$/, parse: (m) => ({ vox: +m[1] }), sim: 'VX0' },
      { cmd: 'AC;', re: /^AC([01])([0-2])([0-3])$/, parse: (m) => ({ tuner: m[3] === '0' ? 0 : 1, tuning: m[3] === '3' ? 1 : 0, acHead: m[1] + m[2] }), sim: 'AC000' }
    ];
  }

  /** Réglages communs. type : toggle, select, level, width, action. when(st) : disponibilité. transmits : émission. */
  function baseControls(widthTable) {
    return [
      { id: 'split', g: 'vfo', label: 'SPLIT', type: 'toggle', write: (v) => 'ST' + v + ';' },
      { id: 'vfoSel', g: 'vfo', label: 'VFO active', type: 'select', options: [[0, 'MAIN (A)'], [1, 'SUB (B)']], write: (v) => 'VS' + v + ';' },
      { id: 'swap', g: 'vfo', label: 'A ⇄ B', type: 'action', write: () => 'SV;' },
      { id: 'aToB', g: 'vfo', label: 'A → B', type: 'action', write: () => 'AB;' },
      { id: 'bToA', g: 'vfo', label: 'B → A', type: 'action', write: () => 'BA;' },
      { id: 'rit', g: 'vfo', label: 'RIT', type: 'toggle', write: (v, s) => 'CF000' + v + (s.xit || 0) + '000;' },
      { id: 'xit', g: 'vfo', label: 'XIT', type: 'toggle', write: (v, s) => 'CF000' + (s.rit || 0) + v + '000;' },
      { id: 'clar', g: 'vfo', label: 'Décalage RIT/XIT', type: 'level', min: -9999, max: 9999, step: 10, unit: 'Hz', write: (v) => 'CF001' + signed4(v) + ';' },
      { id: 'clarClr', g: 'vfo', label: 'CLEAR (décalage RIT/XIT à zéro)', type: 'action', write: () => 'CF001+0000;' },
      { id: 'lock', g: 'vfo', label: 'LOCK (face avant du club)', type: 'toggle', write: (v) => 'LK' + v + ';' },

      { id: 'width', g: 'flt', label: 'WIDTH', type: 'width', write: (v) => 'SH0' + pad(v, 3) + ';', when: (s) => !!widthTable(s.mode) && !s.narrow },
      { id: 'narrow', g: 'flt', label: 'NARROW', type: 'toggle', write: (v) => 'NA0' + v + ';' },
      { id: 'shift', g: 'flt', label: 'IF SHIFT', type: 'level', min: -1200, max: 1200, step: 20, unit: 'Hz', write: (v) => 'IS00' + signed4(v) + ';' },
      { id: 'contour', g: 'flt', label: 'CONTOUR', type: 'toggle', write: (v) => 'CO00' + pad(v, 4) + ';' },
      { id: 'apf', g: 'flt', label: 'APF', type: 'toggle', write: (v) => 'CO02' + pad(v, 4) + ';', when: (s) => /^CW/.test(s.mode || '') },
      { id: 'dnf', g: 'flt', label: 'DNF', type: 'toggle', write: (v) => 'BC0' + v + ';' },
      { id: 'notch', g: 'flt', label: 'NOTCH', type: 'toggle', write: (v) => 'BP00' + pad(v, 3) + ';' },
      { id: 'notchFreq', g: 'flt', label: 'Fréquence NOTCH', type: 'level', min: 10, max: 3200, step: 10, unit: 'Hz', write: (v) => 'BP01' + pad(v / 10, 3) + ';', when: (s) => !/FM/.test(s.mode || '') },
      { id: 'nb', g: 'flt', label: 'NB', type: 'level', min: 0, max: 10, step: 1, off0: true, write: (v) => 'NL0' + pad(v, 3) + ';' },
      { id: 'nr', g: 'flt', label: 'DNR', type: 'level', min: 0, max: 10, step: 1, off0: true, write: (v) => 'RL0' + pad(v, 2) + ';' },

      { id: 'af', g: 'rx', label: 'AF', type: 'level', min: 0, max: 255, step: 1, pct: true, write: (v) => 'AG0' + pad(v, 3) + ';' },
      { id: 'rf', g: 'rx', label: 'RF', type: 'level', min: 0, max: 255, step: 1, pct: true, write: (v) => 'RG0' + pad(v, 3) + ';' },
      { id: 'sql', g: 'rx', label: 'Squelch', type: 'level', min: 0, max: 255, step: 1, pct: true, write: (v) => 'SQ0' + pad(v, 3) + ';' },
      { id: 'agc', g: 'rx', label: 'AGC', type: 'select', options: [[0, 'OFF'], [1, 'FAST'], [2, 'MID'], [3, 'SLOW'], [4, 'AUTO']], write: (v) => 'GT0' + v + ';' },
      { id: 'preamp', g: 'rx', label: 'Préampli', type: 'select', options: [[0, 'IPO'], [1, 'AMP1'], [2, 'AMP2']], write: (v) => 'PA0' + v + ';', when: (s) => s.freq != null && s.freq <= 54000000 },
      { id: 'att', g: 'rx', label: 'ATT', type: 'toggle', write: (v) => 'RA0' + v + ';', when: (s) => s.freq != null && s.freq <= 60000000 && !s.vfoSel },

      { id: 'mic', g: 'tx', label: 'Gain micro', type: 'level', min: 0, max: 100, step: 1, write: (v) => 'MG' + pad(v, 3) + ';' },
      { id: 'proc', g: 'tx', label: 'PROC', type: 'toggle', write: (v) => 'PR0' + v + ';' },
      { id: 'procLvl', g: 'tx', label: 'Niveau PROC', type: 'level', min: 0, max: 100, step: 1, write: (v) => 'PL' + pad(v, 3) + ';' },
      // VOX : on peut le couper à distance, jamais l'activer (il pourrait émettre hors du contrôle du PTT)
      { id: 'vox', g: 'tx', label: 'VOX', type: 'toggle', offOnly: true, write: (v) => 'VX' + v + ';' },
      { id: 'tuner', g: 'tx', label: 'Tuner', type: 'toggle', write: (v, r) => 'AC' + acHead(r) + v + ';' },
      { id: 'tune', g: 'tx', label: 'TUNE', type: 'action', transmits: true, write: (v, r) => 'AC' + acHead(r) + '3;' }
    ];
  }

  /** Découpe un flux série (texte ou octets) en réponses terminées par ';'. */
  class Splitter {
    constructor() { this.acc = ''; }
    push(chunk) {
      if (typeof chunk !== 'string') {
        let s = '';
        for (let i = 0; i < chunk.length; i++) s += String.fromCharCode(chunk[i]);
        chunk = s;
      }
      this.acc += chunk;
      if (this.acc.length > 4096) this.acc = this.acc.slice(-256);
      const out = [];
      let i;
      while ((i = this.acc.indexOf(';')) >= 0) {
        const tok = this.acc.slice(0, i).replace(/[\r\n\s]/g, '').toUpperCase();
        this.acc = this.acc.slice(i + 1);
        if (tok) out.push(tok);
      }
      return out;
    }
  }

  /**
   * Construit un pilote Yaesu.
   * spec : ID, NAME, FREQ_MAX, extraModes, power {read, re, parse, range, step, cmd, fakeRead, fakeWrite},
   *        readOverrides {cmd: lecture|null}, controlOverrides {id: modifs|null}, extraReads, extraControls,
   *        widthTable, tuneCmd, serial, hint
   */
  function build(spec) {
    const ID = spec.ID;
    const NAME = spec.NAME;
    const FREQ_MIN = 30000;
    const FREQ_MAX = spec.FREQ_MAX;
    // spec.modes : table des modes propre au TRX (FTDX5000 : pas de AM-N / PSK / DATA-FM-N) ; spec.freqDigits : FA / FB sur
    // 8 chiffres (FTDX5000) au lieu de 9
    const MODES_ALL = spec.modes ? Object.assign({}, spec.modes) : Object.assign({}, MODES, spec.extraModes || {});
    const MSET = spec.settable || SETTABLE;
    const MKEYS = spec.modeKeys || MODE_KEYS;
    const FD = spec.freqDigits || 9;
    const FA_RE = new RegExp('^FA(\\d{' + FD + '})$'), FB_RE = new RegExp('^FB(\\d{' + FD + '})$');
    const widthTable = spec.widthTable || function (mode) {
      if (mode === 'LSB' || mode === 'USB') return WIDTH_SSB;
      if (NARROW_MODES.indexOf(mode) >= 0) return WIDTH_NARROW;
      return null;
    };
    const P = spec.power;

    // Lectures : puissance du modèle + lectures communes, éventuellement remplacées
    const READS = [{ cmd: P.read, re: P.re, parse: P.parse, sim: null, power: true }];
    for (const r of baseReads()) {
      const o = spec.readOverrides && Object.prototype.hasOwnProperty.call(spec.readOverrides, r.cmd) ? spec.readOverrides[r.cmd] : r;
      if (o) READS.push(Object.assign({ cmd: r.cmd }, o));
    }
    for (const r of spec.extraReads || []) READS.push(r);
    // Les commandes partent une par une, espacées (FRAME_GAP_MS) : une rafale de 30 commandes
    // déborde le tampon CAT de la radio, qui en perd une partie (mode non lu, « plus de réponse »…)
    const FAST = ['FA;', 'MD0;', 'FB;', 'MD1;', 'SM0;', 'TX;', 'FT;'].concat(spec.fastExtra || []); // fastExtra : lectures rapides propres à un TRX
    // Deux récepteurs (FTX-1) : S-mètre du côté SUB par READ METER « RM2 » (manuel CAT : RM P1 2 = S SUB-side ;
    // le FTX-1 ne répond pas à SM1), lu en double réception (FR00) ; en réception simple, SM0 = côté actif
    // FTDX101 : « SM1; » (S-METER READING, P1 1 = SUB Band, 000-255 comme SM0) ; RM2 restait à 0 en double réception
    const FAST_SUB = spec.fastSub || (spec.subBadges ? ['RM2;'] : []);
    // En émission : mesures COMP, ALC, PO, SWR, et aussi puissance et VOX (contrôles de sécurité plus rapides)
    const TXMETERS = ['RM3;', 'RM4;', 'RM5;', 'RM6;', P.read, 'VX;'];
    const SLOW = READS.map((r) => r.cmd).concat(['RM7;', 'RM8;']); // + IDD, VDD
    // Lecture permise dans l'état actuel (when : ex. APF seulement en CW) ; un « ?; » répondu à une lecture sans objet
    // serait pris pour le refus du réglage envoyé juste avant
    const READ_WHEN = {};
    for (const r of READS) if (r.when) READ_WHEN[r.cmd] = r.when;
    const readOk = (cmd, st) => !READ_WHEN[cmd] || !!READ_WHEN[cmd](st || {});
    // Commande de lecture de chaque clé d'état : relue juste après un réglage, sans attendre le tour complet
    const READ_FOR = {};
    function readFor(id, st) {
      if (spec.readForState && st) { const x = spec.readForState(id, st); if (x) return x; }
      if (!Object.keys(READ_FOR).length) {
        for (const r of READS) {
          const m = r.sim && r.re.exec(r.sim);
          if (m) for (const k of Object.keys(r.parse(m))) READ_FOR[k] = r.cmd;
        }
        READ_FOR.power = P.read;
        READ_FOR.powerHead = P.read;
        // CLEAR : relire le décalage tout de suite
        if (READ_FOR.clar) READ_FOR.clarClr = READ_FOR.clar;
        if (READ_FOR.clarB) READ_FOR.clarClrB = READ_FOR.clarB;
        // VC TUNE (FTDX101) : un pas + / − se relit par la position (VT0; / VT1;)
        if (READ_FOR.vc) READ_FOR.vcUp = READ_FOR.vcDn = READ_FOR.vc;
        if (READ_FOR.vcB) READ_FOR.vcUpB = READ_FOR.vcDnB = READ_FOR.vcB;
      }
      return READ_FOR[id] || null;
    }
    const STATE_KEYS = ['smeterB', 'dualRx', 'txVfo', 'split', 'vfoSel', 'rit', 'xit', 'clar', 'lock', 'width', 'narrow', 'shift', 'contour', 'apf',
      'dnf', 'notch', 'notchFreq', 'nb', 'nr', 'af', 'rf', 'sql', 'agc', 'preamp', 'att', 'mic', 'proc', 'procLvl', 'vox',
      'tuner', 'tuning', 'ant', 'ritB', 'xitB', 'clarB', 'hwSplit', 'm3', 'm4', 'm5', 'm6', 'm7', 'm8'].concat(spec.extraStateKeys || []);

    // Réglages
    const CONTROLS = [];
    for (const c of baseControls(widthTable)) {
      const ov = spec.controlOverrides && Object.prototype.hasOwnProperty.call(spec.controlOverrides, c.id) ? spec.controlOverrides[c.id] : undefined;
      if (ov === null) continue;
      CONTROLS.push(Object.assign({}, c, ov || {}));
    }
    for (const c of spec.extraControls || []) CONTROLS.push(c);
    for (const c of spec.extraControlsLate || []) CONTROLS.push(c);
    const CONTROL = {};
    CONTROLS.forEach((c) => { CONTROL[c.id] = c; });

    function validate(id, value, st, opts) {
      const c = CONTROL[id];
      if (!c) throw new Error('commande inconnue');
      st = st || {};
      if (c.when && !(opts && opts.skipWhen) && !c.when(st)) throw new Error(c.label + ' indisponible dans cette configuration');
      if (c.type === 'action') return null;
      const v = Number(value);
      if (c.type === 'toggle') {
        if (v !== 0 && v !== 1) throw new Error('valeur invalide');
        if (c.offOnly && v === 1) throw new Error(c.label + ' ne peut pas être activé à distance');
        return v;
      }
      if (c.type === 'select') {
        if (!c.options.some((o) => o[0] === v)) throw new Error('valeur invalide');
        return v;
      }
      if (c.type === 'level') {
        if (!(v >= c.min && v <= c.max)) throw new Error(c.label + ' : ' + c.min + ' à ' + c.max);
        return Math.round(v / c.step) * c.step;
      }
      if (c.type === 'width') {
        const t = widthTable(st[c.modeKey || 'mode']) || (opts && opts.skipWhen ? WIDTH_SSB : null);
        if (!t || !(Number.isInteger(v) && v >= (spec.widthDefault ? 0 : 1) && v <= t.length)) throw new Error('largeur invalide pour ce mode'); // FTDX101 : 0 = défaut
        return v;
      }
      throw new Error('type inconnu');
    }

    function cmdFreq(hz) {
      hz = Math.round(Number(hz));
      if (!(hz >= FREQ_MIN && hz <= FREQ_MAX)) throw new Error('fréquence hors limites');
      return 'FA' + pad(hz, FD) + ';';
    }
    function cmdFreqB(hz) {
      hz = Math.round(Number(hz));
      if (!(hz >= FREQ_MIN && hz <= FREQ_MAX)) throw new Error('fréquence hors limites');
      return 'FB' + pad(hz, FD) + ';';
    }
    function cmdMode(code, sub) {
      code = String(code).toUpperCase();
      if (MSET.indexOf(code) < 0) throw new Error('mode non autorisé');
      return (sub ? 'MD1' : 'MD0') + code + ';';
    }
    const cmdPower = P.cmd;
    function cmdPtt(on) { return on ? 'TX1;' : 'TX0;'; } // TX1 = CAT TX ON, TX0 = CAT TX OFF
    // Changement de bande par BS (BAND SELECT), comme la touche BAND : la radio rappelle sa propre mémoire de bande
    // (dernière fréquence et dernier mode). Seulement pour les modèles qui déclarent leurs codes de bande.
    const BAND_CODES = spec.bandCodes || null;
    function cmdBand(name, sub) {
      if (!BAND_CODES || !Object.prototype.hasOwnProperty.call(BAND_CODES, name)) throw new Error('bande inconnue');
      // FTDX101 : « BS P1P1; » sans côté (bandSideless) ; FTX-1 : « BS P1 P2P2; » avec le côté
      if (spec.bandSideless) return 'BS' + BAND_CODES[name][0] + ';';
      return 'BS' + (sub ? '1' : '0') + BAND_CODES[name][0] + ';';
    }

    function parse(tok) {
      let m;
      if ((m = FA_RE.exec(tok))) return { freq: parseInt(m[1], 10) };
      if ((m = FB_RE.exec(tok))) return { freqB: parseInt(m[1], 10) };
      if ((m = /^MD0([0-9A-Z])$/.exec(tok))) return { modeCode: m[1], mode: MODES_ALL[m[1]] || ('?' + m[1]) };
      if ((m = /^MD1([0-9A-Z])$/.exec(tok))) return { modeCodeB: m[1], modeB: MODES_ALL[m[1]] || ('?' + m[1]) };
      if ((m = /^SM0(\d{3})$/.exec(tok))) return { smeter: parseInt(m[1], 10) };
      if ((m = /^SM1(\d{3})$/.exec(tok))) return { smeterB: parseInt(m[1], 10) };
      if ((m = /^RM2(\d{3})(\d{3})?$/.exec(tok))) return { smeterB: parseInt(m[1], 10) }; // FTDX5000 : 3 chiffres seulement
      if ((m = /^TX([0-2])$/.exec(tok))) return { tx: parseInt(m[1], 10) }; // 0 RX, 1 TX par CAT, 2 TX par la radio
      // FT : VFO d'émission. Modèles « splitIsFT » (FTX-1) : le SPLIT, c'est FT1 (TX sur SUB), jamais ST1
      if ((m = /^FT([01])$/.exec(tok))) return spec.splitIsFT ? { txVfo: +m[1], split: +m[1] } : { txVfo: +m[1] };
      if ((m = /^RM([3-8])(\d{3})(\d{3})?$/.exec(tok))) return { ['m' + m[1]]: +m[2] };
      if (tok === '?') return { error: true };
      for (const r of READS) if ((m = r.re.exec(tok))) return r.parse(m);
      if (/^EX\d{4}/.test(tok)) return { ok: true }; // réponse à une lecture de menu (phonie à distance…) ; FTDX5000 : menu sur 3 chiffres
      return null;
    }

    function smeterLabel(v) {
      if (v == null) return '—';
      let l = 'S0';
      for (const [raw, lab] of S_CAL) if (v >= raw) l = lab;
      return l;
    }
    function swrValue(raw) {
      if (raw == null) return null;
      for (let i = 1; i < SWR_CAL.length; i++) {
        const [r0, s0] = SWR_CAL[i - 1];
        const [r1, s1] = SWR_CAL[i];
        if (raw <= r1) return s0 + ((raw - r0) / (r1 - r0)) * (s1 - s0);
      }
      return 5;
    }
    function vdValue(raw) { return raw == null ? null : (raw / 210) * 13.8; }
    function idValue(raw) { return raw == null ? null : raw / 29; }

    // ---------------------------------------------------------- simulateur
    class Fake {
      constructor() {
        this.freq = 14250000;
        this.mode = '2';
        this.freqB = 7074000;
        this.modeB = 'C';
        this.power = 100;
        this.head = P.fakeHead;
        this.tx = 0;
        this.ans = {};
        for (const r of READS) if (!r.power) this.ans[r.cmd] = r.sim;
        // Menus de la phonie à distance : MIC (0) au départ, comme au club
        if (spec.voice) for (const k in spec.voice) for (const [id] of spec.voice[k]) this.ans['EX' + id + ';'] = 'EX' + id + '0';
        // Égaliseur du TRX (simulateur) : bandes coupées, niveau 0, largeur 5
        if (spec.trxEq) for (let i = 0; i < 18; i++) { const id = spec.trxEq.menu + pad(spec.trxEq.first + i, 2); this.ans['EX' + id + ';'] = 'EX' + id + (i % 3 === 0 ? '00' : i % 3 === 1 ? '+00' : '05'); }
        // Menus du TRX (simulateur) : chaque réglage à sa première valeur, au format du manuel (chiffres, signe)
        if (spec.menu) for (const g of spec.menu.groups) for (const it of g.items) {
          const d = it.d, k = 'EX' + it.id + ';';
          if (this.ans[k] != null || d.k === 't') continue;
          if (d.k === 'l') { const codes = d.codes || d.labels.map((_, i) => i + d.base); const w = String(Math.max.apply(null, codes)).length; this.ans[k] = 'EX' + it.id + pad(codes[0], w); }
          else { const w = String(Math.max(Math.abs(d.min), Math.abs(d.max))).length; this.ans[k] = 'EX' + it.id + (d.min < 0 ? '+' : '') + pad(Math.max(d.min, 0), w); }
        }
        this.onData = null;
        this.sp = new Splitter();
        this.t = 0;
        this.swrRaw = 40; // ROS simulé (40 ≈ 1,4:1) ; un accord le ramène à 40
      }
      get split() { return this.ans['ST;'] !== 'ST0'; }
      write(str) {
        const out = [];
        const ftvs = () => {
          // FTX-1 réel : « émission sur MAIN » (FT0) pendant que le côté SUB est actif (VS1) → le TRX passe en émission
          if (spec.splitIsFT && !(this.txv || 0) && this.ans['VS;'] === 'VS1' && !this.tx) { this.tx = 2; this.keyedByFtVs = (this.keyedByFtVs || 0) + 1; }
        };
        if (this.kmNoSpace) str = String(str).replace(/KM[1-5][^;]* [^;]*;/g, 'XX;'); // essai : TRX qui refuse les espaces en mémoire
        for (const c of this.sp.push(str)) {
          ftvs();
          let m;
          if (spec.fakeFirst && spec.fakeCmd && spec.fakeCmd(this, c, out)) continue; // simulateur : commandes propres au modèle d'abord
          if (c === 'FA') out.push('FA' + pad(this.freq, FD) + ';');
          else if ((m = FA_RE.exec(c))) this.freq = parseInt(m[1], 10);
          else if (c === 'FB') out.push('FB' + pad(this.freqB, FD) + ';');
          else if ((m = FB_RE.exec(c))) this.freqB = parseInt(m[1], 10);
          else if (c === 'MD0') out.push('MD0' + this.mode + ';');
          else if (c === 'MD1') out.push('MD1' + this.modeB + ';');
          else if ((m = /^MD0([0-9A-Z])$/.exec(c)) && MODES_ALL[m[1]]) this.mode = m[1];
          else if ((m = /^MD1([0-9A-Z])$/.exec(c)) && MODES_ALL[m[1]]) this.modeB = m[1];
          else if (c === 'FR') out.push('FR' + (this.mainMute ? '1' : '0') + (this.single ? '1' : '0') + ';');
          else if ((m = /^FR([01])([01])$/.exec(c))) { this.mainMute = m[1] === '1'; this.single = m[2] === '1'; } // FTDX101 : 1er chiffre = MAIN coupé
          else if (c === 'SM1') { if (spec.fastSub && spec.fastSub.indexOf('SM1;') >= 0) out.push('SM1' + pad(this.single || this.tx ? 0 : Math.round(60 + 30 * Math.sin(this.t * 0.6)), 3) + ';'); /* FTX-1 réel : pas de réponse à SM1 */ }
          else if (c === 'RM2') out.push('RM2' + pad(this.single || this.tx ? 0 : Math.round(40 + 25 * Math.sin(this.t * 0.7)), 3) + (spec.rm3 ? '' : '000') + ';');
          else if (c === 'SM0') {
            this.t += 0.15;
            const v = this.tx ? 0 : Math.round(70 + 45 * Math.sin(this.t) + 20 * Math.random());
            out.push('SM0' + pad(Math.max(0, Math.min(255, v)), 3) + ';');
          } else if (c === 'TX') out.push('TX' + (this.cwTxHidden && this.cwPlay ? 0 : this.tx) + ';'); // essai : TX0 pendant le break-in
          else if (c === 'TX1') { this.tx1n = (this.tx1n || 0) + 1; if (!(this.loseTx1 && this.loseTx1(this.tx1n))) this.tx = 1; }
          else if (c === 'TX0') this.tx = 0;
          else if (c === 'FT') out.push('FT' + (spec.ID === 'ftdx101' ? (this.txv || 0) : spec.splitIsFT ? this.txv || 0 : this.split ? 1 : 0) + ';');
          // FTDX101 (simulateur) : FT lu en absolu (0 = MAIN, 1 = SUB), réglé par FT2 / FT3 ; FT0 / FT1 basculent l'émission ;
          // ST1 → émission sur le VFO non sélectionné ; ST0 → VFO d'émission inchangé
          else if (spec.ID === 'ftdx101' && /^ST[01]$/.test(c)) { if (c === 'ST1') this.txv = this.ans['VS;'] === 'VS1' ? 0 : 1; this.ans['ST;'] = c; }
          else if (spec.ID === 'ftdx101' && /^FT[23]$/.test(c)) this.txv = +c[2] - 2;
          else if (spec.ID === 'ftdx101' && /^FT[01]$/.test(c)) this.txv = (this.txv || 0) ^ 1;
          else if ((m = /^FT([0-3])$/.exec(c))) { if (this.ftMode === 'deaf') { /* essai : TRX qui ignore FT */ } else if (this.ftMode === 'x23' ? +m[1] >= 2 : +m[1] < 2) this.txv = +m[1] % 2; else if (this.ftMode === 'x23') out.push('?;'); }
          // FTX-1 (manuel CAT) : VS0 = MAIN en émission / réception, VS1 = SUB en émission / réception — VS déplace aussi l'émetteur
          else if (spec.splitIsFT && /^VS[01]$/.test(c)) { this.ans['VS;'] = c; this.txv = +c[2]; }
          else if (spec.splitIsFT && /^ST[0-2]$/.test(c)) { this.ans['ST;'] = c; if (c !== 'ST0') this.tx = 2; } // ST1 par CAT : le FTX-1 émet sur le SUB
          else if ((m = /^RM([3-8])$/.exec(c))) {
            const raw = m[1] === '8' ? (this.tx ? 205 : 212) : m[1] === '7' ? (this.tx ? Math.round(this.power * 0.6) : 0)
              : !this.tx ? 0 : { 3: 20, 4: 60, 5: this.silent ? 0 : Math.round(this.power * 2.4), 6: this.swrRaw }[m[1]];
            out.push('RM' + m[1] + pad(raw, 3) + (spec.rm3 ? '' : '000') + ';');
          } else if (c + ';' === P.read) out.push(P.fakeRead(this) + ';');
          else if (P.re.test(c)) { if (!P.fakeWrite(this, c)) out.push('?;'); }
          else if (c === 'SV') {
            [this.freq, this.freqB, this.mode, this.modeB] = [this.freqB, this.freq, this.modeB, this.mode];
          } else if (c === 'AB') { this.freqB = this.freq; this.modeB = this.mode; }
          else if (c === 'BA') { this.freq = this.freqB; this.mode = this.modeB; }
          else if (CONTROL.tune && c + ';' === CONTROL.tune.write()) {
            this.ans['AC;'] = spec.fakeTuning || 'AC001';
            this.swrRaw = 40;
            if (this.ans['RI0;'] != null) {
              this.ans['RI0;'] = 'RI00000100';
              setTimeout(() => { this.ans['RI0;'] = 'RI0' + (this.tuneFail ? '1' : '0') + '000000'; }, this.tuneMs || 2000);
            }
          }
          else if (c === 'AI0') { /* auto-information coupée */ }
          else if ((m = (spec.bandSideless ? /^BS()(\d\d)$/ : /^BS([01])(\d\d)$/).exec(c)) && BAND_CODES) {
            const b = Object.keys(BAND_CODES).find((k) => BAND_CODES[k][0] === m[2]);
            if (!b) out.push('?;');
            else if (m[1] === '1' || (spec.bandSideless && this.ans['VS;'] === 'VS1')) this.freqB = BAND_CODES[b][1];
            else this.freq = BAND_CODES[b][1];
          }
          // Manipulateur CW (simulateur) : vitesse, break-in, mémoires, lecture (émission « par le TRX », TX2)
          else if (spec.cw && (m = /^KS(\d{3})$/.exec(c))) this.cwWpm = +m[1];
          else if (spec.cw && /^BI[01]$/.test(c)) { this.bi = c === 'BI1'; if (this.ans['BI;'] != null) this.ans['BI;'] = c; if (!this.bi && this.cwPlay) { clearTimeout(this.cwPlay); this.cwPlay = null; this.tx = 0; } }
          // VC TUNE (FTDX101, simulateur) : VT P1 P2 [+/- pas] ; relu par VT0; / VT1; (P2, position 000-255, P6)
          else if ((m = /^VT([01])([01])(?:([+-])(\d))?$/.exec(c)) && this.ans['VT' + m[1] + ';'] != null) {
            const k = 'VT' + m[1] + ';';
            let lv = +this.ans[k].slice(4, 7) || 128;
            if (m[3]) lv = Math.max(0, Math.min(255, lv + (m[3] === '+' ? 1 : -1) * (+m[4]) * 2));
            this.ans[k] = 'VT' + m[1] + m[2] + String(lv).padStart(3, '0') + '1';
          }
          else if (spec.cw && /^KR[01]$/.test(c)) { this.kr = c === 'KR1'; if (this.ans['KR;'] != null) this.ans['KR;'] = c; } // simulateur : relu par KR;
          else if (spec.cw && /^EX02021[0][01]$/.test(c)) this.ans['EX020210;'] = c;
          else if (spec.cw && (m = /^KM([1-5])(.*)$/.exec(c))) { this.km = this.km || {}; if (m[2] === '') out.push('KM' + m[1] + (this.km[m[1]] || '') + ';'); else this.km[m[1]] = m[2]; }
          else if (spec.cw && /^KY/.test(c)) {
            const slot = c === spec.cw.play.slice(0, -1) ? spec.cw.mem.slice(2) : null;
            if (c === 'KY00') { if (this.cwPlay) { clearTimeout(this.cwPlay); this.cwPlay = null; this.tx = 0; } }
            else if (slot && this.km && this.km[slot] != null) {
              const t = this.km[slot];
              if (this.kyIgnore > 0) this.kyIgnore--; // essai : TRX qui ignore les premières lectures (constaté sur le FTX-1)
              else if (this.bi) {
                (this.cwLog = this.cwLog || []).push(t);
                const ms = Math.round(t.length * 10 * 1200 / (this.cwWpm || 22));
                clearTimeout(this.cwPlay);
                setTimeout(() => { this.tx = 2; }, 250);
                this.cwPlay = setTimeout(() => { this.tx = 0; this.cwPlay = null; }, 250 + ms);
              }
            } else out.push('?;');
          }
          else if (spec.fakeCmd && spec.fakeCmd(this, c, out)) { /* commande propre au modèle (simulateur) */ }
          else if ((m = /^EX(\d{6})([+-]?\d+)$/.exec(c)) && this.ans['EX' + m[1] + ';'] != null) { this.ans['EX' + m[1] + ';'] = c; (this.exLog = this.exLog || []).push(c + (this.tx ? '@TX' : '')); }
          else if (this.ans[c + ';'] != null) out.push(this.ans[c + ';'] + ';');
          else {
            const r = READS.find((x) => !x.power && x.re.test(c));
            if (r) this.ans[r.cmd] = c;
            else out.push('?;');
          }
        }
        ftvs();
        if (out.length && this.onData) {
          const s = out.join('');
          setTimeout(() => this.onData && this.onData(s), 5);
        }
      }
    }

    return {
      ID, NAME, MODES: MODES_ALL, SETTABLE: MSET, MODE_KEYS: MKEYS, FREQ_MIN, FREQ_MAX, FREQ_DIGITS: FD,
      POWER_RANGE: P.range, POWER_STEP: P.step, MENU: spec.menu || null, HEAD_NAMES: spec.headNames || null, BAND_SIDELESS: !!spec.bandSideless, INIT: (spec.splitIsFT ? 'AI0;ST0;' : 'AI0;') + (spec.initExtra || ''), UNKEY_EXTRA: spec.splitIsFT ? 'ST0;' : '',
      // SPLIT « virtuel » (FTX-1) : le VFO d'émission n'est envoyé au TRX qu'au moment d'émettre (FT), puis remis
      // Lectures CAT autorisées depuis la console de diagnostic (administrateurs) : lectures seulement
      CAT_QUERIES: Array.from(new Set(READS.map((r) => r.cmd).concat(FAST, FAST_SUB, TXMETERS, ['IF;', 'OI;', 'FR;', 'ID;', 'VS;', 'FT;', 'ST;', 'FA;', 'FB;'], spec.extraQueries || []))).filter((c) => !(spec.readOverrides && spec.readOverrides[c] === null && c === 'ST;')),
      VIRTUAL_SPLIT: !!spec.virtualSplit, SPLIT_SWAP: !!spec.splitSwap, cmdTxVfo: spec.virtualSplit ? (v) => 'FT' + (v ? 1 : 0) + ';' : null,
      // Façons de désigner le VFO d'émission, essayées dans l'ordre jusqu'à ce que « FT; » relu le confirme
      // (FT0/FT1 comme Hamlib ; FT2/FT3 comme les FTDX10 / FT-991). Jamais VS1 avant FT1 : FT0 avec VS1 fait émettre le FTX-1.
      txVfoTries: spec.virtualSplit ? (v) => ['FT' + (v ? 1 : 0) + ';', 'FT' + (v ? 3 : 2) + ';'] : null,
      cmdVfoSel: (v) => 'VS' + (v ? 1 : 0) + ';', // FTX-1 : sortir d'un éventuel ST1 (SUB bloqué en émission)
      FAST, FAST_SUB, SLOW, TXMETERS, POLL: FAST, READS, STATE_KEYS, readOk,
      FRAME_GAP_MS: 20, SLOW_PER_TICK: 4, POLL_MS: 250, readFor,
      widthTableFn: widthTable,
      derive: spec.derive || null, preampText: spec.preampText || null, SUB_BADGES: !!spec.subBadges, WIDTH_DEF: !!spec.widthDefault, remapRead: spec.remapRead || null,
      // Émission CW par le manipulateur du TRX : texte écrit dans une mémoire du manipulateur (KM), puis lu (KY),
      // break-in en service (BI1) pour que le TRX émette tout seul ; arrêt : fin de lecture et break-in coupé
      // Commandes envoyées une à une (un refus « ? » est ainsi attribué à la bonne commande)
      // Phonie à distance : la voix arrive par l'entrée USB du TRX. Juste avant l'émission, le menu « MOD SOURCE » du
      // mode est relu, mis sur USB (REAR + REAR SELECT USB sur FTDX10 / FTDX101), puis remis comme avant au retour en
      // réception (le micro du club refonctionne). spec.voice : { MODE: [[menu EX à 6 chiffres, valeur USB], …] }
      // Égaliseur paramétrique du TRX (menus « PRMTRC EQ1 à EQ3 », puis « P PRMTRC » = avec PROC) : 2 jeux × 3 bandes ×
      // (fréquence, niveau, largeur), soit 18 menus EX consécutifs. Profil : { n: [{ f, l, w } ×3], p: [{ f, l, w } ×3] },
      // f = rang de la fréquence (0 = bande coupée), l = niveau (dB), w = largeur.
      TRX_EQ: spec.trxEq ? (() => {
        const E = spec.trxEq;
        const FREQS = [[100, 200, 300, 400, 500, 600, 700], [700, 800, 900, 1000, 1100, 1200, 1300, 1400, 1500],
          [1500, 1600, 1700, 1800, 1900, 2000, 2100, 2200, 2300, 2400, 2500, 2600, 2700, 2800, 2900, 3000, 3100, 3200]];
        const idOf = (set, band, k) => E.menu + pad(E.first + set * 9 + band * 3 + k, 2);
        const ids = [];
        for (let s = 0; s < 2; s++) for (let b = 0; b < 3; b++) for (let k = 0; k < 3; k++) ids.push(idOf(s, b, k));
        const lv = (v) => (v < 0 ? '-' : '+') + pad(Math.abs(v), 2);
        const clean = (pr) => {
          if (!pr || typeof pr !== 'object') return null;
          const one = (x, b) => {
            const f = Math.round(Number(x && x.f));
            const l = Math.round(Number(x && x.l));
            const w = Math.round(Number(x && x.w));
            return { f: f >= 0 && f <= FREQS[b].length ? f : 0, l: Number.isFinite(l) ? Math.max(E.lvl[0], Math.min(E.lvl[1], l)) : 0,
              w: Number.isFinite(w) ? Math.max(E.bw[0], Math.min(E.bw[1], w)) : Math.max(E.bw[0], 5) };
          };
          const set = (a) => [0, 1, 2].map((b) => one(Array.isArray(a) ? a[b] : null, b));
          return { n: set(pr.n), p: set(pr.p) };
        };
        return {
          FREQS, LVL: E.lvl.slice(), BW: E.bw.slice(), ids,
          read: ids.map((i) => 'EX' + i + ';'),
          // Réponses { 'menu': 'valeur' } → profil (null s'il en manque)
          fromValues(vals) {
            const pr = { n: [], p: [] };
            for (let s = 0; s < 2; s++) {
              for (let b = 0; b < 3; b++) {
                const g = [0, 1, 2].map((k) => vals[idOf(s, b, k)]);
                if (g.some((x) => x == null || !/^[+-]?\d+$/.test(x))) return null;
                (s ? pr.p : pr.n).push({ f: parseInt(g[0], 10), l: parseInt(g[1], 10), w: parseInt(g[2], 10) });
              }
            }
            return clean(pr);
          },
          write(pr) {
            const c = clean(pr);
            if (!c) return null;
            const out = [];
            for (let s = 0; s < 2; s++) (s ? c.p : c.n).forEach((x, b) => {
              out.push('EX' + idOf(s, b, 0) + pad(x.f, 2) + ';', 'EX' + idOf(s, b, 1) + lv(x.l) + ';', 'EX' + idOf(s, b, 2) + pad(x.w, 2) + ';');
            });
            return out;
          },
          clean,
          // Commande d'écriture acceptée par le serveur (seulement ces 18 menus, valeurs dans les plages)
          okWrite(cmd) {
            const m = /^EX(\d{6})([+-]?\d{2,3});$/.exec(String(cmd));
            return !!m && ids.indexOf(m[1]) >= 0;
          }
        };
      })() : null,
      VOICE: spec.voice ? {
        modes: Object.keys(spec.voice),
        steps(mode) {
          const list = spec.voice[mode];
          if (!list) return null;
          return list.map(([id, v]) => {
            const re = new RegExp('^EX' + id + '(\\d)$');
            return { label: 'EX' + id, read: 'EX' + id + ';', match: (t) => { const mm = typeof t === 'string' ? re.exec(t) : null; return mm ? mm[1] : null; },
              set: 'EX' + id + v + ';', restore: (p) => 'EX' + id + p + ';' };
          });
        }
      } : null,
      CW: spec.cw ? {
        max: 50,
        wpmMax: 60, // KS 004–060
        setup: (wpm) => (spec.cw.pre || []).concat(['KS' + pad(Math.max(4, Math.min(60, wpm)), 3) + ';', 'KR1;', 'BI1;']),
        mem: (t) => spec.cw.mem + t + ';',
        read: spec.cw.mem + ';', readRe: new RegExp('^' + spec.cw.mem),
        play: spec.cw.play, alt: spec.cw.alt || [],
        stop: () => spec.cw.stop.match(/[^;]+;/g),
        dtr: spec.cw.dtr || null,
        txPoll: ['TX;', 'RM5;'], poRe: /^RM5(\d{3})/,
        pre: spec.cw.pre || []
      } : null,
      GROUPS: [['vfo', 'VFO et SPLIT'], ['flt', 'Filtres et DSP'], ['rx', 'Réception'], ['tx', 'Émission']],
      CONTROLS, CONTROL, validate, widthTable, cmdFreq, cmdFreqB, cmdMode, cmdPower, cmdPtt, parse, Splitter,
      BAND_CODES, cmdBand: BAND_CODES ? cmdBand : null,
      smeterLabel, swrValue, vdValue, idValue, Fake, FakeFTX1: Fake,
      serial: spec.serial, hint: spec.hint
    };
  }

  const api = { build, pad, signed4, sgn, WIDTH_SSB, WIDTH_NARROW, NARROW_MODES };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.YAESU = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
